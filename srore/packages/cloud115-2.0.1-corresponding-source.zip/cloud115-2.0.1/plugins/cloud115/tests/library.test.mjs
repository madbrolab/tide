import {readFileSync} from 'node:fs';
import {createHash,createHmac,randomBytes} from 'node:crypto';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
const sdk=await import(new URL('../main.js',import.meta.url));
const digest=vm.runInNewContext(readFileSync(new URL('../src/digests.js',import.meta.url),'utf8')+';({newDigest,digestUpdate,digestEnd})',{hexByte:v=>(v&255).toString(16).padStart(2,'0'),connectorError:message=>Error(message)});
test('incremental SHA1/SHA256/MD5 across block and continuation boundaries',()=>{
  for(const alg of ['sha1','sha256','md5'])for(const length of [0,1,55,56,63,64,65,127,128,129,100003]){
    const data=randomBytes(length);let s=digest.newDigest(alg);
    for(let offset=0;offset<length;offset+=79){digest.digestUpdate(s,data.subarray(offset,offset+79));s=JSON.parse(JSON.stringify(s));}
    assert.equal(digest.digestEnd(s),createHash(alg).update(data).digest('hex'),alg+' '+length);
  }
});
test('MD4 published test vectors',()=>{
  for(const [text,expected] of [['','31d6cfe0d16ae931b73c59d7e0c089c0'],['a','bde52cb31de33e46245e05fbdbd6fb24'],['abc','a448017aaf21d8525fc10ae87aa6729d'],['message digest','d9130a8164549fe818874806e1c7014b']]){
    const s=digest.newDigest('md4');digest.digestUpdate(s,Buffer.from(text));assert.equal(digest.digestEnd(s),expected);
  }
});
function fakeContext(handler){return {remaining:()=>30000,connection:async()=>({kind:'cookie'}),http:{request:async req=>({status:200,body:JSON.stringify(await handler(new URL(req.url),req))})}};}
test('archive direct links preserve client selection, path metadata and URL escaping',async()=>{
  for(const app of [undefined,'android','web','desktop','ios']){
    const ctx=fakeContext((url,req)=>{
      assert.equal(url.pathname,['web','desktop'].includes(app)?'/files/extract_down_file':'/'+(app??'android')+'/2.0/ufile/extract_down_file');
      assert.equal(url.searchParams.get('full_name'),'folder/中文.txt');assert.equal(req.headers['User-Agent'],'fixture');
      return {state:true,data:{url:'https://cdn.115.com/中文 !@+$;,(x).txt?q=%2F&n=1#x'}};
    });
    const r=await sdk['extract-download-url'](ctx,{pickcode:'fixture',path:'/folder/中文.txt/',user_agent:'fixture',...(app?{app}:{})});
    assert.equal(r.url,'https://cdn.115.com/%E4%B8%AD%E6%96%87%20%21%40%2B%24%3B%2C%28x%29.txt?q=%2F&n=1#x');
    assert.equal(r.path,'/folder/中文.txt');assert.equal(r.name,'中文.txt');assert.deepEqual(r.headers,{'user-agent':'fixture'});
  }
  await assert.rejects(sdk['extract-download-url'](fakeContext(()=>({state:true,data:null})),{pickcode:'fixture',path:'/folder/'}),{code:'not_found'});
});
test('export parser continues through split Unicode names and multiline records',async()=>{
  const text='|——根目录\n| |-目录\n| | |-电影😀.mkv\n| |-a/b\n换行\n';
  for(const format of ['path','patht','dict','depth-name']){
    const action=sdk['export-parse-'+format],expected=await action({},{text}),items=[];let cursor;
    for(let i=0;i<text.length;i++){
      const r=await action({},{text:text[i],cursor,final:i===text.length-1});items.push(...r.items);cursor=r.cursor;
    }
    assert.deepEqual(items,expected.items);assert.equal(cursor,null);
  }
});
test('export parsing accepts existing file IDs without creating or polling an export',async()=>{
  const fileId='1152921504606846976',body=Buffer.from('|——根目录\n| |-test.txt\n','utf16le');let reads=0;
  const source=['pickcodes.js','composition.js','library-workflows.js'].map(f=>readFileSync(new URL('../src/'+f,import.meta.url),'utf8')).join('\n');
  const run=vm.runInNewContext(source+';exportWorkflow',{
    connectorError:message=>Error(message),remoteId:String,
    entryById:async(_,id)=>{assert.equal(id,fileId);return {id,size:body.length}},entryURL:async()=>({url:'https://cdn.115.com/tree.txt',headers:{}})
  });
  const ctx={net:{request:async req=>{reads++;assert.equal(req.headers.Range,'bytes=0-'+(body.length-1));return {status:206,body}}}};
  for(const args of [{export_id:fileId},{file_id:fileId}]){
    const r=await run(ctx,args,'parse');assert.deepEqual(JSON.parse(JSON.stringify(r.items)),['/','/test.txt']);assert.equal(r.complete,true);
  }
  assert.equal(reads,2);
});
test('share lookup stays in share scope and large IDs retain precision',async()=>{
  let calls=0;const ctx=fakeContext(url=>{calls++;assert.equal(url.pathname,'/share/snap');return {state:true,data:{count:1,list:[{fid:'9007199254740993',cid:'0',n:'a.txt',sha:'ABCD',s:'3'}]}};});
  assert.equal(await sdk['vfs-get-id'](ctx,{id:'9007199254740993',scope:{kind:'share',share_code:'abc',receive_code:'1234'}}),'9007199254740993');assert.equal(calls,1);
});
test('tree continuation consumes every page exactly once',async()=>{
  const ctx=fakeContext(url=>{assert.equal(url.pathname,'/files');const cid=url.searchParams.get('cid'),offset=Number(url.searchParams.get('offset')),limit=Number(url.searchParams.get('limit'));
    const items=cid==='0'?[{cid:'1',pid:'0',n:'dir'},{fid:'2',cid:'0',n:'a',sha:'A',s:'1'}]:[{fid:'3',cid:'1',n:'b',sha:'B',s:'1'}];return {state:true,count:items.length,data:items.slice(offset,offset+limit)};});
  const items=[];let cursor;do{const r=await sdk['vfs-iter'](ctx,{id:'0',limit:1,...(cursor?{cursor}:{})});items.push(...r.items);cursor=r.cursor;}while(cursor);
  assert.deepEqual(items.map(n=>n.id),['1','2','3']);assert.deepEqual(items.map(n=>n.path),['/dir','/a','/dir/b']);
});
test('missing versus denied file is preserved by exists',async()=>{
  const make=errno=>fakeContext(()=>({state:false,errno}));assert.equal(await sdk['vfs-exists'](make(50015),{id:'99'}),false);
  await assert.rejects(sdk['vfs-exists'](make(99),{id:'99'}),{code:'forbidden'});
});
test('escaped dot components and name arrays stay literal',async()=>{
  const ctx=fakeContext(url=>{assert.equal(url.pathname,'/files');return {state:true,count:1,data:[{fid:'7',cid:'0',n:'..',sha:'A',s:'1'}]};});
  assert.equal(await sdk['vfs-get-id'](ctx,{path:'/\\..'}),'7');
  assert.equal(await sdk['vfs-get-id'](ctx,{path:['..']}),'7');
});
test('directory pagination uses the advertised cursor',async()=>{
  const offsets=[];const ctx=fakeContext(url=>{const offset=Number(url.searchParams.get('offset'));offsets.push(offset);return {state:true,count:2,data:[{fid:String(offset+1),cid:'0',n:'x',sha:'A',s:1}]};});
  const first=await sdk['vfs-iterdir'](ctx,{id:0,limit:1});const second=await sdk['vfs-iterdir'](ctx,{id:0,limit:1,cursor:first.cursor});
  assert.deepEqual(offsets,[0,1]);assert.equal(second.complete,true);assert.equal(second.items[0].id,'2');
});
test('life detail continuation neither refetches groups nor duplicates events',async()=>{
  let list=0,detail=0,remaining=30000;
  const ctx=fakeContext(url=>{
    if(url.pathname.endsWith('/life_list')){list++;remaining=100;return {state:true,data:{list:[{behavior_type:'upload_file',date:'2023-11-15',total:2,items:[{id:'1',update_time:11}]}]}};}
    detail++;return {state:true,data:{next_page:false,list:[{id:'1',update_time:11},{id:'2',update_time:12}]}};
  });ctx.remaining=()=>remaining;
  const a={start_time:10,end_time:20};const first=await sdk['tool-life-list'](ctx,a);remaining=30000;
  const second=await sdk['tool-life-list'](ctx,{...a,cursor:first.cursor});
  assert.equal(list,1);assert.equal(detail,1);assert.deepEqual([...first.items,...second.items].map(n=>n.id),['1','2']);assert.equal(second.complete,true);
});
test('multipart checkpoints bind account/source, sign list parts correctly and require all parts',async()=>{
  const file=randomBytes(102410),parts=new Map(),checkpoints=new Map();let account='123',stamp='stamp1',serial=0,commits=0;
  const ctx={runId:'upload-fixture',remaining:()=>30000,connection:async()=>({kind:'bearer'}),
    fs:{sourceInfo:async()=>({size:file.length,stamp}),sourceSHA1:async()=>createHash('sha1').update(file).digest('hex'),hashRange:async(_,o,n,alg)=>createHash(alg).update(file.subarray(o,o+n)).digest('hex')},
    crypto:{hmacSHA1:async(k,s)=>createHmac('sha1',k).update(s).digest('hex')},
    secrets:{seal:async(p,s)=>{assert.ok(Buffer.byteLength(s)<=65536);return Buffer.from(p+'\n'+s).toString('base64')},open:async(p,s)=>{const v=Buffer.from(s,'base64').toString();assert.ok(v.startsWith(p+'\n'));return v.slice(p.length+1)}},
    db:{exec:async(sql,p)=>{if(sql.startsWith('INSERT INTO checkpoints'))checkpoints.set(p[0]+':'+p[1],p[3]);return 1},query:async(sql,p)=>[{value:checkpoints.get(p[0]+':'+p[1])}]},
    http:{request:async req=>{
      const url=new URL(req.url);let result;
      if(url.pathname==='/open/user/info')result={state:true,data:{user_id:account}};
      else if(url.pathname==='/open/upload/init')result={state:true,data:{status:1,bucket:'fhnfile',object:'test/object',pickcode:'pc',callback:{callback:'{}',callback_var:'{}'}}};
      else if(url.pathname==='/open/upload/get_token')result={state:true,data:{AccessKeyId:'key',AccessKeySecret:'secret',SecurityToken:'token'}};
      else if(url.host==='fhnfile.oss-cn-shenzhen.aliyuncs.com'){
        const q=[...url.searchParams].filter(([k])=>!['max-parts','part-number-marker'].includes(k)).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>encodeURIComponent(k)+'='+encodeURIComponent(v)).join('&');
        const signedHeaders=Object.keys(req.headers).filter(k=>k.startsWith('x-oss-')).sort().map(k=>k+':'+req.headers[k]).join('\n');
        const sign=[req.method,'',req.headers['content-type']??'',req.headers.date,signedHeaders,'/fhnfile'+url.pathname+(q?'?'+q:'')].join('\n');
        assert.equal(req.headers.authorization,'OSS key:'+createHmac('sha1','secret').update(sign).digest('base64'));
        if(url.searchParams.has('uploads'))return {status:200,body:'<UploadId>fixture</UploadId>'};
        if(req.method==='GET')return {status:200,body:'<ListPartsResult>'+[...parts].map(([number,p])=>`<Part><PartNumber>${number}</PartNumber><Size>${p.size}</Size><ETag>${p.etag}</ETag></Part>`).join('')+'<IsTruncated>false</IsTruncated></ListPartsResult>'};
        if(req.method==='PUT'){const {offset,length}=req.sourceRange,etag='"'+createHash('md5').update(file.subarray(offset,offset+length)).digest('hex')+'"';parts.set(Number(url.searchParams.get('partNumber')),{size:length,etag});return {status:200,body:'',etag};}
        if(req.method==='POST'){commits++;result={state:true,data:{file_id:'777'}};}
      }
      assert.ok(result,'unexpected request '+req.url);return {status:200,body:JSON.stringify(result)};
    }} };
  let r=await sdk['multipart-init'](ctx,{filename:'test.bin',partSize:102400});
  await assert.rejects(sdk['multipart-complete'](ctx,{state:r.state}),{code:'conflict'});
  account='456';await assert.rejects(sdk['multipart-step'](ctx,{state:r.state}),{code:'invalid_input'});account='123';
  stamp='changed';await assert.rejects(sdk['multipart-step'](ctx,{state:r.state}),{code:'conflict'});stamp='stamp1';
  r=await sdk['multipart-step'](ctx,{state:r.state});assert.equal(r.uploaded,102400);
  r=await sdk['multipart-step'](ctx,{state:r.state});assert.equal(r.uploaded,file.length);
  r=await sdk['multipart-complete'](ctx,{state:r.state});assert.equal(r.complete,true);assert.equal(commits,1);
});
