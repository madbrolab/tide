const te = "https://webapi.115.com", De = "https://proapi.115.com/open", Z = "36.2.28", ai = "Mozilla/5.0 115disk/" + Z + " 115Browser/" + Z + " 115wangpan_android/" + Z, je = "fb1a19d652f5aaf7bc651d0f69bf422f", Ie = "69bf422f49960550a0ad44ec3446cb4c";
function qe(i) {
  return encodeURIComponent(String(i)).replace(
    /[!'()*]/g,
    (e) => "%" + e.charCodeAt(0).toString(16).toUpperCase()
  ).replace(/%20/g, "+");
}
function Ue(i) {
  return Object.keys(i).sort().map((e) => qe(e) + "=" + qe(i[e])).join("&");
}
function ni(i) {
  try {
    const e = j(i);
    if (e && typeof e == "object" && !Array.isArray(e))
      return e;
  } catch {
  }
  throw Error("115 响应格式无效");
}
async function Xe(i, e, t = {}) {
  const r = await i.http.request({ url: e, credential: !0, ...t });
  if (r.status === 401 || r.status === 403)
    return { state: !1, errno: r.status };
  if (r.status < 200 || r.status >= 300)
    throw y("115 HTTP " + r.status, "upstream");
  return t.response === "hex" ? r.body : ni(r.body);
}
function V(i) {
  return i.state === !1 || i.state === 0 || i.state === "0";
}
function St(i) {
  const e = Number(i.errno ?? i.errNo ?? i.errcode ?? i.errCode ?? i.code ?? i.msg_code ?? i.status);
  return Number.isSafeInteger(e) ? e : 0;
}
function T(i) {
  if (!i || typeof i != "object" || Array.isArray(i)) throw y("115 响应不是对象", "upstream");
  if (V(i)) {
    const e = St(i), t = [10014, 20009, 20013, 20018, 31001, 31003, 31004, 50003, 50015, 70005, 70008, 90008, 231011, 430004, 800001].includes(e) ? "not_found" : [99, 911, 401, 403, 50038, 51011, 990001, 40140125].includes(e) ? "forbidden" : [1001, 10004, 20001, 20002, 20003, 20020, 20021, 320001, 990002].includes(e) ? "invalid_input" : e === 20004 ? "conflict" : [51012, 590075].includes(e) ? "busy" : "upstream";
    throw Object.assign(y("115 拒绝请求（" + e + "）", t), { upstreamCode: e });
  }
  return i;
}
function D(i) {
  return (i & 255).toString(16).padStart(2, "0");
}
function ne(i) {
  return (i.match(/../g) || []).map((e) => parseInt(e, 16));
}
function Xt(i) {
  return [i, i >>> 8, i >>> 16, i >>> 24].map(D).join("");
}
function pe(i) {
  const e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let t = "";
  for (let r = 0; r < i.length; r += 3) {
    const a = i[r] << 16 | (i[r + 1] || 0) << 8 | (i[r + 2] || 0);
    t += e[a >> 18 & 63] + e[a >> 12 & 63] + (r + 1 < i.length ? e[a >> 6 & 63] : "=") + (r + 2 < i.length ? e[a & 63] : "=");
  }
  return t;
}
function Nt(i) {
  const e = "1d030e80a178dceececda377de128d8ed9ddcf55ae61ed46ea121a1cfc81", t = e.slice(0, 30) + "0073000000" + Xt(i) + e.slice(30) + "0001000000";
  let r = -1;
  for (const a of [
    ...Array.from("^j>WD3Kr?J2gLFjD4W2y@", (o) => o.charCodeAt(0)),
    ...ne(t)
  ]) {
    r ^= a;
    for (let o = 0; o < 8; o++) r = r >>> 1 ^ (r & 1 ? 3988292384 : 0);
  }
  return pe(ne(t + Xt(~r)));
}
function jt(i) {
  const e = ne(i), t = [], r = e[e.length - 1];
  r > 0 && r < 16 && e.slice(-r).every((o) => o === r) && (e.length -= r);
  const a = () => {
    throw Error("秒传响应压缩格式无效");
  };
  for (let o = 0; o + 2 <= e.length; ) {
    let u = function(_) {
      if (_ === 15) {
        let m;
        do
          o >= s && a(), m = e[o++], _ += m;
        while (m === 255);
      }
      return _;
    };
    const n = e[o] | e[o + 1] << 8;
    if (o += 2, !n) break;
    const s = o + n, d = t.length;
    for (s > e.length && a(); o < s; ) {
      const _ = e[o++], m = u(_ >> 4);
      (o + m > s || t.length - d + m > 8192) && a();
      for (let x = 0; x < m; x++) t.push(e[o++]);
      if (o === s) break;
      o + 2 > s && a();
      const w = e[o] | e[o + 1] << 8;
      o += 2;
      const g = 4 + u(_ & 15);
      (!w || w > t.length - d || t.length - d + g > 8192) && a();
      for (let x = 0; x < g; x++)
        t.push(t[t.length - w]);
    }
    t.length > 262144 && a();
  }
  return ni(
    decodeURIComponent(t.map((o) => "%" + D(o)).join(""))
  );
}
async function It(i, e, t, r) {
  const a = String(t.user_id), o = e.sha1.toUpperCase(), n = "U_1_" + e.remoteDir, s = Math.floor(Date.now() / 1e3), d = async (Q) => await i.crypto.digest("sha1", Q), u = async (Q) => await i.crypto.digest("md5", Q), _ = r.sign_key || "", m = r.sign_val || "", w = (await d(
    t.userkey + await d(a + o + n + "0") + "000000"
  )).toUpperCase(), g = await u(
    "Qclm8MGWUv59TnrR0XPg" + o + e.sizeBytes + _ + m + a + s + await u(a) + Z
  ), x = {
    appversion: Z,
    fileid: o,
    filename: e.filename,
    target: n,
    topupload: "true",
    userid: a,
    userkey: t.userkey,
    t: s,
    sig: w,
    token: g
  };
  e.sizeBytes && (x.filesize = e.sizeBytes), e.dirname && (x.path = e.dirname), _ && (x.sign_key = _, x.sign_val = m);
  const k = Ue(x), q = (16 - k.length % 16) % 16, ae = Array.from(k, (Q) => D(Q.charCodeAt(0))).join("") + D(q).repeat(q), $ = await Xe(
    i,
    "https://uplb.115.com/4.0/initupload.php?k_ec=" + qe(Nt(s)),
    {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": ai
      },
      bodyHex: await i.crypto.aesCBC("encrypt", je, Ie, ae),
      response: "hex"
    }
  );
  return typeof $ != "string" ? $ : jt(await i.crypto.aesCBC("decrypt", je, Ie, $));
}
async function Ki(i, e) {
  const t = await i.connection();
  if (typeof e.filename != "string" || !e.filename || !Number.isSafeInteger(e.sizeBytes) || e.sizeBytes < 0 || !/^[a-fA-F0-9]{40}$/.test(e.sha1 ?? "")) throw Error("需要文件名、字节数和 SHA-1");
  e = { ...e, remoteDir: N(e.remoteDir ?? "0"), mode: t.kind === "cookie" ? "cookie" : "open", hasSource: t.hasSource };
  let r;
  if (e.mode === "cookie") {
    if (r = await Xe(i, te + "/files/uploadinfo"), V(r))
      return { outcome: "rejected", reason: "115 错误 " + St(r) };
    if (!r.userkey || !/^\d+$/.test(String(r.user_id)))
      throw Error("上传账号信息无效");
  }
  const a = {};
  for (let o = 0; o < 2; o++) {
    let n;
    if (r) n = await It(i, e, r, a);
    else {
      const _ = await Xe(i, De + "/upload/init", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: Ue({
          file_name: e.filename,
          fileid: e.sha1.toUpperCase(),
          file_size: e.sizeBytes,
          target: "U_1_" + e.remoteDir,
          path: e.dirname ?? "",
          topupload: 1,
          ...a
        })
      });
      n = V(_) ? _ : _.data;
    }
    if (!n) throw Error("秒传响应无效");
    if (V(n))
      return { outcome: "rejected", reason: "115 错误 " + St(n) };
    if (n.status === 2 || n.status === 1)
      return {
        outcome: n.status === 2 ? "reused" : "not_reused",
        data: n
      };
    if (n.status !== 7) throw Error("秒传状态未确认");
    if (!e.hasSource) return { outcome: "needs_source" };
    const s = /^(?:bytes=)?(\d+)-(\d+)$/.exec(n.sign_check);
    if (o !== 0 || !s || !n.sign_key) throw Error("秒传区间挑战无效");
    const d = Number(s[1]), u = Number(s[2]);
    if (!Number.isSafeInteger(d) || !Number.isSafeInteger(u) || u < d)
      throw Error("秒传校验区间无效");
    a.sign_key = n.sign_key, a.sign_val = (await i.fs.hashRange("@source", d, u - d + 1, "sha1")).toUpperCase();
  }
}
function Ye(i) {
  return new Date(Date.now() + (8 + i * 24) * 36e5).toISOString().slice(0, 10);
}
function y(i, e = "invalid_input") {
  return Object.assign(new Error(i), { code: e, retryable: ["busy", "timeout", "unavailable", "upstream"].includes(e) });
}
function b(i, e, t) {
  return Object.hasOwn(i, e) ? i[e] : t;
}
function de(i, e, t = null) {
  return b(i, e, t);
}
function c(i, e, t = null) {
  return Object.hasOwn(i, e) || (i[e] = t), i[e];
}
function S(i, e) {
  if (!Object.hasOwn(i, e)) throw Error("缺少协议字段 " + e);
  return i[e];
}
function li(i) {
  return typeof i == "object" && i !== null ? Object.keys(i).length : i.length;
}
function z(i) {
  return i && (typeof i != "object" || li(i) > 0);
}
function be(i, e) {
  return typeof i == "string" || Array.isArray(i) ? i.includes(e) : Object.hasOwn(i, e);
}
function Yt(i, e) {
  return (Array.isArray(e) ? e : [e]).some(
    (t) => i.startsWith(t)
  );
}
function Vi(i, e) {
  if (e === void 0) return i.trimStart();
  let t = 0;
  for (; t < i.length && e.includes(i[t]); ) t++;
  return i.slice(t);
}
function He(i, e) {
  if (e === void 0) return i.trimEnd();
  let t = i.length;
  for (; t && e.includes(i[t - 1]); ) t--;
  return i.slice(0, t);
}
function Zt(i, e) {
  return He(Vi(i, e), e);
}
function P(i) {
  const e = Number(i);
  if (!Number.isFinite(e)) throw Error("无效整数");
  return Math.trunc(e);
}
async function si(i, e) {
  if (!e) return "670b14728ad9902aecba32e22fa4f6bd";
  const t = String(e);
  return t.length === 32 ? t : await i.crypto.digest("md5", t.padStart(6, "0"));
}
function p(i, e, t) {
  for (const a of Object.keys(i))
    if (!(t && a === "payload") && !e.includes(a))
      throw Error("未知方法参数 " + a);
  const r = b(i, "payload", {});
  if (r === null || typeof r != "object" || Array.isArray(r))
    throw Error("payload 应为协议字段对象");
  for (const [a, o] of Object.entries(r)) {
    if (!/^[a-zA-Z0-9_][a-zA-Z0-9_.\[\]-]{0,120}$/.test(a) || /^(?:__proto__|constructor|prototype|ac|ct|action|method|_method|callback|base_url|headers|url_override)(?:\[|$)/i.test(
      a
    ))
      throw Error("受保护的协议字段");
    if (typeof o != "string" && !(typeof o == "number" && Number.isSafeInteger(o)) && typeof o != "boolean")
      throw Error("协议字段应为字符串、安全整数或布尔值；长文件 ID 使用字符串");
  }
  return { ...r };
}
function H(i) {
  return (Array.isArray(i) ? i : Object.entries(i)).map(
    ([e, t]) => qe(e) + "=" + qe(t === !0 ? "True" : t === !1 ? "False" : t)
  ).join("&");
}
function j(i) {
  const e = i.replace(
    /"(?:\\[\s\S]|[^"\\])*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g,
    (t) => t[0] === '"' || /[.eE]/.test(t) || Number.isSafeInteger(Number(t)) ? t : '"' + t + '"'
  );
  return JSON.parse(e);
}
function J(i, e, t, r, a, o = !1) {
  return l(i, e, t, r, a, o, !1);
}
async function l(i, e, t, r, a, o = !1, n = !0) {
  if (r !== null) {
    c(r, "app_ver", Z);
    const _ = H(r);
    _ && (e += (e.includes("?") ? "&" : "?") + _);
  }
  const s = {
    url: e,
    method: t,
    credential: n,
    originReferer: !0,
    headers: { "User-Agent": "Mozilla/5.0" }
  };
  a !== null && (s.headers["Content-Type"] = o ? "application/json" : "application/x-www-form-urlencoded", s.body = o ? JSON.stringify(a) : H(a));
  const d = await i.http.request(s);
  if (d.status < 200 || d.status >= 300) throw y("115 HTTP " + d.status, "upstream");
  const u = j(d.body);
  if (u === null || typeof u != "object" || Array.isArray(u))
    throw Error("115 响应类型不匹配");
  return u;
}
function A(i, e, t, r) {
  return r.ac = e, l(
    i,
    "https://clouddownload.115.com/web/",
    t,
    t === "GET" ? r : null,
    t === "GET" ? null : r
  );
}
const Xi = [
  "web",
  "desktop",
  "chrome",
  "aps",
  "android",
  "115android",
  "ios",
  "115ios",
  "115ipad",
  "ipad",
  "harmony",
  "windows",
  "mac",
  "linux",
  "os_windows",
  "os_mac",
  "os_linux",
  "tv",
  "wechatmini",
  "alipaymini"
];
function h(i, e, t) {
  const r = b(i, "app", e);
  if (!Xi.includes(r) && r !== e)
    throw Error("未知客户端 app");
  return t ? ["windows", "mac", "linux"].includes(r) ? "os_" + r : [
    "ios",
    "115ios",
    "115ipad",
    "android",
    "115android",
    "harmony",
    "os_windows",
    "os_mac",
    "os_linux"
  ].includes(r) ? r : r.endsWith("ios") ? "ios" : r.endsWith("ipad") ? "115ipad" : "android" : r;
}
function pi(i, e, t) {
  return S(t, h(i, e, !1));
}
async function v(i, e) {
  return Ei(e.userId ?? T(await Le(i, {})).user_id);
}
function Ut(i) {
  const e = i.runId;
  return e.slice(0, 8) + "-" + e.slice(8, 12) + "-4" + e.slice(13, 16) + "-" + (parseInt(e[16], 16) & 3 | 8).toString(16) + e.slice(17, 20) + "-" + e.slice(20);
}
async function tt(i, e, t, r, a, o) {
  r !== null && (c(r, "app_ver", Z), e += (e.includes("?") ? "&" : "?") + H(r));
  const n = {
    url: e,
    method: t,
    response: "hex",
    credential: o,
    originReferer: !0,
    headers: { "User-Agent": "Mozilla/5.0" }
  };
  a !== null && (n.body = H(a), n.headers["Content-Type"] = "application/x-www-form-urlencoded");
  const s = await i.http.request(n);
  if (s.status !== 200) throw Error("115 HTTP " + s.status);
  return { hex: s.body };
}
function N(i) {
  if (typeof i == "number" && !Number.isSafeInteger(i) || !/^(0|[1-9][0-9]{0,29})$/.test(String(i)))
    throw Error("远端 ID 无效");
  return String(i);
}
function G(i, e, t) {
  if (!Number.isSafeInteger(i) || i < e || i > t)
    throw Error("分页或深度超出范围");
  return i;
}
function X(i) {
  const e = String(i).trim().replace(/^[\/#]+|[\/#]+$/g, ""), t = /^([a-z0-9]+)(?:-([a-z0-9]+))?$/i.exec(e);
  if (t) return { share_code: t[1], receive_code: t[2] ?? "" };
  const r = /^https?:\/\/[^/?#]+\/(?:[^?#]*\/)?([a-z0-9]+)\/?(?:\?([^#]*))?(?:#.*)?$/i.exec(e);
  if (!r) throw Error("分享链接无效");
  const a = /(?:^|&)password=([^&]*)/.exec(r[2] ?? "");
  return { share_code: r[1], receive_code: a ? decodeURIComponent(a[1]) : "" };
}
async function mt(i, { uid: e, app: t = "alipaymini", loginExchange: r = !0 }) {
  if (!Zi.includes(t)) throw Error("未知扫码设备");
  const a = { ios: "UPhone", qios: "OfficePhone", ipad: "UPad", qipad: "OfficePad" }[t], o = a ? "ios" : t === "desktop" ? "web" : ["windows", "mac", "linux"].includes(t) ? "os_" + t : t, n = { "Content-Type": "application/x-www-form-urlencoded" };
  a && (n["User-Agent"] = a + "/1.0.0");
  const s = await i.http.request({
    url: "https://qrcodeapi.115.com/app/1.0/" + o + "/1.0/login/qrcode/",
    method: "POST",
    headers: n,
    credential: !1,
    loginExchange: r,
    body: H({ account: e })
  });
  if (s.status !== 200) throw Error("115 HTTP " + s.status);
  const d = j(s.body);
  if (d.data && s.cookies && Object.keys(s.cookies).length) {
    const u = d.data.cookie, _ = typeof u == "string" ? Object.fromEntries(u.split(/;\s*/).flatMap((w) => {
      const g = w.indexOf("=");
      return g > 0 ? [[w.slice(0, g).trim(), w.slice(g + 1)]] : [];
    })) : u || {}, m = {};
    for (const w of [s.cookies, _])
      for (const [g, x] of Object.entries(w))
        /^(uid|cid|seid|kid)$/i.test(g) && x && (m[g.toUpperCase()] = x);
    d.data.cookie = { ...Object.fromEntries(Object.entries(_).filter(([w]) => !/^(uid|cid|seid|kid)$/i.test(w))), ...m };
  }
  return d;
}
async function di(i, e) {
  const t = await J(
    i,
    "https://qrcodeapi.115.com/api/1.0/web/1.0/status",
    "GET",
    { uid: S(e, "uid"), _: Date.now() },
    null
  ), r = Number(t.code || t.errno || 0), a = String(t.message || t.error || "");
  let o = { 90038: 0, 90039: 1, 90032: -1 }[r];
  if (o === void 0)
    if (/取消|拒绝|cancel|denied|refused/i.test(a)) o = -2;
    else if (/key invalid|expired|已过期|已失效/i.test(a)) o = -1;
    else if (t.data?.status != null && [-2, -1, 0, 1, 2].includes(Number(t.data.status))) o = Number(t.data.status);
    else if (!r && [!0, 1, "1"].includes(t.state) && t.key) o = 2;
    else return t;
  return { state: !0, data: { status: o } };
}
async function Yi(i, e) {
  if (typeof e != "string" || e.length > 2048 || !/^https:\/\/avatars\.115\.com\/[a-zA-Z0-9_%./?=&+-]+$/.test(e)) throw Error("无效的官方头像地址");
  const t = await i.http.request({ url: e, method: "GET", response: "hex", credential: !1 });
  if (t.status !== 200 || !t.body || t.body.length > 98304) throw Error("头像不可用或超过 48 KiB");
  const r = t.body, a = r.startsWith("ffd8ff") ? "jpeg" : r.startsWith("89504e470d0a1a0a") ? "png" : r.startsWith("52494646") && r.slice(16, 24) === "57454250" ? "webp" : /^47494638(37|39)61/.test(r) ? "gif" : "";
  if (!a) throw Error("不支持的头像图片格式");
  return { image: "data:image/" + a + ";base64," + pe(ne(r)) };
}
const Zi = ["alipaymini", "wechatmini", "ios", "bios", "115ios", "android", "bandroid", "115android", "harmony", "ipad", "bipad", "115ipad", "qios", "qipad", "qandroid", "web", "desktop", "windows", "os_windows", "mac", "os_mac", "linux", "os_linux", "tv", "apple_tv"];
function Qi(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/login/getKey", J(i, o, "GET", r, a);
}
function Wr(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://appversion.115.com/1.0/web/1.0/api/chrome", J(i, o, "GET", r, a);
}
function Br(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://appversion.115.com/1.0/web/1.0/api/getMultiVer", J(i, o, "GET", r, a);
}
function Hr(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/open/authCodeToToken", J(i, o, "POST", r, { grant_type: "authorization_code", ...t });
}
function eo(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/login/login", c(t, "cipher_ver", 2), J(i, o, "POST", r, t);
}
function Fr(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/qrcode", tt(i, o, "GET", r, a, !1);
}
function ui(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/open/deviceCodeToToken", J(i, o, "POST", r, t);
}
function to(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/api/2.0/prompt.php", l(i, o, "GET", t, a);
}
function Jr(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/api/2.0/cancel.php", l(i, o, "GET", t, a);
}
function io(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/api/2.0/slogin.php", l(i, o, "GET", t, a);
}
function $r(i, e) {
  let t = p(e, ["uid", "app"], !1);
  S(e, "uid");
  let r = null, a = null, o;
  return mt(i, e);
}
function Kr(i, e) {
  let t = p(e, ["mode"], !0), r = null, a = null, o;
  if (e.mode === "snapshot") return di(i, t);
  if (e.mode !== void 0 && e.mode !== "wait") throw Error("未知扫码查询模式");
  return o = "https://qrcodeapi.115.com/get/status/", J(i, o, "GET", t, a);
}
function ci(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/token/", J(i, o, "GET", r, a);
}
function Rt(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/open/authDeviceCode", J(i, o, "POST", r, t);
}
function _i(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/open/refreshToken", J(i, o, "POST", r, t);
}
function oo(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/code/sms/login", t = { tpl: "login_from_two_step", cv21: 2, ...t }, J(i, o, "POST", r, t);
}
function ro(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/login/vip", J(i, o, "POST", r, t);
}
function ao(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://uplb.115.com/3.0/gettoken.php", J(i, o, "GET", r, a);
}
function Vr(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://uplb.115.com/3.0/getuploadinfo.php", J(i, o, "GET", r, a);
}
function Xr(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/open/offline/get_quota_info", l(i, o, "GET", r, a);
}
function Yr(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/offline/add_task_bt ", l(i, o, "POST", r, t);
}
function Zr(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/offline/add_task_urls", l(i, o, "POST", r, t);
}
function Qr(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/offline/clear_task", l(i, o, "POST", r, t);
}
function ea(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/offline/del_task", l(i, o, "POST", r, t);
}
function fi(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/offline/get_task_list", l(i, o, "GET", t, a);
}
function ta(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/offline/torrent", l(i, o, "POST", r, t);
}
function ia(i, e) {
  let t = p(e, ["pid"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/ufile/copy", c(t, "pid", b(e, "pid", 0)), l(i, o, "POST", r, t);
}
function oa(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/ufile/delete", l(i, o, "POST", r, t);
}
function no(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/ufile/files", t = { aid: 1, count_folders: 1, limit: 32, offset: 0, record_open_time: 1, show_dir: 1, cid: 0, ...t }, z(["asc", "fc_mix", "o"].some((n) => Object.hasOwn(t, n))) && c(t, "custom_order", 2), l(i, o, "GET", t, a);
}
function ra(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null, o, n, s;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? (o = "https://proapi.115.com/open/folder/get_info", z(n = de(t, "path")) && (z(Yt(n, ["/", ">"])) ? (s = S(n, 0), t.path = s + Zt(n, s)) : z(be(n, ">")) ? t.path = "/" + He(n, "/") : t.path = ">" + He(n, ">")), z("POST".toUpperCase() === "POST") ? a = t : r = t, l(i, o, "POST", r, a)) : (o = "https://proapi.115.com/open/folder/get_info", z(n = de(t, "path")) && (z(Yt(n, ["/", ">"])) ? (s = S(n, 0), t.path = s + Zt(n, s)) : z(be(n, ">")) ? t.path = "/" + He(n, "/") : t.path = ">" + He(n, ">")), z("GET".toUpperCase() === "POST") ? a = t : r = t, l(i, o, "GET", r, a));
}
function aa(i, e) {
  let t = p(e, ["pid"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/folder/add", c(t, "pid", b(e, "pid", 0)), l(i, o, "POST", r, t);
}
function na(i, e) {
  let t = p(e, ["pid"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/ufile/move", c(t, "to_cid", b(e, "pid", 0)), l(i, o, "POST", r, t);
}
function la(i, e) {
  let t = p(e, [], !0), r = null, a = null;
  return hi(i, { payload: t });
}
function sa(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/ufile/search", t = { aid: 1, cid: 0, limit: 1150, offset: 0, show_dir: 1, ...t }, l(i, o, "GET", t, a);
}
function pa(i, e) {
  let t = p(e, ["star"], !0), r = null, a = null;
  return c(t, "star", P(b(e, "star", !0))), hi(i, { payload: t });
}
function da(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/video/play", l(i, o, "GET", t, a);
}
function ua(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/video/history", l(i, o, "GET", t, a);
}
function ca(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/video/history", l(i, o, "POST", r, t);
}
function _a(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/video/video_push", c(t, "op", "vip_push"), l(i, o, "POST", r, t);
}
function fa(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/video/subtitle", l(i, o, "GET", t, a);
}
function hi(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/ufile/update", l(i, o, "POST", r, t);
}
function ha(i, e) {
  let t = p(e, ["password"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/rb/del", l(i, o, "POST", r, t);
}
function ya(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/rb/list", c(t, "limit", 32), l(i, o, "GET", t, a);
}
function ma(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/rb/revert", l(i, o, "POST", r, t);
}
function ba(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/open/upload/get_token", l(i, o, "GET", r, a);
}
function wa(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/upload/init", l(i, o, "POST", r, t);
}
function lo(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/open/user/info", l(i, o, "GET", r, a);
}
function xa(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/open/vip/qr_url", l(i, o, "GET", t, a);
}
function so(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/adopt", l(i, o, "POST", r, t);
}
function po(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/aid_desire", l(i, o, "POST", r, t);
}
function ga(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/del_aid_desire", l(i, o, "POST", r, t);
}
function uo(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/desire_aid_list", t = { start: 0, page: 1, limit: 10, ...t }, l(i, o, "GET", t, a);
}
function ka(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/get_act_info", l(i, o, "GET", r, a);
}
function co(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/get_desire_info", l(i, o, "GET", t, a);
}
function Ta(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/home_list", l(i, o, "GET", r, a);
}
function Ea(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/my_aid_desire", t = { type: 0, start: 0, page: 1, limit: 10, ...t }, l(i, o, "GET", t, a);
}
function _o(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/my_desire", t = { type: 0, start: 0, page: 1, limit: 10, ...t }, l(i, o, "GET", t, a);
}
function fo(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/wish", c(t, "rewardSpace", 5), l(i, o, "POST", r, t);
}
function ho(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://act.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/act2024xys/del_wish", l(i, o, "POST", r, t);
}
function qa(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://captchaapi.115.com/?ct=index&ac=code&t=all", tt(i, o, "GET", r, a, !0);
}
function va(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://captchaapi.115.com/?ct=index&ac=code", tt(i, o, "GET", r, a, !0);
}
function yo(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://captchaapi.115.com/?ac=code&t=sign", l(i, o, "GET", r, a);
}
function Sa(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://captchaapi.115.com/?ct=index&ac=code&t=single", tt(i, o, "GET", r, a, !0);
}
function Oa(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/offine/downpath", l(i, o, "GET", t, a);
}
function Pa(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/offine/downpath", l(i, o, "POST", r, t);
}
function Ga(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? A(i, "get_id", "POST", t) : A(i, "get_id", "GET", t);
}
function Aa(i, e) {
  let t = p(e, ["method"], !1), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? A(i, "get_quota_info", "POST", {}) : A(i, "get_quota_info", "GET", {});
}
function za(i, e) {
  let t = p(e, ["method"], !1), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? A(i, "get_quota_package_array", "POST", {}) : A(i, "get_quota_package_array", "GET", {});
}
function Na(i, e) {
  let t = p(e, ["method"], !1), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? A(i, "get_quota_package_info", "POST", {}) : A(i, "get_quota_package_info", "GET", {});
}
function ja(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://115.com/?ct=clouddownload&ac=space", l(i, o, "GET", r, a);
}
function Ia(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/offlinesign", l(i, o, "GET", r, a);
}
function Ua(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? A(i, "get_user_task", "POST", t) : A(i, "get_user_task", "GET", t);
}
function Ra(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? A(i, "add_task_bt", "GET", t) : A(i, "add_task_bt", "POST", t);
}
function Ca(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? A(i, "add_task_url", "GET", t) : A(i, "add_task_url", "POST", t);
}
function Da(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? A(i, "add_task_urls", "GET", t) : A(i, "add_task_urls", "POST", t);
}
function Ma(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? A(i, "task_clear", "GET", t) : A(i, "task_clear", "POST", t);
}
function La(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? A(i, "get_task_cnt", "POST", t) : A(i, "get_task_cnt", "GET", t);
}
function Wa(i, e) {
  let t = p(e, ["method"], !1), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? A(i, "task_count", "POST", {}) : A(i, "task_count", "GET", {});
}
function Ba(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? A(i, "task_del", "GET", t) : A(i, "task_del", "POST", t);
}
function yi(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? (c(t, "page_size", 30), A(i, "task_lists", "POST", t)) : (c(t, "page_size", 30), A(i, "task_lists", "GET", t));
}
function Ha(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? A(i, "pause_task", "GET", t) : A(i, "pause_task", "POST", t);
}
function mo(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? A(i, "restart", "GET", t) : A(i, "restart", "POST", t);
}
function Fa(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? A(i, "resume_task", "GET", t) : A(i, "resume_task", "POST", t);
}
function Ja(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? A(i, "torrent", "POST", t) : A(i, "torrent", "GET", t);
}
function $a(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/diary/delete", l(i, o, "POST", r, t);
}
function Ka(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/diary/detail", l(i, o, "GET", t, a);
}
function Va(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/diarydetail", l(i, o, "GET", t, a);
}
function Xa(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/diary/get_diary_config", l(i, o, "GET", r, a);
}
function Ya(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/diary/getlatesttags", l(i, o, "GET", t, a);
}
function Za(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/diary/gettagcolor", l(i, o, "POST", r, t);
}
function Qa(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null;
  if (["web"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "web" });
  if (["desktop"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "desktop" });
  if (["chrome"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "chrome" });
  if (["aps"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "aps" });
  if (["android"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "android" });
  if (["115android"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "115android" });
  if (["ios"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "ios" });
  if (["115ios"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "115ios" });
  if (["115ipad"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "115ipad" });
  if (["ipad"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "ipad" });
  if (["harmony"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "harmony" });
  if (["windows"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "windows" });
  if (["mac"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "mac" });
  if (["linux"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "linux" });
  if (["os_windows"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "os_windows" });
  if (["os_mac"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "os_mac" });
  if (["os_linux"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "os_linux" });
  if (["tv"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "tv" });
  if (["wechatmini"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "wechatmini" });
  if (["alipaymini"].includes(e.app ?? "web"))
    return t = { ...t }, c(t, "type", 5), W(i, { payload: t, app: "alipaymini" });
  throw Error("未知客户端 app");
}
function en(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/diary/search", l(i, o, "GET", t, a);
}
function tn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/diary/settag", l(i, o, "POST", r, t);
}
function on(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null;
  if (["web"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "web" });
  if (["desktop"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "desktop" });
  if (["chrome"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "chrome" });
  if (["aps"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "aps" });
  if (["android"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "android" });
  if (["115android"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "115android" });
  if (["ios"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "ios" });
  if (["115ios"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "115ios" });
  if (["115ipad"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "115ipad" });
  if (["ipad"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "ipad" });
  if (["harmony"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "harmony" });
  if (["windows"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "windows" });
  if (["mac"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "mac" });
  if (["linux"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "linux" });
  if (["os_windows"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "os_windows" });
  if (["os_mac"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "os_mac" });
  if (["os_linux"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "os_linux" });
  if (["tv"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "tv" });
  if (["wechatmini"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "wechatmini" });
  if (["alipaymini"].includes(e.app ?? "web"))
    return c(t, "type", 5), B(i, { payload: t, app: "alipaymini" });
  throw Error("未知客户端 app");
}
function bo(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/downfiles", t = { page: 1, per_page: 5e3, ...t }, l(i, o, "GET", t, a);
}
function rn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  if (["chrome", "web", "desktop"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/app/2.0/chrome/downfiles", t = { page: 1, per_page: 5e3, ...t }, l(i, o, "GET", t, a);
  if (["aps", "android", "115android", "ios", "115ios", "115ipad", "ipad", "harmony", "windows", "os_windows", "tv", "wechatmini", "alipaymini"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_windows/2.0/ufile/downfiles", t = { page: 1, per_page: 5e3, ...t }, Ne(i, o, "GET", t, a, !1);
  if (["mac", "os_mac"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_mac/2.0/ufile/downfiles", t = { page: 1, per_page: 5e3, ...t }, Ne(i, o, "GET", t, a, !1);
  if (["linux", "os_linux"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_linux/2.0/ufile/downfiles", t = { page: 1, per_page: 5e3, ...t }, Ne(i, o, "GET", t, a, !1);
  throw Error("未知客户端 app");
}
function wo(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/downfolders", t = { page: 1, per_page: 5e3, ...t }, l(i, o, "GET", t, a);
}
function an(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  if (["chrome", "web", "desktop"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/app/2.0/chrome/downfolders", t = { page: 1, per_page: 5e3, ...t }, l(i, o, "GET", t, a);
  if (["aps", "android", "115android", "ios", "115ios", "115ipad", "ipad", "harmony", "windows", "os_windows", "tv", "wechatmini", "alipaymini"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_windows/2.0/ufile/downfolders", t = { page: 1, per_page: 5e3, ...t }, Ne(i, o, "GET", t, a, !1);
  if (["mac", "os_mac"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_mac/2.0/ufile/downfolders", t = { page: 1, per_page: 5e3, ...t }, Ne(i, o, "GET", t, a, !1);
  if (["linux", "os_linux"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_linux/2.0/ufile/downfolders", t = { page: 1, per_page: 5e3, ...t }, Ne(i, o, "GET", t, a, !1);
  throw Error("未知客户端 app");
}
function nn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  if (["chrome", "web", "desktop"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/app/chrome/downfolder", l(i, o, "GET", t, a);
  if (["aps", "android", "tv", "wechatmini", "alipaymini"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/android/folder/downfolder", l(i, o, "GET", t, a);
  if (["115android"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/115android/folder/downfolder", l(i, o, "GET", t, a);
  if (["ios"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/ios/folder/downfolder", l(i, o, "GET", t, a);
  if (["115ios"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/115ios/folder/downfolder", l(i, o, "GET", t, a);
  if (["115ipad", "ipad"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/115ipad/folder/downfolder", l(i, o, "GET", t, a);
  if (["harmony"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/harmony/folder/downfolder", l(i, o, "GET", t, a);
  if (["windows", "os_windows"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_windows/folder/downfolder", l(i, o, "GET", t, a);
  if (["mac", "os_mac"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_mac/folder/downfolder", l(i, o, "GET", t, a);
  if (["linux", "os_linux"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_linux/folder/downfolder", l(i, o, "GET", t, a);
  throw Error("未知客户端 app");
}
function ln(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/add_extract_file", l(i, o, "POST", r, t);
}
function sn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/add_extract_file", l(i, o, "POST", r, t);
}
function pn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/extract_folders", l(i, o, "GET", t, a);
}
function dn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/extract_folders", l(i, o, "GET", t, a);
}
function un(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/extract_folders", l(i, o, "POST", r, t);
}
function cn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/extract_folders", l(i, o, "POST", r, t);
}
function xo(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/extract_info", t = { paths: "文件", page_count: 999, next_marker: "", file_name: "", ...t }, l(i, o, "GET", t, a);
}
function go(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/extract_info", t = { paths: "文件", page_count: 999, next_marker: "", file_name: "", ...t }, l(i, o, "GET", t, a);
}
function ko(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/add_extract_file", l(i, o, "GET", t, a);
}
function To(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/add_extract_file", l(i, o, "GET", t, a);
}
function Eo(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/push_extract", l(i, o, "POST", r, t);
}
function qo(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/push_extract", l(i, o, "POST", r, t);
}
function vo(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/push_extract", l(i, o, "GET", t, a);
}
function So(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/push_extract", l(i, o, "GET", t, a);
}
function Oo(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/batch_edit", l(i, o, "POST", r, t);
}
function _n(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/batch_edit", l(i, o, "POST", r, t);
}
function mi(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/category/get", c(t, "aid", 1), l(i, o, "GET", t, a);
}
function fn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/category/get", c(t, "aid", 1), l(i, o, "GET", t, a);
}
function hn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/category/shortcut", t = { limit: 1150, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Po(i, e) {
  let t = p(e, ["set"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/category/shortcut", t = { op: ["delete", "add"][Number(b(e, "set", !0))], ...t }, l(i, o, "POST", r, t);
}
function it(i, e) {
  let t = p(e, ["pid"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/copy", c(t, "pid", b(e, "pid", 0)), l(i, o, "POST", r, t);
}
function yn(i, e) {
  let t = p(e, ["pid", "app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/copy", c(t, "pid", b(e, "pid", 0)), l(i, o, "POST", r, t);
}
function mn(i, e) {
  let t = p(e, ["fid_cover"], !0), r = null, a = null;
  return c(t, "fid_cover", b(e, "fid_cover", 0)), ot(i, { payload: t });
}
function bn(i, e) {
  let t = p(e, ["fid_cover", "app"], !0), r = null, a = null;
  if (["android"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "android" });
  if (["web"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "web" });
  if (["desktop"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "desktop" });
  if (["chrome"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "chrome" });
  if (["aps"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "aps" });
  if (["115android"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "115android" });
  if (["ios"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "ios" });
  if (["115ios"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "115ios" });
  if (["115ipad"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "115ipad" });
  if (["ipad"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "ipad" });
  if (["harmony"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "harmony" });
  if (["windows"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "windows" });
  if (["mac"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "mac" });
  if (["linux"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "linux" });
  if (["os_windows"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "os_windows" });
  if (["os_mac"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "os_mac" });
  if (["os_linux"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "os_linux" });
  if (["tv"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "tv" });
  if (["wechatmini"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "wechatmini" });
  if (["alipaymini"].includes(e.app ?? "android"))
    return c(t, "fid_cover", b(e, "fid_cover", 0)), E(i, { payload: t, app: "alipaymini" });
  throw Error("未知客户端 app");
}
function Me(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/rb/delete", l(i, o, "POST", r, t);
}
async function wn(i, e) {
  let t = p(e, ["app", "userId"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/rb/delete", t = { ...t, user_id: await v(i, e) }, l(i, o, "POST", r, t);
}
function xn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/desc", t = { compat: 1, ...t }, l(i, o, "GET", t, a);
}
function gn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/desc", t = { compat: 1, ...t }, l(i, o, "GET", t, a);
}
function kn(i, e) {
  let t = p(e, ["desc"], !0), r = null, a = null;
  return c(t, "file_desc", b(e, "desc", "")), ot(i, { payload: t });
}
function Tn(i, e) {
  let t = p(e, ["desc", "app"], !0), r = null, a = null;
  if (["android"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "android" });
  if (["web"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "web" });
  if (["desktop"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "desktop" });
  if (["chrome"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "chrome" });
  if (["aps"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "aps" });
  if (["115android"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "115android" });
  if (["ios"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "ios" });
  if (["115ios"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "115ios" });
  if (["115ipad"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "115ipad" });
  if (["ipad"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "ipad" });
  if (["harmony"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "harmony" });
  if (["windows"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "windows" });
  if (["mac"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "mac" });
  if (["linux"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "linux" });
  if (["os_windows"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "os_windows" });
  if (["os_mac"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "os_mac" });
  if (["os_linux"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "os_linux" });
  if (["tv"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "tv" });
  if (["wechatmini"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "wechatmini" });
  if (["alipaymini"].includes(e.app ?? "android"))
    return c(t, "file_desc", b(e, "desc", "")), E(i, { payload: t, app: "alipaymini" });
  throw Error("未知客户端 app");
}
function En(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/getid", l(i, o, "GET", t, a);
}
function Go(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/get_path_id", l(i, o, "GET", t, a);
}
function qn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/getid", l(i, o, "GET", t, a);
}
function vn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/document", l(i, o, "GET", t, a);
}
function Sn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/document", l(i, o, "GET", t, a);
}
function ot(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/edit", l(i, o, "POST", r, t);
}
function Ao(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/export_dir", c(t, "target", "U_1_0"), l(i, o, "POST", r, t);
}
function On(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/export_dir", c(t, "target", "U_1_0"), l(i, o, "POST", r, t);
}
function zo(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/export_dir", l(i, o, "GET", t, a);
}
function Pn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/export_dir", l(i, o, "GET", t, a);
}
function No(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/get_info", l(i, o, "GET", t, a);
}
function jo(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null, o;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? (o = "https://webapi.115.com/files/file", z("POST".toUpperCase() === "POST") ? a = t : r = t, l(i, o, "POST", r, a)) : (o = "https://webapi.115.com/files/file", z("GET".toUpperCase() === "POST") ? a = t : r = t, l(i, o, "GET", r, a));
}
function Io(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files", t = { aid: 1, count_folders: 1, limit: 32, offset: 0, record_open_time: 1, show_dir: 1, cid: 0, ...t }, z(["asc", "fc_mix", "o"].some((n) => Object.hasOwn(t, n))) && c(t, "custom_order", 2), l(i, o, "GET", t, a);
}
function Gn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/files", t = { aid: 1, count_folders: 1, limit: 32, offset: 0, record_open_time: 1, show_dir: 1, cid: 0, ...t }, z(["asc", "fc_mix", "o"].some((n) => Object.hasOwn(t, n))) && c(t, "custom_order", 2), l(i, o, "GET", t, a);
}
function An(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = pi(e, "android", { android: "https://proapi.115.com/android/files", web: "https://proapi.115.com/android/files", desktop: "https://proapi.115.com/android/files", chrome: "https://proapi.115.com/android/files", aps: "https://proapi.115.com/android/files", "115android": "https://proapi.115.com/115android/files", ios: "https://proapi.115.com/ios/files", "115ios": "https://proapi.115.com/115ios/files", "115ipad": "https://proapi.115.com/115ipad/files", ipad: "https://proapi.115.com/115ipad/files", harmony: "https://proapi.115.com/harmony/files", windows: "https://proapi.115.com/os_windows/files", mac: "https://proapi.115.com/os_mac/files", linux: "https://proapi.115.com/os_linux/files", os_windows: "https://proapi.115.com/os_windows/files", os_mac: "https://proapi.115.com/os_mac/files", os_linux: "https://proapi.115.com/os_linux/files", tv: "https://proapi.115.com/android/files", wechatmini: "https://proapi.115.com/wechatmini/files", alipaymini: "https://proapi.115.com/alipaymini/files" }), t = { aid: 1, count_folders: 1, limit: 32, offset: 0, record_open_time: 1, show_dir: 1, cid: 0, ...t }, z(["asc", "fc_mix", "o"].some((n) => Object.hasOwn(t, n))) && c(t, "custom_order", 2), l(i, o, "GET", t, a);
}
function zn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://aps.115.com/natsort/files.php", t = { aid: 1, count_folders: 1, limit: 32, offset: 0, record_open_time: 1, show_dir: 1, cid: 0, ...t }, z(["asc", "fc_mix"].some((n) => Object.hasOwn(t, n))) && c(t, "custom_order", 2), l(i, o, "GET", t, a);
}
function Nn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/blank_document", t = { pid: 0, type: 1, ...t }, l(i, o, "POST", r, t);
}
function jn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/cover", l(i, o, "GET", t, a);
}
function In(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/cover", c(t, "show", 1), l(i, o, "POST", r, t);
}
function Un(i, e) {
  let t = p(e, [], !0), r = null, a = null, o, n;
  return o = "https://webapi.115.com/files/imglist", t = { limit: 32, offset: 0, cid: 0, ...t }, z(n = de(t, "cid")) && c(t, "file_id", n), l(i, o, "GET", t, a);
}
function Rn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/imglist", t = { limit: 32, offset: 0, aid: 1, cid: 0, cur: 1, ...t }, l(i, o, "GET", t, a);
}
function Cn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/medialist", t = { limit: 32, offset: 0, aid: 1, cid: 0, cur: 1, type: -1, ...t }, z(S(t, "type") === 99) && (t.type = -1), l(i, o, "GET", t, a);
}
function Dn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/medialist", t = { limit: 32, offset: 0, aid: 1, cid: 0, cur: 1, type: -1, ...t }, z(S(t, "type") === 99) && (t.type = -1), l(i, o, "GET", t, a);
}
function Mn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/recent", l(i, o, "POST", r, t);
}
function Ln(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/recent", l(i, o, "POST", r, t);
}
function Wn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/get_second_type", t = { cid: 0, type: 1, ...t }, l(i, o, "GET", t, a);
}
function Bn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/get_second_type", t = { cid: 0, type: 1, ...t }, l(i, o, "GET", t, a);
}
function E(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/update", l(i, o, "POST", r, t);
}
async function Hn(i, e) {
  let t = p(e, ["app", "userId"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/folder/update", t = { limit: 1150, offset: 0, p_id: 0, user_id: await v(i, e), ...t }, l(i, o, "GET", t, a);
}
async function Fn(i, e) {
  let t = p(e, ["app", "userId"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/folder", t = { aid: 1, limit: 1150, offset: 0, p_id: 0, user_id: await v(i, e), ...t }, l(i, o, "GET", t, a);
}
async function Jn(i, e) {
  let t = p(e, ["userId"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/folder/file", t = { aid: 1, limit: 1150, offset: 0, cid: 0, user_id: await v(i, e), ...t }, l(i, o, "GET", t, a);
}
function $n(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://aps.115.com/getFolderPlaylong", l(i, o, "POST", r, t);
}
async function L(i, e) {
  let t = p(e, ["app", "userId"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/folder/update", t = { aid: 1, pid: 0, user_id: await v(i, e), ...t }, l(i, o, "POST", r, t);
}
async function Kn(i, e) {
  let t = p(e, ["app", "userId"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/folder", t = { aid: 1, pid: 0, user_id: await v(i, e), ...t }, l(i, o, "POST", r, t);
}
function Uo(i, e) {
  let t = p(e, ["hidden"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/hiddenfiles", c(t, "hidden", P(b(e, "hidden", !0))), l(i, o, "POST", r, t);
}
function Vn(i, e) {
  let t = p(e, ["hidden", "app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/hiddenfiles", c(t, "hidden", P(b(e, "hidden", !0))), l(i, o, "POST", r, t);
}
function Xn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://115.com/?ct=hiddenfiles&ac=switching", z(be([0, 1], t)) && (t = { show: P(t) }), t.safe_pwd = String(de(t, "safe_pwd") || "").padStart(6, "0"), l(i, o, "POST", r, t);
}
async function Yn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/hiddenswitch", z(be([0, 1], t)) && (t = { show: P(t) }), t.safe_pwd = await si(i, de(t, "safe_pwd")), l(i, o, "GET", t, a);
}
function Zn(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/history", t = { category: 1, fetch: "one", ...t }, l(i, o, "GET", t, a);
}
function Qn(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/history", t = { category: 1, action: "get_one", ...t }, l(i, o, "GET", t, a);
}
function el(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/history/clean", t = { with_file: 0, type: 0, ...t }, l(i, o, "POST", r, t);
}
function tl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/history/delete", c(t, "with_file", 0), l(i, o, "POST", r, t);
}
function il(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/history/delete", c(t, "with_file", 0), l(i, o, "POST", r, t);
}
function ol(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/history/clean", t = { with_file: 0, type: 0, ...t }, l(i, o, "POST", r, t);
}
function Ro(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/history/list", t = { limit: 1150, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Co(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/history/list", t = { limit: 1150, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function rl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/history/move_target_list", t = { cid: 0, limit: 1150, offset: 0, aid: 1, show_dir: 1, ...t }, l(i, o, "GET", t, a);
}
function al(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/history/receive_list", t = { limit: 1150, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function nl(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/history/receive_list", t = { limit: 1150, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function ll(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null, o;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? (o = "https://webapi.115.com/history/renamelist", l(i, o, "GET", t, a)) : (o = "https://webapi.115.com/history/renamelist", l(i, o, "POST", r, t));
}
function sl(i, e) {
  let t = p(e, ["method", "app"], !0), r = null, a = null, o;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? (o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/history/renamelist", l(i, o, "GET", t, a)) : (o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/history/renamelist", l(i, o, "POST", r, t));
}
function pl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/history", t = { category: 1, op: "update", ...t }, l(i, o, "POST", r, t);
}
function dl(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/hiddenswitch", t = { category: 1, op: "update", ...t }, l(i, o, "POST", r, t);
}
function ul(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/image", l(i, o, "GET", t, a);
}
function cl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://imgjump.115.com/getimgdata_url", l(i, o, "POST", r, t);
}
function _l(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/index_info", l(i, o, "GET", t, a);
}
function Do(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/label/delete", l(i, o, "POST", r, t);
}
function fl(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/label/delete", l(i, o, "POST", r, t);
}
function hl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/label/edit", l(i, o, "POST", r, t);
}
function yl(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/label/edit", l(i, o, "POST", r, t);
}
function ml(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/label/files", t = { offset: 0, limit: 1150, ...t }, l(i, o, "GET", t, a);
}
function bl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/label/list", t = { offset: 0, limit: 11500, ...t }, l(i, o, "GET", t, a);
}
function wl(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/label/list", t = { offset: 0, limit: 11500, ...t }, l(i, o, "GET", t, a);
}
function xl(i, e) {
  let t = p(e, ["label"], !0), r = null, a = null;
  return c(t, "file_label", b(e, "label", "")), ot(i, { payload: t });
}
function gl(i, e) {
  let t = p(e, ["label", "app"], !0), r = null, a = null;
  if (["android"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "android" });
  if (["web"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "web" });
  if (["desktop"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "desktop" });
  if (["chrome"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "chrome" });
  if (["aps"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "aps" });
  if (["115android"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "115android" });
  if (["ios"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "ios" });
  if (["115ios"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "115ios" });
  if (["115ipad"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "115ipad" });
  if (["ipad"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "ipad" });
  if (["harmony"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "harmony" });
  if (["windows"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "windows" });
  if (["mac"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "mac" });
  if (["linux"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "linux" });
  if (["os_windows"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "os_windows" });
  if (["os_mac"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "os_mac" });
  if (["os_linux"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "os_linux" });
  if (["tv"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "tv" });
  if (["wechatmini"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "wechatmini" });
  if (["alipaymini"].includes(e.app ?? "android"))
    return c(t, "file_label", b(e, "label", "")), E(i, { payload: t, app: "alipaymini" });
  throw Error("未知客户端 app");
}
function kl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/batch_label", l(i, o, "POST", r, t);
}
function Tl(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/batch_label", l(i, o, "POST", r, t);
}
function El(i, e) {
  let t = p(e, ["pid"], !0), r = null, a = null;
  return c(t, "parent_id", b(e, "pid", 0)), t.is_create = 1, Go(i, { payload: t });
}
function ql(i, e) {
  let t = p(e, ["pid", "app"], !0), r = null, a = null, o;
  if (["chrome"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/app/chrome/add_path", c(t, "parent_id", b(e, "pid", 0)), l(i, o, "POST", r, t);
  if (["web", "desktop", "aps", "android", "tv", "wechatmini", "alipaymini"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/android/2.0/ufile/add_path", c(t, "parent_id", b(e, "pid", 0)), l(i, o, "POST", r, t);
  if (["115android"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/115android/2.0/ufile/add_path", c(t, "parent_id", b(e, "pid", 0)), l(i, o, "POST", r, t);
  if (["ios"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/ios/2.0/ufile/add_path", c(t, "parent_id", b(e, "pid", 0)), l(i, o, "POST", r, t);
  if (["115ios"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/115ios/2.0/ufile/add_path", c(t, "parent_id", b(e, "pid", 0)), l(i, o, "POST", r, t);
  if (["115ipad", "ipad"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/115ipad/2.0/ufile/add_path", c(t, "parent_id", b(e, "pid", 0)), l(i, o, "POST", r, t);
  if (["harmony"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/harmony/2.0/ufile/add_path", c(t, "parent_id", b(e, "pid", 0)), l(i, o, "POST", r, t);
  if (["windows", "os_windows"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_windows/2.0/ufile/add_path", c(t, "parent_id", b(e, "pid", 0)), l(i, o, "POST", r, t);
  if (["mac", "os_mac"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_mac/2.0/ufile/add_path", c(t, "parent_id", b(e, "pid", 0)), l(i, o, "POST", r, t);
  if (["linux", "os_linux"].includes(e.app ?? "chrome"))
    return o = "https://proapi.115.com/os_linux/2.0/ufile/add_path", c(t, "parent_id", b(e, "pid", 0)), l(i, o, "POST", r, t);
  throw Error("未知客户端 app");
}
function bi(i, e) {
  let t = p(e, ["pid"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/add", c(t, "pid", b(e, "pid", 0)), l(i, o, "POST", r, t);
}
async function vl(i, e) {
  let t = p(e, ["pid", "app", "userId"], !0), r = null, a = null;
  if (["android"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "android" });
  if (["web"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "web" });
  if (["desktop"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "desktop" });
  if (["chrome"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "chrome" });
  if (["aps"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "aps" });
  if (["115android"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "115android" });
  if (["ios"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "ios" });
  if (["115ios"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "115ios" });
  if (["115ipad"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "115ipad" });
  if (["ipad"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "ipad" });
  if (["harmony"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "harmony" });
  if (["windows"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "windows" });
  if (["mac"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "mac" });
  if (["linux"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "linux" });
  if (["os_windows"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "os_windows" });
  if (["os_mac"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "os_mac" });
  if (["os_linux"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "os_linux" });
  if (["tv"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "tv" });
  if (["wechatmini"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "wechatmini" });
  if (["alipaymini"].includes(e.app ?? "android"))
    return c(t, "pid", b(e, "pid", 0)), L(i, { payload: t, userId: await v(i, e), app: "alipaymini" });
  throw Error("未知客户端 app");
}
function bt(i, e) {
  let t = p(e, ["pid"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/move", c(t, "pid", b(e, "pid", 0)), l(i, o, "POST", r, t);
}
async function Sl(i, e) {
  let t = p(e, ["pid", "app", "userId"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/move", t = { to_cid: b(e, "pid", 0), user_id: await v(i, e), ...t }, l(i, o, "POST", r, t);
}
function Ol(i, e) {
  let t = p(e, ["pid"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/move_check_conflict", c(t, "pid", b(e, "pid", 0)), l(i, o, "POST", r, t);
}
function Pl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/move_progress", l(i, o, "GET", t, a);
}
function Gl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/music", l(i, o, "GET", t, a);
}
function Al(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/music/musicplay", l(i, o, "GET", t, a);
}
function zl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/music_file_exist", l(i, o, "GET", t, a);
}
function Nl(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://webapi.115.com/files/music_fond_list", l(i, o, "GET", r, a);
}
function jl(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/music/music_fond_list", l(i, o, "GET", r, a);
}
function Il(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/music_topic_fond", c(t, "fond", 1), l(i, o, "POST", r, t);
}
function Ul(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/include_music_list", t = { asc: 0, limit: 1150, order: "user_etime", ...t }, l(i, o, "GET", t, a);
}
function Rl(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/music/include_music_list", t = { asc: 0, limit: 1150, order: "user_etime", ...t }, l(i, o, "GET", t, a);
}
function Cl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/music_info", l(i, o, "GET", t, a);
}
function Dl(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/music/musicdetail", l(i, o, "GET", t, a);
}
function Ml(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/music_list", t = { start: 0, limit: 1150, topic_id: 1, ...t }, l(i, o, "GET", t, a);
}
function Ll(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/music/music_list", t = { start: 0, limit: 1150, topic_id: 1, ...t }, l(i, o, "GET", t, a);
}
function Wl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/musicnew", t = { start: 0, limit: 1150, type: 0, topic_id: 1, ...t }, l(i, o, "GET", t, a);
}
function Bl(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/music/musicnew", t = { type: 0, topic_id: 1, ...t }, l(i, o, "GET", t, a);
}
function Hl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/music", t = { op: "add", fond: 1, music_id: 1, topic_id: 1, ...t }, l(i, o, "POST", r, t);
}
function Fl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/music_status", l(i, o, "GET", t, a);
}
function Jl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/music_topic_listnew", t = { fond: 0, hidden: 0, limit: 1150, start: 0, ...t }, l(i, o, "GET", t, a);
}
function $l(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/music/musiclistnew", t = { fond: 0, limit: 1150, start: 0, ...t }, l(i, o, "GET", t, a);
}
function Kl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/music_topic", l(i, o, "POST", r, t);
}
function Vl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/office?act=check_complete", l(i, o, "POST", r, t);
}
function Xl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/office?act=office_init", l(i, o, "POST", r, t);
}
function Yl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/office?act=save", l(i, o, "POST", r, t);
}
function Zl(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/order", t = { file_id: 0, user_asc: 1, user_order: "user_ptime", ...t }, l(i, o, "POST", r, t);
}
function Ql(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/order", t = { file_id: 0, user_asc: 1, user_order: "user_ptime", ...t }, l(i, o, "POST", r, t);
}
function es(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/preview", l(i, o, "POST", r, t);
}
function Ct(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/batch_rename", l(i, o, "POST", r, t);
}
function ts(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/batch_rename", l(i, o, "POST", r, t);
}
function is(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://aps.115.com/rename/set_names.php", l(i, o, "POST", r, t);
}
function os(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://aps.115.com/rename/reset_names.php", l(i, o, "POST", r, t);
}
function rs(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/get_repeat_sha", t = { offset: 0, limit: 1150, ...t }, l(i, o, "GET", t, a);
}
function as(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/get_repeat_sha", t = { offset: 0, limit: 1150, ...t }, l(i, o, "GET", t, a);
}
function wi(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/search", t = { aid: 1, cid: 0, limit: 1150, offset: 0, show_dir: 1, ...t }, l(i, o, "GET", t, a);
}
function ns(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/search", t = { aid: 1, cid: 0, limit: 1150, offset: 0, show_dir: 1, ...t }, l(i, o, "GET", t, a);
}
function ls(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/search", t = { aid: 1, cid: 0, limit: 1150, offset: 0, show_dir: 1, ...t }, l(i, o, "GET", t, a);
}
function Mo(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/shasearch", l(i, o, "GET", t, a);
}
function ss(i, e) {
  let t = p(e, ["show"], !0), r = null, a = null;
  return c(t, "show_play_long", P(b(e, "show", !0))), ot(i, { payload: t });
}
function ps(i, e) {
  let t = p(e, ["show", "app"], !0), r = null, a = null;
  if (["android"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "android" });
  if (["web"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "web" });
  if (["desktop"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "desktop" });
  if (["chrome"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "chrome" });
  if (["aps"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "aps" });
  if (["115android"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "115android" });
  if (["ios"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "ios" });
  if (["115ios"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "115ios" });
  if (["115ipad"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "115ipad" });
  if (["ipad"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "ipad" });
  if (["harmony"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "harmony" });
  if (["windows"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "windows" });
  if (["mac"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "mac" });
  if (["linux"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "linux" });
  if (["os_windows"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "os_windows" });
  if (["os_mac"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "os_mac" });
  if (["os_linux"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "os_linux" });
  if (["tv"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "tv" });
  if (["wechatmini"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "wechatmini" });
  if (["alipaymini"].includes(e.app ?? "android"))
    return c(t, "show_play_long", P(b(e, "show", !0))), E(i, { payload: t, app: "alipaymini" });
  throw Error("未知客户端 app");
}
function ds(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://webapi.115.com/user/space_summury", l(i, o, "POST", r, a);
}
function Lo(i, e) {
  let t = p(e, ["star"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/star", t = { star: P(b(e, "star", !0)), ...t }, l(i, o, "POST", r, t);
}
async function us(i, e) {
  let t = p(e, ["star", "app", "userId"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/star", t = { star: P(b(e, "star", !0)), ...t }, c(t, "user_id", await v(i, e)), l(i, o, "POST", r, t);
}
function cs(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://115.com/index.php?ct=ajax&ac=get_storage_info", l(i, o, "GET", r, a);
}
function Wo(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/supervision", t = { preview_type: "file", module: 10, ...t }, l(i, o, "POST", r, t);
}
function _s(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/supervision", t = { preview_type: "file", module: 10, ...t }, l(i, o, "POST", r, t);
}
function fs(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/getpackage", l(i, o, "GET", t, a);
}
function Bo(i, e) {
  let t = p(e, ["top"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/top", t = { top: P(b(e, "top", !0)), ...t }, l(i, o, "POST", r, t);
}
function hs(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/video", l(i, o, "GET", t, a);
}
function ys(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/movies/add_caption_map", c(t, "type", 2), l(i, o, "POST", r, t);
}
function ms(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/video_def", l(i, o, "POST", r, t);
}
function bs(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/files/is_transcoded", l(i, o, "POST", r, t);
}
function ws(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/movies/user_multitrack", l(i, o, "POST", r, t);
}
function xs(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://115.com/?ct=play&ac=push", c(t, "op", "vip_push"), l(i, o, "POST", r, t);
}
function gs(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://115.com/?ctl=play&ac=batch_push", l(i, o, "POST", r, t);
}
function ks(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/movies/batch_push", l(i, o, "POST", r, t);
}
function Ho(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/movies/subtitle", l(i, o, "GET", t, a);
}
function Ts(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/video/subtitle", l(i, o, "GET", t, a);
}
function Es(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/movies/user_subtitle", c(t, "action", "set"), l(i, o, "POST", r, t);
}
function qs(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://transcode.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/trans_code/check_transcode_job", c(t, "priority", 100), l(i, o, "GET", t, a);
}
function vs(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/life_batch_delete", l(i, o, "POST", r, t);
}
function xi(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/behavior/detail", t = { limit: 1e3, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Fo(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = pi(e, "android", { android: "https://proapi.115.com/android/behavior/detail", web: "https://proapi.115.com/android/behavior/detail", desktop: "https://proapi.115.com/android/behavior/detail", chrome: "https://proapi.115.com/android/behavior/detail", aps: "https://proapi.115.com/android/behavior/detail", "115android": "https://proapi.115.com/115android/behavior/detail", ios: "https://proapi.115.com/ios/behavior/detail", "115ios": "https://proapi.115.com/115ios/behavior/detail", "115ipad": "https://proapi.115.com/115ipad/behavior/detail", ipad: "https://proapi.115.com/115ipad/behavior/detail", harmony: "https://proapi.115.com/harmony/behavior/detail", windows: "https://proapi.115.com/os_windows/behavior/detail", mac: "https://proapi.115.com/os_mac/behavior/detail", linux: "https://proapi.115.com/os_linux/behavior/detail", os_windows: "https://proapi.115.com/os_windows/behavior/detail", os_mac: "https://proapi.115.com/os_mac/behavior/detail", os_linux: "https://proapi.115.com/os_linux/behavior/detail", tv: "https://proapi.115.com/android/behavior/detail", wechatmini: "https://proapi.115.com/wechatmini/behavior/detail", alipaymini: "https://proapi.115.com/alipaymini/behavior/detail" }), t = { limit: 1e3, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Jo(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/doc_behavior", l(i, o, "POST", r, t);
}
function $o(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/files/img_behavior", l(i, o, "POST", r, t);
}
function Ss(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/calendar/getoption", l(i, o, "GET", r, a);
}
function Os(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/calendar/recent_operations_getoption", l(i, o, "GET", r, a);
}
function gi(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/calendar/setoption", t = { locus: 1, open_life: 1, ...t }, l(i, o, "POST", r, t);
}
function Ps(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/calendar/recent_operations_setoption", t = { locus: 1, open_life: 1, ...t }, l(i, o, "POST", r, t);
}
function Gs(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o, n;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/cdlist", t = { ...t }, z(!be(t, "start_time")) && (n = (/* @__PURE__ */ new Date()).getFullYear(), t.start_time = P(new Date(n, 0, 1).getTime() / 1e3)), z(!be(t, "end_time")) && (n = new Date(P(t.start_time) * 1e3).getFullYear(), t.end_time = P(new Date(n + 1, 0, 1).getTime() / 1e3) - 1), l(i, o, "GET", t, a);
}
function Ko(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/imgload/get_pic_url", l(i, o, "POST", r, t);
}
function Vo(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://q.115.com/ajax_request/get_pic_url", l(i, o, "POST", r, t);
}
function As(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/life_clear_history", l(i, o, "POST", r, t);
}
function W(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/glist", t = { ...t }, c(t, "type", 8), l(i, o, "GET", t, a);
}
function zs(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/life_has_data", l(i, o, "GET", t, a);
}
function Xo(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  if (["web", "desktop", "chrome", "aps"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/web/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["android"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/android/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["115android"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/115android/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["ios"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/ios/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["115ios"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/115ios/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["115ipad"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/115ipad/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["ipad"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/ipad/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["harmony"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/harmony/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["windows"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/windows/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["mac"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/mac/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["linux"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/linux/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["os_windows"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/os_windows/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["os_mac"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/os_mac/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["os_linux"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/os_linux/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["tv"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/tv/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["wechatmini"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/wechatmini/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  if (["alipaymini"].includes(e.app ?? "web"))
    return o = "https://life.115.com/api/1.0/alipaymini/1.0/life/life_list", t = { limit: 1e3, show_type: 0, start: 0, ...t }, l(i, o, "GET", t, a);
  throw Error("未知客户端 app");
}
function Ns(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/recent_browse", c(t, "limit", 1e3), l(i, o, "GET", t, a);
}
function js(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/recent_operation_items", t = { limit: 100, date: String(Ye(0)), ...t }, l(i, o, "GET", t, a);
}
function Is(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/recent_operations", c(t, "limit", 1e3), l(i, o, "GET", t, a);
}
function Us(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/recent_operations_clear", l(i, o, "POST", r, t);
}
function Rs(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/recent_operations_del", l(i, o, "POST", r, t);
}
function B(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/life/set_top", l(i, o, "GET", t, a);
}
function Cs(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/user/getAppAuthDetail", l(i, o, "GET", t, a);
}
function Yo(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/user/getAppAuthList", l(i, o, "GET", r, a);
}
function Zo(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/user/deauthApp", l(i, o, "POST", r, t);
}
function Ds(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/check/sso", l(i, o, "GET", r, a);
}
function Qo(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/login_log/login_devices", l(i, o, "GET", r, a);
}
function Ms(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/login_info", l(i, o, "GET", r, a);
}
function Ls(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/login_log/log", t = { start: 0, limit: 100, ...t }, l(i, o, "GET", t, a);
}
function Ws(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/login_log/login_online", l(i, o, "GET", r, a);
}
function Bs(i, e) {
  let t = p(e, ["method", "app"], !1), r = null, a = null, o;
  if (!["GET", "POST"].includes(e.method ?? "GET")) throw Error("method 无效");
  return e.method === "POST" ? (o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/login/renewal", l(i, o, "POST", r, a)) : (o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/login/renewal", l(i, o, "GET", r, a));
}
function Hs(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/two_step_trust/device_del", t.device_id = S(t, "id"), l(i, o, "POST", r, t);
}
function Fs(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/two_step_trust/device_edit", l(i, o, "POST", r, t);
}
function Js(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/two_step_trust/device_list", c(t, "limit", 100), l(i, o, "GET", t, a);
}
function $s(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/two_step_trust/device_trust", l(i, o, "POST", r, t);
}
function Ks(i, e) {
  let t = p(e, ["method", "app"], !1), r = null, a = null, o;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? (o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "android", !1) + "/1.0/logout/index", l(i, o, "GET", r, a)) : (o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "android", !1) + "/1.0/logout/index", l(i, o, "POST", r, a));
}
function Vs(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/logout/mange", l(i, o, "POST", r, t);
}
function Xs(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://pmsg.115.com/api/1.0/app/1.0/contact/ls", t = { limit: 115, t: 1, skip: 0, ...t }, l(i, o, "GET", t, a);
}
function Ys(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://msg.115.com/?ct=contacts&ac=notice&client=web", l(i, o, "GET", r, a);
}
function Zs(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://msg.115.com/?ct=im&ac=get_websocket_host", l(i, o, "GET", r, a);
}
function Qs(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/collection_listen", t = { channel_id: 1, limit: 32, ...t }, l(i, o, "GET", t, a);
}
function ep(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/collection_listen", t = { collection: 1, ...t }, l(i, o, "POST", r, t);
}
function tp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/collection_watch", t = { channel_id: 5, limit: 32, ...t }, l(i, o, "GET", t, a);
}
function ip(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/collection_watch", t = { channel_id: 5, collection: 1, ...t }, l(i, o, "POST", r, t);
}
function op(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/cover", c(t, "channel_id", 1), l(i, o, "POST", r, t);
}
function rp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/cover_check", c(t, "channel_id", 1), l(i, o, "GET", t, a);
}
function ap(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/date", t = { channel_id: 1, limit: 1e3, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function np(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/listen", t = { channel_id: 1, limit: 32, ...t }, l(i, o, "GET", t, a);
}
function lp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/listen", c(t, "channel_id", 1), l(i, o, "POST", r, t);
}
function sp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/watch", t = { channel_id: 5, limit: 32, ...t }, l(i, o, "GET", t, a);
}
function pp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/watch", c(t, "channel_id", 5), l(i, o, "POST", r, t);
}
function dp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/recent_listen", t = { channel_id: 1, limit: 32, ...t }, l(i, o, "GET", t, a);
}
function up(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/recent_listen", t = { channel_id: 1, action: "clear", ...t }, l(i, o, "POST", r, t);
}
function cp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/recent_watch", t = { channel_id: 5, limit: 32, ...t }, l(i, o, "GET", t, a);
}
function _p(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/recent_watch", t = { channel_id: 5, action: "clear", ...t }, l(i, o, "POST", r, t);
}
function fp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/relate_file", t = { channel_id: 1, limit: 32, ...t }, l(i, o, "GET", t, a);
}
function hp(i, e) {
  let t = p(e, ["channel_id"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/relate_file", c(t, "channel_id", b(e, "channel_id", 1)), l(i, o, "POST", r, t);
}
function yp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/related", c(t, "channel_id", 1), l(i, o, "GET", t, a);
}
function mp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/related", l(i, o, "POST", r, t);
}
function bp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/relation", l(i, o, "POST", r, t);
}
function wp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/type", c(t, "channel_id", 1), l(i, o, "GET", t, a);
}
function xp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/multimedia/type", l(i, o, "POST", r, t);
}
function gp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://bookmark.115.com/api/bookmark_list.php", c(t, "limit", 1150), z("".toUpperCase() === "POST") ? l(i, o, "GET", r, t) : l(i, o, "GET", t, a);
}
function kp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=addcate", l(i, o, "POST", r, t);
}
function Tp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=delcate", l(i, o, "POST", r, t);
}
function Ep(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=node&ac=upcate", l(i, o, "POST", r, t);
}
function qp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=cate", l(i, o, "GET", t, a);
}
function vp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=get_category", l(i, o, "GET", t, a);
}
function Sp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=delete", l(i, o, "POST", r, t);
}
function Op(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=note_delete", l(i, o, "POST", r, t);
}
function Pp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=detail", l(i, o, "GET", t, a);
}
function Gp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=note_detail", l(i, o, "GET", t, a);
}
function Ap(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=edit_attaches", l(i, o, "POST", r, t);
}
function zp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=get_fav_note_list", t = { limit: 1150, start: 0, ...t }, l(i, o, "GET", t, a);
}
function Np(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=fav", c(t, "op", "add"), l(i, o, "POST", r, t);
}
function er(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=get_pic_url", l(i, o, "POST", r, t);
}
function tr(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=get_pic_url", l(i, o, "POST", r, t);
}
function jp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=is_fav", z("".toUpperCase() === "POST") ? l(i, o, "GET", r, t) : l(i, o, "GET", t, a);
}
function Ip(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note", t = { ac: "all", cid: 0, has_picknews: 1, page_size: 1150, start: 0, ...t }, l(i, o, "GET", t, a);
}
function Up(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=note_list", t = { cid: 0, has_picknews: 1, page_size: 1150, start: 0, ...t }, l(i, o, "GET", t, a);
}
function Rp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=save", l(i, o, "POST", r, t);
}
function Cp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=note_edit", l(i, o, "POST", r, t);
}
function Dp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=search", t = { has_picknews: 1, limit: 1150, start: 0, ...t }, z("".toUpperCase() === "POST") ? l(i, o, "GET", r, t) : l(i, o, "GET", t, a);
}
function Mp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=update_note_cate", l(i, o, "POST", r, t);
}
function Lp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=set_note_cate", l(i, o, "POST", r, t);
}
function Wp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=set_tag", l(i, o, "POST", r, t);
}
function Bp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=get_tag_color", l(i, o, "POST", r, t);
}
function Hp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/api/2.0/api.php?ac=get_latest_tags", t = { is_return_color: 1, limit: 1150, ...t }, l(i, o, "GET", t, a);
}
function Fp(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=get_user_setting", l(i, o, "GET", r, a);
}
function Jp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://note.115.com/?ct=note&ac=set_user_setting", l(i, o, "POST", r, t);
}
function $p(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/album", l(i, o, "GET", t, a);
}
function Kp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/albumadd", l(i, o, "POST", r, t);
}
function Vp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/albumgroup", t = { home_page: 1, limit: 100, ...t }, l(i, o, "GET", t, a);
}
function Xp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/albumlist", t = { album_type: 1, limit: 9999, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Yp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/album", l(i, o, "POST", r, t);
}
function Zp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/photo", t = { action: "addtoalbum", to_album_id: 1, ...t }, l(i, o, "POST", r, t);
}
function Qp(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/photolist", c(t, "limit", 1150), l(i, o, "GET", t, a);
}
function ed(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharealbum", l(i, o, "GET", t, a);
}
function td(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharealbumadd", l(i, o, "POST", r, t);
}
function id(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharealbumlist", t = { limit: 1150, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function od(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharealbummember", l(i, o, "GET", t, a);
}
function rd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharealbumrecordlist", t = { limit: 1150, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function ad(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharealbumrecord", l(i, o, "POST", r, t);
}
function nd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharealbum", l(i, o, "POST", r, t);
}
function ld(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharephotolist", c(t, "limit", 1150), l(i, o, "GET", t, a);
}
function sd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharephoto", l(i, o, "POST", r, t);
}
function pd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharephotosave", l(i, o, "POST", r, t);
}
function dd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/sharephototimeline", c(t, "limit", 99999), l(i, o, "GET", t, a);
}
function ud(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/photo/phototimeline", c(t, "limit", 99999), l(i, o, "GET", t, a);
}
function ir(i, e) {
  let t = p(e, ["password"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/rb/secret_del", c(t, "password", b(e, "password", "000000")), t.password = String(de(t, "password") || "").padStart(6, "0"), l(i, o, "POST", r, t);
}
function cd(i, e) {
  let t = p(e, ["password"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/rb/clean", c(t, "password", b(e, "password", "000000")), t.password = String(de(t, "password") || "").padStart(6, "0"), l(i, o, "POST", r, t);
}
async function _d(i, e) {
  let t = p(e, ["password", "app", "userId"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/rb/secret_del", c(t, "user_id", await v(i, e)), c(t, "password", b(e, "password", "000000")), t.password = String(de(t, "password") || "").padStart(6, "0"), l(i, o, "POST", r, t);
}
function fd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/rb/rb_info", l(i, o, "GET", t, a);
}
function hd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/rb", t = { aid: 7, cid: 0, limit: 32, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function yd(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/rb", t = { aid: 7, cid: 0, limit: 32, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function or(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/rb/revert", l(i, o, "POST", r, t);
}
async function md(i, e) {
  let t = p(e, ["app", "userId"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/rb/revert", c(t, "user_id", await v(i, e)), l(i, o, "POST", r, t);
}
function bd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/access_user_list", l(i, o, "GET", t, a);
}
function wd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/activeshare", l(i, o, "POST", r, t);
}
function xd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/batch_renewal_long_skip", l(i, o, "POST", r, t);
}
function gd(i, e) {
  let t = p(e, ["skip_login"], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/batch_skip_login_down", t = t, c(t, "skip_login", P(b(e, "skip_login", !0))), l(i, o, "POST", r, t);
}
function kd(i, e) {
  let t = p(e, ["shareUrl"], !0);
  e.shareUrl && Object.assign(t, X(e.shareUrl));
  let r = null, a = null, o;
  return o = "https://webapi.115.com/share/downlist", l(i, o, "GET", t, a);
}
function Td(i, e) {
  let t = p(e, ["shareUrl", "app"], !0);
  e.shareUrl && Object.assign(t, X(e.shareUrl));
  let r = null, a = null, o;
  if (["android", "web", "desktop", "aps", "115android", "ios", "115ios", "115ipad", "ipad", "harmony", "windows", "os_windows", "tv", "wechatmini", "alipaymini"].includes(e.app ?? "android"))
    return o = "https://proapi.115.com/os_windows/2.0/share/downlist", l(i, o, "GET", t, a);
  if (["chrome"].includes(e.app ?? "android"))
    return o = "https://proapi.115.com/app/share/downlist", l(i, o, "GET", t, a);
  if (["mac", "os_mac"].includes(e.app ?? "android"))
    return o = "https://proapi.115.com/os_mac/2.0/share/downlist", l(i, o, "GET", t, a);
  if (["linux", "os_linux"].includes(e.app ?? "android"))
    return o = "https://proapi.115.com/os_linux/2.0/share/downlist", l(i, o, "GET", t, a);
  throw Error("未知客户端 app");
}
function Ed(i, e) {
  let t = p(e, ["shareUrl", "app"], !0);
  e.shareUrl && Object.assign(t, X(e.shareUrl));
  let r = null, a = null, o;
  if (["android", "web", "desktop", "aps", "115android", "ios", "115ios", "115ipad", "ipad", "harmony", "windows", "os_windows", "tv", "wechatmini", "alipaymini"].includes(e.app ?? "android"))
    return o = "https://proapi.115.com/os_windows/2.0/share/downurl", l(i, o, "GET", t, a);
  if (["chrome"].includes(e.app ?? "android"))
    return _r(i, e);
  if (["mac", "os_mac"].includes(e.app ?? "android"))
    return o = "https://proapi.115.com/os_mac/2.0/share/downurl", l(i, o, "GET", t, a);
  if (["linux", "os_linux"].includes(e.app ?? "android"))
    return o = "https://proapi.115.com/os_linux/2.0/share/downurl", l(i, o, "GET", t, a);
  throw Error("未知客户端 app");
}
function rr(i, e) {
  let t = p(e, ["shareUrl"], !0);
  e.shareUrl && Object.assign(t, X(e.shareUrl));
  let r = null, a = null, o;
  return o = "https://webapi.115.com/share/downurl", l(i, o, "GET", t, a);
}
function qd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/shareinfo", l(i, o, "GET", t, a);
}
function vd(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/share/shareinfo", l(i, o, "GET", t, a);
}
function ar(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/slist", t = { limit: 32, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Sd(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/share/slist", t = { limit: 32, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Od(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://webapi.115.com/user/notlogin_dl_quota", l(i, o, "GET", r, a);
}
function Pd(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/user/notlogin_dl_quota", l(i, o, "GET", r, a);
}
function nr(i, e) {
  let t = p(e, ["shareUrl"], !0);
  e.shareUrl && Object.assign(t, X(e.shareUrl));
  let r = null, a = null, o;
  return o = "https://webapi.115.com/share/receive", l(i, o, "POST", r, t);
}
function Gd(i, e) {
  let t = p(e, ["shareUrl", "app"], !0);
  e.shareUrl && Object.assign(t, X(e.shareUrl));
  let r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/share/receive", l(i, o, "POST", r, t);
}
function Ad(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/recvcode", c(t, "action", "cancel"), l(i, o, "GET", t, a);
}
function zd(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/share/recvcode", c(t, "action", "cancel"), l(i, o, "GET", t, a);
}
function Nd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/reshare", c(t, "ignore_warn", 1), l(i, o, "POST", r, t);
}
function lr(i, e) {
  let t = p(e, ["shareUrl"], !0);
  e.shareUrl && Object.assign(t, X(e.shareUrl));
  let r = null, a = null, o;
  return o = "https://webapi.115.com/share/search", t = { cid: 0, limit: 32, offset: 0, search_value: ".", ...t }, l(i, o, "GET", t, a);
}
function jd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/send", t = { ignore_warn: 1, is_asc: 1, order: "file_name", ...t }, l(i, o, "POST", r, t);
}
function Id(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/share/send", t = { ignore_warn: 1, is_asc: 1, order: "file_name", ...t }, l(i, o, "POST", r, t);
}
function Ud(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://webapi.115.com/share/setting", l(i, o, "GET", r, a);
}
function Rd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/is_skip_login", c(t, "file_id", 1), l(i, o, "POST", r, t);
}
function Cd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/skip_login_down", c(t, "skip_login", 1), l(i, o, "POST", r, t);
}
function Dd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/skip_login_down_first", l(i, o, "GET", t, a);
}
function Md(i, e) {
  let t = p(e, [], !0), r = null, a = null, o, n, s, d;
  return o = "https://webapi.115.com/share/skip_login_down_details", d = Ye(0), s = String(d) + " 00:00:00", n = String(Ye(1)) + " 00:00:00", t = { share_code: "", limit: 32, offset: 0, start_time: s, end_time: n, ...t }, l(i, o, "GET", t, a);
}
function ki(i, e) {
  let t = p(e, ["shareUrl"], !0);
  e.shareUrl && Object.assign(t, X(e.shareUrl));
  let r = null, a = null, o;
  return o = "https://webapi.115.com/share/snap", t = { cid: 0, limit: 32, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Ld(i, e) {
  let t = p(e, ["shareUrl", "app"], !0);
  e.shareUrl && Object.assign(t, X(e.shareUrl));
  let r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/share/snap", t = { cid: 0, limit: 32, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Wd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/share/updateshare", l(i, o, "POST", r, t);
}
function Bd(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/share/updateshare", l(i, o, "POST", r, t);
}
function Hd(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://115.com/?ct=tool&ac=clear_empty_folder", l(i, o, "GET", r, a);
}
function Fd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://aps.115.com/repeat/repeat.php", l(i, o, "POST", r, t);
}
function Jd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://aps.115.com/repeat/repeat_delete.php", l(i, o, "POST", r, t);
}
function $d(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://aps.115.com/repeat/delete_status.php", l(i, o, "GET", r, a);
}
function Kd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://aps.115.com/repeat/repeat_list.php", t = { s: 0, l: 100, ...t }, l(i, o, "GET", t, a);
}
function Vd(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://aps.115.com/repeat/repeat_status.php", l(i, o, "GET", r, a);
}
function Xd(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://115.com/?ct=tool&ac=space", l(i, o, "GET", r, a);
}
function Le(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://webapi.115.com/files/uploadinfo", l(i, o, "GET", r, a);
}
function Yd(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/app/uploadinfo", l(i, o, "GET", r, a);
}
function sr(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://115.com/api/chat/image/upload", z(!be(t, "filename")) && (t.filename = String(Ut(i)) + ".jpg"), t = { filesize: 1, width: 1, height: 1, target: "U_3_-1", userid: 11500, ...t }, l(i, o, "POST", r, t, !0);
}
function pr(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://uplb.115.com/3.0/imginitupload.php", z(!be(t, "filename")) && (t.filename = String(Ut(i)) + ".jpg"), c(t, "target", "U_4_-1"), l(i, o, "POST", r, t);
}
function Zd(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://uplb.115.com/3.0/sampleinitupload.php", z(!be(t, "filename")) && (t.filename = String(Ut(i))), c(t, "target", "U_1_0"), l(i, o, "POST", r, t);
}
function Qd(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://qrcodeapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/user/base_info", l(i, o, "GET", r, a);
}
function eu(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/user/card", l(i, o, "GET", r, a);
}
function tu(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/user/count_space_nums", l(i, o, "GET", r, a);
}
function iu(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "android", !1) + "/1.0/user/display_uid_list", l(i, o, "GET", r, a);
}
function ou(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://webapi.115.com/user/fingerprint", l(i, o, "GET", r, a);
}
function ru(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://my.115.com/proapi/3.0/index.php?method=user_info", c(t, "method", "user_info"), l(i, o, "GET", t, a);
}
async function au(i, e) {
  let t = p(e, ["app", "userId"], !0), r = null, a = null, o;
  return o = "https://home.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/user/user_info", z(!z(t)) && (t = { uid: await v(i, e) }), l(i, o, "GET", t, a);
}
function nu(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://my.115.com/?ct=ajax&ac=nav", l(i, o, "GET", r, a);
}
function lu(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://webapi.115.com/user/info", l(i, o, "GET", r, a);
}
function su(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/user/info", l(i, o, "GET", r, a);
}
function pu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://my.115.com/proapi/3.0/index.php?method=set_user", l(i, o, "POST", r, t);
}
function du(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://my.115.com/proapi/3.0/index.php?method=get_interests_list", l(i, o, "GET", r, a);
}
function uu(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://my.115.com/?ct=ajax&ac=nav", l(i, o, "GET", r, a);
}
function cu(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://my.115.com/?ct=ajax&ac=get_user_aq", l(i, o, "GET", r, a);
}
function _u(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://points.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/user/balance", l(i, o, "GET", r, a);
}
function fu(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/user/points_sign", l(i, o, "GET", r, a);
}
async function hu(i, e) {
  let t = p(e, ["app", "userId"], !1), r = null, a = null, o, n;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/user/points_sign", n = P(Date.now() / 1e3), t = { token: await i.crypto.digest("sha1", await v(i, e) + "-Points_Sign@#115-" + n), token_time: n }, l(i, o, "POST", r, t);
}
function yu(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://points.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/user/transaction", c(t, "limit", 32), l(i, o, "GET", t, a);
}
function mu(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://my.115.com/proapi/3.0/index.php?method=get_public", l(i, o, "GET", r, a);
}
function bu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://my.115.com/proapi/3.0/index.php?method=set_public", c(t, "open", 1), l(i, o, "POST", r, t);
}
function wu(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://home.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/my_star/relation_info", l(i, o, "GET", r, a);
}
async function xu(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "android", !1) + "/1.0/user/security_key_check", t.passwd = await si(i, de(t, "passwd")), l(i, o, "POST", r, t);
}
function gu(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://115.com/?ac=setting&even=saveedit&is_wl_tpl=1", l(i, o, "GET", r, a);
}
function ku(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://115.com/?ct=user_setting&ac=get", l(i, o, "GET", r, a);
}
function Tu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://115.com/?ct=setting&even=saveedit&is_wl_tpl=1", l(i, o, "POST", r, t);
}
function Eu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/user/setting", l(i, o, "GET", t, a);
}
function qu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/user/setting", l(i, o, "POST", r, t);
}
function vu(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/1.0/user/setting", l(i, o, "GET", r, a);
}
function Su(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/1.0/user/setting", l(i, o, "POST", r, t);
}
function Ou(i, e) {
  let t = p(e, [], !1), r = null, a = null, o;
  return o = "https://q.115.com/home/setting/sign", l(i, o, "GET", r, a);
}
function Pu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://q.115.com/ajax_users/save_sign", l(i, o, "POST", r, t);
}
function Gu(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/user/space_info", l(i, o, "GET", r, a);
}
function Au(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/user/teen_mode_state", l(i, o, "GET", r, a);
}
async function zu(i, e) {
  let t = p(e, ["app", "userId"], !0), r = null, a = null, o, n;
  return o = "https://passportapi.115.com/app/1.0/" + h(e, "web", !1) + "/1.0/user/teen_mode_set_state", c(t, "passwd", "0000"), z(li(String(n = de(t, "passwd")))) && (t.passwd = await i.crypto.digest("md5", String(n).padStart(4, "0") + await v(i, e) + "62454aa2c6fd4")), l(i, o, "POST", r, t);
}
function Nu(i, e) {
  let t = p(e, ["app"], !1), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/vip/check_spw", l(i, o, "GET", r, a);
}
function ju(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/user/vip_limit", l(i, o, "GET", t, a);
}
function Iu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/usershare/add_folder", l(i, o, "POST", r, t);
}
function Uu(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/add_folder", l(i, o, "POST", r, t);
}
function Ru(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/usershare/action", t = { limit: 32, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Cu(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/action", t = { limit: 32, offset: 0, ...t }, l(i, o, "GET", t, a);
}
function Du(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/usershare/copy", l(i, o, "POST", r, t);
}
function Mu(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/copy", l(i, o, "POST", r, t);
}
function Lu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/usershare/delete", l(i, o, "POST", r, t);
}
function Wu(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/delete", l(i, o, "POST", r, t);
}
function Bu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/usershare/filelist", t = { limit: 32, offset: 0, show_dir: 1, ...t }, l(i, o, "GET", t, a);
}
function Hu(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/filelist", t = { limit: 32, offset: 0, show_dir: 1, ...t }, l(i, o, "GET", t, a);
}
function Fu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/usershare/shareinfo", l(i, o, "GET", t, a);
}
function Ju(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/shareinfo", l(i, o, "GET", t, a);
}
function $u(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/usershare/invite", l(i, o, "POST", r, t);
}
function Ku(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/invite", l(i, o, "POST", r, t);
}
function Vu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/usershare/list", t = { limit: 1150, offset: 0, type: "all", ...t }, l(i, o, "GET", t, a);
}
function Xu(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/list", t = { limit: 1150, offset: 0, type: "all", ...t }, l(i, o, "GET", t, a);
}
function Yu(i, e) {
  let t = p(e, ["method"], !0), r = null, a = null, o;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? (o = "https://webapi.115.com/usershare/member", c(t, "action", "member_list"), l(i, o, "GET", t, a)) : (o = "https://webapi.115.com/usershare/member", c(t, "action", "member_list"), l(i, o, "POST", r, t));
}
function Zu(i, e) {
  let t = p(e, ["method", "app"], !0), r = null, a = null, o;
  if (!["GET", "POST"].includes(e.method ?? "POST")) throw Error("method 无效");
  return e.method === "GET" ? (o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/member", c(t, "action", "member_list"), l(i, o, "GET", t, a)) : (o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/member", c(t, "action", "member_list"), l(i, o, "POST", r, t));
}
function Qu(i, e) {
  let t = p(e, [], !0), r = null, a = null, o;
  return o = "https://webapi.115.com/usershare/share", t = { ignore_warn: 0, share_opt: 1, safe_pwd: "", ...t }, l(i, o, "POST", r, t);
}
function ec(i, e) {
  let t = p(e, ["app"], !0), r = null, a = null, o;
  return o = "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/usershare/share", t = { ignore_warn: 0, share_opt: 1, safe_pwd: "", ...t }, l(i, o, "POST", r, t);
}
const Qt = 0x8686980c0f5a24c4b9d43020cd2c22703ff3f450756529058b1cf88f09b8602136477198a6e2683149659bd122c33592fdb5ad47944ad1ea4d36c6b172aad6338c3bb6ac6227502d010993ac967d1aef00f0c8e038de2e4d3bc2ec368af2e9f10a6f1eda4f7262f136420c07c331b871bf139f74f3010e3c4fe57df3afb71683n, ei = ne(
  "f0e569aebfdcbf8a1a45e8be7da673b8de8fe7c445da86c49b648b146ab4f1aa3801359e26692c86006b4fa5363462a62a966818f24afdbd6b978f4d8f8913b76c8e93ed0e0d483ed72f88d8fefe7e8650954fd1eb832634db667b9c7e9d7a8132eab633de3aa95934663baaba816048b9d5819cf86c8477ff5478265fbee81e369f34805c452c9b76d51b8fccc3b8f5"
);
function ct(i, e) {
  const t = i.length % 4;
  return i.map((r, a) => r ^ e[(a < t ? a : a - t) % e.length]);
}
function Ti(i) {
  const e = BigInt("0x" + i.map(D).join(""));
  let t = e;
  for (let r = 0; r < 16; r++) t = t * t % Qt;
  return ne((t * e % Qt).toString(16).padStart(256, "0"));
}
function wt(i) {
  const e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  if (typeof i != "string" || !i.length || i.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(i))
    throw Error("115 密文编码无效");
  const t = [];
  for (let r = 0; r < i.length; r += 4) {
    const a = e.indexOf(i[r]) << 18 | e.indexOf(i[r + 1]) << 12 | Math.max(0, e.indexOf(i[r + 2])) << 6 | Math.max(0, e.indexOf(i[r + 3]));
    t.push(a >> 16), i[r + 2] !== "=" && t.push(a >> 8 & 255), i[r + 3] !== "=" && t.push(a & 255);
  }
  return t;
}
function ie(i) {
  const e = [];
  for (const t of encodeURIComponent(i).match(/%[0-9A-F]{2}|./g) || [])
    e.push(t.length === 3 ? parseInt(t.slice(1), 16) : t.charCodeAt(0));
  return e;
}
function ve(i) {
  const e = ct(ie(i), [141, 165, 165, 141]).reverse(), t = Array(16).fill(0).concat(
    ct(e, [120, 6, 173, 76, 51, 134, 93, 24, 76, 1, 63, 70])
  ), r = [];
  for (let a = 0; a < t.length; a += 117) {
    const o = t.slice(a, a + 117);
    r.push(
      ...Ti([0, ...Array(126 - o.length).fill(2), 0, ...o])
    );
  }
  return pe(r);
}
function Se(i) {
  const e = wt(i), t = [];
  if (e.length % 128 || e.length > 128 * 512)
    throw Error("115 密文分块无效");
  for (let o = 0; o < e.length; o += 128) {
    const n = Ti(e.slice(o, o + 128));
    let s = 0;
    for (; s < 128 && n[s] === 0; ) s++;
    const d = n.indexOf(0, s);
    if (d < 0) throw Error("115 响应填充无效");
    t.push(...n.slice(d + 1));
  }
  if (t.length < 16) throw Error("115 响应缺少密钥前缀");
  const r = Array.from(
    { length: 12 },
    (o, n) => t[n] + ei[n * 12] & 255 ^ ei[(11 - n) * 12]
  ), a = ct(
    ct(t.slice(16), r).reverse(),
    [141, 165, 165, 141]
  );
  return decodeURIComponent(a.map((o) => "%" + D(o)).join(""));
}
async function Dt(i, e, t) {
  const r = e.pickcode;
  if (typeof r != "string" || !/^[a-z0-9]+(?:,[a-z0-9]+){0,63}$/.test(r) || r.length > 2e3)
    throw Error("提取码无效");
  const a = e.userAgent ?? (await i.connection()).userAgent ?? "";
  if (typeof a != "string" || a.length > 512 || /[\r\n]/.test(a))
    throw Error("User-Agent 无效");
  let o, n;
  if (t === "open")
    o = De + "/ufile/downurl", n = { pick_code: r };
  else {
    const u = e.userId ?? T(await Le(i, {})).user_id;
    n = {
      data: ve(
        JSON.stringify({
          pickcode: r,
          ...e.shareId ? { share_id: e.shareId } : {},
          user_id: Ei(u)
        })
      )
    }, o = "https://proapi.115.com/app/chrome/downurl";
  }
  const s = await i.http.request({
    url: o,
    method: "POST",
    credential: !0,
    originReferer: !0,
    headers: {
      "User-Agent": a,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: H(n)
  });
  if (s.status !== 200) throw Error("115 HTTP " + s.status);
  const d = j(s.body);
  return t === "cookie" && !V(d) && d.data && (d.data = j(Se(d.data))), d.headers = { "user-agent": a }, d;
}
function Ei(i) {
  const e = N(i), t = Number(e);
  if (!Number.isSafeInteger(t)) throw Error("账号 ID 超出范围");
  return t;
}
async function we(i, e, t, r) {
  const a = T(await Dt(i, e, t)), o = a.data;
  if (!o || typeof o != "object" || Array.isArray(o))
    throw Error("下载链接响应无效");
  const n = [];
  for (const [s, d] of Object.entries(o)) {
    const u = d.url?.url ?? "";
    if (u && !/^https?:\/\//i.test(u)) throw Error("下载链接协议无效");
    if (!u && e.strict !== !1 && r) throw Error("所选项目是目录");
    n.push({
      id: N(s),
      pickcode: d.pick_code,
      name: d.file_name,
      size: d.file_size,
      sha1: d.sha1 ?? "",
      is_dir: !u,
      url: u,
      headers: a.headers
    });
  }
  if (r && n.length !== 1)
    throw Error("单文件动作需要恰好一个下载结果");
  return r ? n[0] : n;
}
async function qi(i, e) {
  const t = e.filename;
  if (typeof t != "string" || !t || t.length > 255 || /[/\\\r\n\x00]/.test(t))
    throw Error("需要有效文件名");
  return T(
    await l(i, "https://uplb.115.com/3.0/sampleinitupload.php", "POST", null, {
      filename: t,
      path: e.dirname ?? "",
      target: "U_1_" + N(e.pid ?? "0")
    })
  );
}
async function dr(i, e) {
  const t = await qi(i, e), r = {
    name: e.filename,
    key: t.object,
    policy: t.policy,
    OSSAccessKeyId: t.accessid,
    success_action_status: "200",
    callback: t.callback,
    signature: t.signature
  };
  if (Object.values(r).some((n) => typeof n != "string" || !n))
    throw Error("115 上传票据缺少必要字段");
  const a = String(t.host).replace(/^http:\/\//, "https://"), o = await i.http.request({
    method: "POST",
    url: a,
    multipart: { filename: e.filename, fields: r }
  });
  if (o.status !== 200)
    throw Error("OSS 上传结果需核对，HTTP " + o.status);
  return T(j(o.body));
}
async function Pe(i, e, t, r) {
  const a = await we(i, e, t, !0), o = Number(a.size), n = G(e.offset ?? 0, 0, o);
  if (!Number.isSafeInteger(o)) throw Error("文件长度超出安全整数范围");
  const s = r === "hash", d = G(
    e.length ?? (s ? o - n : Math.min(65536, o - n)),
    0,
    s ? o - n : Math.min(65536, o - n)
  ), u = {
    url: a.url.replace(/^http:\/\//i, "https://"),
    userAgent: a.headers["user-agent"],
    offset: n,
    length: d
  };
  if (s && (u.digests = e.digests ?? ["sha1"]), s && (!Array.isArray(u.digests) || !u.digests.length))
    throw Error("至少选择一个摘要算法");
  const _ = await i.http.readContent(u);
  if (s) return _;
  const m = {
    ..._,
    nextOffset: n + d < o ? n + d : null
  };
  if (r === "text") {
    const w = _.base64 ? wt(_.base64) : [];
    m.text = decodeURIComponent(
      w.map((g) => "%" + D(g)).join("")
    ), delete m.base64;
  }
  return m;
}
async function Ge(i, e, t) {
  const r = e.userAgent ?? (await i.connection()).userAgent ?? "", a = { "User-Agent": r }, o = { ...e.payload ?? {} }, n = {
    method: "GET",
    headers: a,
    linkMeta: !0,
    credential: !0,
    originReferer: !0
  };
  if (t === "redirect")
    n.url = "https://115.com/?ct=download&ac=video&" + H({ pickcode: e.pickcode, app_ver: Z });
  else if (t === "team")
    n.url = te + "/usershare/download", n.method = "POST", n.body = H({ share_id: e.shareId, pick_code: e.pickcode });
  else if (t === "extract-app" || t === "extract-web") {
    const _ = t === "extract-app" ? "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/extract_down_file" : te + "/files/extract_down_file";
    n.url = _ + "?" + H({
      ...p({ payload: o }, [], !0),
      app_ver: Z
    });
  } else {
    const _ = { pickcode: e.pickcode };
    if (n.method = e.method ?? "POST", n.url = te + "/files/download", n.method === "POST")
      n.body = H({ data: ve(JSON.stringify(_)) });
    else if (n.method === "GET")
      n.url += "?" + H({ ..._, app_ver: Z });
    else throw Error("仅允许 GET 或 POST");
  }
  n.method === "POST" && (a["Content-Type"] = "application/x-www-form-urlencoded");
  const s = await i.http.request(n), d = { "user-agent": r };
  if (s.mediaCookie && (d.cookie = s.mediaCookie), t === "redirect")
    return s.status === 302 && s.location ? { state: !0, url: s.location, headers: d } : { state: !1, errno: 31003, response: { status: s.status } };
  if (s.status !== 200) throw Error("获取下载链接 HTTP " + s.status);
  const u = j(s.body);
  return t === "file" && n.method === "POST" && !V(u) && u.data && (u.data = j(Se(u.data))), { ...u, headers: d };
}
async function rt(i, e, t) {
  const r = { ...e.payload, ...e.shareUrl ? X(e.shareUrl) : {} }, a = e.app === "" ? "" : h(e, t === "regular" ? "android" : "chrome", !1);
  let o;
  if (t === "regular")
    if (a === "web" || a === "desktop") o = await rr(i, { payload: r });
    else if (a === "" || a === "chrome")
      o = await l(i, "https://proapi.115.com/app/share/downurl", "POST", null, { data: ve(JSON.stringify(r)) }), !V(o) && o.data && (o.data = j(Se(o.data)));
    else {
      const s = ["windows", "mac", "linux", "os_windows", "os_mac", "os_linux"].includes(a) ? h(e, "android", !0) : "os_windows";
      o = await l(i, "https://proapi.115.com/" + s + "/2.0/share/downurl", "GET", r, null);
    }
  else if (t === "web" || t === "skip" && ["web", "desktop"].includes(a))
    o = await J(i, te + "/share/skip_login_downurl", "POST", null, r);
  else {
    const s = a === "chrome" || a === "";
    o = await J(i, s ? "https://proapi.115.com/app/share/skip_login_downurl" : "https://proapi.115.com/" + h(e, "chrome", !0) + "/2.0/share/skip_login_downurl", "POST", null, s ? { data: ve(JSON.stringify(r)) } : r), s && !V(o) && o.data && (o.data = j(Se(o.data)));
  }
  if (t === "app" || t === "web") return o;
  const n = T(o).data;
  if (!n) throw Error("分享文件不存在");
  if (!n.url && e.strict !== !1) throw Error("所选项目是目录");
  return { url: n.url?.url || "", id: String(n.fid), name: n.fn, size: n.fs, sha1: n.sha1 || "", is_dir: !n.url };
}
async function xt(i, e) {
  const t = { pick_code: e.pickcode, file_name: (e.path || "").replace(/^\/+|\/+$/g, ""), paths: "文件", next_marker: e.nextMarker || "", page_count: Number.isInteger(e.pageCount) && e.pageCount >= 1 && e.pageCount <= 999 ? e.pageCount : 999 };
  return ["", "web", "desktop", "aps"].includes(e.app ?? "web") ? await xo(i, { payload: t }) : await go(i, { payload: t, app: e.app });
}
async function vi(i, e, t) {
  const r = h(e, "web", !1), a = t ? "https://ictxl.115.com/app/1.1/" + r + "/1.2/upload/set_avatar" : "https://credentials.115.com/api/1.0/" + r + "/1.0/credentials/upload_images", o = await i.http.request({ url: a, method: "POST", credential: !0, multipart: { filename: "a.jpg", field: t ? "file" : "image" } });
  if (o.status !== 200) throw Error("115 HTTP " + o.status);
  return j(o.body);
}
async function ur(i, e) {
  const t = { ac: "security_code", type: "web", ctype: "web", client: "web", ...e.payload };
  return Object.hasOwn(t, "sign") || (t.sign = (await yo(i, {})).sign), l(i, te + "/user/captcha", "POST", null, t);
}
async function cr(i, e, t, r, a) {
  const o = e.filename, n = N(e.pid ?? "0"), s = {
    filename: o,
    sizeBytes: r.size,
    sha1: a,
    remoteDir: n,
    dirname: e.dirname ?? ""
  }, d = t === "cookie" ? T(await Le(i, {})) : null, u = {};
  for (let _ = 0; _ < 2; _++) {
    const m = d ? await It(i, s, d, u) : T(
      await l(i, De + "/upload/init", "POST", null, {
        file_name: o,
        fileid: a,
        file_size: r.size,
        target: "U_1_" + n,
        path: s.dirname,
        topupload: 1,
        ...u
      })
    ).data;
    if (!m || V(m)) throw Error("115 拒绝初始化上传");
    if (m.status === 1 || m.status === 2) return m;
    const w = /^(?:bytes=)?(\d+)-(\d+)$/.exec(m.sign_check);
    if (_ || m.status !== 7 || !m.sign_key || !w)
      throw Error("115 上传挑战无效");
    const g = Number(w[1]), x = Number(w[2]);
    u.sign_key = m.sign_key, u.sign_val = (await i.fs.hashRange("@source", g, x - g + 1, "sha1")).toUpperCase();
  }
}
async function Ot(i, e) {
  const t = e === "open" ? T(await l(i, De + "/upload/get_token", "GET", null, null)) : await ao(i, {}), r = t.data ?? t, a = r.SecurityToken ?? r.security_token, o = r.AccessKeyId ?? r.access_key_id, n = r.AccessKeySecret ?? r.access_key_secret;
  if (!a || !o || !n) throw Error("OSS 短期签名凭据无效");
  return { token: a, key: o, secret: n };
}
async function le(i, e, t, r, a = {}, o = {}) {
  if (t.bucket !== "fhnfile" || typeof t.object != "string" || !/^[\w./-]+$/.test(t.object) || t.object.split("/").some((q) => !q || q === ".."))
    throw Error("未授权的 OSS 对象");
  const n = Ue(a), s = Ue(Object.fromEntries(Object.entries(a).filter(([q]) => !["max-parts", "part-number-marker"].includes(q)))), d = "/" + t.object, u = (/* @__PURE__ */ new Date()).toUTCString(), _ = {
    "x-oss-security-token": e.token,
    ...o.ossHeaders ?? {}
  }, m = Object.keys(_).sort().map((q) => q + ":" + _[q]).join(`
`), w = o.type ?? "", g = [
    r,
    "",
    w,
    u,
    m,
    "/" + t.bucket + d + (s ? "?" + s : "")
  ].join(`
`);
  _.date = u, _.authorization = "OSS " + e.key + ":" + pe(ne(await i.crypto.hmacSHA1(e.secret, g))), w && (_["content-type"] = w);
  const x = "https://fhnfile.oss-cn-shenzhen.aliyuncs.com" + d + (n ? "?" + n : ""), k = await i.http.request({
    url: x,
    method: r,
    transfer: !0,
    headers: _,
    ...o.body ? { body: o.body } : {},
    ...o.range ? { sourceRange: o.range } : {}
  });
  if (k.status < 200 || k.status >= 300)
    throw Error("OSS HTTP " + k.status);
  return k;
}
function Pt(i) {
  if (typeof i.callback?.callback != "string" || typeof i.callback.callback_var != "string")
    throw Error("缺少上传回调");
  return {
    "x-oss-callback": pe(ie(i.callback.callback)),
    "x-oss-callback-var": pe(ie(i.callback.callback_var))
  };
}
async function Mt(i, e, t) {
  const r = await at(i, e, t), a = await i.fs.sourceInfo(), o = r.pickcode ?? r.pick_code ?? null;
  if (r.status === 2) return { outcome: "reused", pickcode: o, size: a.size, data: r };
  const n = { bucket: r.bucket, object: r.object, callback: r.callback }, s = G(e.partSize ?? 8388608, 102400, 134217728);
  if (Math.ceil(a.size / s) > 2e3) throw Error("请提高 partSize，分片最多 2000 个");
  const d = await Ot(i, t), u = Pt(n);
  let _;
  if (!a.size) _ = await le(i, d, n, "PUT", {}, { ossHeaders: u, range: { offset: 0, length: 0 } });
  else {
    const m = await le(i, d, n, "POST", { sequential: "1", uploads: "1" }), w = /<UploadId>([A-Za-z0-9._-]+)<\/UploadId>/.exec(m.body)?.[1];
    if (!w) throw Error("OSS 未返回上传 ID");
    const g = [];
    try {
      for (let x = 0; x < a.size; x += s) {
        const k = g.length + 1, q = await le(i, d, n, "PUT", { partNumber: k, uploadId: w }, { range: { offset: x, length: Math.min(s, a.size - x) } });
        if (!/^"?(?:[A-Fa-f0-9]{32})"?$/.test(q.etag ?? "")) throw Error("分片 ETag 无效");
        g.push("<Part><PartNumber>" + k + "</PartNumber><ETag>" + q.etag + "</ETag></Part>");
      }
    } catch (x) {
      try {
        await le(i, d, n, "DELETE", { uploadId: w });
      } catch {
      }
      throw x;
    }
    _ = await le(i, d, n, "POST", { uploadId: w }, { ossHeaders: u, type: "text/xml", body: "<CompleteMultipartUpload>" + g.join("") + "</CompleteMultipartUpload>" });
  }
  return { outcome: "uploaded", pickcode: o, size: a.size, data: T(j(_.body)) };
}
async function at(i, e, t) {
  if (typeof e.filename != "string" || !e.filename || e.filename.length > 255 || /[\/\\\x00\r\n]/.test(e.filename))
    throw Error("需要有效文件名");
  const r = await i.fs.sourceInfo(), a = (await i.fs.sourceSHA1()).toUpperCase();
  if (e.sha1 && String(e.sha1).toUpperCase() !== a)
    throw Error("源文件 SHA-1 不匹配");
  return cr(i, e, t, r, a);
}
function tc(i, e) {
  return S(e, "url"), Yi(i, e.url);
}
function ic(i, e) {
  return ar(i, { payload: { offset: e.offset ?? 0, limit: e.limit ?? 30, ...e.payload } });
}
async function oc(i, e) {
  return ((await i.connection()).kind === "cookie" ? yi : fi)(i, { payload: { page: e.page ?? 1, page_size: e.pageSize ?? 30, stat: e.stat ?? 0, ...e.payload } });
}
function rc(i, e) {
  return S(e, "filename"), S(e, "sizeBytes"), S(e, "sha1"), Ki(i, e);
}
function ac(i, e) {
  return S(e, "pickcode"), we(i, e, "cookie", !0);
}
function nc(i, e) {
  return S(e, "pickcode"), we(i, e, "cookie", !1);
}
function lc(i, e) {
  return S(e, "pickcode"), Dt(i, e, "cookie");
}
function sc(i, e) {
  return S(e, "pickcode"), Pe(i, e, "cookie", "range");
}
function pc(i, e) {
  return S(e, "pickcode"), Pe(i, e, "cookie", "text");
}
function dc(i, e) {
  return S(e, "pickcode"), Pe(i, e, "cookie", "hash");
}
function uc(i, e) {
  return S(e, "filename"), at(i, e, "cookie");
}
function cc(i, e) {
  return S(e, "filename"), Mt(i, e, "cookie");
}
function _c(i, e) {
  return S(e, "pickcode"), we(i, e, "open", !0);
}
function fc(i, e) {
  return S(e, "pickcode"), we(i, e, "open", !1);
}
function hc(i, e) {
  return S(e, "pickcode"), Dt(i, e, "open");
}
function yc(i, e) {
  return S(e, "pickcode"), Pe(i, e, "open", "range");
}
function mc(i, e) {
  return S(e, "pickcode"), Pe(i, e, "open", "text");
}
function bc(i, e) {
  return S(e, "pickcode"), Pe(i, e, "open", "hash");
}
function wc(i, e) {
  return S(e, "filename"), at(i, e, "open");
}
function xc(i, e) {
  return S(e, "filename"), Mt(i, e, "open");
}
function gc(i, e) {
  return Ge(i, e, "file");
}
function kc(i, e) {
  return Ge(i, e, "redirect");
}
function Tc(i, e) {
  return Ge(i, e, "team");
}
function Ec(i, e) {
  return Ge(i, e, "extract-web");
}
function qc(i, e) {
  return Ge(i, e, "extract-app");
}
function vc(i, e) {
  return S(e, "filename"), qi(i, e);
}
function Sc(i, e) {
  return S(e, "filename"), dr(i, e);
}
function Oc(i, e) {
  return S(e, "payload"), rt(i, e, "regular");
}
function Pc(i, e) {
  return S(e, "payload"), rt(i, e, "skip");
}
function Gc(i, e) {
  return S(e, "payload"), rt(i, e, "web");
}
function Ac(i, e) {
  return S(e, "payload"), rt(i, e, "app");
}
function zc(i, e) {
  return S(e, "pickcode"), xt(i, e);
}
function Nc(i, e) {
  return vi(i, e, !0);
}
function jc(i, e) {
  return vi(i, e, !1);
}
function Ic(i, e) {
  return S(e, "payload"), ur(i, e);
}
function Uc(i, e) {
  return S(e, "fileId"), l(i, te + "/files/score", "POST", null, { file_id: (Array.isArray(e.fileId) ? e.fileId : [e.fileId]).map(N).join(","), score: e.score ?? 0 });
}
function Rc(i, e) {
  return S(e, "pickcode"), tt(i, "https://115.com/api/video/m3u8/" + encodeURIComponent(e.pickcode) + ".m3u8?definition=" + encodeURIComponent(e.definition ?? 0), "GET", null, null, !0);
}
async function _r(i, e) {
  const t = { ...e.payload, ...e.shareUrl ? X(e.shareUrl) : {} }, r = await l(i, "https://proapi.115.com/app/share/downurl", "POST", null, { data: ve(JSON.stringify(t)) });
  return !V(r) && r.data && (r.data = j(Se(r.data))), r;
}
async function Si(i, e, t) {
  const r = t === "open" ? "pick_code" : "pickcode", a = typeof e.payload == "string" ? { [r]: e.payload } : { ...e.payload };
  a[r] ??= a[t === "open" ? "pickcode" : "pick_code"];
  const o = a.callback_var ?? a.callback?.callback_var;
  if (o) {
    const n = typeof o == "string" ? j(o) : o;
    a[r] = n["x:pick_code"], a.target = n["x:target"], t === "cookie" && (a.userid = n["x:user_id"]);
  }
  return delete a.callback, delete a.callback_var, a.fileid ??= "0".repeat(40), a[t === "open" ? "file_size" : "filesize"] ??= 1, a.target ??= "U_1_0", t === "cookie" && (a.userid ??= await v(i, e)), l(i, t === "open" ? De + "/upload/resume" : "https://uplb.115.com/3.0/resumeupload.php", "POST", null, a);
}
async function Oi(i, e) {
  const t = { appid: 0, target: "U_1_0", sign_key: "", sign_val: "", topupload: "true", appversion: Z, ...e.payload };
  if (!t.userid || !t.userkey) {
    const s = T(await Le(i, {}));
    t.userid ??= s.user_id, t.userkey ??= s.userkey;
  }
  t.t = Math.floor(Date.now() / 1e3), t.sig = (await i.crypto.digest("sha1", t.userkey + await i.crypto.digest("sha1", String(t.userid) + t.fileid + t.target + "0") + "000000")).toUpperCase(), t.token = await i.crypto.digest("md5", "Qclm8MGWUv59TnrR0XPg" + t.fileid + t.filesize + t.sign_key + t.sign_val + t.userid + t.t + await i.crypto.digest("md5", String(t.userid)) + t.appversion);
  const r = Ue(Object.fromEntries(Object.entries(t).filter(([, s]) => z(s)))), a = (16 - ie(r).length % 16) % 16, o = await i.crypto.aesCBC("encrypt", je, Ie, ie(r).map(D).join("") + D(a).repeat(a)), n = await Xe(i, "https://uplb.115.com/4.0/initupload.php?k_ec=" + qe(Nt(t.t)), {
    method: "POST",
    bodyHex: o,
    response: "hex",
    headers: { "Content-Type": "application/x-www-form-urlencoded", "User-Agent": "Mozilla/5.0 115disk/" + t.appversion + " 115Browser/" + t.appversion + " 115wangpan_android/" + t.appversion }
  });
  return typeof n == "string" ? jt(await i.crypto.aesCBC("decrypt", je, Ie, n)) : n;
}
function Gt(i, e, t = !0, r = []) {
  for (const [a, o] of Object.entries(i)) {
    const n = e && !a.startsWith(e + "[") ? e + "[" + a + "]" : a;
    Array.isArray(o) ? o.forEach((s, d) => {
      const u = n + "[" + (t ? d : "") + "]";
      s && typeof s == "object" ? Gt(s, u, t, r) : r.push([u, s]);
    }) : o && typeof o == "object" ? Gt(o, n, t, r) : r.push([n, o]);
  }
  return r;
}
function Pi(i, e, t) {
  const r = typeof e.payload == "string" ? [["form[content]", e.payload]] : Gt(e.payload, "form");
  return !t && !r.some(([a]) => a === "form[user_time]") && r.push(["form[user_time]", Math.floor(Date.now() / 1e3)]), l(i, "https://life.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/diary/" + (t ? "edit" : "add"), "POST", null, r);
}
function Lt(i, e, t) {
  const r = typeof e.payload == "string" ? [["name[]", e.payload]] : Array.isArray(e.payload) ? e.payload.map((a) => Array.isArray(a) ? a : ["name[]", a]) : e.payload;
  return l(i, t ? "https://proapi.115.com/" + h(e, "android", !0) + "/label/add_multi" : te + "/label/add_multi", "POST", null, r);
}
async function fr(i, e) {
  const t = typeof e.payload == "string" ? { pickcode: e.payload } : { ...e.payload };
  t.user_id = await v(i, e);
  const r = await l(i, "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/video/play", "POST", null, { data: ve(JSON.stringify(t)) });
  return (!V(r) || Number(r.errno) === 409) && r.data && (r.data = j(Se(r.data))), r;
}
async function hr(i, e) {
  if (typeof e.pickcode != "string" || typeof e.path != "string") throw y("需要压缩包提取码和文件路径");
  const t = e.path.replace(/\/+$/, ""), r = e.app ?? "android", a = T(await Ge(i, { app: r, userAgent: e.user_agent, payload: { pick_code: e.pickcode, full_name: t.replace(/^\/+/, "") } }, ["web", "desktop"].includes(r) ? "extract-web" : "extract-app"));
  if (typeof a.data?.url != "string") throw y("文件不存在、是目录或者不支持下载", "not_found");
  return { url: encodeURI(a.data.url).replace(/[!'()*;,@+$]/g, (n) => "%" + n.charCodeAt(0).toString(16).toUpperCase()).replaceAll("%25", "%"), name: t.slice(t.lastIndexOf("/") + 1), path: t, headers: a.headers };
}
async function Gi(i, e) {
  const t = String(e.dirname ?? "").replace(/^\/+|\/+$/g, ""), r = typeof e.files == "string" ? [e.files] : e.files ?? [], a = typeof e.dirs == "string" ? [e.dirs] : e.dirs ?? [], o = [["pick_code", e.pickcode], ["paths", t ? "文件/" + t : "文件"], ["to_pid", e.to_pid ?? "0"]];
  let n = [...r.filter(Boolean).map((s) => ({ name: s, dir: !1 })), ...a.filter(Boolean).map((s) => ({ name: s, dir: !0 }))];
  if (!n.length) {
    let s = "";
    const d = /* @__PURE__ */ new Set();
    do {
      const u = T(await xt(i, { pickcode: e.pickcode, path: t, nextMarker: s, app: e.app }));
      if (n.push(...u.data.list.map((_) => ({ name: _.file_name, dir: !Number(_.file_category) }))), s = u.data.next_marker ?? "", s && d.has(s)) throw y("压缩包分页未前进", "upstream");
      if (d.add(s), n.length > 1e4) throw y("请按 files/dirs 分批解压", "conflict");
    } while (s);
  }
  return o.push(...n.map((s) => [s.dir ? "extract_dir[]" : "extract_file[]", s.name.replace(/^\/+|\/+$/g, "")])), l(i, ["", "web", "desktop", "aps"].includes(e.app ?? "web") ? te + "/files/add_extract_file" : "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/ufile/add_extract_file", "POST", null, o);
}
async function Wt(i, e, t) {
  const r = /^[US]_/.test(e.pid ?? "") ? e.pid : e.share_id ? "S_" + e.share_id + "_" + (e.pid ?? 0) : e.pid !== void 0 ? "U_1_" + e.pid : t ? "U_3_-1" : "U_4_-1", a = { filename: e.filename ?? "1.jpg", path: e.dirname ?? "", target: r }, o = T(await (t ? sr : pr)(i, { payload: a })), n = { key: o.object, policy: o.policy, OSSAccessKeyId: o.accessid, signature: o.signature, callback: o.callback, ...t ? { host: o.host } : { name: a.filename, success_action_status: "200" } }, s = await i.http.request({ url: o.host.replace(/^http:/, "https:"), method: "POST", multipart: { filename: a.filename, field: "file", fields: n } });
  if (s.status !== 200) throw y("图片上传结果需核对，HTTP " + s.status, "upstream");
  return { ...j(s.body), oss_info: o };
}
async function gt(i) {
  const e = await Qo(i, {});
  return V(e) ? null : e.data?.list?.find((t) => Number(t.is_current) === 1) ?? null;
}
async function nt(i, e, t, r = !1) {
  const o = T(await (t ? await Rt(i, { payload: { client_id: e.app_id ?? 100195125 } }) : await ci(i, {}))).data.uid, n = T(await to(i, { payload: { uid: o } }));
  return r ? { app_id: e.app_id ?? 100195125, name: String(n.data.tip_txt ?? "").replace(/^\uFEFF/, "").slice(0, -10), icon: n.data.icon } : (T(await io(i, { payload: { uid: o } })), e.uidOnly ? o : t ? await ui(i, { payload: { uid: o } }) : await mt(i, { uid: o, app: e.app ?? (await gt(i))?.icon ?? "alipaymini", loginExchange: !1 }));
}
async function Bt(i, e, t) {
  if (!e.session) {
    const o = T(await (t ? await Rt(i, { payload: { client_id: e.app_id ?? 100195125 } }) : await ci(i, {})));
    return { stage: "scan", session: o.data, qrcode: o.data.qrcode ?? "https://115.com/scan/dg-" + o.data.uid };
  }
  const r = T(await di(i, e.session)).data?.status;
  if (r === -1 || r === -2) return { stage: r === -1 ? "expired" : "cancelled", session: e.session };
  if (r !== 2) return { stage: r === 1 ? "confirm" : "scan", session: e.session };
  const a = await (t ? await ui(i, { payload: { uid: e.session.uid } }) : await mt(i, { uid: e.session.uid, app: e.app ?? "alipaymini" }));
  return { stage: "complete", result: T(a) };
}
function Cc(i, e) {
  return Si(i, e, "cookie");
}
function Dc(i, e) {
  return Si(i, e, "open");
}
function Mc(i, e) {
  return Oi(i, e);
}
function Lc(i, e) {
  return l(i, "https://proapi.115.com/" + h(e, "android", !0) + "/2.0/user/upload_key", "GET", null, null);
}
function Wc(i, e) {
  return Pi(i, e, !1);
}
function Bc(i, e) {
  return Pi(i, e, !0);
}
function Hc(i, e) {
  return Lt(i, e, !1);
}
function Fc(i, e) {
  return Lt(i, e, !0);
}
function Jc(i, e) {
  return Oo(i, { payload: Object.fromEntries((Array.isArray(e.ids) ? e.ids : [e.ids]).map((t) => ["show_play_long[" + N(t) + "]", e.is_set ?? 1])) });
}
function $c(i, e) {
  return l(i, te + "/user/report", "GET", { month: e.month ?? new Date(Date.UTC(Number(Ye(0).slice(0, 4)), Number(Ye(0).slice(5, 7)) - 2, 1)).toISOString().slice(0, 7).replace("-", "") }, null);
}
function Kc(i, e) {
  return fr(i, e);
}
function Vc(i, e) {
  return Gi(i, e);
}
function Xc(i, e) {
  return Wt(i, e, !0);
}
function Yc(i, e) {
  return Wt(i, e, !1);
}
function Zc(i, e) {
  return we(i, { ...e, pickcode: Array.isArray(e.pickcodes) ? e.pickcodes.join(",") : e.pickcodes, shareId: e.share_id, userAgent: e.user_agent }, "cookie", !1);
}
function Qc(i, e) {
  return we(i, { ...e, shareId: e.share_id, userAgent: e.user_agent }, "cookie", !0);
}
function e_(i, e) {
  return hr(i, e);
}
function t_(i, e) {
  return gt(i);
}
async function i_(i, e) {
  return await (await gt(i))?.icon ?? null;
}
async function o_(i, e) {
  return !!(await l(i, "https://my.115.com/?ct=guide&ac=status", "GET", null, null)).state;
}
function r_(i, e) {
  return nt(i, { ...e, uidOnly: !0 }, !1);
}
function a_(i, e) {
  return nt(i, e, !1);
}
function n_(i, e) {
  return nt(i, e, !0);
}
function l_(i, e) {
  return nt(i, e, !0, !0);
}
function s_(i, e) {
  return mt(i, e);
}
function p_(i, e) {
  return Bt(i, e, !1);
}
function d_(i, e) {
  return Bt(i, e, !0);
}
function u_(i, e) {
  return _i(i, { payload: { refresh_token: e.refresh_token } });
}
function Y(i) {
  if (typeof i != "string" || !/^[-+]?\d+$/.test(i)) return i;
  const e = Number(i);
  return Number.isSafeInteger(e) ? e : i;
}
function yr(i) {
  return typeof i == "string" && /^-?(?:0|[1-9]\d*)$/.test(i) ? Y(i) : i;
}
function Ai(i) {
  return i ? typeof i == "string" ? ti[Ze(i)] ?? 99 : i.is_dir ? 0 : Tr[i.class] ?? ti[Ze(String(i.name)).toLowerCase()] ?? (i.is_video || Object.hasOwn(i, "defination") ? 4 : 99) : 0;
}
function Ze(i) {
  const e = i.lastIndexOf(".");
  return e > 0 && /[^.]/.test(i.slice(0, e)) ? i.slice(e) : "";
}
function _e(i, e = {}) {
  if (i.id !== void 0 && i.name !== void 0 && i.is_dir !== void 0) return { ...i, id: N(i.id), parent_id: N(i.parent_id ?? 0) };
  const t = e.kind ?? (Object.hasOwn(i, "fn") ? "app" : Object.hasOwn(i, "file_id") || Object.hasOwn(i, "category_id") ? "app2" : "web"), r = Object.hasOwn(i, "fc") ? Number(i.fc) === 0 : Object.hasOwn(i, "file_category") ? Number(i.file_category) === 0 : Object.hasOwn(i, "sha") ? !i.sha : Object.hasOwn(i, "sha1") ? !i.sha1 : Object.hasOwn(i, "file_sha1") ? !i.file_sha1 : t === "web" && Object.hasOwn(i, "cid") ? !Object.hasOwn(i, "fid") : t === "app2" && Object.hasOwn(i, "category_id") ? !Object.hasOwn(i, "file_id") : !["s", "fs", "file_size", "size"].some((d) => Object.hasOwn(i, d)), a = {
    ...e.default,
    is_dir: r,
    id: N(t === "web" ? r ? i.cid : i.fid : t === "app" ? i.fid : i.file_id ?? i.category_id),
    parent_id: N(t === "web" ? r ? i.pid : i.cid : t === "app" ? i.pid : i.parent_id ?? i.category_id ?? 0),
    name: t === "web" ? i.n || i.fn || i.file_name : t === "app" ? i.fn || i.n || i.file_name : i.file_name ?? i.category_name,
    sha1: t === "web" ? i.sha || i.sha1 || "" : i.sha1 || i.sha || i.file_sha1 || "",
    size: Y(t === "app2" ? i.file_size || 0 : t === "app" ? i.fs || i.s || 0 : i.s || i.fs || 0)
  };
  if (typeof a.name != "string") throw y("115 文件信息缺少名称", "upstream");
  const o = t === "app2" ? i.pick_code : i.pc;
  o !== void 0 && (a.pickcode = o);
  const n = t === "web" ? { ctime: i.tp, mtime: i.te } : t === "app" ? { ctime: i.uppt, mtime: i.upt } : { ctime: i.user_pptime ?? i.pptime, mtime: i.user_ptime ?? i.ptime };
  for (const [d, u] of Object.entries(n)) u !== void 0 && (a[d] = Y(u));
  const s = t === "web" ? i.c : t === "app" ? i.ic : i.is_collect;
  if (s !== void 0 && (a.is_collect = Y(s)), !e.simple) {
    a.ico = i.ico ?? (r ? "folder" : ""), o !== void 0 && (a.pick_code = o), a.ctime !== void 0 && (a.user_ptime = a.ctime), a.mtime !== void 0 && (a.user_utime = a.mtime);
    for (const [d, u] of Er[t]) Object.hasOwn(i, d) && (a[u] = yr(i[d]));
    if (t === "web")
      i.to !== void 0 && (a.atime = a.user_otime = Y(i.to)), i.tu !== void 0 && (a.utime = Y(i.tu)), i.t && (a.time = Y(i.t)), i.fdes !== void 0 && (typeof i.fdes == "string" && (a.desc = i.fdes), a.has_desc = i.fdes ? 1 : 0), i.vdi && (a.defination = i.vdi, a.defination_str = { 1: "video-sd", 2: "video-hd", 3: "video-fhd", 4: "video-1080p", 5: "video-4k", 100: "video-origin" }[i.vdi] ?? "video-sd");
    else if (t === "app")
      i.uet !== void 0 && (a.utime = Y(i.uet)), i.thumb !== void 0 && (a.thumb = i.thumb.startsWith("?") ? "https://imgjump.115.com" + i.thumb + "&size=0&sha1=" + a.sha1 : i.thumb);
    else {
      (i.user_utime !== void 0 || i.utime !== void 0) && (a.utime = Y(i.user_utime ?? i.utime)), i.real_user_ptime !== void 0 && (a.time = Y(i.real_user_ptime));
      const d = r ? i.category_desc : i.file_description, u = r ? i.category_cover : i.music_cover;
      d !== void 0 && (a.desc = d), u !== void 0 && (a.cover = u), !r && i.thumb_url !== void 0 && (a.thumb = i.thumb_url), !r && i.file_tag !== void 0 && (a.file_type = Y(i.file_tag)), i.fl !== void 0 && (a.labels = i.fl), a.is_mark !== void 0 && (a.star = a.is_mark);
    }
  }
  return t === "web" && i.star_time !== void 0 && (a.star_time = Y(i.star_time || 0)), a.type = t === "app2" && i.type !== void 0 ? i.type : r ? 0 : t === "web" && (i.iv || Object.hasOwn(i, "vdi")) ? 4 : t === "app" && i.thumb?.startsWith("?") || t === "app2" && Object.hasOwn(i, "thumb_url") ? 2 : t === "app" && Object.hasOwn(i, "muc") || t === "app2" && (Object.hasOwn(i, "music_cover") || Object.hasOwn(i, "play_url")) ? 3 : t === "app" && (i.isv || ["def", "def2", "v_img"].some((d) => Object.hasOwn(i, d))) || t === "app2" && (i.is_video || ["definition", "definition2", "video_img_url"].some((d) => Object.hasOwn(i, d))) ? 4 : Ai(a), e.keep_raw && (a.raw = i), a;
}
function ue(i) {
  return String(i).replace(/\\/g, "\\\\").replace(/\//g, "\\/").replace(/^\.{1,2}$/, (e) => "\\" + e);
}
function Ht(i) {
  if (Array.isArray(i)) return i.map((n) => ({ name: String(n), quoted: !0 }));
  const e = [];
  let t = "", r = !1, a = !1;
  for (const n of String(i))
    r ? (t += n, r = !1, a = !0) : n === "\\" ? r = !0 : n === "/" ? (e.push({ name: t, quoted: a }), t = "", a = !1) : t += n;
  r && (t += "\\"), e.push({ name: t, quoted: a });
  const o = [];
  for (const n of e)
    !n.name || n.name === "." && !n.quoted || o.push(n);
  return o;
}
function Ae(i) {
  return Ht(i).map((e) => e.name);
}
function _t() {
  return { id: "0", parent_id: "0", name: "", is_dir: !0, sha1: "", size: 0, pickcode: "", type: 0 };
}
async function kt(i, e, t = {}) {
  if (e = N(e), e === "0") return _t();
  const r = T(await No(i, { payload: { file_id: e } })), a = Array.isArray(r.data) ? r.data[0] : r.data;
  if (!a) throw y("文件或目录不存在", "not_found");
  return _e(a, t);
}
async function oe(i, e) {
  const t = e.scope ?? {}, r = t.kind === "zip" ? String(e.id ?? e.path ?? "/") : N(e.id ?? e.cid ?? 0), a = G(e.cursor?.offset ?? e.offset ?? 0, 0, Number.MAX_SAFE_INTEGER), o = G(e.limit ?? 200, 1, 1e3);
  let n, s, d, u;
  if (t.kind === "share")
    n = T(await ki(i, { payload: { ...X(t.url ?? t.share_code), receive_code: t.receive_code ?? X(t.url ?? t.share_code).receive_code, cid: r, offset: a, limit: o, ...e.payload } })), s = n.data?.list ?? [], d = Number(n.data?.count ?? n.count ?? s.length), u = a + s.length < d ? a + s.length : null;
  else if (t.kind === "zip") {
    const _ = r === "0" ? "/" : r;
    n = T(await xt(i, { pickcode: t.pickcode, path: Ae(_).join("/"), nextMarker: e.cursor?.marker ?? e.marker ?? "", pageCount: o, app: e.app })), s = (n.data?.list ?? []).map((w) => ({ ...w, file_id: w.file_id ?? w.file_name, parent_id: r }));
    const m = s.map((w) => ({ id: (_ === "/" ? "" : _) + "/" + ue(w.file_name), parent_id: _, name: w.file_name, is_dir: Number(w.file_category) === 0, size: Y(w.file_size ?? 0), sha1: w.sha1 ?? "" }));
    return u = n.data?.next_marker || null, { items: m, next: u, cursor: u === null ? null : { marker: u }, complete: u === null, total: null, ...e.get_raw ? { raw: n } : {} };
  } else {
    const _ = (await i.connection()).kind;
    n = T(await (_ === "bearer" ? await no(i, { payload: { cid: r, offset: a, limit: o, show_dir: 1, ...e.payload } }) : await Io(i, { payload: { cid: r, offset: a, limit: o, show_dir: 1, ...e.payload } }))), s = Array.isArray(n.data) ? n.data : n.data?.list ?? [], d = Number(n.count ?? n.data?.count ?? s.length), u = n.has_next_page === !0 || n.has_next_page === 1 || a + s.length < d ? a + s.length : null;
  }
  if (u !== null && !s.length) throw y("115 分页为空但仍有后续结果", "upstream");
  return { items: s.map((_) => _e(_, { simple: e.simple ?? !1, keep_raw: e.keep_raw })), next: u, cursor: u === null ? null : { offset: u }, complete: u === null, total: d, ...e.get_raw ? { raw: n } : {} };
}
async function Oe(i, e) {
  const t = [], r = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
  let o = e.scope?.kind === "zip" ? "" : 0;
  do {
    const n = await oe(i, { ...e, cursor: void 0, ...e.scope?.kind === "zip" ? { marker: o } : { offset: o }, limit: 1e3 });
    for (const s of n.items) r.has(s.id) || (r.add(s.id), t.push(s));
    if (n.next !== null && (a.has(n.next) || n.next === o)) throw y("115 分页游标未前进", "upstream");
    if (a.add(o), o = n.next, t.length > (e.maxItems ?? 2e4)) throw y("目录过大，请使用分页目录接口", "conflict");
  } while (o !== null);
  return t;
}
async function U(i, e = 0, t = {}) {
  if (e && typeof e == "object" && !Array.isArray(e)) return e.name !== void 0 && e.is_dir !== void 0 ? { ...e, id: String(e.id), parent_id: String(e.parent_id ?? 0) } : await U(i, e.id ?? e.path, t);
  const r = t.scope ?? {}, a = r.kind === "zip" ? { ..._t(), id: "/", parent_id: "/" } : _t();
  if (e === 0 || e === "0" || e === "/" || Array.isArray(e) && !e.length) return a;
  if (typeof e == "number" || typeof e == "string" && /^\d+$/.test(e)) {
    if (r.kind === "zip") throw y("压缩包文件使用路径 ID");
    return r.kind === "share" ? await br(i, String(e), t) : await kt(i, e);
  }
  let o = typeof e == "string" && e.startsWith("/") || !t.pid ? a : await U(i, t.pid, { ...t, pid: 0 });
  for (const n of Ht(e)) {
    const s = n.name;
    if (s === ".." && !n.quoted) {
      o = await U(i, o.parent_id, { ...t, pid: 0 });
      continue;
    }
    if (!o.is_dir) throw y("路径中包含文件", "not_found");
    const d = (await Oe(i, { id: o.id, scope: t.scope })).filter((u) => u.name === s);
    if (!d.length) throw y("路径不存在", "not_found");
    if (d.length > 1) throw y("路径名称不唯一，请改用文件 ID", "conflict");
    o = d[0];
  }
  return o;
}
async function Qe(i, e, t = {}) {
  let r = await U(i, e, t);
  const a = [r], o = /* @__PURE__ */ new Set([r.id]);
  for (; r.id !== "0" && r.id !== "/"; ) {
    if (o.has(r.parent_id)) throw y("115 父目录关系存在循环", "upstream");
    if (r = await U(i, r.parent_id, { ...t, pid: 0 }), o.add(r.id), a.unshift(r), a.length > 1024) throw y("目录层级过深", "upstream");
  }
  return a;
}
function ft(i, e = !1) {
  let t = "^";
  const r = String(i);
  for (let a = 0; a < r.length; a++) {
    const o = r[a];
    if (o === "*" && r[a + 1] === "*")
      a++, r[a + 1] === "/" ? (a++, t += "(?:.*/)?") : t += ".*";
    else if (o === "*") t += "[^/]*";
    else if (o === "?") t += "[^/]";
    else if (o === "[") {
      const n = r.indexOf("]", a + 1);
      if (n < 0) t += "\\[";
      else {
        const s = r.slice(a + 1, n);
        t += "[" + (s.startsWith("!") ? "^" + s.slice(1) : s) + "]", a = n;
      }
    } else t += /[\\^$+?.()|{}]/.test(o) ? "\\" + o : o;
  }
  return new RegExp(t + "$", e ? "i" : "");
}
function mr(i, e = {}) {
  return !(e.type !== void 0 && i.type !== e.type || e.is_dir !== void 0 && i.is_dir !== e.is_dir || e.minSize !== void 0 && Number(i.size) < e.minSize || e.maxSize !== void 0 && Number(i.size) > e.maxSize || e.name && !ft(e.name, e.ignore_case).test(i.name));
}
async function xe(i, e) {
  const t = G(e.limit ?? 100, 1, 1e3), r = e.max_depth ?? -1, a = e.min_depth ?? 1, o = e.cursor ? null : await U(i, e.top ?? e.id ?? 0, e), n = e.cursor ? JSON.parse(JSON.stringify(e.cursor.queue)) : [{ id: o.id, path: "", depth: 0, offset: 0 }];
  if (!Array.isArray(n) || n.length > 2e4) throw y("遍历游标无效");
  const s = [], d = e.pattern ? ft(e.pattern, e.ignore_case) : null;
  for (; n.length && s.length < t && i.remaining() > 1e3; ) {
    const u = n[0], _ = await oe(i, { id: u.id, ...e.scope?.kind === "zip" ? { marker: u.offset || "" } : { offset: u.offset }, limit: Math.min(200, t - s.length), scope: e.scope, payload: e.payload });
    for (const m of _.items) {
      const w = u.depth + 1, g = u.path + "/" + ue(m.name);
      m.is_dir && (r < 0 || w < r) && n.push({ id: m.id, path: g, depth: w, offset: 0 }), w >= a && (r < 0 || w <= r) && mr(m, e.filter) && (!d || d.test(g.slice(1))) && s.push({ ...m, path: g, depth: w });
    }
    if (_.next === null) n.shift();
    else {
      if (_.next === u.offset || typeof _.next == "number" && _.next < u.offset) throw y("遍历游标未前进", "upstream");
      u.offset = _.next;
    }
    if (n.length > 2e4 || ie(JSON.stringify(n)).length > 16e4) throw y("遍历队列过大，请分目录处理", "conflict");
  }
  return { items: s, cursor: n.length ? { queue: n } : null, complete: n.length === 0 };
}
async function O(i, e, t) {
  const r = e.id_or_path ?? e.path ?? e.id ?? 0;
  if (t === "exists" || t === "isdir" || t === "isfile")
    try {
      const o = await U(i, r, e);
      return t === "exists" ? !0 : t === "isdir" ? o.is_dir : !o.is_dir;
    } catch (o) {
      if (o.code === "not_found") return !1;
      throw o;
    }
  if (t === "iter" || t === "glob" || t === "rglob") return xe(i, { ...e, top: r, pattern: t === "rglob" ? "**/" + (e.pattern ?? "*") : e.pattern });
  const a = await U(i, r, e);
  if (["get_attr", "as_path"].includes(t)) return a;
  if (t === "get_id") return a.id;
  if (t === "get_parent_id") return a.parent_id;
  if (t === "get_ancestors" || t === "get_path" || t === "get_patht") {
    const o = await Qe(i, a.id, e);
    return t === "get_ancestors" ? o : t === "get_patht" ? o.map((n) => n.name) : "/" + o.slice(1).map((n) => ue(n.name)).join("/");
  }
  if (["iterdir", "listdir", "dictdir", "readdir", "dirlen", "is_empty"].includes(t)) {
    if (!a.is_dir) {
      if (t === "is_empty") return Number(a.size) === 0;
      throw y("目标不是目录");
    }
    if (t === "iterdir") return oe(i, { ...e, id: a.id });
    const o = await Oe(i, { ...e, id: a.id });
    return t === "listdir" ? o.map((n) => n.name) : t === "dictdir" ? Object.fromEntries(o.map((n) => [n.id, n])) : t === "dirlen" ? o.length : t === "is_empty" ? !o.length : o;
  }
  if (t === "stat") return zi(a, e.scope);
  if (t === "has_child") return (await Qe(i, e.child, e)).some((o) => o.id === a.id);
  if (["copy", "move", "remove", "rename"].includes(t) && e.scope?.kind && e.scope.kind !== "drive") throw y("分享和压缩包视图只读", "forbidden");
  if (t === "remove") return T(await Me(i, { payload: { "fid[0]": a.id } }));
  if (t === "rename") return T(await Ct(i, { payload: { ["files_new_name[" + a.id + "]"]: e.name } }));
  if (t === "copy" || t === "move") {
    const o = await U(i, e.to_dir ?? e.to_pid ?? 0, e);
    if (!o.is_dir) throw y("目标不是目录");
    return T(await (t === "copy" ? it : bt)(i, { payload: { pid: o.id, "fid[0]": a.id } }));
  }
  if (t === "get_url") return ce(i, a, e);
  if (["read", "read_block", "read_range", "read_text", "hash", "hashes"].includes(t)) {
    const o = ["hash", "hashes"].includes(t);
    let n = e.start ?? e.offset ?? 0, s = e.size ?? e.length ?? (o ? Number(a.size) - n : Math.min(65536, Number(a.size) - n));
    if (e.stop !== void 0 && (s = e.stop - n), e.bytes_range) {
      const d = /^(\d*)-(\d*)$/.exec(String(e.bytes_range).replace(/^bytes=/, ""));
      if (!d) throw y("无效字节区间");
      n = d[1] ? Number(d[1]) : Math.max(0, Number(a.size) - Number(d[2])), s = d[1] && d[2] ? Number(d[2]) - n + 1 : Number(a.size) - n;
    }
    return e.scope?.kind === "share" || e.scope?.kind === "zip" ? Ni(i, a, { ...e, offset: n, length: s }, t) : Pe(i, { pickcode: a.pickcode, offset: n, length: s, digests: e.digests ?? (e.digest ? [e.digest] : void 0), userAgent: e.userAgent }, (await i.connection()).kind === "bearer" ? "open" : "cookie", t === "read_text" ? "text" : o ? "hash" : "range");
  }
  if (t === "download") {
    const o = await ce(i, a, e);
    if (typeof e.destination != "string" || !e.destination.startsWith("/")) throw y("需要绝对路径 destination");
    const n = await i.net.request({ url: o.url, headers: o.headers, outputPath: e.destination, followRedirects: !0 });
    if (n.status < 200 || n.status >= 300) throw y("下载失败，HTTP " + n.status, "upstream");
    return { path: n.path, bytes: n.bytes };
  }
  throw y("未知文件操作");
}
async function Ft(i, e) {
  if (e.scope?.kind && e.scope.kind !== "drive") throw y("分享和压缩包视图只读", "forbidden");
  let t = await U(i, e.pid ?? 0);
  const r = e.name !== void 0 ? [e.name] : Ae(e.path ?? e.id_or_path ?? "");
  if (!r.length) throw y("目录名不能为空");
  for (const a of r) {
    if (!a || /[\x00\r\n]/.test(a)) throw y("目录名无效");
    const o = (await Oe(i, { id: t.id })).filter((s) => s.name === a);
    if (o.length > 1) throw y("目录名称不唯一", "conflict");
    if (o.length) {
      if (!o[0].is_dir) throw y("同名文件已存在", "conflict");
      t = o[0];
      continue;
    }
    const n = T(await bi(i, { payload: { pid: t.id, cname: a } }));
    t = { id: N(n.cid ?? n.data?.category_id ?? n.data?.file_id), parent_id: t.id, name: a, is_dir: !0, size: 0, sha1: "", type: 0 };
  }
  return t;
}
async function br(i, e, t) {
  const r = t.scope?.entries?.find((o) => String(o.id) === e);
  if (r) return r;
  let a = null;
  do {
    const o = await xe(i, { scope: t.scope, top: 0, cursor: a, limit: 200 }), n = o.items.find((s) => s.id === e);
    if (n) return n;
    if (a = o.cursor, a && i.remaining() < 1500) throw y("查找尚未完成，请提供分享路径或已列出的文件信息", "busy");
  } while (a);
  throw y("分享中不存在该文件", "not_found");
}
function zi(i, e) {
  return { st_mode: (i.is_dir ? 16384 : 32768) | (["share", "zip"].includes(e?.kind) ? 292 : 511), st_ino: i.id, st_dev: i.parent_id, st_nlink: 1, st_uid: 0, st_gid: 0, st_size: i.is_dir ? 0 : i.size, st_atime: i.atime ?? 0, st_mtime: i.mtime ?? 0, st_ctime: i.ctime ?? 0 };
}
function ze(i) {
  const e = i.scope ?? i, t = X(e.url ?? e.share_code);
  return { kind: "share", ...t, receive_code: e.receive_code ?? t.receive_code };
}
async function ce(i, e, t) {
  if (e.is_dir) throw y("目录没有下载链接");
  if (t.scope?.kind === "share") return rt(i, { payload: { ...ze(t), file_id: e.id }, strict: !0, app: t.app }, "regular");
  if (t.scope?.kind === "zip") {
    const r = T(await Ge(i, { app: t.app, userAgent: t.userAgent, payload: { pick_code: t.scope.pickcode, full_name: Ae(e.id).join("/") } }, ["", "web", "desktop", "aps"].includes(t.app ?? "web") ? "extract-web" : "extract-app")), a = r.data?.url?.url ?? r.data?.url ?? r.url;
    if (typeof a != "string") throw y("压缩包下载链接缺失", "upstream");
    return { ...e, url: a, headers: r.headers ?? {} };
  }
  return we(i, { pickcode: e.pickcode, strict: !0, userAgent: t.userAgent }, (await i.connection()).kind === "bearer" ? "open" : "cookie", !0);
}
async function Ni(i, e, t, r) {
  const a = t.url ? { url: t.url, headers: t.headers ?? {}, size: e.size } : await ce(i, e, t), o = G(t.offset, 0, Number(e.size)), n = G(t.length, 0, Number(e.size) - o);
  if (r === "hash" || r === "hashes") return Jt(i, a, { offset: o, length: n, digests: t.digests ?? [t.digest ?? "sha1"], cursor: t.cursor });
  if (n > 65536) throw y("单次读取最多 65536 字节，请继续 nextOffset");
  let s = new Uint8Array();
  if (n) {
    const d = await i.net.request({ url: a.url, headers: { ...a.headers, Range: "bytes=" + o + "-" + (o + n - 1) }, responseType: "bytes", maxBytes: 65536, followRedirects: !0 });
    if (d.status !== 206 && !(d.status === 200 && o === 0 && Number(e.size) <= n)) throw y("上游没有返回请求的范围", "upstream");
    if (s = d.body, s.length !== n) throw y("读取长度与文件信息不符", "upstream");
  }
  return { bytes: s.length, ...r === "read_text" ? { text: decodeURIComponent(Array.from(s, (d) => "%" + D(d)).join("")) } : { base64: pe(s) }, nextOffset: o + n < Number(e.size) ? o + n : null };
}
async function I(i, e, t) {
  if (t === "wrap_path_iter") {
    const u = [];
    for (const _ of e.items ?? []) u.push(await I(i, { ...e, id_or_path: _ }, "path"));
    return u;
  }
  const r = await U(i, e.id_or_path ?? e.path ?? e.id ?? 0, e);
  if (t === "id" || t === "inode") return r.id;
  if (t === "is_dir") return r.is_dir;
  if (t === "is_file") return !r.is_dir;
  if (t === "is_absolute") return !0;
  if (t === "is_symlink") return !1;
  if (t === "get_length") return r.is_dir ? (await Oe(i, { ...e, id: r.id })).length : r.size;
  const a = Ze(r.name), o = a ? r.name.slice(0, -a.length) : r.name;
  if (t === "stem") return o;
  if (t === "suffix") return a;
  if (t === "suffixes") {
    const u = r.name.replace(/^\.+/, "");
    return u.endsWith(".") ? [] : u.split(".").slice(1).map((_) => "." + _);
  }
  if (t === "media_type") return wr[a.toLowerCase()] ?? null;
  const n = await Qe(i, r, e), s = n.map((u) => u.name), d = "/" + s.slice(1).map(ue).join("/");
  if (t === "ancestors") return n;
  if (["parts", "patht"].includes(t)) return s;
  if (t === "path") return d;
  if (t === "root") return n[0];
  if (["parent", "get_parent"].includes(t)) return n.at(-2) ?? n[0];
  if (["parents", "get_parents"].includes(t)) return n.slice(0, -1).reverse();
  if (t === "match") return ft(e.pattern, e.ignore_case).test(e.pattern.startsWith("/") ? d : d.slice(1)) || !e.pattern.includes("/") && ft(e.pattern, e.ignore_case).test(r.name);
  if (["join", "joinpath"].includes(t)) return U(i, Ae(d).concat(e.parts ?? []), { ...e, pid: 0 });
  if (["with_name", "with_stem", "with_suffix"].includes(t)) {
    const u = t === "with_name" ? e.name : t === "with_stem" ? e.stem + a : o + e.suffix;
    if (typeof u != "string" || !u) throw y("新名称不能为空");
    if (t === "with_suffix" && e.suffix !== "" && (!e.suffix.startsWith(".") || e.suffix.includes("/"))) throw y("后缀必须以点开头");
    return U(i, s.slice(1, -1).concat(u), { ...e, pid: 0 });
  }
  throw y("未知路径操作");
}
const wr = { ".mp4": "video/mp4", ".mkv": "video/x-matroska", ".avi": "video/x-msvideo", ".mov": "video/quicktime", ".mp3": "audio/mpeg", ".flac": "audio/flac", ".wav": "audio/wav", ".m4a": "audio/mp4", ".ogg": "audio/ogg", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".gif": "image/gif", ".webp": "image/webp", ".svg": "image/svg+xml", ".pdf": "application/pdf", ".zip": "application/zip", ".7z": "application/x-7z-compressed", ".rar": "application/vnd.rar", ".txt": "text/plain", ".html": "text/html", ".json": "application/json", ".srt": "text/plain", ".ass": "text/plain" };
async function fe(i, e, t) {
  const r = e.state ?? {}, a = e.scope ?? r.scope ?? { kind: "drive" }, o = e.pid ?? r.cid ?? 0, n = { ...e, pid: o, scope: a };
  if (t === "create") return { scope: a, cid: String(o), cwd: await O(i, { id: o, scope: a }, "get_path") };
  if (t === "getcid") return String(o);
  if (t === "getcwd") return O(i, { id: o, scope: a }, "get_path");
  if (t === "user_id") return String(await v(i, e));
  if (t === "attr_to_stat") return zi(e.attr, a);
  const s = e.id_or_path ?? e.path ?? e.id ?? o, d = await U(i, s, n);
  if (t === "chdir") {
    if (!d.is_dir) throw y("当前目录必须是目录");
    return { scope: a, cid: d.id, cwd: await O(i, { ...n, id_or_path: d }, "get_path") };
  }
  if (t === "open") return { entry: d, scope: a, offset: e.start ?? 0, length: d.size, readAction: "vfs-read-block", seekable: !0 };
  if (t === "listdir_path" || t === "dictdir_path") {
    const u = await Oe(i, { ...n, id: d.id });
    return t === "listdir_path" ? u : Object.fromEntries(u.map((_) => [_.id, _]));
  }
  if (t === "walk") {
    const u = e.cursor?.queue ?? [{ id: d.id, path: await O(i, { ...n, id_or_path: d }, "get_path"), depth: 0 }], _ = [], m = G(e.limit ?? 20, 1, 100);
    for (; u.length && _.length < m && i.remaining() > 1500; ) {
      const w = u.shift(), g = await Oe(i, { ...n, id: w.id }), x = g.filter((q) => q.is_dir), k = g.filter((q) => !q.is_dir);
      if (_.push({ path: w.path, dirs: x, files: k }), (e.max_depth === void 0 || e.max_depth < 0 || w.depth < e.max_depth) && u.push(...x.map((q) => ({ id: q.id, path: w.path.replace(/\/$/, "") + "/" + ue(q.name), depth: w.depth + 1 }))), u.length > 2e4) throw y("遍历队列过大，请分目录处理", "conflict");
    }
    return { items: _, cursor: u.length ? { queue: u } : null, complete: !u.length };
  }
  throw y("未知文件系统状态操作");
}
async function ge(i, e, t) {
  const r = ze(e);
  if (t === "from_url") return { scope: r, cid: "0", cwd: "/" };
  if (t === "receive") {
    const o = e.ids ?? [(await U(i, e.id_or_path ?? e.id ?? 0, { ...e, scope: r })).id];
    return T(await nr(i, { payload: { share_code: r.share_code, receive_code: r.receive_code, file_id: o.map(N).join(","), cid: N(e.to_pid ?? 0) } }));
  }
  const a = T(await ki(i, { payload: { share_code: r.share_code, receive_code: r.receive_code, limit: 1 } })).data;
  if (["share_data", "get_share_data"].includes(t)) return a;
  if (t === "share_info") return a.share_info;
  if (t === "snap_id") return String(a.share_info.snap_id);
  if (t === "share_user_id") return String(a.userinfo.user_id);
  if (t === "create_timestamp") return Number(a.share_info.create_time);
  if (t === "create_time") return new Date(Number(a.share_info.create_time) * 1e3).toISOString();
  throw y("未知分享操作");
}
const xr = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298], gr = Array.from({ length: 64 }, (i, e) => Math.floor(Math.abs(Math.sin(e + 1)) * 4294967296) | 0);
function K(i, e) {
  return i << e | i >>> 32 - e;
}
function Fe(i) {
  if (!["sha1", "sha256", "md5", "md4"].includes(i)) throw y("不支持的摘要算法 " + i);
  return { alg: i, total: 0, tail: [], h: i === "sha256" ? [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225] : [1732584193, 4023233417, 2562383102, 271733878, ...i === "sha1" ? [3285377520] : []] };
}
function At(i, e, t) {
  const r = new Int32Array(80), a = i.alg.startsWith("sha");
  for (let x = 0; x < 16; x++) {
    const k = t + x * 4;
    r[x] = a ? e[k] << 24 | e[k + 1] << 16 | e[k + 2] << 8 | e[k + 3] : e[k] | e[k + 1] << 8 | e[k + 2] << 16 | e[k + 3] << 24;
  }
  let [o, n, s, d, u, _, m, w] = i.h;
  if (i.alg === "sha1") {
    for (let x = 16; x < 80; x++) r[x] = K(r[x - 3] ^ r[x - 8] ^ r[x - 14] ^ r[x - 16], 1);
    for (let x = 0; x < 80; x++) {
      const k = Math.floor(x / 20), q = k === 0 ? n & s | ~n & d : k === 2 ? n & s | n & d | s & d : n ^ s ^ d, ae = K(o, 5) + q + u + [1518500249, 1859775393, 2400959708, 3395469782][k] + r[x] | 0;
      u = d, d = s, s = K(n, 30), n = o, o = ae;
    }
  } else if (i.alg === "sha256") {
    for (let x = 16; x < 64; x++) {
      const k = r[x - 15], q = r[x - 2];
      r[x] = r[x - 16] + (K(k, 25) ^ K(k, 14) ^ k >>> 3) + r[x - 7] + (K(q, 15) ^ K(q, 13) ^ q >>> 10) | 0;
    }
    for (let x = 0; x < 64; x++) {
      const k = w + (K(u, 26) ^ K(u, 21) ^ K(u, 7)) + (u & _ ^ ~u & m) + xr[x] + r[x] | 0, q = (K(o, 30) ^ K(o, 19) ^ K(o, 10)) + (o & n ^ o & s ^ n & s) | 0;
      w = m, m = _, _ = u, u = d + k | 0, d = s, s = n, n = o, o = k + q | 0;
    }
  } else if (i.alg === "md5")
    for (let x = 0; x < 64; x++) {
      const k = x >>> 4, q = k === 0 ? n & s | ~n & d : k === 1 ? d & n | ~d & s : k === 2 ? n ^ s ^ d : s ^ (n | ~d), ae = k === 0 ? x : k === 1 ? (5 * x + 1) % 16 : k === 2 ? (3 * x + 5) % 16 : 7 * x % 16, $ = [[7, 12, 17, 22], [5, 9, 14, 20], [4, 11, 16, 23], [6, 10, 15, 21]][k][x % 4], Q = n + K(o + q + gr[x] + r[ae] | 0, $) | 0;
      o = d, d = s, s = n, n = Q;
    }
  else
    for (let x = 0; x < 48; x++) {
      const k = Math.floor(x / 16), q = x % 16, ae = k === 0 ? q : k === 1 ? q % 4 * 4 + (q >>> 2) : [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15][q], $ = k === 0 ? n & s | ~n & d : k === 1 ? n & s | n & d | s & d : n ^ s ^ d, Q = [[3, 7, 11, 19], [3, 5, 9, 13], [3, 9, 11, 15]][k][x % 4], $i = K(o + $ + r[ae] + [0, 1518500249, 1859775393][k] | 0, Q);
      o = d, d = s, s = n, n = $i;
    }
  const g = [o, n, s, d, u, _, m, w];
  i.h = i.h.map((x, k) => x + g[k] | 0);
}
function Je(i, e) {
  i.total += e.length;
  let t = 0;
  if (i.tail.length) {
    const r = Math.min(64 - i.tail.length, e.length);
    i.tail.push(...e.slice(0, r)), t = r, i.tail.length === 64 && (At(i, i.tail, 0), i.tail = []);
  }
  for (; t + 64 <= e.length; )
    At(i, e, t), t += 64;
  return t < e.length && i.tail.push(...e.slice(t)), i;
}
function $e(i) {
  const e = JSON.parse(JSON.stringify(i)), t = e.alg.startsWith("sha"), r = [...e.tail, 128];
  for (; r.length % 64 !== 56; ) r.push(0);
  const a = BigInt(e.total) * 8n, o = Array.from({ length: 8 }, (n, s) => Number(a >> BigInt(s * 8) & 255n));
  r.push(...t ? o.reverse() : o);
  for (let n = 0; n < r.length; n += 64) At(e, r, n);
  return e.h.map((n) => Array.from({ length: 4 }, (s, d) => D(n >>> (t ? 24 - d * 8 : d * 8))).join("")).join("");
}
async function Jt(i, e, t) {
  const r = G(t.offset ?? 0, 0, Number.MAX_SAFE_INTEGER), a = G(t.length, 0, Number.MAX_SAFE_INTEGER - r), o = t.digests ?? ["sha1"], n = t.cursor;
  if (!Array.isArray(o) || !o.length || o.length > 4) throw y("摘要算法列表无效");
  const s = n ? JSON.parse(JSON.stringify(n)) : { offset: r, length: a, done: 0, states: o.map(Fe) };
  if (s.offset !== r || s.length !== a || s.states.map((u) => u.alg).join() !== o.join() || s.done < 0 || s.done > a) throw y("摘要游标与文件范围不一致");
  let d = 0;
  for (; s.done < a && i.remaining() > 1500 && d++ < 32; ) {
    const u = r + s.done, _ = Math.min(262144, a - s.done), m = await i.net.request({ url: e.url, headers: { ...e.headers, Range: "bytes=" + u + "-" + (u + _ - 1) }, responseType: "bytes", maxBytes: _, followRedirects: !0 });
    if (m.status !== 206 && !(m.status === 200 && u === 0 && Number(e.size) === _)) throw y("上游没有返回摘要所需范围", "upstream");
    if (m.body.length !== _) throw y("摘要读取长度错误", "upstream");
    for (const w of s.states) Je(w, m.body);
    s.done += _;
  }
  return { bytes: s.done, complete: s.done === a, cursor: s.done === a ? null : s, digests: s.done === a ? Object.fromEntries(s.states.map((u) => [u.alg, $e(u)])) : null };
}
const zt = "0123456789abcdefghijklmnopqrstuvwxyz", Re = { a: "fuln1ytpj3smg8d5a094qh7cxkbi62zvewro", b: "sk721n9a0emlfpcrzbqdw3gjh6ty5xui48vo", c: "ywcz3hite6f1j0guoakvdb2ns7p8qr9ml5x4", d: "rq2vl5o7wsken9u8tp4jg3zbyc6xmhifd01a", e: "ljm9eqbcfhw7ktv3x1dgp5ua8y6s4znr2io0", fa: "fumk0ytpj3sng8d5a194qh7cxlbi62zvewro", fb: "sk732o9a1enmfpcrzbqdw4gjh6ty5xui08vl", fc: "ywcz6hite9f4j3gup2kvdb5osal0qr1nm8x7", fd: "on6vl0r2wpkeq9u3ts8jg7zbyc1xmhifd45a", fe: "ljm0es2cfhwakqv6x4dgp8r1by9u7znt5io3" };
function et(i) {
  return i.startsWith("f") ? i.slice(0, 2) : i[0];
}
function Ce(i, e, t = !1) {
  const r = Re[e];
  if (!r) throw y("提取码前缀无效");
  const a = t ? zt : r, o = t ? r : zt;
  return Array.from(i, (n) => {
    const s = a.indexOf(n);
    if (s < 0) throw y("提取码字符无效");
    return o[s];
  }).join("");
}
function Ke(i) {
  if (i = String(i), i.length < 4) return i.padStart(4, "0");
  const e = et(i), t = Re[e] && i.length >= e.length + 4;
  if (!t && i.at(-4) === "0") return i.slice(-4);
  const r = t ? e : Object.keys(Re).find((a) => Ce("0", a) === i.at(-4));
  return Ce(i.slice(-4), r, !0);
}
function me(i) {
  if (i === 0 || i === "") return "0";
  if (typeof i == "number" || /^\d+$/.test(i)) return N(i);
  const e = et(i), t = Ce(i.slice(e.length, -4), e, !0);
  if (!t) throw y("提取码中没有文件 ID");
  let r = 0n;
  for (const a of t) r = r * 36n + BigInt(zt.indexOf(a));
  return r.toString();
}
function ji(i, e = "0000", t = "a") {
  if (typeof i == "string" && /^[a-f]/.test(i))
    return me(i), i;
  const r = BigInt(N(i));
  if (!r) return "";
  const a = t || (Re[et(e)] && e.length > 4 ? et(e) : Object.keys(Re).find((o) => Ce("0", o) === e.at(-4)) ?? "a");
  return a + Ce(r.toString(36) + Ke(e), a);
}
async function kr(i, e) {
  if (e.stable_point) return Ke(e.stable_point);
  if (e.pickcode) return Ke(e.pickcode);
  const t = await oe(i, { id: 0, limit: 1 });
  if (t.items[0]?.pickcode) return Ke(t.items[0].pickcode);
  throw y("账号没有可用提取码，请传入 stable_point", "not_found");
}
function f(i, e) {
  return (t, r) => i(t, r, e);
}
const ti = /* @__PURE__ */ JSON.parse('{".ass":1,".chm":1,".csv":1,".doc":1,".docm":1,".docx":1,".dotm":1,".dot":1,".dps":1,".dwg":1,".et":1,".htm":1,".html":1,".idx":1,".jar":1,".key":1,".log":1,".lrc":1,".md":1,".mdb":1,".mdf":1,".numbers":1,".odp":1,".ods":1,".odt":1,".pages":1,".pdf":1,".pot":1,".pps":1,".ppt":1,".pptm":1,".pptx":1,".rtf":1,".srt":1,".ssa":1,".sub":1,".torrent":1,".txt":1,".wps":1,".wri":1,".xlam":1,".xls":1,".xlsb":1,".xlsm":1,".xlsx":1,".xltm":1,".xltx":1,".vtt":1,".avif":2,".bmp":2,".dng":2,".exif":2,".gif":2,".heic":2,".heif":2,".ico":2,".jfif":2,".jpeg":2,".jpg":2,".png":2,".psd":2,".raw":2,".svg":2,".tif":2,".tiff":2,".webp":2,".aac":3,".ac3":3,".aiff":3,".alac":3,".amr":3,".ape":3,".au":3,".dsf":3,".dts":3,".f4a":3,".flac":3,".m4a":3,".mid":3,".midi":3,".mp3":3,".ogg":3,".opus":3,".ra":3,".wav":3,".wma":3,".wv":3,".3g2":4,".3gp":4,".3gp2":4,".3gpp":4,".asf":4,".avi":4,".dat":4,".divx":4,".f4v":4,".flv":4,".iso":4,".m2ts":4,".m4v":4,".mkv":4,".mov":4,".mp4":4,".mpe":4,".mpeg":4,".mpeg4":4,".mpg":4,".mts":4,".ogv":4,".ram":4,".rm":4,".rmvb":4,".swf":4,".ts":4,".vob":4,".webm":4,".wmv":4,".7z":5,".bz2":5,".cab":5,".dmg":5,".gz":5,".msi":5,".part":5,".rar":5,".tar":5,".xz":5,".z":5,".zip":5,".apk":6,".app":6,".bat":6,".deb":6,".exe":6,".ipa":6,".pkg":6,".rpm":6,".azw":7,".azw3":7,".epub":7,".fb2":7,".lit":7,".lrf":7,".mobi":7,".prc":7}'), Tr = /* @__PURE__ */ JSON.parse('{"JG_DOC":1,"DOC":1,"JG_PIC":2,"PIC":2,"JG_MUS":3,"MUS":3,"JG_AVI":4,"AVI":4,"JG_RAR":5,"RAR":5,"RAR_EXTRACT":5,"JG_EXE":6,"EXE":6,"JG_BOOK":7,"BOOK":7}'), Er = /* @__PURE__ */ JSON.parse('{"web":[["aid","area_id"],["all_skip_login","all_skip_login"],["audio_play_long","audio_play_long"],["c","is_collect"],["cc","cover"],["cc","category_cover"],["class","class"],["current_time","current_time"],["d","has_desc"],["dp","dir_path"],["e","pick_expire"],["fl","labels"],["hdf","is_private"],["is_skip_login","is_skip_login"],["is_top","is_top"],["ispl","show_play_long"],["issct","is_shortcut"],["iv","is_video"],["last_time","last_time"],["m","is_mark"],["m","star"],["ns","name_show"],["p","has_pass"],["play_long","play_long"],["played_end","played_end"],["pt","pick_time"],["score","score"],["sh","is_share"],["sta","status"],["style","style"],["u","thumb"],["uid","user_id"],["fuuid","user_id"]],"app":[["aid","area_id"],["all_skip_login","all_skip_login"],["audio_play_long","audio_play_long"],["current_time","current_time"],["d_img","d_img"],["def","defination"],["def2","defination2"],["fatr","audio_play_long"],["fco","cover"],["fco","folder_cover"],["fdesc","desc"],["fl","labels"],["fflabel","fflabel"],["fta","status"],["ftype","file_type"],["fuuid","user_id"],["ic","is_collect"],["is_skip_login","is_skip_login"],["is_top","is_top"],["ism","is_mark"],["ism","star"],["isp","is_private"],["ispl","show_play_long"],["iss","is_share"],["issct","is_shortcut"],["isv","is_video"],["last_time","last_time"],["muc","cover"],["muc","music_cover"],["multitrack","multitrack"],["play_long","play_long"],["played_end","played_end"],["unzip_status","unzip_status"],["uo","source_url"],["v_img","video_img_url"]],"app2":[["area_id","area_id"],["can_delete","can_delete"],["cate_mark","cate_mark"],["category_file_count","category_file_count"],["category_order","category_order"],["current_time","current_time"],["d_img","d_img"],["definition","definition"],["definition2","definition2"],["file_answer","file_answer"],["file_category","file_category"],["file_eda","file_eda"],["file_name_sort","file_name_sort"],["file_question","file_question"],["file_sort","file_sort"],["file_status","file_status"],["has_desc","has_desc"],["has_pass","has_pass"],["is_collect","is_collect"],["is_mark","is_mark"],["is_private","is_private"],["is_share","is_share"],["is_top","is_top"],["is_video","is_video"],["last_time","last_time"],["password","password"],["pick_expire","pick_expire"],["pick_time","pick_time"],["play_long","play_long"],["play_url","play_url"],["played_end","played_end"],["show_play_long","show_play_long"],["user_id","user_id"],["video_img_url","video_img_url"]]}'), c_ = /* @__PURE__ */ f(O, "as_path");
const __ = /* @__PURE__ */ f(O, "get_attr");
const f_ = /* @__PURE__ */ f(O, "get_id");
const h_ = /* @__PURE__ */ f(O, "get_parent_id");
const y_ = /* @__PURE__ */ f(O, "get_ancestors");
const m_ = /* @__PURE__ */ f(O, "get_path");
const b_ = /* @__PURE__ */ f(O, "get_patht");
const w_ = /* @__PURE__ */ f(O, "exists");
const x_ = /* @__PURE__ */ f(O, "isdir");
const g_ = /* @__PURE__ */ f(O, "isfile");
const k_ = /* @__PURE__ */ f(O, "iter");
const T_ = /* @__PURE__ */ f(O, "glob");
const E_ = /* @__PURE__ */ f(O, "rglob");
const q_ = /* @__PURE__ */ f(O, "iterdir");
const v_ = /* @__PURE__ */ f(O, "listdir");
const S_ = /* @__PURE__ */ f(O, "dictdir");
const O_ = /* @__PURE__ */ f(O, "readdir");
const P_ = /* @__PURE__ */ f(O, "dirlen");
const G_ = /* @__PURE__ */ f(O, "is_empty");
const A_ = /* @__PURE__ */ f(O, "stat");
const z_ = /* @__PURE__ */ f(O, "has_child");
const N_ = /* @__PURE__ */ f(O, "copy");
const j_ = /* @__PURE__ */ f(O, "move");
const I_ = /* @__PURE__ */ f(O, "remove");
const U_ = /* @__PURE__ */ f(O, "rename");
const R_ = /* @__PURE__ */ f(O, "get_url");
const C_ = /* @__PURE__ */ f(O, "read");
const D_ = /* @__PURE__ */ f(O, "read_block");
const M_ = /* @__PURE__ */ f(O, "read_range");
const L_ = /* @__PURE__ */ f(O, "read_text");
const W_ = /* @__PURE__ */ f(O, "hash");
const B_ = /* @__PURE__ */ f(O, "hashes");
const H_ = /* @__PURE__ */ f(O, "download");
function F_(i, e) {
  return _e(e.info, e);
}
function J_(i, e) {
  return _e(e.info, { ...e, kind: "web" });
}
function $_(i, e) {
  return _e(e.info, { ...e, kind: "app" });
}
function K_(i, e) {
  return _e(e.info, { ...e, kind: "app2" });
}
function V_(i, e) {
  return _e(e.info, { ...e, simple: !0 });
}
function X_(i, e) {
  return Ai(e.attr);
}
const Y_ = /* @__PURE__ */ f(I, "ancestors");
const Z_ = /* @__PURE__ */ f(I, "get_length");
const Q_ = /* @__PURE__ */ f(I, "get_parent");
const ef = /* @__PURE__ */ f(I, "get_parents");
const tf = /* @__PURE__ */ f(I, "id");
const of = /* @__PURE__ */ f(I, "inode");
const rf = /* @__PURE__ */ f(I, "is_absolute");
const af = /* @__PURE__ */ f(I, "is_dir");
const nf = /* @__PURE__ */ f(I, "is_file");
const lf = /* @__PURE__ */ f(I, "is_symlink");
const sf = /* @__PURE__ */ f(I, "join");
const pf = /* @__PURE__ */ f(I, "joinpath");
const df = /* @__PURE__ */ f(I, "match");
const uf = /* @__PURE__ */ f(I, "media_type");
const cf = /* @__PURE__ */ f(I, "parent");
const _f = /* @__PURE__ */ f(I, "parents");
const ff = /* @__PURE__ */ f(I, "parts");
const hf = /* @__PURE__ */ f(I, "path");
const yf = /* @__PURE__ */ f(I, "patht");
const mf = /* @__PURE__ */ f(I, "root");
const bf = /* @__PURE__ */ f(I, "stem");
const wf = /* @__PURE__ */ f(I, "suffix");
const xf = /* @__PURE__ */ f(I, "suffixes");
const gf = /* @__PURE__ */ f(I, "with_name");
const kf = /* @__PURE__ */ f(I, "with_stem");
const Tf = /* @__PURE__ */ f(I, "with_suffix");
const Ef = /* @__PURE__ */ f(I, "wrap_path_iter");
const qf = /* @__PURE__ */ f(fe, "chdir");
const vf = /* @__PURE__ */ f(fe, "getcid");
const Sf = /* @__PURE__ */ f(fe, "getcwd");
const Of = /* @__PURE__ */ f(fe, "listdir_path");
const Pf = /* @__PURE__ */ f(fe, "dictdir_path");
const Gf = /* @__PURE__ */ f(fe, "walk");
const Af = /* @__PURE__ */ f(fe, "open");
const zf = /* @__PURE__ */ f(fe, "attr_to_stat");
const Nf = /* @__PURE__ */ f(fe, "user_id");
const jf = /* @__PURE__ */ f(ge, "create_time");
const If = /* @__PURE__ */ f(ge, "create_timestamp");
const Uf = /* @__PURE__ */ f(ge, "get_share_data");
const Rf = /* @__PURE__ */ f(ge, "share_data");
const Cf = /* @__PURE__ */ f(ge, "share_info");
const Df = /* @__PURE__ */ f(ge, "share_user_id");
const Mf = /* @__PURE__ */ f(ge, "snap_id");
const Lf = /* @__PURE__ */ f(ge, "receive");
const Wf = /* @__PURE__ */ f(ge, "from_url");
const Bf = /* @__PURE__ */ f(fe, "create");
function Hf(i, e) {
  return { kind: e.scope?.kind ?? "drive", representation: "JSON", pathEscape: "backslash", idType: "string" };
}
function We(i) {
  return (Array.isArray(i) ? i : [i]).map((e) => N(e && typeof e == "object" ? e.id ?? e.file_id : e));
}
function ee(i, e = "fid") {
  return Object.fromEntries(i.map((t, r) => [e + "[" + r + "]", t]));
}
function C(i, e, t = {}) {
  return { items: i, cursor: e, complete: e === null, ...t };
}
async function he(i, e, t) {
  const r = e.cursor?.offset ?? e.offset ?? 0, a = G(e.limit ?? e.page_size ?? 100, 1, 1e3), o = e.cursor?.page ?? e.page ?? e.page_start ?? 1;
  let n, s, d, u;
  if (t === "offline" || t === "offline-restart") {
    n = T(await ((await i.connection()).kind === "bearer" ? fi : yi)(i, { payload: { page: o, page_size: a, stat: t === "offline-restart" ? 9 : e.stat ?? 0 } }));
    const _ = Array.isArray(n.tasks) ? n : n.data;
    if (s = _.tasks ?? [], d = Number(_.count ?? 0), u = s.length && o < Number(_.page_count ?? o) && (e.page_stop === void 0 || e.page_stop < 0 || o + 1 < e.page_stop) ? { page: o + 1 } : null, t === "offline-restart") {
      const m = [];
      for (const w of s) {
        if (!w.available_actions?.includes("retry")) {
          if (e.begins_with_retryable) {
            u = null;
            break;
          }
          continue;
        }
        m.push({ task: w, result: await mo(i, { payload: { info_hash: w.info_hash } }) });
      }
      s = m;
    }
  } else if (t === "wish" || t === "wish-aid")
    n = T(await (t === "wish" ? _o : uo)(i, { payload: { page: o, limit: a, ...t === "wish" ? { type: e.type ?? 0 } : { id: e.wish_id } } })), s = n.data.list ?? [], u = s.length ? { page: o + 1 } : null;
  else if (t === "history" || t === "life") {
    const _ = e.app ?? "web", m = !["", "web", "desktop", "chrome", "aps"].includes(_), w = t === "history" ? m ? Co : Ro : m ? Fo : xi, g = { offset: r, limit: a, type: e.type ?? (t === "history" ? 0 : ""), ...t === "life" ? { date: e.date ?? "" } : {} };
    n = T(await w(i, { payload: g, ...m ? { app: _ } : {} }));
    const x = n.data.list ?? [], k = new Set(e.cursor?.seen ?? []);
    d = Number(n.data.total ?? n.data.count ?? x.length);
    let q = !1;
    s = [];
    const ae = t === "history" ? qr : vr;
    for (const $ of x) {
      if (e.from_id && BigInt($.id) <= BigInt(e.from_id) || e.from_time && Number($.update_time) < e.from_time) {
        q = !0;
        break;
      }
      const Q = String(t === "life" && e.yield_latest !== !1 ? $.file_id : $.id);
      !k.has(Q) && !e.ignore_types?.includes(Number($.type)) && s.push({ ...$, event_name: ae[$.type] ?? "" }), k.add(Q);
    }
    if (u = !q && x.length && r + x.length < d ? { offset: r + x.length, seen: [...k] } : null, u?.seen.length > 1e4) throw y("事件去重状态过大，请缩小时间区间", "conflict");
    return C(s, u, { total: d, watermark: { from_id: s[0]?.id ?? e.from_id ?? "0", from_time: Number(s[0]?.update_time ?? e.from_time ?? 0) } });
  } else if (t === "search" || t === "share-search") {
    const _ = { cid: e.cid ?? e.id ?? 0, offset: r, limit: a, search_value: e.search_value ?? e.name ?? "", ...e.payload };
    t === "share-search" && Object.assign(_, ze(e)), delete _.kind, n = T(await (t === "search" ? wi : lr)(i, { payload: _ }));
    const m = n.data, w = Array.isArray(m) ? m : m?.list ?? [];
    s = w.map((g) => _e(g, e)), d = Number(n.count ?? m?.count ?? w.length), u = w.length && r + w.length < d ? { offset: r + w.length } : null;
  } else throw y("未知集合类型");
  if (e.raise_for_update && e.cursor?.count !== void 0 && e.cursor.count !== d) throw y("列表总数发生变化", "conflict");
  return u && e.raise_for_update && (u.count = d), C(s, u, { ...d !== void 0 ? { total: d } : {} });
}
const qr = { 0: "all", 2: "offline_download", 3: "browse_video", 4: "upload", 7: "receive", 8: "move" }, vr = { 1: "upload_image_file", 2: "upload_file", 3: "star_image", 4: "star_file", 5: "move_image_file", 6: "move_file", 7: "browse_image", 8: "browse_video", 9: "browse_audio", 10: "browse_document", 14: "receive_files", 17: "new_folder", 18: "copy_folder", 19: "folder_label", 20: "folder_rename", 22: "delete_file", 23: "copy_file", 24: "file_rename" };
async function M(i, e, t) {
  const r = We(e.ids ?? []), a = G(e.cursor?.offset ?? 0, 0, r.length), o = G(e.batch_size ?? 100, 1, 1e3), n = r.slice(a, a + o);
  if (!n.length) return C([], null, { processed: a });
  const s = ee(n);
  let d;
  if (["copy", "move", "delete"].includes(t))
    t !== "delete" && (s.pid = N(e.pid ?? 0)), d = await (t === "copy" ? it : t === "move" ? bt : Me)(i, { payload: s });
  else if (["cover", "desc", "label", "show_play_long"].includes(t)) {
    const _ = { cover: "fid_cover", desc: "file_desc", label: "file_label", show_play_long: "show_play_long" }[t];
    d = await ot(i, { payload: { ...ee(n), [_]: e.value ?? (t === "show_play_long" ? 1 : "") } });
  } else if (t === "star" || t === "top")
    d = await (t === "star" ? Lo : Bo)(i, { payload: { file_id: n.join(","), [t]: Number(e.value ?? !0) } });
  else if (t === "score") d = await l(i, te + "/files/score", "POST", null, { file_id: n.join(","), score: e.value ?? 0 });
  else if (t === "category_shortcut") d = await Po(i, { payload: { file_id: n.join(","), op: e.value === !1 ? "delete" : "add" } });
  else if (t === "hide") d = await Uo(i, { payload: { ...s, hidden: Number(e.hidden ?? !0) } });
  else if (t === "recyclebin_clean" || t === "recyclebin_revert") {
    const _ = ee(n, "rid");
    d = await (t === "recyclebin_clean" ? ir : or)(i, { payload: _, ...t === "recyclebin_clean" && e.password ? { password: e.password } : {} });
  } else if (t === "batch_label") {
    const _ = e.mode ?? "add";
    if (!["add", "remove", "reset", "replace"].includes(_)) throw y("标签操作无效");
    d = await l(i, te + "/files/batch_label", "POST", null, { ...e.payload, action: _, file_ids: n.join(","), file_label: e.label ?? e.value ?? "" });
  } else if (t === "post_event")
    d = await (e.type === "img" ? $o : Jo)(i, { payload: ee(n, "file_id"), app: e.app ?? "android" });
  else throw y("不支持的批处理方法");
  T(d);
  const u = a + n.length;
  return C([{ ids: n, result: d }], u < r.length ? { offset: u } : null, { processed: u });
}
async function Ii(i, e, t) {
  const r = e.pairs ?? [], a = G(e.cursor?.offset ?? 0, 0, r.length), o = G(e.limit ?? 50, 1, 200), n = r.slice(a, a + o), s = [];
  if (t)
    for (const d of n) {
      const u = Array.isArray(d) ? d[0] : e.pid ?? 0, _ = Array.isArray(d) ? d[1] : d;
      s.push(await Ft(i, { pid: u, ...e.contain_dir ? { path: _ } : { name: _ } }));
    }
  else {
    const d = {};
    for (const [u, _] of n) {
      if (typeof _ != "string" || !_) throw y("文件名不能为空");
      d["files_new_name[" + N(u) + "]"] = _;
    }
    n.length && s.push(T(await Ct(i, { payload: d })));
  }
  return C(s, a + n.length < r.length ? { offset: a + n.length } : null);
}
async function ye(i, e, t) {
  if (t === "get_info") return T(await mi(i, { payload: { cid: N(e.id ?? 0) } }));
  if (t === "get_file_count" || t === "get_dir_count") {
    const a = await oe(i, { id: e.id ?? 0, limit: 1, get_raw: !0, payload: { cur: e.recursive ? 0 : 1, count_folders: 1, show_dir: 1 } });
    return Number(t === "get_dir_count" ? a.raw.folder_count ?? a.raw.data?.folder_count ?? 0 : a.raw.file_count ?? (a.raw.count ?? a.total) - Number(a.raw.folder_count ?? 0));
  }
  if (t === "get_id_to_sha1") {
    const a = T(await Mo(i, { payload: { sha1: e.sha1 } })), o = a.data?.file_id ?? a.data?.fid ?? a.file_id;
    if (o === void 0) throw y("找不到该 SHA1 对应文件", "not_found");
    return String(o);
  }
  if (t === "get_id_to_name" || t === "share_get_id_to_name") {
    let a = null;
    do {
      const o = e.recursive ? await xe(i, { ...e, id: e.cid ?? e.pid ?? 0, cursor: a, filter: { name: e.name, ...e.ensure_file !== void 0 ? { is_dir: !e.ensure_file } : {} } }) : await oe(i, { ...e, id: e.cid ?? e.pid ?? 0, offset: a?.offset ?? 0 }), n = o.items.find((s) => s.name === e.name && (e.ensure_file === void 0 || s.is_dir !== e.ensure_file));
      if (n) return n.id;
      a = e.recursive ? o.cursor : o.next === null ? null : { offset: o.next };
    } while (a && i.remaining() > 1e3);
    throw a ? y("查找尚未完成，请缩小起始目录", "busy") : y("文件名不存在", "not_found");
  }
  const r = await U(i, e.path ?? e.id_or_path ?? e.id ?? 0, e);
  if (t === "dir_getid" && !r.is_dir) throw y("路径不是目录", "not_found");
  return r.id;
}
async function Be(i, e, t) {
  const r = e.ids ?? e.pickcodes ?? [], a = e.cursor?.offset ?? 0, o = r.slice(a, a + G(e.limit ?? 100, 1, 200)), n = [];
  if (t === "skim")
    o.length && n.push(...T(await jo(i, { method: "POST", payload: { file_id: We(o).join(",") } })).data);
  else for (const s of o) {
    const d = typeof s == "object" ? s.id : s;
    try {
      t === "info" ? n.push(T(await mi(i, { payload: { cid: N(d) } }))) : t === "supervision" ? n.push(T(await Wo(i, { payload: { pickcode: typeof s == "object" ? s.pickcode : s } })).data) : t === "update" ? n.push(T(await E(i, { payload: { file_id: N(d) }, app: e.app ?? "android" })).data) : n.push(await kt(i, d));
    } catch (u) {
      if (u.code !== "not_found") throw u;
    }
  }
  return C(n, a + o.length < r.length ? { offset: a + o.length } : null);
}
async function re(i, e, t) {
  const r = t.startsWith("share_") ? ze(e) : t.startsWith("extract_") ? { kind: "zip", pickcode: e.pickcode } : e.scope;
  if (t === "share_iterdir" || t === "extract_iterdir") {
    const n = await oe(i, { ...e, id: e.path ?? e.cid ?? e.id ?? 0, scope: r, offset: e.cursor?.offset ?? e.offset ?? 0, marker: e.cursor?.marker ?? "" });
    return C(n.items, n.next === null ? null : r.kind === "zip" ? { marker: n.next } : { offset: n.next });
  }
  const a = { ...e.filter };
  t.includes("files") && (a.is_dir = !1), t === "iter_dirs" && (a.is_dir = !0);
  const o = await xe(i, { ...e, top: e.top ?? e.cid ?? e.id ?? 0, scope: r, filter: a });
  if (t === "iter_3_ancestor_names") {
    const n = [];
    for (const s of o.items) {
      const d = await Qe(i, s, { ...e, scope: r });
      n.push({ id: s.id, names: d.slice(-3).map((u) => u.name) });
    }
    return { ...o, items: n };
  }
  if (t === "get_id_to_dirnode") return { ...o, items: o.items.filter((n) => n.is_dir).map((n) => ({ id: n.id, name: n.name, parent_id: n.parent_id })) };
  if (t === "iter_keyed_ids" || t === "iter_keyed_dupfiles") {
    const n = { ...e.cursor?.groups ?? {} }, s = [];
    for (const d of o.items) {
      const u = e.key === "name" ? d.name : e.key === "size" ? String(d.size) : d.sha1 + ":" + d.size;
      t === "iter_keyed_ids" ? s.push({ key: u, id: d.id }) : n[u] ? s.push({ key: u, first: n[u], duplicate: d }) : n[u] = d;
    }
    if (JSON.stringify(n).length > 15e4) throw y("去重状态过大，请使用本地索引查询重复文件", "conflict");
    return { ...o, items: s, cursor: o.cursor ? { ...o.cursor, ...t === "iter_keyed_dupfiles" ? { groups: n } : {} } : null };
  }
  return o;
}
function lt(i) {
  const e = i.cursor ? JSON.parse(JSON.stringify(i.cursor)) : { depth: 0, line: "", pending: "", stack: [], serial: 0 }, t = (e.pending + String(i.text ?? "")).replace(/^\uFEFF/, ""), r = t.split(`
`), a = [];
  e.pending = i.final === !1 ? r.pop() : "", i.final !== !1 && r.at(-1) === "" && r.pop();
  function o(n = !1) {
    const s = e.depth, d = n && s === 0 && e.line === "根目录" ? "" : e.line;
    if (s > e.stack.length) throw y("目录树层级跳跃");
    const u = s ? e.stack[s - 1] : null, _ = ++e.serial, m = (u ? u.path + "/" : "") + (i.escape === !0 ? ue(d) : i.escape === !1 ? d.replaceAll("/", "|") : d), w = [...e.stack.slice(0, s).map((g) => g.name), d];
    e.stack[s] = { id: _, name: d, path: m }, e.stack.length = s + 1, a.push(i.format === "depth_name" ? [s, d] : i.format === "dict" ? { id: _, parent_id: u?.id ?? 0, depth: s, name: d } : i.format === "patht" ? w : m || "/");
  }
  for (const n of r) {
    const s = n.replace(/\r$/, ""), d = /^((?:\| )+)\|-(.*)$/.exec(s);
    d ? (o(!0), e.depth = d[1].length / 2, e.line = d[2]) : !e.line && s.startsWith("|——") ? e.line = s.slice(3) : e.line += `
` + s;
  }
  return i.final !== !1 && e.line && o(), C(a, i.final === !1 ? e : null);
}
const Ff = /* @__PURE__ */ f(he, "history");
const Jf = /* @__PURE__ */ f(he, "life");
const $f = /* @__PURE__ */ f(he, "offline");
function Kf(i, e) {
  return he(i, e, "offline-restart");
}
const Vf = /* @__PURE__ */ f(he, "search");
function Xf(i, e) {
  return he(i, e, "share-search");
}
const Yf = /* @__PURE__ */ f(he, "wish");
function Zf(i, e) {
  return he(i, e, "wish-aid");
}
const Qf = /* @__PURE__ */ f(M, "copy");
const eh = /* @__PURE__ */ f(M, "move");
const th = /* @__PURE__ */ f(M, "delete");
const ih = /* @__PURE__ */ f(M, "hide");
const oh = /* @__PURE__ */ f(M, "recyclebin_clean");
const rh = /* @__PURE__ */ f(M, "recyclebin_revert");
const ah = /* @__PURE__ */ f(M, "batch_label");
const nh = /* @__PURE__ */ f(M, "cover");
const lh = /* @__PURE__ */ f(M, "desc");
const sh = /* @__PURE__ */ f(M, "label");
const ph = /* @__PURE__ */ f(M, "show_play_long");
const dh = /* @__PURE__ */ f(M, "star");
const uh = /* @__PURE__ */ f(M, "score");
const ch = /* @__PURE__ */ f(M, "top");
const _h = /* @__PURE__ */ f(M, "category_shortcut");
function fh(i, e) {
  return M(i, e, e.method.replace(/^fs_/, " ").trim().replace(/_set$/, ""));
}
const hh = /* @__PURE__ */ f(M, "post_event");
function yh(i, e) {
  return Ii(i, e, !1);
}
function mh(i, e) {
  return Ii(i, e, !0);
}
const bh = /* @__PURE__ */ f(ye, "dir_getid");
const wh = /* @__PURE__ */ f(ye, "get_id_to_name");
const xh = /* @__PURE__ */ f(ye, "get_id_to_path");
function gh(i, e) {
  return ye(i, e, "get_id_to_sha1");
}
const kh = /* @__PURE__ */ f(ye, "get_info");
const Th = /* @__PURE__ */ f(ye, "get_file_count");
const Eh = /* @__PURE__ */ f(ye, "get_dir_count");
function qh(i, e) {
  return ye(i, { ...e, scope: ze(e) }, "share_get_id");
}
function vh(i, e) {
  return ye(i, { ...e, scope: ze(e) }, "share_get_id_to_name");
}
function Sh(i, e) {
  return ye(i, { ...e, scope: ze(e) }, "share_get_id_to_path");
}
const Oh = /* @__PURE__ */ f(re, "get_id_to_dirnode");
function Ph(i, e) {
  return re(i, e, "iter_3_ancestor_names");
}
const Gh = /* @__PURE__ */ f(re, "iter_dirs");
const Ah = /* @__PURE__ */ f(re, "iter_files");
const zh = /* @__PURE__ */ f(re, "iter_files_skim");
const Nh = /* @__PURE__ */ f(re, "iter_keyed_dupfiles");
const jh = /* @__PURE__ */ f(re, "iter_keyed_ids");
const Ih = /* @__PURE__ */ f(re, "share_iter_files");
const Uh = /* @__PURE__ */ f(re, "share_iterdir");
const Rh = /* @__PURE__ */ f(re, "extract_iter_files");
const Ch = /* @__PURE__ */ f(re, "extract_iterdir");
const Dh = /* @__PURE__ */ f(re, "traverse_tree");
function Mh(i, e) {
  return oe(i, { ...e, offset: e.cursor?.offset ?? e.offset ?? 0 });
}
function Lh(i, e) {
  return oe(i, { ...e, simple: !0 });
}
const Wh = /* @__PURE__ */ f(Be, "file");
const Bh = /* @__PURE__ */ f(Be, "skim");
const Hh = /* @__PURE__ */ f(Be, "info");
const Fh = /* @__PURE__ */ f(Be, "supervision");
const Jh = /* @__PURE__ */ f(Be, "update");
function $h(i, e) {
  return gi(i, {});
}
async function Kh(i, e) {
  return e.app_id > 0 && e.app_id % 2 === 1 && !V(await Rt(i, { payload: { client_id: e.app_id } }));
}
async function Vh(i, e) {
  return e.app_id > 0 && e.app_id % 2 === 1 ? (await nt(i, e, !0, !0)).name : null;
}
function Xh(i, e) {
  return lt({ ...e, format: "depth_name" });
}
function Yh(i, e) {
  return lt({ ...e, format: "dict" });
}
function Zh(i, e) {
  return lt({ ...e, format: "path" });
}
function Qh(i, e) {
  return lt({ ...e, format: "patht" });
}
async function ey(i, e) {
  return T(await co(i, { payload: { id: e.wish_id } })).data;
}
async function ty(i, e) {
  return T(await fo(i, { payload: { rewardSpace: e.size ?? 5, content: e.content ?? "随便许个愿" } })).data;
}
async function iy(i, e) {
  return T(await po(i, { payload: { id: e.wish_id, content: e.content ?? "帮你助个愿", file_ids: We(e.file_ids ?? []).join(",") } })).data;
}
async function oy(i, e) {
  return T(await so(i, { payload: { did: e.wish_id, aid: e.aid_id, to_cid: e.to_cid ?? 0 } }));
}
async function ry(i, e) {
  return T(await ho(i, { payload: { ids: Array.isArray(e.wish_id) ? e.wish_id.join(",") : e.wish_id } }));
}
function Ui(i) {
  if (typeof i.index != "string" || !i.index || i.index.length > 128) throw y("需要 index（每个账号使用不同索引名）");
  return i.index;
}
function ht(i) {
  if (!i) return i;
  const e = i.extra ? j(i.extra) : {};
  return { ...e, ...i, is_dir: !!i.is_dir, is_alive: !!i.is_alive, extra: e };
}
async function se(i, e, t) {
  if (t = N(t), t === "0") return { ..._t(), is_alive: !0 };
  const r = await i.db.query("SELECT * FROM nodes WHERE index_key=? AND id=? LIMIT 1", [e, t]);
  if (!r.length) throw y("索引中不存在该文件", "not_found");
  return ht(r[0]);
}
async function Ri(i, e, t) {
  const r = [], a = /* @__PURE__ */ new Set();
  let o = await se(i, e, t);
  for (; ; ) {
    if (a.has(o.id)) throw y("索引中存在父目录循环", "conflict");
    if (a.add(o.id), r.unshift(o), o.id === "0") return r;
    if (o = await se(i, e, o.parent_id), r.length > 1024) throw y("索引目录层级过深", "conflict");
  }
}
async function ii(i, e, t) {
  const r = Ht(t.path ?? ""), a = t.is_alive === !1 ? "" : " AND is_alive=1";
  let o = String(t.parent_id ?? 0);
  if (!r.length) return [o];
  for (let n = 0; n < r.length; n++) {
    if (r[n].name === ".." && !r[n].quoted) {
      if (o = (await se(i, e, o)).parent_id, n === r.length - 1) return [o];
      continue;
    }
    const s = n === r.length - 1, d = s ? t.ensure_file === void 0 ? "" : t.ensure_file ? " AND is_dir=0" : " AND is_dir=1" : " AND is_dir=1", u = await i.db.query("SELECT id FROM nodes WHERE index_key=? AND parent_id=? AND name=?" + a + d + " ORDER BY is_dir DESC,id LIMIT 200", [e, o, r[n].name]);
    if (!u.length) return [];
    if (s) return u.map((_) => _.id);
    o = u[0].id;
  }
}
async function R(i, e, t) {
  const r = Ui(e), a = N(e.id ?? e.parent_id ?? 0), o = e.is_alive === !1 ? "" : " AND is_alive=1";
  if (t === "get_attr") return se(i, r, a);
  if (["get_ancestors", "get_path", "get_patht"].includes(t)) {
    const g = await Ri(i, r, a);
    return t === "get_ancestors" ? g : t === "get_patht" ? g.map((x) => x.name) : "/" + g.slice(1).map((x) => ue(x.name)).join("/");
  }
  if (t === "has_id" || t === "is_alive") {
    if (a === "0") return !0;
    const g = await i.db.query("SELECT is_alive FROM nodes WHERE index_key=? AND id=?" + (t === "has_id" ? o : "") + " LIMIT 1", [r, a]);
    return t === "has_id" ? !!g.length : g.length ? !!g[0].is_alive : !0;
  }
  if (t === "get_parent_id") return (await se(i, r, a)).parent_id;
  if (["get_id", "path_to_id", "get_pickcode", "get_sha1"].includes(t)) {
    let g;
    if (e.id !== void 0 && t !== "path_to_id") g = await se(i, r, e.id);
    else if (e.pickcode || e.sha1) {
      const x = e.pickcode ? "pickcode" : "sha1", k = await i.db.query("SELECT * FROM nodes WHERE index_key=? AND " + x + "=?" + o + " LIMIT 1", [r, e[x]]);
      g = ht(k[0]);
    } else {
      const x = await ii(i, r, e);
      x.length && (g = await se(i, r, x[0]));
    }
    if (!g) throw y("索引查询没有结果", "not_found");
    return t === "get_pickcode" ? g.pickcode : t === "get_sha1" ? g.sha1 : g.id;
  }
  if (t === "get_count_tree") return Di(i, r, a, e.cursor);
  if (t === "iter_descendants" || t === "iter_descendants_bfs") return Ci(i, r, a, e);
  if (t === "iter_dangling_ids" || t === "select_na_ids") return Or(i, r, e, t === "select_na_ids");
  if (t === "iter_count_dir" || t === "iter_count_tree") return Sr(i, r, a, e, t === "iter_count_tree");
  if (t === "iter_id_to_parent_id" && e.recursive) return Pr(i, r, e);
  const n = G(e.cursor?.offset ?? e.offset ?? 0, 0, Number.MAX_SAFE_INTEGER), s = G(e.limit ?? 100, 1, 199);
  let d, u = [], _ = (g) => ht(g);
  if (t === "iter_id_to_path") {
    const g = await ii(i, r, e);
    return C(g.slice(n, n + s), n + s < g.length ? { offset: n + s } : null);
  }
  if (t === "iter_children")
    d = "SELECT * FROM nodes WHERE index_key=? AND parent_id=?" + o + (e.ensure_file === void 0 ? "" : e.ensure_file ? " AND is_dir=0" : " AND is_dir=1"), u = [r, a];
  else if (t === "iter_dup_files")
    d = "SELECT n.*,(SELECT COUNT(*) FROM nodes d WHERE d.index_key=n.index_key AND d.sha1=n.sha1 AND d.size=n.size AND d.is_dir=0 AND d.is_alive=1) AS total,(SELECT COUNT(*) FROM nodes d WHERE d.index_key=n.index_key AND d.sha1=n.sha1 AND d.size=n.size AND d.is_dir=0 AND d.is_alive=1 AND d.id<=n.id) AS nth FROM nodes n WHERE n.index_key=? AND n.is_dir=0 AND n.is_alive=1 AND total>1", u = [r];
  else if (t === "iter_dangling_parent_ids")
    d = "SELECT DISTINCT n.parent_id AS id FROM nodes n LEFT JOIN nodes p ON n.index_key=p.index_key AND n.parent_id=p.id WHERE n.index_key=? AND n.parent_id!='0' AND p.id IS NULL", u = [r], _ = (g) => g.id;
  else if (["iter_existing_id", "iter_id_to_parent_id", "iter_parent_id"].includes(t)) {
    const g = We(e.ids ?? []);
    if (g.length > 1e3) throw y("每次最多查询 1000 个 ID");
    d = "SELECT * FROM nodes WHERE index_key=? AND id IN (" + (g.map(() => "?").join(",") || "NULL") + ")" + (t === "iter_existing_id" ? o : ""), u = [r, ...g], _ = t === "iter_existing_id" ? (k) => k.id : t === "iter_parent_id" ? (k) => k.parent_id : (k) => [k.id, k.parent_id];
  } else throw y("未知索引查询");
  const m = await i.db.query(d + " ORDER BY " + (t === "iter_descendants_bfs" ? "depth," : "") + "id LIMIT ? OFFSET ?", [...u, s + 1, n]), w = [];
  for (const g of m.slice(0, s)) {
    let x = _(g);
    t === "iter_children" && Array.isArray(e.fields) && e.fields.length && (x = Object.fromEntries(e.fields.map((k) => [k, x[k] ?? null]))), w.push(x);
  }
  return C(w, m.length > s ? { offset: n + s } : null);
}
function Tt(i) {
  if (ie(JSON.stringify(i)).length > 15e4) throw y("索引游标过大，请分目录查询", "conflict");
  return i;
}
async function Ci(i, e, t, r) {
  const a = G(r.limit ?? 100, 1, 199), o = r.max_depth ?? -1, n = r.min_depth ?? 1;
  if (o >= 0 && o < n) return C([], null);
  const s = JSON.parse(JSON.stringify(r.cursor?.queue ?? [{ id: t, depth: 0, after: "", parents: [t] }])), d = [];
  for (; s.length && d.length < a && i.remaining() > 1500; ) {
    const u = s[0], _ = Math.min(100, a - d.length), m = await i.db.query("SELECT * FROM nodes WHERE index_key=? AND parent_id=? AND is_alive=1 AND id>? ORDER BY id LIMIT ?", [e, u.id, u.after, _]);
    for (const w of m) {
      u.after = w.id;
      const g = u.depth + 1;
      if (u.parents.includes(w.id)) throw y("索引中存在父目录循环", "conflict");
      if (w.is_dir && (o < 0 || g < o) && s.push({ id: w.id, depth: g, after: "", parents: [...u.parents, w.id] }), g < n || r.ensure_file !== void 0 && !!w.is_dir === r.ensure_file) continue;
      let x = ht(w);
      if (r.fields !== !1) {
        const k = await Ri(i, e, w.id);
        x.depth = g, x.ancestors = k.map((q) => ({ id: q.id, parent_id: q.parent_id, name: q.name })), x.path = "/" + k.slice(1).map((q) => ue(q.name)).join("/"), x.relpath = k.slice(k.findIndex((q) => q.id === t) + 1).map((q) => ue(q.name)).join("/");
      }
      typeof r.fields == "string" ? x = x[r.fields] ?? null : Array.isArray(r.fields) && r.fields.length && (x = Object.fromEntries(r.fields.map((k) => [k, x[k] ?? null]))), d.push(x);
    }
    m.length < _ && s.shift();
  }
  return C(d, s.length ? Tt({ queue: s }) : null);
}
async function Di(i, e, t, r) {
  const a = r ? JSON.parse(JSON.stringify(r)) : { queue: [t], seen: [], dir_count: 0, file_count: 0 };
  let o = 0;
  for (; a.queue.length && i.remaining() > 1500 && o++ < 100; ) {
    const n = a.queue[0];
    if (!a.after) {
      if (a.seen.includes(n)) throw y("索引中存在父目录循环", "conflict");
      a.seen.push(n);
      const d = (await i.db.query("SELECT COALESCE(SUM(is_dir),0) AS dirs,COALESCE(SUM(1-is_dir),0) AS files FROM nodes WHERE index_key=? AND parent_id=? AND is_alive=1", [e, n]))[0];
      a.dir_count += Number(d.dirs), a.file_count += Number(d.files);
    }
    const s = await i.db.query("SELECT id FROM nodes WHERE index_key=? AND parent_id=? AND is_dir=1 AND is_alive=1 AND id>? ORDER BY id LIMIT 199", [e, n, a.after ?? ""]);
    a.queue.push(...s.map((d) => d.id)), s.length === 199 ? a.after = s.at(-1).id : (a.queue.shift(), delete a.after);
  }
  return { dir_count: a.dir_count, file_count: a.file_count, complete: !a.queue.length, cursor: a.queue.length ? Tt(a) : null };
}
async function Sr(i, e, t, r, a) {
  const o = JSON.parse(JSON.stringify(r.cursor ?? { tree: null, root: t !== "0" ? t : null, pending: [] })), n = [], s = G(r.limit ?? 50, 1, 100);
  for (o.root && (o.pending.push({ id: o.root }), o.root = null); n.length < s && i.remaining() > 1500; ) {
    if (!o.pending.length) {
      if (o.finished) break;
      const _ = await Ci(i, e, t, { cursor: o.tree, ensure_file: !1, limit: Math.min(s - n.length, 50), fields: !1 });
      if (o.tree = _.cursor, o.finished = _.complete, o.pending.push(..._.items), !o.pending.length) break;
    }
    const d = o.pending[0], u = (await i.db.query("SELECT COALESCE(SUM(is_dir),0) AS dir_count,COALESCE(SUM(1-is_dir),0) AS file_count FROM nodes WHERE index_key=? AND parent_id=? AND is_alive=1", [e, d.id]))[0];
    if (Number(u.dir_count) + Number(u.file_count)) {
      const _ = { id: d.id, parent_id: (await se(i, e, d.id)).parent_id, ...u };
      if (a) {
        const m = await Di(i, e, d.id, o.count);
        if (!m.complete) {
          o.count = m.cursor;
          break;
        }
        _.tree_dir_count = m.dir_count, _.tree_file_count = m.file_count, delete o.count;
      }
      n.push(_);
    }
    o.pending.shift();
  }
  return C(n, o.finished && !o.pending.length ? null : Tt(o));
}
async function Or(i, e, t, r) {
  const a = await i.db.query("SELECT id,parent_id,is_alive FROM nodes WHERE index_key=? AND id>?" + (r ? " AND is_alive=1" : "") + " ORDER BY id LIMIT ?", [e, t.cursor?.after ?? "", G(t.limit ?? 100, 1, 199)]), o = [];
  let n = t.cursor?.after ?? "", s = 0;
  for (const d of a) {
    if (i.remaining() < 1500) break;
    let u = d;
    const _ = /* @__PURE__ */ new Set();
    for (; u.parent_id !== "0"; ) {
      if (_.has(u.id)) throw y("索引中存在父目录循环", "conflict");
      _.add(u.id);
      const m = await i.db.query("SELECT id,parent_id,is_alive FROM nodes WHERE index_key=? AND id=? LIMIT 1", [e, u.parent_id]);
      if (!m.length) {
        o.push(d.id);
        break;
      }
      if (u = m[0], r && !u.is_alive) break;
    }
    n = d.id, s++;
  }
  return C(o, a.length && (s < a.length || a.length === (t.limit ?? 100)) ? { after: n } : null);
}
async function Pr(i, e, t) {
  const r = JSON.parse(JSON.stringify(t.cursor ?? { queue: We(t.ids ?? []), seen: [] })), a = [], o = G(t.limit ?? 100, 1, 199);
  for (; r.queue.length && a.length < o && i.remaining() > 1500; ) {
    const n = r.queue.shift();
    if (n === "0" || r.seen.includes(n)) continue;
    r.seen.push(n);
    let s;
    try {
      s = await se(i, e, n);
    } catch (d) {
      if (d.code === "not_found") continue;
      throw d;
    }
    a.push([s.id, s.parent_id]), r.queue.push(s.parent_id);
  }
  return C(a, r.queue.length ? Tt(r) : null);
}
async function vt(i, e, t, r) {
  const a = t.id !== void 0 ? t : _e(t);
  await i.db.exec("INSERT INTO nodes(index_key,id,parent_id,name,sha1,size,pickcode,mtime,is_dir,is_alive,generation,extra) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(index_key,id) DO UPDATE SET parent_id=excluded.parent_id,name=excluded.name,sha1=excluded.sha1,size=excluded.size,pickcode=excluded.pickcode,mtime=excluded.mtime,is_dir=excluded.is_dir,is_alive=excluded.is_alive,generation=excluded.generation,extra=excluded.extra", [e, String(a.id), String(a.parent_id ?? 0), a.name ?? "", a.sha1 ?? "", String(a.size ?? 0), a.pickcode ?? "", Number(a.mtime ?? 0), +!!a.is_dir, a.is_alive === !1 ? 0 : 1, r, JSON.stringify(a)]);
}
async function Et(i, e, t) {
  const r = Ui(e);
  if (t === "init") return { index: r, ready: !0 };
  if (t === "events") {
    const n = await he(i, e, "life");
    for (const s of n.items) {
      const d = String(s.file_id);
      let u = {};
      try {
        u = await se(i, r, d);
      } catch (m) {
        if (m.code !== "not_found") throw m;
      }
      const _ = { ...u, id: d, parent_id: String(s.parent_id ?? u.parent_id ?? 0), name: s.file_name ?? u.name ?? "", sha1: s.sha1 ?? u.sha1 ?? "", size: s.file_size ?? u.size ?? 0, mtime: Number(s.update_time ?? 0), is_alive: Number(s.type) !== 22 };
      _.is_dir = !_.sha1, await vt(i, r, _, "event"), await i.db.exec("INSERT OR IGNORE INTO cloud_events(index_key,event_id,data) VALUES(?,?,?)", [r, String(s.id), JSON.stringify(s)]);
    }
    return n;
  }
  if (t === "import") {
    const n = e.entries ?? [];
    if (n.length > 200) throw y("每次导入最多 200 个条目");
    for (const s of n) await vt(i, r, s, "import");
    return { count: n.length };
  }
  const a = e.cursor ? JSON.parse(JSON.stringify(e.cursor)) : { queue: [{ id: N(e.cid ?? 0), offset: 0 }], generation: i.runId, processed: 0 };
  if (!Array.isArray(a.queue) || a.queue.length > 2e4) throw y("索引同步游标无效");
  let o = 0;
  for (; a.queue.length && i.remaining() > 2e3 && o++ < (e.pages ?? 1); ) {
    const n = a.queue[0], s = await oe(i, { id: n.id, offset: n.offset, limit: Math.min(e.limit ?? 100, 200) });
    for (const d of s.items)
      await vt(i, r, d, a.generation), d.is_dir && e.recursive !== !1 && a.queue.push({ id: d.id, offset: 0 }), a.processed++;
    s.next === null ? (e.only_alive || await i.db.exec("UPDATE nodes SET is_alive=0 WHERE index_key=? AND parent_id=? AND generation!=?", [r, n.id, a.generation]), a.queue.shift()) : n.offset = s.next;
  }
  return { index: r, processed: a.processed, complete: !a.queue.length, cursor: a.queue.length ? a : null };
}
const ay = /* @__PURE__ */ f(R, "get_ancestors");
const ny = /* @__PURE__ */ f(R, "get_attr");
const ly = /* @__PURE__ */ f(R, "get_count_tree");
const sy = /* @__PURE__ */ f(R, "get_id");
const py = /* @__PURE__ */ f(R, "get_parent_id");
const dy = /* @__PURE__ */ f(R, "get_path");
const uy = /* @__PURE__ */ f(R, "get_patht");
const cy = /* @__PURE__ */ f(R, "get_pickcode");
function _y(i, e) {
  return R(i, e, "get_sha1");
}
const fy = /* @__PURE__ */ f(R, "has_id");
const hy = /* @__PURE__ */ f(R, "is_alive");
const yy = /* @__PURE__ */ f(R, "iter_children");
const my = /* @__PURE__ */ f(R, "iter_count_dir");
const by = /* @__PURE__ */ f(R, "iter_count_tree");
const wy = /* @__PURE__ */ f(R, "iter_dangling_ids");
const xy = /* @__PURE__ */ f(R, "iter_dangling_parent_ids");
const gy = /* @__PURE__ */ f(R, "iter_descendants");
const ky = /* @__PURE__ */ f(R, "iter_descendants_bfs");
const Ty = /* @__PURE__ */ f(R, "iter_dup_files");
const Ey = /* @__PURE__ */ f(R, "iter_existing_id");
const qy = /* @__PURE__ */ f(R, "iter_id_to_parent_id");
const vy = /* @__PURE__ */ f(R, "iter_id_to_path");
const Sy = /* @__PURE__ */ f(R, "iter_parent_id");
const Oy = /* @__PURE__ */ f(R, "path_to_id");
const Py = /* @__PURE__ */ f(R, "select_na_ids");
const Gy = /* @__PURE__ */ f(Et, "init");
const Ay = /* @__PURE__ */ f(Et, "scan");
const zy = /* @__PURE__ */ f(Et, "events");
const Ny = /* @__PURE__ */ f(Et, "import");
function ut(i) {
  if (i == null) return {};
  if (typeof i == "object" && !Array.isArray(i)) return Object.fromEntries(Object.entries(i).map(([t, r]) => [t, String(r)]));
  const e = {};
  for (const t of String(i).split(";")) {
    const r = t.indexOf("=");
    if (r > 0) {
      const a = t.slice(0, r).trim(), o = t.slice(r + 1).trim();
      if (!/^[!#$%&'*+.^_`|~\w-]+$/.test(a) || /[\r\n]/.test(o)) throw y("Cookie 格式无效");
      e[a] = o;
    }
  }
  return e;
}
async function Te(i, e, t) {
  let r = e.session ? j(await i.secrets.open("p115-client", e.session)) : { kind: e.kind ?? "cookie", cookies: {}, headers: { "user-agent": "Mozilla/5.0", accept: "*/*" } };
  if (t === "from_path") {
    if (typeof e.path != "string" || !e.path.startsWith("/")) throw y("需要凭据文件的绝对路径");
    const o = await i.fs.readBytes(e.path, 0, 16385);
    if (o.length > 16384) throw y("凭据文件过大");
    r.cookies = ut(decodeURIComponent(Array.from(o, (n) => "%" + D(n)).join("")));
  }
  if (t === "init" || t === "update_cookies") {
    if (e.cookies !== void 0 && (r.cookies = t === "update_cookies" ? { ...r.cookies, ...ut(e.cookies) } : ut(e.cookies)), e.cookies === null && (r.cookies = {}), e.access_token && (r.access_token = e.access_token), e.refresh_token && (r.refresh_token = e.refresh_token), e.refresh_token && !e.access_token) {
      const o = T(await _i(i, { payload: { refresh_token: e.refresh_token } }));
      r.access_token = o.data.access_token, r.refresh_token = o.data.refresh_token;
    }
    if (e.headers && (r.headers = { ...r.headers, ...e.headers }), t === "init" && (r.kind === "cookie" ? !Object.keys(r.cookies).length : !r.access_token)) {
      const o = await Bt(i, { ...e, session: r.qr }, r.kind === "bearer");
      if (o.stage !== "complete")
        return r.qr = o.session, { stage: o.stage, qrcode: o.qrcode ?? null, session: await i.secrets.seal("p115-client", JSON.stringify(r)) };
      delete r.qr, r.kind === "cookie" ? r.cookies = ut(o.result.data.cookie) : (r.access_token = o.result.data.access_token, r.refresh_token = o.result.data.refresh_token);
    }
  }
  if (t === "cookies") return r.cookies;
  if (t === "cookies_str") return Object.entries(r.cookies).map(([o, n]) => o + "=" + n).join("; ");
  if (t === "headers") return r.headers;
  if (t === "user_id") {
    if (r.cookies.UID) return r.cookies.UID.split("_")[0];
    if (!r.access_token || !e.uuid) throw y("需要有效 session；令牌会话还需要 uuid");
    const o = T((await i.invoke({ version: 1, target: "com.tide.cloud115", operation: "open-user-info", uuid: e.uuid, credential: { kind: "bearer", inline: r.access_token }, args: {} })).data);
    return N(o.data.user_id);
  }
  return t === "login_ssoent" ? r.cookies.UID ? r.cookies.UID.split("_")[1] ?? "" : "" : { session: await i.secrets.seal("p115-client", JSON.stringify(r)), kind: r.kind, headers: r.headers, ...e.uuid ? { credential: await i.secrets.issue({ uuid: e.uuid, kind: r.kind, value: r.kind === "cookie" ? Object.entries(r.cookies).map(([o, n]) => o + "=" + n).join("; ") : r.access_token }) } : {} };
}
async function Gr(i) {
  const e = (await i.connection()).kind;
  if (e === "bearer") {
    const t = T(await lo(i, {}));
    return N(t.data?.user_id ?? t.user_id);
  }
  if (e === "cookie") return String(await v(i, {}));
  throw y("需要账号凭据", "forbidden");
}
async function oi(i, e) {
  const t = String(e.key ?? "");
  if (!t || t.length > 128) throw y("需要锁的 key");
  if (e.release)
    return { released: await i.db.exec("DELETE FROM client_locks WHERE lock_key=? AND token=?", [t, e.token ?? ""]) === 1 };
  const r = Date.now(), a = r + G(e.ttl_ms ?? 3e4, 100, 3e5), o = i.runId;
  return await i.db.exec("INSERT INTO client_locks(lock_key,token,expires) VALUES(?,?,?) ON CONFLICT(lock_key) DO UPDATE SET token=excluded.token,expires=excluded.expires WHERE client_locks.expires<?", [t, o, a, r]) ? { acquired: !0, key: t, token: o, expires: a } : { acquired: !1, key: t };
}
function Ee(i, e) {
  const t = i[e++];
  let r = i[e++];
  if (r & 128) {
    let a = r & 127;
    if (r = 0, a > 4) throw y("RSA DER 长度无效");
    for (; a--; ) r = r * 256 + i[e++];
  }
  if (e + r > i.length) throw y("RSA DER 截断");
  return { tag: t, start: e, end: e + r, data: i.slice(e, e + r) };
}
function Ar(i) {
  const e = wt(i.replace(/-----[^-]+-----/g, "").replace(/\s/g, ""));
  let t = Ee(e, 0), r = Ee(e, t.start);
  if (r.tag !== 2) {
    const o = Ee(e, r.end);
    if (o.tag !== 3 || o.data[0] !== 0) throw y("RSA 公钥结构无效");
    t = Ee(o.data, 1);
    const n = Ee(o.data, t.start), s = Ee(o.data, n.end);
    return { n: BigInt("0x" + n.data.map(D).join("")), e: BigInt("0x" + s.data.map(D).join("")), size: n.data[0] === 0 ? n.data.length - 1 : n.data.length };
  }
  const a = Ee(e, r.end);
  return { n: BigInt("0x" + r.data.map(D).join("")), e: BigInt("0x" + a.data.map(D).join("")), size: r.data[0] === 0 ? r.data.length - 1 : r.data.length };
}
async function jy(i, e) {
  if (e.sms_code) return ro(i, { payload: { account: e.account, code: e.sms_code } });
  if (e.session?.user_id)
    return { stage: "sms", session: e.session, result: await oo(i, { payload: { user_id: e.session.user_id } }) };
  const t = T(await Qi(i, {})), r = decodeURIComponent(wt(t.data.key).map((w) => "%" + D(w)).join("")), a = Ar(r), o = ie(await i.crypto.digest("sha1", e.password) + "_" + Math.floor(Date.now() / 1e3));
  if (a.size < o.length + 11 || a.size > 512) throw y("RSA 公钥位数不符合登录协议", "upstream");
  const n = [];
  for (; n.length < a.size - o.length - 3; ) {
    const w = await i.fs.readBytes("/dev/urandom", 0, a.size);
    for (const g of w) g && n.length < a.size - o.length - 3 && n.push(g);
  }
  let s = BigInt("0x" + [0, 2, ...n, 0, ...o].map(D).join("")), d = a.e, u = 1n;
  for (; d; )
    d & 1n && (u = u * s % a.n), s = s * s % a.n, d >>= 1n;
  const _ = pe(ne(u.toString(16).padStart(a.size * 2, "0"))), m = await eo(i, { app: e.app ?? "web", payload: { account: e.account, passwd: _, device_id: e.device_id ?? "", code: e.code ?? "", code_id: e.code_id ?? "" } });
  return Number(m.errno) === 40101010 ? { stage: "sms", session: { user_id: m.data.user_id }, result: m } : { stage: V(m) ? "challenge" : "complete", result: m };
}
async function Mi(i, e) {
  if (typeof e.url != "string" || !/^https:\/\/[^/]+\.115\.com(?:\/|$)/.test(e.url) && !e.url.startsWith("https://115.com/")) throw y("协议请求仅支持 115 HTTPS 地址");
  const t = e.method ?? "GET";
  if (!["GET", "POST", "PUT", "DELETE", "HEAD"].includes(t)) throw y("HTTP 方法无效");
  let r = e.url, a = e.body, o = { "User-Agent": "Mozilla/5.0", ...e.headers }, n;
  if (e.payload && (t === "GET" || t === "HEAD" ? r += (r.includes("?") ? "&" : "?") + H(e.payload) : (a = H(e.payload), o["Content-Type"] = "application/x-www-form-urlencoded")), e.ecdh_encrypt) {
    if (a) {
      const u = ie(a + "&"), _ = (16 - u.length % 16) % 16;
      n = await i.crypto.aesCBC("encrypt", je, Ie, u.map(D).join("") + D(_).repeat(_)), a = void 0;
    }
    r += (r.includes("?") ? "&" : "?") + "k_ec=" + qe(Nt(0));
  }
  const s = await i.http.request({ url: r, method: t, credential: e.credential !== !1, headers: o, ...a !== void 0 ? { body: a } : {}, ...n !== void 0 ? { bodyHex: n } : {}, ...e.ecdh_encrypt ? { response: "hex" } : {} });
  if (e.raw) return s;
  if (s.status < 200 || s.status >= 300) throw y("115 HTTP " + s.status, "upstream");
  const d = e.ecdh_encrypt ? jt(await i.crypto.aesCBC("decrypt", je, Ie, s.body)) : j(s.body);
  return e.check ? T(d) : d;
}
function Ne(i, e, t, r, a, o) {
  return r && (e += (e.includes("?") ? "&" : "?") + H({ app_ver: Z, ...r })), Mi(i, { url: e, method: t, ecdh_encrypt: !0, credential: !o, ...a ? { body: H(a) } : {}, headers: { "Content-Type": "application/x-www-form-urlencoded", "User-Agent": ai } });
}
async function Iy(i, e) {
  const t = { ...e.payload, ...e.action ? { ac: e.action } : {} }, r = e.type ?? "web";
  if (r === "ssp") {
    const a = await l(i, "https://clouddownload.115.com/lixianssp/", "POST", null, { data: ve(JSON.stringify(Object.fromEntries(Object.entries({ app_ver: Z, ...t }).map(([o, n]) => [o, String(n)])))) });
    if (typeof a.data == "string") try {
      a.data = j(Se(a.data));
    } catch {
    }
    return a;
  }
  return Mi(i, { url: "https://clouddownload.115.com/" + (r === "web" ? "web/" : ""), payload: t, method: e.method ?? "POST", ecdh_encrypt: r !== "web" && (e.method ?? "POST") === "POST" });
}
function zr(i) {
  let e = 0, t = 0;
  function r() {
    for (; /\s/.test(i[e] ?? "") && e < i.length; ) e++;
  }
  function a(n = 0) {
    if (r(), ++t > 1e5 || n > 32) throw y("区域数据过深或过大", "upstream");
    const s = i[e++];
    if (s === "{" || s === "[") {
      const u = s === "{" ? {} : [], _ = s === "{" ? "}" : "]";
      for (r(); i[e] !== _; ) {
        if (s === "{") {
          r();
          const m = i[e] === '"' || i[e] === "'", w = i[e] === "'" || i[e] === '"' ? a(n + 1) : (/^[\w]+/.exec(i.slice(e)) ?? [])[0];
          if (w === void 0) throw y("区域数据键无效", "upstream");
          if (m || (e += String(w).length), r(), i[e++] !== ":") throw y("区域数据结构无效", "upstream");
          Object.defineProperty(u, w, { value: a(n + 1), enumerable: !0 });
        } else u.push(a(n + 1));
        if (r(), i[e] === _) break;
        if (i[e++] !== ",") throw y("区域数据分隔无效", "upstream");
        r();
      }
      return e++, u;
    }
    if (s === "'" || s === '"') {
      let u = "";
      for (; e < i.length; ) {
        const _ = i[e++];
        if (_ === s) return u;
        if (_ === "\\") {
          const m = i[e++];
          if (m === "u" || m === "x") {
            const w = m === "u" ? 4 : 2, g = i.slice(e, e + w);
            if (!new RegExp("^[0-9a-f]{" + w + "}$", "i").test(g)) throw y("区域字符串转义无效");
            u += String.fromCharCode(parseInt(g, 16)), e += w;
          } else u += { n: `
`, r: "\r", t: "	", b: "\b", f: "\f" }[m] ?? m;
        } else u += _;
      }
      throw y("区域字符串未结束");
    }
    e--;
    const d = /^(?:-?\d+(?:\.\d+)?|true|false|null)/.exec(i.slice(e));
    if (!d) throw y("区域数据包含非字面量", "upstream");
    return e += d[0].length, JSON.parse(d[0]);
  }
  const o = a();
  if (r(), e !== i.length) throw y("区域数据含额外内容", "upstream");
  return o;
}
async function st(i, e, t) {
  if (t === "area") {
    let s = function(d) {
      for (const [u, _] of Object.entries(d)) /^\d+$/.test(u) && (n.push([Number(u), typeof _ == "object" ? _.n : _]), _ && typeof _ == "object" && (_.c || _.t) && s(_.c || _.t));
    };
    const r = await i.http.request({ url: "https://cdnres.115.com/my/m_r/setting_new/js/ylmf_area.js", credential: !1 }), a = /(?<=n=)\{[\s\S]+?\}(?=;)/.exec(r.body)?.[0];
    if (!a) throw y("区域数据未找到", "upstream");
    const o = zr(a), n = [];
    return s(o), { state: !0, data: n };
  }
  if (t === "face") {
    const r = await i.http.request({ url: "https://my.115.com/api/face_code.js", credential: !1 });
    return j(r.body.slice(25, -1));
  }
  if (t === "authorize") {
    const r = await i.net.request({ url: "https://qrcodeapi.115.com/open/authorize?" + H({ response_type: "code", ...e.payload }), responseType: "text", followRedirects: !1 });
    if (r.status === 302) {
      const a = r.headers.location?.[0] ?? r.headers.Location?.[0], o = {};
      for (const n of (a.split("?")[1] ?? "").split("&")) {
        const [s, ...d] = n.split("=");
        o[decodeURIComponent(s)] = decodeURIComponent(d.join("=").replaceAll("+", " "));
      }
      return { state: !0, url: a, data: o, headers: r.headers };
    }
    return j(r.body);
  }
  if (t === "logout") {
    const r = e.app ?? (await gt(i))?.icon;
    if (!r) throw y("无法确定退出的设备");
    if ((await i.http.request({ url: "https://qrcodeapi.115.com/app/1.0/" + h({ app: r }, "web", !1) + "/1.0/logout/logout", credential: !0 })).status !== 200) throw y("退出登录失败", "upstream");
    return null;
  }
  if (t === "avatar2") {
    let r = e.base64;
    if (r === void 0) {
      const a = await i.fs.readBytes(e.path, 0, 196609);
      if (a.length > 196608) throw y("头像超过单次请求限制，请先缩小图片");
      r = pe(a);
    }
    return Xe(i, "https://job.115.com/api/1.0/" + h(e, "web", !1) + "/1.0/upload/avatar", { method: "POST", body: "img=" + r, headers: { "Content-Type": "application/x-www-form-urlencoded" } });
  }
  throw y("未知客户端辅助操作");
}
const Uy = /* @__PURE__ */ f(Te, "init");
const Ry = /* @__PURE__ */ f(Te, "from_path");
const Cy = /* @__PURE__ */ f(Te, "cookies");
const Dy = /* @__PURE__ */ f(Te, "cookies_str");
const My = /* @__PURE__ */ f(Te, "headers");
const Ly = /* @__PURE__ */ f(Te, "update_cookies");
const Wy = /* @__PURE__ */ f(Te, "user_id");
const By = /* @__PURE__ */ f(Te, "login_ssoent");
async function Hy(i, e) {
  return T(await Le(i, {})).userkey;
}
function Fy(i, e) {
  return T(e.response);
}
function Jy(i, e) {
  return me(e.value);
}
async function $y(i, e) {
  return ji(e.value, await kr(i, e), e.prefix ?? "a");
}
const Ky = /* @__PURE__ */ f(st, "area");
const Vy = /* @__PURE__ */ f(st, "face");
const Xy = /* @__PURE__ */ f(st, "authorize");
const Yy = /* @__PURE__ */ f(st, "logout");
function Zy(i, e) {
  return st(i, e, "avatar2");
}
function Qy(i, e) {
  return { url: e.url, headers: e.headers ?? {}, offset: e.start ?? 0, readAction: "client-read-range", seekable: !0 };
}
function em(i, e) {
  return Ni(i, { size: e.size, id: "external", is_dir: !1 }, { ...e, offset: e.start ?? 0, length: e.length ?? 65536 }, "read");
}
async function ke(i, e, t) {
  const r = (await i.connection()).kind === "bearer" ? "open" : "cookie", a = await Gr(i);
  let o = e.state ? await Ji(i, "p115-upload", e.state) : null;
  if (t === "init") {
    const n = await i.fs.sourceInfo(), s = await at(i, e, r);
    if (o = { v: 1, mode: r, account: a, size: n.size, stamp: n.stamp, filename: e.filename, partSize: G(e.partSize ?? 8388608, 102400, 5368709120), pickcode: s.pickcode ?? s.pick_code ?? null, remote: { bucket: s.bucket, object: s.object, callback: s.callback }, parts: [] }, Math.ceil(n.size / o.partSize) > 1e4) throw y("请增大分片，单文件最多 10000 片");
    if (Number(s.status) === 2)
      o.result = s, o.complete = !0;
    else {
      const d = await Ot(i, r);
      if (n.size === 0) {
        const u = await le(i, d, o.remote, "PUT", {}, { ossHeaders: Pt(o.remote), range: { offset: 0, length: 0 } });
        o.result = T(j(u.body)), o.complete = !0;
      } else {
        const u = await le(i, d, o.remote, "POST", { sequential: "1", uploads: "1" });
        if (o.uploadId = /<UploadId>([A-Za-z0-9._-]+)<\/UploadId>/.exec(u.body)?.[1], !o.uploadId) throw y("OSS 上传 ID 缺失", "upstream");
      }
    }
  } else {
    if (!o || o.v !== 1 || o.mode !== r || o.account !== a) throw y("上传状态与账号不匹配");
    if (t === "completed") return !!o.complete;
    if (t === "succeeded") return !!(o.complete && o.result && !V(o.result));
    if (t === "result") return o.result ?? null;
    if (!o.complete) {
      const n = await Ot(i, r);
      if (t === "list" || t === "step" || t === "complete") {
        const s = await Nr(i, n, o), d = new Map(o.parts.map((u) => [u.number, u]));
        for (const u of s) {
          const _ = d.get(u.number);
          u.verified = !!(_?.verified && _.etag.toLowerCase().replaceAll('"', "") === u.etag.toLowerCase().replaceAll('"', ""));
        }
        o.parts = s;
      }
      if (t === "list") {
        const s = G(e.part_number_start ?? 1, 1, 1e4) - 1, d = G(e.limit ?? 100, 1, 500);
        return { parts: o.parts.slice(s, s + d), next_part_number: s + d < o.parts.length ? s + d + 1 : null, state: await yt(i, "p115-upload", o) };
      }
      if (t === "step") {
        const s = await i.fs.sourceInfo();
        if (s.size !== o.size || s.stamp !== o.stamp) throw y("续传源文件发生变化", "conflict");
        for (const m of o.parts) if (!m.verified) {
          if (i.remaining() < 2500 || m.size > 16777216) break;
          if ((await i.fs.hashRange("@source", (m.number - 1) * o.partSize, m.size, "md5")).toLowerCase() !== m.etag.replaceAll('"', "").toLowerCase()) throw y("服务器分片与源文件摘要不符", "conflict");
          m.verified = !0;
        }
        const d = o.parts.findIndex((m) => !m.verified);
        d >= 0 && (o.parts = o.parts.slice(0, d));
        let u = o.parts.reduce((m, w) => m + w.size, 0), _ = 0;
        for (; u < o.size && i.remaining() > 2500 && _++ < G(e.parts_per_call ?? 1, 1, 16); ) {
          const m = o.parts.length + 1, w = Math.min(o.partSize, o.size - u), g = await le(i, n, o.remote, "PUT", { partNumber: m, uploadId: o.uploadId }, { range: { offset: u, length: w } });
          if (!/^"?[a-fA-F0-9]{32}"?$/.test(g.etag ?? "")) throw y("OSS 分片 ETag 无效", "upstream");
          o.parts.push({ number: m, size: w, etag: g.etag, verified: !0 }), u += w;
        }
      }
      if (t === "complete") {
        if (o.parts.some((u) => !u.verified) || o.parts.reduce((u, _) => u + _.size, 0) !== o.size) throw y("分片尚未全部上传或校验，请先调用 multipart-step", "conflict");
        const s = "<CompleteMultipartUpload>" + o.parts.map((u) => "<Part><PartNumber>" + u.number + "</PartNumber><ETag>" + u.etag + "</ETag></Part>").join("") + "</CompleteMultipartUpload>", d = await le(i, n, o.remote, "POST", { uploadId: o.uploadId }, { body: s, type: "text/xml", ossHeaders: Pt(o.remote) });
        o.result = T(j(d.body)), o.complete = !0;
      }
      if (t === "url" || t === "urls") {
        const s = G(e.part_number ?? e.part_number_start ?? 1, 1, 1e4), d = [];
        for (let u = s; u < s + (t === "url" ? 1 : G(e.limit ?? 10, 1, 100)); u++) d.push(await jr(i, n, o, u));
        return t === "url" ? d[0] : C(d, { part_number_start: s + d.length });
      }
    }
  }
  return { state: await yt(i, "p115-upload", o), pickcode: o.pickcode, size: o.size, uploaded: o.complete ? o.size : o.parts.reduce((n, s) => n + s.size, 0), complete: !!o.complete, readyToComplete: o.parts.reduce((n, s) => n + s.size, 0) === o.size, result: o.result ?? null };
}
async function Nr(i, e, t) {
  const r = [];
  let a = 0;
  do {
    const o = await le(i, e, t.remote, "GET", { uploadId: t.uploadId, "max-parts": 1e3, ...a ? { "part-number-marker": a } : {} });
    for (const s of o.body.matchAll(/<Part>([\s\S]*?)<\/Part>/g)) {
      const d = Number(/<PartNumber>(\d+)<\/PartNumber>/.exec(s[1])?.[1]), u = Number(/<Size>(\d+)<\/Size>/.exec(s[1])?.[1]), _ = /<ETag>(["\w-]+)<\/ETag>/.exec(s[1])?.[1];
      if (d !== r.length + 1 || !Number.isSafeInteger(u) || u !== Math.min(t.partSize, t.size - (d - 1) * t.partSize) || !/^"?[a-fA-F0-9]{32}"?$/.test(_ ?? "")) throw y("服务器分片与源文件计划不一致", "conflict");
      r.push({ number: d, size: u, etag: _ });
    }
    if (!/<IsTruncated>true<\/IsTruncated>/.test(o.body)) break;
    const n = Number(/<NextPartNumberMarker>(\d+)<\/NextPartNumberMarker>/.exec(o.body)?.[1]);
    if (n <= a || r.length > 1e4) throw y("OSS 分片游标无效", "upstream");
    a = n;
  } while (!0);
  return r;
}
async function jr(i, e, t, r) {
  const a = { partNumber: r, uploadId: t.uploadId }, o = Ue(a), n = (/* @__PURE__ */ new Date()).toUTCString(), s = pe(ne(await i.crypto.hmacSHA1(e.secret, ["PUT", "", "", n, "x-oss-security-token:" + e.token, "/" + t.remote.bucket + "/" + t.remote.object + "?" + o].join(`
`))));
  return { method: "PUT", url: "https://fhnfile.oss-cn-shenzhen.aliyuncs.com/" + t.remote.object + "?" + o, headers: { date: n, "x-oss-security-token": e.token, authorization: "OSS " + e.key + ":" + s }, part_number: r, offset: (r - 1) * t.partSize, length: Math.max(0, Math.min(t.partSize, t.size - (r - 1) * t.partSize)) };
}
async function Li(i, e) {
  const t = e.entry ?? await U(i, e.id ?? e.path ?? 0, e), r = N(e.pid ?? 0), a = e.name ?? t.name;
  if (t.is_dir) throw y("秒传复制需要文件");
  const o = (await i.connection()).kind === "bearer" ? "open" : "cookie", n = { filename: a, sha1: t.sha1, sizeBytes: Number(t.size), remoteDir: r, dirname: e.dirname ?? "" };
  let s = {};
  const d = o === "cookie" ? T(await Le(i, {})) : null;
  for (let u = 0; u < 2; u++) {
    const _ = d ? await It(i, n, d, s) : T(await l(i, De + "/upload/init", "POST", null, { file_name: a, fileid: t.sha1, file_size: t.size, target: "U_1_" + r, ...s })).data;
    if (Number(_.status) === 2) return _;
    if (Number(_.status) === 7 && u === 0) {
      const m = /^(\d+)-(\d+)$/.exec(_.sign_check ?? "");
      if (!m) throw y("秒传校验区间无效", "upstream");
      const w = e.source_url ? { url: e.source_url, headers: e.source_headers ?? {}, size: t.size } : await ce(i, t, e), g = await Jt(i, w, { offset: Number(m[1]), length: Number(m[2]) - Number(m[1]) + 1, digests: ["sha1"] });
      if (!g.complete) throw y("秒传挑战超出本次期限，请提供源文件续传", "timeout");
      s = { sign_key: _.sign_key, sign_val: g.digests.sha1.toUpperCase() };
      continue;
    }
    return _;
  }
}
const tm = /* @__PURE__ */ f(ke, "init");
const im = /* @__PURE__ */ f(ke, "step");
const om = /* @__PURE__ */ f(ke, "complete");
const rm = /* @__PURE__ */ f(ke, "list");
const am = /* @__PURE__ */ f(ke, "url");
const nm = /* @__PURE__ */ f(ke, "urls");
const lm = /* @__PURE__ */ f(ke, "completed");
const sm = /* @__PURE__ */ f(ke, "succeeded");
const pm = /* @__PURE__ */ f(ke, "result");
async function dm(i, e) {
  return Mt(i, { ...e, pid: (await U(i, e.pid ?? 0)).id }, (await i.connection()).kind === "bearer" ? "open" : "cookie");
}
async function um(i, e) {
  return at(i, e, (await i.connection()).kind === "bearer" ? "open" : "cookie");
}
function cm(i, e) {
  return Wt(i, { ...e, filename: "x.jpg" }, !1);
}
async function _m(i, e) {
  return [2, 7].includes(Number((await Oi(i, { payload: { fileid: e.sha1.toUpperCase(), filesize: e.size, filename: "?" } })).status));
}
async function qt(i, e, t) {
  if (t === "raw") {
    const s = T(await xt(i, { pickcode: e.pickcode, path: e.path ?? "", nextMarker: e.cursor?.marker ?? "", pageCount: e.limit ?? 100, app: e.app }));
    return C(s.data.list, s.data.next_marker ? { marker: s.data.next_marker } : null);
  }
  const r = e.app ?? "web", a = !["", "web", "desktop", "aps"].includes(r);
  let o, n;
  return t === "push" ? (o = a ? qo : Eo, n = { pick_code: e.pickcode, secret: e.secret ?? "" }) : t === "push_progress" ? (o = a ? So : vo, n = { pick_code: e.pickcode }) : (o = a ? To : ko, n = { extract_id: e.extract_id }), T(await o(i, { payload: n, ...a ? { app: r } : {} }));
}
async function pt(i, e, t) {
  const r = { kind: "zip", pickcode: e.pickcode };
  if (t === "load") return xe(i, { ...e, top: "/", scope: r });
  if (t === "id_to_path" || t === "path_to_id") return (await U(i, e.path ?? e.id ?? "/", { ...e, scope: r })).id;
  const a = [], o = [];
  for (const n of e.paths ?? [e.path ?? e.id ?? "/"]) {
    const s = await U(i, n, { ...e, scope: r });
    (s.is_dir ? o : a).push(Ae(s.id).join("/"));
  }
  return Gi(i, { pickcode: e.pickcode, files: a, dirs: o, to_pid: e.to_pid ?? 0, app: e.app });
}
async function dt(i, e, t) {
  let r = e.cursor ?? {}, a = e.export_id ?? r.export_id;
  if ((t === "parse" || t === "export") && !r.file_id) {
    const w = a === void 0 ? "0" : me(a);
    (e.file_id !== void 0 || BigInt(w) >= 1n << 60n) && (r = { ...r, file_id: me(e.file_id ?? w), offset: 0, parser: null });
  }
  if (t === "start" || t === "export" && !a && !r.file_id) {
    const w = String(e.target ?? 0);
    if (a = T(await Ao(i, { payload: { file_ids: (e.file_ids ?? [0]).map(me).join(","), target: w.startsWith("U_") ? w : "U_1_" + me(w), ...e.layer_limit ? { layer_limit: e.layer_limit } : {} } })).data.export_id, r = { export_id: a }, t === "start") return a;
  }
  if (!r.file_id) {
    const w = T(await zo(i, { payload: { export_id: a } }));
    if (t === "status") return w.data || { export_id: a };
    if (!w.data || !w.data.file_id) return { items: [], complete: !1, stage: "exporting", cursor: { export_id: a } };
    if (t === "result") return w.data;
    r = { ...r, file_id: String(w.data.file_id), offset: 0, parser: null };
  }
  const o = await kt(i, r.file_id), n = await ce(i, o, e), s = Math.min(32768, Number(o.size) - r.offset), d = s ? await i.net.request({ url: n.url, headers: { ...n.headers, Range: "bytes=" + r.offset + "-" + (r.offset + s - 1) }, responseType: "bytes", maxBytes: 32768, followRedirects: !0 }) : { status: 200, body: new Uint8Array() };
  if (d.status !== 206 && !(d.status === 200 && r.offset === 0 && Number(o.size) <= 32768)) throw y("无法读取导出的目录树", "upstream");
  if (d.body.length !== s || s % 2) throw y("目录树 UTF-16 数据长度错误", "upstream");
  let u = "";
  for (let w = 0; w < d.body.length; w += 2) u += String.fromCharCode(d.body[w] | d.body[w + 1] << 8);
  const _ = r.offset + s >= Number(o.size), m = lt({ text: u, cursor: r.parser, final: _, format: e.format ?? "path", escape: e.escape });
  return _ && e.delete && T(await Me(i, { payload: ee([r.file_id]) })), { items: m.items, complete: _, stage: _ ? "complete" : "reading", cursor: _ ? null : { export_id: a, file_id: r.file_id, offset: r.offset + s, parser: m.cursor } };
}
async function Ir(i, e) {
  const t = Array.isArray(e.sha1) ? e.sha1 : [e.sha1], r = t.map((u) => {
    const _ = String(u);
    if (/^[0-9a-f]{40}$/i.test(_)) return _.toUpperCase();
    if (/^fhn[a-z]+_/.test(_)) return _;
    if (/^[A-Z2-7]{32}$/i.test(_)) {
      let m = 0, w = 0, g = "";
      for (const x of _.toUpperCase())
        w = w << 5 | "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567".indexOf(x), m += 5, m >= 8 && (m -= 8, g += D(w >>> m & 255));
      return g.toUpperCase();
    }
    return "fhnfile_" + _;
  }), a = e.select ?? "life_v1", o = { life_v1: Ko, life_v2: Vo, note_v1: er, note_v2: tr }[a];
  if (!o) throw y("图片接口类型无效");
  const n = r.length === 1 ? { rs: r[0] } : ee(r, "rs"), s = T(await o(i, { payload: n }));
  let d;
  return a === "life_v1" ? d = s.data.map((u) => u.json.replace("&i=0", "&i=1")) : a === "life_v2" ? d = s.data.json.map((u) => u + "&i=1") : d = s.data.map((u) => "https://q.115.com/imgload?" + u.slice(u.indexOf("&") + 1) + "&i=1"), Array.isArray(e.sha1) ? d : d[0];
}
async function fm(i, e) {
  if (!e.pickcode) return xe(i, { ...e, top: e.top ?? 0, filter: { is_dir: e.files === !1 } });
  const t = { pickcode: e.pickcode, page: e.cursor?.page ?? 1, per_page: G(e.limit ?? 200, 1, 1e3) }, r = T(await (e.files === !1 ? wo : bo)(i, { payload: t })), a = r.data, o = [];
  for (const n of a.list ?? []) {
    let s = e.files === !1 ? { is_dir: !0, id: String(n.fid), parent_id: String(n.pid), name: n.fn } : { is_dir: !1, id: me(n.pc), pickcode: n.pc, parent_id: String(n.pid), size: n.fs, sha1: n.sha1 ?? "", ...n.fn ? { name: n.fn } : {} };
    e.ensure_name && !s.name && (s = { ...s, ...await kt(i, s.id) }), o.push(e.get_raw ? n : s);
  }
  return C(o, a.has_next_page ? { page: t.page + 1 } : null);
}
async function Ur(i, e) {
  const t = (await i.connection()).kind === "bearer" ? "open" : "cookie";
  if (Array.isArray(e.pickcodes)) {
    const o = e.cursor?.offset ?? 0, n = e.pickcodes.slice(o, o + Math.min(e.limit ?? 10, 64)), s = [];
    for (const u of n) s.push(typeof u == "string" && /^[a-f]/.test(u) ? u : (await U(i, u)).pickcode);
    const d = s.length ? await we(i, { pickcode: s.join(","), strict: !1, userAgent: e.userAgent }, t, !1) : [];
    return C(d, o + n.length < e.pickcodes.length ? { offset: o + n.length } : null);
  }
  const r = await xe(i, { ...e, top: e.top ?? e.id ?? 0, filter: { is_dir: !1 }, limit: Math.min(e.limit ?? 10, 64) }), a = [];
  for (const o of r.items) a.push(await ce(i, o, e));
  return { ...r, items: a };
}
async function hm(i, e) {
  const t = await U(i, e.entry ?? e.id_or_path ?? e.id ?? 0, e), r = await ce(i, t, e), a = e.destination;
  if (typeof a != "string" || !a.startsWith("/")) throw y("需要绝对目标路径");
  let o = 0, n = !1;
  try {
    o = (await i.fs.stat(a)).size, n = !0;
  } catch (d) {
    if (!/not exist|不存在|no such/i.test(d.message) && d.code !== "not_found") throw d;
  }
  if (n && !e.resume && !e.cursor) throw y("目标文件已存在", "conflict");
  if (o > Number(t.size)) throw y("目标文件长度超过源文件", "conflict");
  if (o)
    for (const d of [.../* @__PURE__ */ new Set([0, Math.max(0, o - 65536)])]) {
      const u = Math.min(65536, o - d), _ = await i.fs.hashRange(a, d, u, "sha1"), m = await Jt(i, r, { offset: d, length: u, digests: ["sha1"] });
      if (!m.complete || _ !== m.digests.sha1) throw y("目标文件与源文件不匹配", "conflict");
    }
  else n || await i.fs.writeBytes(a, new Uint8Array());
  let s = 0;
  for (; o < Number(t.size) && i.remaining() > 1500 && s++ < G(e.chunks ?? 8, 1, 64); ) {
    const d = Math.min(1048576, Number(t.size) - o), u = await i.net.request({ url: r.url, headers: { ...r.headers, Range: "bytes=" + o + "-" + (o + d - 1) }, responseType: "bytes", maxBytes: d, followRedirects: !0 });
    if (u.status !== 206 && !(u.status === 200 && o === 0 && Number(t.size) === d) || u.body.length !== d) throw y("下载区间响应不匹配", "upstream");
    await i.fs.writeAt(a, u.body, o), o += d;
  }
  return { destination: a, bytes: o, total: t.size, complete: o === Number(t.size), cursor: o === Number(t.size) ? null : { offset: o, id: t.id, size: t.size } };
}
async function ym(i, e) {
  const t = await U(i, e.id_or_path ?? e.id ?? 0, e), r = await ce(i, t, e), a = Number(t.size), o = e.cursor ?? { id: t.id, size: a, offset: 0, block: Fe("md4"), all: Fe("md4") };
  if (o.id !== t.id || o.size !== a) throw y("ED2K 游标与文件不匹配");
  let n = 0;
  for (; o.offset < a && i.remaining() > 1500 && n++ < 32; ) {
    const u = Math.min(262144, a - o.offset, 9728e3 - o.block.total), _ = await i.net.request({ url: r.url, headers: { ...r.headers, Range: "bytes=" + o.offset + "-" + (o.offset + u - 1) }, responseType: "bytes", maxBytes: u, followRedirects: !0 });
    if (_.status !== 206 && !(_.status === 200 && o.offset === 0 && a === u) || _.body.length !== u) throw y("ED2K 读取范围错误", "upstream");
    Je(o.block, _.body), o.offset += u, o.block.total === 9728e3 && (Je(o.all, ne($e(o.block))), o.block = Fe("md4"));
  }
  if (o.offset < a) return { complete: !1, bytes: o.offset, cursor: o };
  Je(o.all, ne($e(o.block)));
  const s = $e(o.all), d = (e.name ?? t.name).replaceAll("%", "%25").replaceAll("/", "%2F").replaceAll("|", "%7C");
  return { complete: !0, cursor: null, bytes: a, hash: s, url: "ed2k://|file|" + d + "|" + a + "|" + s + "|/" };
}
async function $t(i, e, t) {
  const r = We(e.ids ?? []);
  if (r.length > 1e3) throw y("每次最多 1000 个文件");
  if (t === "star") await M(i, { ids: r, value: !0, batch_size: 1e3 }, "star");
  else if (t === "event")
    T(await gi(i, {})), await M(i, { ids: r, batch_size: 1e3, type: e.type ?? "img" }, "post_event");
  else {
    const a = T(await Lt(i, { payload: "tide-" + i.runId }, !1)), o = String(a.data?.[0]?.id ?? a.data?.list?.[0]?.id ?? a.data?.id ?? "");
    if (!o) throw y("创建临时标签失败", "upstream");
    try {
      await M(i, { ids: r, batch_size: 1e3, label: o, mode: e.replace_label === !1 ? "add" : "reset" }, "batch_label");
      const n = T(await wi(i, { payload: { file_label: o, limit: Math.max(1, r.length), offset: 0 } }));
      return C((n.data ?? []).map((s) => _e(s)), null);
    } finally {
      T(await Do(i, { payload: { id: o } }));
    }
  }
  if (t === "event") {
    const a = await he(i, { ...e, type: e.type === "doc" ? "browse_document" : "browse_image", yield_latest: !0 }, "life");
    return { ...a, items: a.items.filter((o) => r.includes(String(o.file_id))) };
  }
  return Be(i, { ...e, ids: r }, "file");
}
async function mm(i, e) {
  const t = e.cursor?.start_time ?? e.start_time ?? Math.floor(Date.now() / 1e3) - 2, r = e.cursor?.end_time ?? e.end_time ?? Math.floor(Date.now() / 1e3), a = [], o = JSON.parse(JSON.stringify(e.cursor?.pending ?? [])), n = o.length ? null : T(await Xo(i, { payload: { show_type: 0, start_time: t, end_time: r }, app: e.app ?? "web" }));
  for (const s of n?.data.list ?? []) {
    if (!s.items) {
      Number(s.update_time) > t && Number(s.update_time) < r && a.push(s);
      continue;
    }
    a.push(...s.items.map((d) => ({ ...d, behavior_type: s.behavior_type, date: s.date }))), (s.total > s.items.length || s.behavior_type.startsWith("upload_")) && o.push({ type: s.behavior_type, date: s.date, offset: 0, seen: s.items.map((d) => String(d.id)) });
  }
  for (; o.length && i.remaining() > 1500 && a.length < 200; ) {
    const s = o[0], d = T(await xi(i, { payload: { type: s.type, date: s.date, offset: s.offset, limit: 32 } })).data;
    for (const u of d.list ?? []) !s.seen.includes(String(u.id)) && Number(u.update_time) > t && Number(u.update_time) < r && (a.push({ ...u, behavior_type: s.type, date: s.date }), s.seen.push(String(u.id)));
    d.next_page ? s.offset += 32 : o.shift();
  }
  if (ie(JSON.stringify(o)).length > 15e4) throw y("事件游标过大，请缩小时间段", "conflict");
  return { items: a, complete: !o.length, cursor: { start_time: o.length ? t : r, ...o.length ? { end_time: r } : {}, pending: o }, nextPollAfterMS: 1e3 };
}
async function bm(i, e) {
  const t = T(await Yo(i, {})), r = [];
  for (const a of t.data ?? []) (!e.app_ids || e.app_ids.map(String).includes(String(a.app_id))) && r.push({ auth_id: a.auth_id, result: T(await Zo(i, { payload: { auth_id: a.auth_id } })) });
  return r;
}
async function wm(i, e) {
  const t = [];
  for (const r of e.items ?? []) {
    const a = await Qe(i, r, e);
    t.push({ ...r, ancestors: a, path: "/" + a.slice(1).map((o) => ue(o.name)).join("/") });
  }
  return t;
}
async function xm(i, e) {
  const t = await Ir(i, { sha1: e.sha1, select: "note_v1" }), r = await i.net.request({ url: t, method: "HEAD", followRedirects: !0, responseType: "bytes", maxBytes: 1024 });
  return r.status !== 404 && r.status >= 200 && r.status < 400;
}
async function Wi(i, e, t) {
  const r = await U(i, e.entry ?? e.id ?? 0, e), a = String(e.pid ?? r.parent_id), o = e.name ?? r.name;
  if (r.is_dir) throw y("此组合动作只接受文件");
  if (a === r.parent_id && o === r.name) return { state: !0, unchanged: !0 };
  if (!t && o === r.name) return T(await it(i, { payload: { ...ee([r.id]), pid: a } }));
  if (t && Ze(o) === Ze(r.name))
    return a !== r.parent_id && T(await bt(i, { payload: { ...ee([r.id]), pid: a } })), o === r.name ? { state: !0 } : T(await Ct(i, { payload: { ["files_new_name[" + r.id + "]"]: o } }));
  const n = await Li(i, { entry: r, pid: a, name: o });
  return t && Number(n.status) === 2 && T(await Me(i, { payload: ee([r.id]) })), n;
}
async function Kt(i, e, t) {
  const r = String(await v(i, e));
  let a = e.cursor ? await Ji(i, "p115-file-job", e.cursor.state) : null;
  if (a || (a = { job: i.runId, account: r, phase: "plan", scan: null, top: e.top ?? 0, pid: String(e.pid ?? 0), flatten: !!e.flatten, operation: t, planned: 0, done: 0 }), a.account !== r || a.operation !== t) throw y("批处理游标与账号或操作不匹配");
  if (!e.cursor) {
    const _ = Date.now() - 2592e6;
    await i.db.exec("DELETE FROM file_jobs WHERE job IN (SELECT job FROM file_job_runs WHERE created<?)", [_]), await i.db.exec("DELETE FROM file_job_runs WHERE created<?", [_]), await i.db.exec("INSERT INTO file_job_runs(job,created) VALUES(?,?)", [a.job, Date.now()]);
  }
  const o = (await i.db.query("SELECT complete,planned,processed FROM file_job_runs WHERE job=? LIMIT 1", [a.job]))[0];
  if (!o) throw y("批处理记录已过期", "not_found");
  if (o.complete) return { planned: o.planned, processed: o.processed, complete: !0, cursor: null };
  if (a.phase === "plan") {
    const _ = await xe(i, { top: a.top, cursor: a.scan, filter: { is_dir: !1 }, limit: Math.min(e.limit ?? 100, 200) });
    for (const m of _.items)
      await i.db.exec("INSERT OR IGNORE INTO file_jobs(job,id,data,status) VALUES(?,?,?,'pending')", [a.job, m.id, JSON.stringify(m)]), a.planned++;
    return a.scan = _.cursor, _.complete && (a.phase = "apply"), a.planned = Number((await i.db.query("SELECT COUNT(*) AS count FROM file_jobs WHERE job=?", [a.job]))[0].count), await i.db.exec("UPDATE file_job_runs SET planned=? WHERE job=?", [a.planned, a.job]), { phase: a.phase, planned: a.planned, processed: a.done, complete: !1, cursor: { state: await yt(i, "p115-file-job", a) } };
  }
  if (e.resolve_id) {
    if (!["done", "pending"].includes(e.resolution)) throw y("resolution 必须为 done 或 pending");
    await i.db.exec("UPDATE file_jobs SET status=? WHERE job=? AND id=? AND status='running'", [e.resolution, a.job, N(e.resolve_id)]);
  }
  const n = await i.db.query("SELECT id,data,status FROM file_jobs WHERE job=? AND status!='done' ORDER BY id LIMIT ?", [a.job, Math.min(e.limit ?? 10, 100)]), s = [];
  for (const _ of n) {
    if (_.status === "running") throw y("上次写入结果不确定，请核对该文件后用 resolve_id 标记结果", "conflict");
    const m = j(_.data);
    let w = a.pid;
    if (t !== "delete" && !a.flatten) {
      const x = Ae(m.path).slice(0, -1);
      x.length && (w = (await Ft(i, { pid: w, path: x })).id);
    }
    if (!await i.db.exec("UPDATE file_jobs SET status='running' WHERE job=? AND id=? AND status='pending'", [a.job, _.id])) throw y("该批处理已在其他调用中执行", "busy");
    const g = T(await (t === "copy" ? it : t === "move" ? bt : Me)(i, { payload: { ...ee([_.id]), ...t !== "delete" ? { pid: w } : {} } }));
    await i.db.exec("UPDATE file_jobs SET status='done' WHERE job=? AND id=?", [a.job, _.id]), a.done++, s.push({ id: _.id, result: g });
  }
  const d = await i.db.query("SELECT COUNT(*) AS count FROM file_jobs WHERE job=? AND status!='done'", [a.job]), u = Number(d[0].count) === 0;
  return a.done = a.planned - Number(d[0].count), await i.db.exec("UPDATE file_job_runs SET complete=?,processed=? WHERE job=?", [Number(u), a.done, a.job]), { items: s, planned: a.planned, processed: a.done, complete: u, cursor: u ? null : { state: await yt(i, "p115-file-job", a) } };
}
async function gm(i, e) {
  const t = await oe(i, { id: 0, offset: 0, limit: e.limit ?? 100, payload: { cur: 0, star: 1, ...e.ensure_file !== void 0 ? { show_dir: +!e.ensure_file } : {} } });
  return t.items.length && await M(i, { ids: t.items.map((r) => r.id), value: !1, batch_size: 1e3 }, "star"), { processed: t.items.length, complete: t.next === null, cursor: t.next === null ? null : { continue: !0 } };
}
async function Bi(i, e, t) {
  const r = e.cursor?.offset ?? 0;
  let a;
  if (e.entries) {
    const n = e.entries.slice(r, r + Math.min(e.limit ?? 10, 50));
    a = C(n, r + n.length < e.entries.length ? { offset: r + n.length } : null);
  } else {
    if (!e.source?.uuid || !e.source?.credential) throw y("需要源账号 source.uuid 与 source.credential");
    a = (await i.invoke({ version: 1, target: "com.tide.cloud115", operation: "vfs-iter", uuid: e.source.uuid, credential: e.source.credential, args: { id: e.top ?? 0, filter: { is_dir: !1 }, limit: Math.min(e.limit ?? 5, 20), ...e.cursor ? { cursor: e.cursor } : {} } })).data;
  }
  const o = [];
  for (const n of a.items) {
    let s = String(e.pid ?? 0);
    const d = n.path ? Ae(n.path).slice(0, -1) : [];
    if (!e.flatten && d.length && (s = (await Ft(i, { pid: s, path: d })).id), t) {
      const m = (await Oe(i, { id: s })).find((w) => w.name === n.name && w.sha1 === n.sha1 && String(w.size) === String(n.size));
      if (m) {
        o.push({ source: n.id, outcome: "existing", id: m.id });
        continue;
      }
    }
    let u = n.url ? { url: n.url, headers: n.headers } : null;
    !u && e.source && (u = (await i.invoke({ version: 1, target: "com.tide.cloud115", operation: "vfs-get-url", uuid: e.source.uuid, credential: e.source.credential, args: { id_or_path: n } })).data);
    const _ = await Li(i, { entry: n, pid: s, source_url: u?.url, source_headers: u?.headers });
    o.push({ source: n.id, result: _ });
  }
  return { ...a, items: o };
}
async function km(i, e) {
  let t;
  if (Array.isArray(e.file_ids)) {
    const o = e.cursor?.offset ?? 0, n = e.file_ids.slice(o, o + Math.min(e.limit ?? 50, 200));
    t = C(n.map((s) => ({ id: s })), o + n.length < e.file_ids.length ? { offset: o + n.length } : null);
  } else
    t = await xe(i, { ...e, top: e.top ?? e.file_ids ?? 0, filter: { is_dir: !1 } }), t.items = t.items.filter((o) => /\.(srt|ass|ssa)$/i.test(o.name));
  if (!t.items.length) return t;
  const r = T(await bi(i, { payload: { pid: 0, cname: "subtitle-" + i.runId } })), a = String(r.cid ?? r.data?.file_id ?? r.data?.category_id);
  try {
    T(await it(i, { payload: { ...ee(t.items.map((s) => String(s.id))), pid: a } }));
    const o = await oe(i, { id: a, limit: 1 });
    if (!o.items[0]) return { ...t, items: [] };
    const n = T(await Ho(i, { payload: { pickcode: o.items[0].pickcode } }));
    return { ...t, items: (n.data.list ?? []).filter((s) => s.file_id !== void 0) };
  } finally {
    T(await Me(i, { payload: ee([a]) }));
  }
}
async function Tm(i, e) {
  const t = G(e.limit ?? 16, 1, 64), r = [], a = e.urls ?? (await Ur(i, { top: e.top ?? 0, limit: t })).items;
  let o = 0, n = "limit";
  try {
    for (const s of a.slice(0, t)) {
      if (i.remaining() < 2e3) {
        n = "deadline";
        break;
      }
      const d = /^https:\/\/([^/:]+)(?::443)?(\/.*)?$/.exec(typeof s == "string" ? s : s.url);
      if (!d) throw y("下载链接必须是 HTTPS");
      try {
        const u = await i.net.connect({ address: d[1] + ":443", tls: !0, timeoutMs: 5e3 });
        r.push(u.handle);
        const _ = typeof s == "string" ? {} : s.headers ?? {};
        if (Object.values(_).some((x) => /[\r\n]/.test(String(x)))) throw y("下载请求头无效");
        const m = "GET " + (d[2] ?? "/") + ` HTTP/1.1\r
Host: ` + d[1] + `\r
Connection: keep-alive\r
` + Object.entries(_).map(([x, k]) => x + ": " + k + `\r
`).join("") + `\r
`;
        await i.net.write({ handle: u.handle, data: new Uint8Array(ie(m)), timeoutMs: 5e3 });
        const w = await i.net.readBytes({ handle: u.handle, length: 256, timeoutMs: 5e3 }), g = String.fromCharCode(...w.data);
        if (!/^HTTP\/1\.[01] 20[06]/.test(g)) {
          n = "refused";
          break;
        }
        o++;
      } catch (u) {
        n = u.code ?? "unavailable";
        break;
      }
    }
    return { count: o, complete: n === "refused", bounded: !0, stopReason: n };
  } finally {
    for (const s of r) try {
      await i.net.close({ handle: s });
    } catch {
    }
  }
}
async function Em(i, e) {
  if (typeof e.temp_dir != "string" || !e.temp_dir.startsWith("/")) throw y("需要 temp_dir 保存单个传输块");
  const t = await U(i, e.id ?? me(e.pickcode), e), r = await ce(i, t, e), a = G(e.block_size ?? 52428800, 1, 268435456), o = e.cursor?.block_number ?? e.start_block_number ?? 1, n = (o - 1) * a;
  if (n >= Number(t.size)) return C([], null);
  const s = Math.min(a, Number(t.size) - n), d = e.temp_dir.replace(/\/$/, "") + "/tide-block-" + i.runId;
  let u = !1;
  try {
    const _ = await i.net.request({ url: r.url, headers: { ...r.headers, Range: "bytes=" + n + "-" + (n + s - 1) }, outputPath: d, followRedirects: !0 });
    if (u = !0, _.bytes !== s || _.status !== 206 && !(_.status === 200 && n === 0 && s === Number(t.size))) throw y("源文件范围响应错误", "upstream");
    const m = {};
    for (const k of e.hashmethods ?? ["sha1", "md5"]) m[k] = Fe(k);
    for (let k = 0; k < s; k += 1048576) {
      const q = await i.fs.readBytes(d, k, Math.min(1048576, s - k));
      for (const ae of Object.values(m)) Je(ae, q);
    }
    const w = Object.fromEntries(Object.entries(m).map(([k, q]) => [k, $e(q)])), g = await i.fs.source(d), x = await i.invoke({ version: 1, target: "com.tide.cloud115", operation: "tool-upload-block", uuid: e.account.uuid, credential: e.account.credential, args: { sourceRef: g, filename: "block-" + o } });
    return C([{ block_number: o, block_size: s, hashes: w, result: x.data }], n + s < Number(t.size) ? { block_number: o + 1 } : null);
  } finally {
    u && await i.fs.remove(d);
  }
}
async function qm(i, e) {
  const t = T(await l(i, "https://uplb.115.com/3.0/sampleinitupload.php", "POST", null, { filename: e.filename, path: "", target: "U_12_0" })), r = await i.http.request({ url: String(t.host).replace(/^http:/, "https:"), method: "POST", multipart: { filename: e.filename, fields: { name: e.filename, key: t.object, policy: t.policy, OSSAccessKeyId: t.accessid, success_action_status: "200", callback: t.callback, signature: t.signature } } });
  if (r.status !== 200) throw y("块上传结果需核对", "upstream");
  return T(j(r.body));
}
const vm = /* @__PURE__ */ f(qt, "raw");
const Sm = /* @__PURE__ */ f(qt, "push");
const Om = /* @__PURE__ */ f(qt, "push_progress");
const Pm = /* @__PURE__ */ f(qt, "progress");
const Gm = /* @__PURE__ */ f(pt, "load");
const Am = /* @__PURE__ */ f(pt, "id_to_path");
const zm = /* @__PURE__ */ f(pt, "path_to_id");
const Nm = /* @__PURE__ */ f(pt, "extract");
const jm = /* @__PURE__ */ f(pt, "extract_many");
const Im = /* @__PURE__ */ f(dt, "start");
const Um = /* @__PURE__ */ f(dt, "status");
const Rm = /* @__PURE__ */ f(dt, "result");
const Cm = /* @__PURE__ */ f(dt, "parse");
const Dm = /* @__PURE__ */ f(dt, "export");
async function Mm(i, e) {
  return ce(i, await U(i, e.value ?? e.id_or_path ?? e.id ?? 0, e), e);
}
const Lm = /* @__PURE__ */ f($t, "event");
const Wm = /* @__PURE__ */ f($t, "label");
const Bm = /* @__PURE__ */ f($t, "star");
const Hm = /* @__PURE__ */ f(Kt, "copy");
const Fm = /* @__PURE__ */ f(Kt, "move");
const Jm = /* @__PURE__ */ f(Kt, "delete");
function $m(i, e) {
  return Wi(i, e, !1);
}
function Km(i, e) {
  return Wi(i, e, !0);
}
function Vm(i, e) {
  return Bi(i, e, !1);
}
function Xm(i, e) {
  return Bi(i, e, !0);
}
function Hi(i) {
  const e = /^(https?):\/\/([^/?#]+)([^?#]*)(?:\?([^#]*))?(?:#(.*))?$/.exec(i);
  if (!e) throw y("URL 格式无效");
  return { scheme: e[1], host: e[2], path: e[3] || "/", query: e[4] ?? "", hash: e[5] ?? "" };
}
function Fi(i) {
  const e = {};
  for (const t of i.split("&")) {
    if (!t) continue;
    const [r, ...a] = t.split("=");
    e[decodeURIComponent(r.replaceAll("+", " "))] = decodeURIComponent(a.join("=").replaceAll("+", " "));
  }
  return e;
}
function ri(i) {
  return i.scheme + "://" + i.host + i.path + (i.query ? "?" + i.query : "") + (i.hash ? "#" + i.hash : "");
}
function Rr(i) {
  let e = String(i.path ?? ""), t = i.app ?? "", r = i.base_url ?? "", a = i.domain ?? "";
  e.startsWith("/") || (e = "/" + e), i.version && (e = "/" + i.version + e);
  let o = typeof i.query == "string" ? i.query : H(i.query ?? {});
  if (/^https?:\/\/[fn]\.115\.com\/api\/proxy\/115/.test(r)) return r + (r.includes("?") ? "" : "?") + (a ? "&domain=" + a : "") + "&path=" + e + (o ? "?" + o : "");
  let n = Array.isArray(i.force_app) ? i.force_app.includes(t) : i.force_app;
  return t.startsWith("=") && (n = !0, t = t.slice(1)), r || (r = t || e.startsWith("/open/") ? "https://proapi.115.com" : a ? (a === "web.api" || a === "pro.api" ? "http://" : "https://") + a + ".115.com" : "https://webapi.115.com"), ["windows", "mac", "linux"].includes(t) && (t = "os_" + t), t && !e.startsWith("/open/") && (!n && !["ios", "115ios", "115ipad", "android", "115android", "harmony", "os_windows", "os_mac", "os_linux"].includes(t) && (t = t.endsWith("ios") ? "ios" : t.endsWith("ipad") ? "115ipad" : "android"), e = "/" + t + e), typeof i.query == "string" && (o = H(Cr(i.query))), e = e.replace(/[?#]/g, (s) => s === "?" ? "%3F" : "%23"), r + e + (o ? (r.includes("?") ? "&" : "?") + o : "");
}
function Cr(i) {
  return i.split("&").filter((e) => e.includes("=") && e.slice(e.indexOf("=") + 1)).map((e) => {
    const t = e.indexOf("=");
    return [e.slice(0, t), e.slice(t + 1)].map((r) => decodeURIComponent(r.replaceAll("+", " ")));
  });
}
function Ve(i, e, t = {}) {
  const r = Hi(i), a = Fi(r.query), o = ["thumb.115.com", "thumbapi.115.com"].includes(r.host);
  if (e === "reduce") {
    if (!o) return i;
    const [n, s] = r.path.split("/").at(-1).split("_");
    return "https://imgjump.115.com/?sha1=" + n + "&size=" + (t.size !== void 0 && t.size !== "" ? t.size : s || "0") + "&" + r.query;
  }
  if (e === "cdn") {
    const n = r.host === "115.com" ? "site" : /^([^.]+)\.115\.com$/.exec(r.host)?.[1];
    return !n || n === "proapi" ? i : ri({ ...r, host: t.host ?? "115cdn.com", path: "/" + n + r.path, query: "", hash: "" });
  }
  if (Object.hasOwn(a, "x-oss-process")) delete a["x-oss-process"];
  else if (r.host === "imgjump.115.com") a.size = "0";
  else {
    if (o)
      return a.sha1 = r.path.split("/").at(-1).split("_")[0], a.size = "0", "https://imgjump.115.com/?" + H(a);
    if (r.path.endsWith("/imgload")) a.i = "1";
    else return i;
  }
  return ri({ ...r, query: H(a) });
}
async function Dr(i, e) {
  let t = e.url;
  const r = /* @__PURE__ */ new Set();
  for (let a = 0; a < 16; a++) {
    if (r.has(t)) throw y("图片跳转循环", "upstream");
    r.add(t);
    const o = /\/([1-5]\d\d)\.jpg/.exec(t);
    if (o) return Number(o[1]);
    const n = Hi(t), s = Fi(n.query);
    if (Object.hasOwn(s, "x-oss-process")) return Ve(t, "max");
    if (["thumb.115.com", "thumbapi.115.com"].includes(n.host)) {
      t = Ve(t, "reduce");
      continue;
    }
    if (n.host !== "imgjump.115.com" && !n.path.endsWith("/imgload") && s.ct !== "imgload") return t;
    const d = await i.net.request({ url: t, method: "HEAD", followRedirects: !1, responseType: "bytes", maxBytes: 1024 });
    if (d.status === 404) return 404;
    const u = d.headers.location?.[0] ?? d.headers.Location?.[0];
    if (!u) return t;
    t = u;
  }
  throw y("图片跳转次数过多", "upstream");
}
async function F(i, e, t) {
  const r = e.value;
  if (t === "is_valid_id") return typeof r == "number" && Number.isSafeInteger(r) && r >= 0 || typeof r == "string" && /^(0|[1-9]\d*)$/.test(r);
  if (t === "is_valid_name") return typeof r == "string" && !/[>/]/.test(r);
  if (t === "is_valid_sha1") return typeof r == "string" && /^(?:[a-f\d]{40}|[a-z2-7]{32})$/i.test(r);
  if (t === "is_valid_pickcode") {
    if (r === "") return !0;
    const a = typeof r == "string" ? et(r) : "";
    return !!(Re[a] && r.length >= a.length + 5 && /^[a-z0-9]+$/.test(r) && Ce("0", a) === r.at(-4));
  }
  if (t === "normalize_pickcode") return String(r).startsWith("f") ? ji(me(r), r) : r;
  if (t === "posix_escape_name") return String(r).replaceAll("/", e.repl ?? "|");
  if (t === "unescape_115_charref") return String(r).replace(/\[\x02(\d+)\]/g, (a, o) => String.fromCodePoint(Number(o)));
  if (t === "determine_part_size") {
    const a = Number(e.size), o = e.min_part_size ?? 10485760, n = e.max_part_count ?? 1e4;
    if (!Number.isSafeInteger(a) || a < 0 || o <= 0 || n <= 0) throw y("分片参数无效");
    if (a <= o) return a;
    let s = o;
    for (; s < Math.ceil(a / n); ) s *= 2;
    return s;
  }
  if (t === "complete_url") return Rr(e);
  if (t === "share_extract_payload") return X(r);
  if (t === "reduce_image_url_layers") return Ve(r, "reduce", e);
  if (t === "max_image_quality") return Ve(r, "max", e);
  if (t === "to_cdn_url") return Ve(r, "cdn", e);
  if (t === "load_final_image") return Dr(i, { url: r });
  if (t === "get_stable_point" || t === "set_stable_point" || t === "get_user_key" || t === "set_user_key") {
    const a = (t.endsWith("user_key") ? "key:" : "point:") + N(e.user_id);
    if (t.startsWith("set")) {
      const n = t.endsWith("user_key") ? String(r) : Ke(r);
      return await i.db.exec("INSERT INTO support_cache(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", [a, await i.secrets.seal("p115-cache", n)]), n;
    }
    const o = await i.db.query("SELECT value FROM support_cache WHERE key=? LIMIT 1", [a]);
    if (!o.length) throw y("尚未缓存该账号的数据", "not_found");
    return i.secrets.open("p115-cache", o[0].value);
  }
  if (t === "call_with_lock") {
    const a = await oi(i, e);
    if (!a.acquired) throw y("锁正被使用", "busy");
    try {
      return (await i.invoke(e.call)).data;
    } finally {
      await oi(i, { key: e.key, token: a.token, release: !0 });
    }
  }
  throw y("未知支持函数");
}
function Mr(i) {
  const e = i.value ?? {}, t = i.operation ?? "of";
  if (t === "geturl" || t === "url") return typeof e == "string" ? e : e.url;
  if (t === "get") return Object.hasOwn(e, i.key) ? e[i.key] : i.default ?? null;
  if (t === "keys") return Object.keys(e);
  if (t === "values") return Object.values(e);
  if (t === "items") return Object.entries(e);
  if (t === "derive" || t === "derive_backend") return { ...e, ...i.updates };
  if (t === "UID") {
    const r = String(e.UID ?? e);
    return { value: r, user_id: r.split("_")[0], ssoent: r.split("_")[1] ?? "", mtime: r.split("_")[2] ?? "" };
  }
  return ["CID", "SEID", "KID"].includes(t) ? e[t] ?? "" : e;
}
async function Ym(i, e) {
  const t = await i.db.query("SELECT value FROM support_constants WHERE name=? LIMIT 1", [e.name]);
  if (!t.length) throw y("常量不存在", "not_found");
  const r = j(t[0].value);
  if (e.key !== void 0) {
    if (!Object.hasOwn(r, e.key)) throw y("常量键不存在", "not_found");
    return r[e.key];
  }
  return r;
}
function Vt(i, e = !1) {
  if (i.url !== void 0) {
    if (/^https?:\/\/\//.test(i.url)) throw y("115 返回无效下载地址", "upstream");
    return i.url;
  }
  const t = i.type ?? "P115OSError", r = /FileNotFound/.test(t) ? "not_found" : /Authentication|Login|AccessToken|AccessError|AuthLimit/.test(t) ? "forbidden" : /Busy/.test(t) ? "busy" : /InvalidArgument/.test(t) ? "invalid_input" : /NotSupported/.test(t) ? "unavailable" : "upstream", a = { type: t, code: r, errno: i.errno ?? 5, message: i.message ?? null };
  if (!e) return a;
  const o = y(typeof a.message == "string" ? a.message : JSON.stringify(a.message), r);
  throw o.name = t, o;
}
let Lr = 0;
async function yt(i, e, t) {
  const r = i.runId + "-" + ++Lr, a = Date.now(), o = JSON.stringify(t), n = [];
  let s = "";
  if (ie(o).length > 2 * 1024 * 1024) throw y("检查点过大，请缩小任务", "conflict");
  for (const d of o)
    s += d, s.length >= 1e4 && (n.push(s), s = "");
  s && n.push(s), await i.db.exec("DELETE FROM checkpoints WHERE created<?", [a - 30 * 864e5]);
  for (let d = 0; d < n.length; d++) await i.db.exec("INSERT INTO checkpoints(id,part,created,value) VALUES(?,?,?,?)", [r, d, a, await i.secrets.seal(e, n[d])]);
  return i.secrets.seal(e, JSON.stringify({ checkpoint: r, parts: n.length }));
}
async function Ji(i, e, t) {
  const r = j(await i.secrets.open(e, t));
  if (!r.checkpoint) return r;
  let a = "";
  for (let o = 0; o < r.parts; o++) {
    const n = await i.db.query("SELECT value FROM checkpoints WHERE id=? AND part=? LIMIT 1", [r.checkpoint, o]);
    if (!n.length) throw y("检查点已过期或被清除", "not_found");
    a += await i.secrets.open(e, n[0].value);
  }
  return j(a);
}
const Zm = /* @__PURE__ */ f(F, "call_with_lock");
const Qm = /* @__PURE__ */ f(F, "complete_url");
const e1 = /* @__PURE__ */ f(F, "determine_part_size");
const t1 = /* @__PURE__ */ f(F, "get_stable_point");
const i1 = /* @__PURE__ */ f(F, "get_user_key");
const o1 = /* @__PURE__ */ f(F, "is_valid_id");
const r1 = /* @__PURE__ */ f(F, "is_valid_name");
const a1 = /* @__PURE__ */ f(F, "is_valid_pickcode");
function n1(i, e) {
  return F(i, e, "is_valid_sha1");
}
const l1 = /* @__PURE__ */ f(F, "load_final_image");
const s1 = /* @__PURE__ */ f(F, "max_image_quality");
const p1 = /* @__PURE__ */ f(F, "normalize_pickcode");
const d1 = /* @__PURE__ */ f(F, "posix_escape_name");
const u1 = /* @__PURE__ */ f(F, "reduce_image_url_layers");
const c1 = /* @__PURE__ */ f(F, "set_stable_point");
const _1 = /* @__PURE__ */ f(F, "set_user_key");
const f1 = /* @__PURE__ */ f(F, "share_extract_payload");
const h1 = /* @__PURE__ */ f(F, "to_cdn_url");
function y1(i, e) {
  return F(i, e, "unescape_115_charref");
}
function m1(i, e) {
  return Mr(e);
}
function b1(i, e) {
  return Vt(e);
}
function w1(i, e) {
  return Vt(e, !0);
}
function x1(i, e) {
  return Vt(e);
}
export {
  so as "act-xys-adopt",
  po as "act-xys-aid-desire",
  ga as "act-xys-aid-desire-del",
  uo as "act-xys-desire-aid-list",
  ka as "act-xys-get-act-info",
  co as "act-xys-get-desire-info",
  Ta as "act-xys-home-list",
  Ea as "act-xys-my-aid-desire",
  _o as "act-xys-my-desire",
  fo as "act-xys-wish",
  ho as "act-xys-wish-del",
  bh as "attr-dir-getid",
  Eh as "attr-get-dir-count",
  Th as "attr-get-file-count",
  wh as "attr-get-id-to-name",
  xh as "attr-get-id-to-path",
  gh as "attr-get-id-to-sha1",
  kh as "attr-get-info",
  F_ as "attr-normalize",
  $_ as "attr-normalize-app",
  K_ as "attr-normalize-app2",
  V_ as "attr-normalize-simple",
  J_ as "attr-normalize-web",
  qh as "attr-share-get-id",
  vh as "attr-share-get-id-to-name",
  Sh as "attr-share-get-id-to-path",
  X_ as "attr-type",
  qa as "captcha-all",
  va as "captcha-code",
  yo as "captcha-sign",
  Sa as "captcha-single",
  Ic as "captcha-verify",
  Ky as "client-area",
  Xy as "client-authorize",
  Zy as "client-avatar2",
  Fy as "client-check-response",
  Cy as "client-cookies",
  Dy as "client-cookies-str",
  Vy as "client-face",
  Ry as "client-from-path",
  My as "client-headers",
  Uy as "client-init",
  oi as "client-lock",
  By as "client-login-ssoent",
  Yy as "client-logout",
  Qy as "client-open",
  jy as "client-password-login",
  kr as "client-pickcode-stable-point",
  em as "client-read-range",
  Mi as "client-request",
  Jy as "client-to-id",
  $y as "client-to-pickcode",
  Ly as "client-update-cookies",
  Wy as "client-user-id",
  Hy as "client-user-key",
  Oa as "clouddownload-downpath",
  Pa as "clouddownload-downpath-set",
  Ga as "clouddownload-get-id",
  Aa as "clouddownload-quota-info",
  za as "clouddownload-quota-package-array",
  Na as "clouddownload-quota-package-info",
  Iy as "clouddownload-request",
  ja as "clouddownload-sign",
  Ia as "clouddownload-sign-app",
  Ua as "clouddownload-task",
  Ra as "clouddownload-task-add-bt",
  Ca as "clouddownload-task-add-url",
  Da as "clouddownload-task-add-urls",
  Ma as "clouddownload-task-clear",
  La as "clouddownload-task-cnt",
  Wa as "clouddownload-task-count",
  Ba as "clouddownload-task-del",
  yi as "clouddownload-task-list",
  Ha as "clouddownload-task-pause",
  mo as "clouddownload-task-restart",
  Fa as "clouddownload-task-resume",
  Ja as "clouddownload-torrent",
  Qi as "common-app-publick-key",
  Wr as "common-app-version-list",
  Br as "common-app-version-list2",
  Hr as "common-login-authorize-access-token-open",
  eo as "common-login-login",
  Fr as "common-login-qrcode",
  ui as "common-login-qrcode-access-token-open",
  to as "common-login-qrcode-scan",
  Jr as "common-login-qrcode-scan-cancel",
  io as "common-login-qrcode-scan-confirm",
  $r as "common-login-qrcode-scan-result",
  Kr as "common-login-qrcode-scan-status",
  ci as "common-login-qrcode-token",
  Rt as "common-login-qrcode-token-open",
  _i as "common-login-refresh-token-open",
  oo as "common-login-two-step-sms",
  ro as "common-login-two-step-sms-login",
  ao as "common-upload-gettoken",
  Vr as "common-upload-url",
  dc as "content-cookie-hash",
  sc as "content-cookie-range",
  pc as "content-cookie-text",
  bc as "content-open-hash",
  yc as "content-open-range",
  mc as "content-open-text",
  Wc as "diary-add",
  $a as "diary-del",
  Ka as "diary-detail",
  Va as "diary-detail2",
  Bc as "diary-edit",
  Xa as "diary-get-config",
  Ya as "diary-get-latest-tags",
  Za as "diary-get-tag-color",
  Qa as "diary-list",
  en as "diary-search",
  tn as "diary-settag",
  on as "diary-settop",
  nn as "download-downfolder-app",
  qc as "download-extract-app",
  Ec as "download-extract-web",
  gc as "download-file",
  bo as "download-files",
  rn as "download-files-app",
  wo as "download-folders",
  an as "download-folders-app",
  kc as "download-redirect",
  Tc as "download-team",
  Dm as "export-export",
  Cm as "export-parse",
  Xh as "export-parse-depth-name",
  Yh as "export-parse-dict",
  Zh as "export-parse-path",
  Qh as "export-parse-patht",
  Rm as "export-result",
  Im as "export-start",
  Um as "export-status",
  ln as "extract-add-file",
  sn as "extract-add-file-app",
  e_ as "extract-download-url",
  Vc as "extract-file",
  pn as "extract-folders",
  dn as "extract-folders-app",
  un as "extract-folders-post",
  cn as "extract-folders-post-app",
  xo as "extract-info",
  go as "extract-info-app",
  zc as "extract-list",
  ko as "extract-progress",
  To as "extract-progress-app",
  Eo as "extract-push",
  qo as "extract-push-app",
  vo as "extract-push-progress",
  So as "extract-push-progress-app",
  Oo as "fs-batch-edit",
  _n as "fs-batch-edit-app",
  mi as "fs-category-get",
  fn as "fs-category-get-app",
  hn as "fs-category-shortcut",
  Po as "fs-category-shortcut-set",
  it as "fs-copy",
  yn as "fs-copy-app",
  mn as "fs-cover-set",
  bn as "fs-cover-set-app",
  Me as "fs-delete",
  wn as "fs-delete-app",
  xn as "fs-desc",
  gn as "fs-desc-app",
  kn as "fs-desc-set",
  Tn as "fs-desc-set-app",
  En as "fs-dir-getid",
  qn as "fs-dir-getid-app",
  Go as "fs-dir-getid2",
  vn as "fs-document",
  Sn as "fs-document-app",
  ot as "fs-edit",
  Ao as "fs-export-dir",
  On as "fs-export-dir-app",
  zo as "fs-export-dir-status",
  Pn as "fs-export-dir-status-app",
  No as "fs-file",
  jo as "fs-file-skim",
  Io as "fs-files",
  Gn as "fs-files-app",
  An as "fs-files-app2",
  zn as "fs-files-aps",
  Nn as "fs-files-blank-document",
  jn as "fs-files-cover",
  In as "fs-files-cover-set",
  Un as "fs-files-image",
  Rn as "fs-files-image-app",
  Cn as "fs-files-media",
  Dn as "fs-files-media-app",
  Mn as "fs-files-recent-docs",
  Ln as "fs-files-recent-docs-app",
  Wn as "fs-files-second-type",
  Bn as "fs-files-second-type-app",
  E as "fs-files-update-app",
  Hn as "fs-folder-app",
  Fn as "fs-folder-app2",
  Jn as "fs-folder-file",
  $n as "fs-folder-playlong",
  Jc as "fs-folder-playlong-set",
  L as "fs-folder-update-app",
  Kn as "fs-folder-update-app2",
  Xn as "fs-hidden-switch",
  Yn as "fs-hidden-switch-app",
  Uo as "fs-hide",
  Vn as "fs-hide-app",
  Zn as "fs-history",
  Qn as "fs-history-app",
  el as "fs-history-clean",
  ol as "fs-history-clean-app",
  tl as "fs-history-delete",
  il as "fs-history-delete-app",
  Ro as "fs-history-list",
  Co as "fs-history-list-app",
  rl as "fs-history-move-target-list",
  al as "fs-history-receive-list",
  nl as "fs-history-receive-list-app",
  ll as "fs-history-rename-list",
  sl as "fs-history-rename-list-app",
  pl as "fs-history-set",
  dl as "fs-history-set-app",
  ul as "fs-image",
  cl as "fs-imagedata",
  _l as "fs-index-info",
  Hc as "fs-label-add",
  Fc as "fs-label-add-app",
  kl as "fs-label-batch",
  Tl as "fs-label-batch-app",
  Do as "fs-label-del",
  fl as "fs-label-del-app",
  hl as "fs-label-edit",
  yl as "fs-label-edit-app",
  ml as "fs-label-files",
  bl as "fs-label-list",
  wl as "fs-label-list-app",
  xl as "fs-label-set",
  gl as "fs-label-set-app",
  El as "fs-makedirs",
  ql as "fs-makedirs-app",
  bi as "fs-mkdir",
  vl as "fs-mkdir-app",
  bt as "fs-move",
  Sl as "fs-move-app",
  Ol as "fs-move-check-conflict",
  Pl as "fs-move-progress",
  Gl as "fs-music",
  Al as "fs-music-app",
  zl as "fs-music-file-exist",
  Nl as "fs-music-fond-list",
  jl as "fs-music-fond-list-app",
  Il as "fs-music-fond-set",
  Ul as "fs-music-include-list",
  Rl as "fs-music-include-list-app",
  Cl as "fs-music-info",
  Dl as "fs-music-info-app",
  Ml as "fs-music-list",
  Ll as "fs-music-list-app",
  Wl as "fs-music-new",
  Bl as "fs-music-new-app",
  Hl as "fs-music-set",
  Fl as "fs-music-status",
  Jl as "fs-music-topic-listnew",
  $l as "fs-music-topic-listnew-app",
  Kl as "fs-music-topic-set",
  Vl as "fs-office-check-complete",
  Xl as "fs-office-init",
  Yl as "fs-office-save",
  Zl as "fs-order-set",
  Ql as "fs-order-set-app",
  es as "fs-preview",
  Ct as "fs-rename",
  ts as "fs-rename-app",
  os as "fs-rename-reset-names",
  is as "fs-rename-set-names",
  rs as "fs-repeat-sha1",
  as as "fs-repeat-sha1-app",
  Uc as "fs-score-set",
  wi as "fs-search",
  ns as "fs-search-app",
  ls as "fs-search-app2",
  Mo as "fs-shasearch",
  ss as "fs-show-play-long-set",
  ps as "fs-show-play-long-set-app",
  $c as "fs-space-report",
  ds as "fs-space-summury",
  Lo as "fs-star-set",
  us as "fs-star-set-app",
  cs as "fs-storage-info",
  Wo as "fs-supervision",
  _s as "fs-supervision-app",
  fs as "fs-sys-dir",
  Bo as "fs-top-set",
  hs as "fs-video",
  ys as "fs-video-add-caption-map",
  Kc as "fs-video-app",
  ms as "fs-video-def-set",
  bs as "fs-video-is-transcode",
  Rc as "fs-video-m3u8",
  ws as "fs-video-multitrack-set",
  xs as "fs-video-push",
  gs as "fs-video-push-batch",
  ks as "fs-video-push-batch2",
  Ho as "fs-video-subtitle",
  Ts as "fs-video-subtitle-app",
  Es as "fs-video-subtitle-set",
  qs as "fs-video-transcode",
  zy as "index-events",
  ay as "index-get-ancestors",
  ny as "index-get-attr",
  ly as "index-get-count-tree",
  sy as "index-get-id",
  py as "index-get-parent-id",
  dy as "index-get-path",
  uy as "index-get-patht",
  cy as "index-get-pickcode",
  _y as "index-get-sha1",
  fy as "index-has-id",
  Ny as "index-import",
  Gy as "index-init",
  hy as "index-is-alive",
  yy as "index-iter-children",
  my as "index-iter-count-dir",
  by as "index-iter-count-tree",
  wy as "index-iter-dangling-ids",
  xy as "index-iter-dangling-parent-ids",
  gy as "index-iter-descendants",
  ky as "index-iter-descendants-bfs",
  Ty as "index-iter-dup-files",
  Ey as "index-iter-existing-id",
  qy as "index-iter-id-to-parent-id",
  vy as "index-iter-id-to-path",
  Sy as "index-iter-parent-id",
  Oy as "index-path-to-id",
  Ay as "index-scan",
  Py as "index-select-na-ids",
  rc as instant,
  vs as "life-batch-delete",
  xi as "life-behavior-detail",
  Fo as "life-behavior-detail-app",
  Jo as "life-behavior-doc-post-app",
  $o as "life-behavior-img-post-app",
  Ss as "life-calendar-getoption",
  Os as "life-calendar-getoption2",
  gi as "life-calendar-setoption",
  Ps as "life-calendar-setoption2",
  Gs as "life-cdlist",
  As as "life-clear-history",
  Ko as "life-get-pic-url",
  Vo as "life-get-pic-url2",
  W as "life-glist",
  zs as "life-has-data",
  Xo as "life-list",
  Ns as "life-recent-browse",
  js as "life-recent-operation-items",
  Is as "life-recent-operations",
  Us as "life-recent-operations-clear",
  Rs as "life-recent-operations-del",
  B as "life-set-top",
  lc as "link-cookie-info",
  nc as "link-cookie-many",
  ac as "link-cookie-one",
  hc as "link-open-info",
  fc as "link-open-many",
  _c as "link-open-one",
  i_ as "login-app",
  s_ as "login-bind-app",
  Ds as "login-check-sso",
  t_ as "login-device",
  Qo as "login-devices",
  Ms as "login-info",
  l_ as "login-info-open",
  Ls as "login-log",
  Ws as "login-online",
  Cs as "login-open-auth-detail",
  Yo as "login-open-auth-list",
  Zo as "login-open-deauth",
  Bs as "login-renewal",
  o_ as "login-status",
  Hs as "login-two-step-trust-device-del",
  Fs as "login-two-step-trust-device-edit",
  Js as "login-two-step-trust-device-list",
  $s as "login-two-step-trust-device-trust",
  a_ as "login-with-app",
  d_ as "login-with-app-id",
  n_ as "login-with-open",
  p_ as "login-with-qrcode",
  r_ as "login-without-app",
  Ks as logout,
  Vs as "logout-by-ssoent",
  Xs as "msg-contacts-ls",
  Ys as "msg-contacts-notice",
  Zs as "msg-get-websocket-host",
  Qs as "multimedia-collection-listen",
  ep as "multimedia-collection-listen-set",
  tp as "multimedia-collection-watch",
  ip as "multimedia-collection-watch-set",
  op as "multimedia-cover-auto",
  rp as "multimedia-cover-check",
  ap as "multimedia-date",
  np as "multimedia-listen",
  lp as "multimedia-listen-update",
  dp as "multimedia-recent-listen",
  up as "multimedia-recent-listen-update",
  cp as "multimedia-recent-watch",
  _p as "multimedia-recent-watch-update",
  fp as "multimedia-relate-file",
  hp as "multimedia-relate-file-update",
  yp as "multimedia-related",
  mp as "multimedia-related-update",
  bp as "multimedia-relation",
  wp as "multimedia-type",
  xp as "multimedia-type-update",
  sp as "multimedia-watch",
  pp as "multimedia-watch-update",
  om as "multipart-complete",
  lm as "multipart-completed",
  tm as "multipart-init",
  rm as "multipart-list",
  pm as "multipart-result",
  im as "multipart-step",
  sm as "multipart-succeeded",
  am as "multipart-url",
  nm as "multipart-urls",
  Lm as "nodes-by-event",
  Wh as "nodes-by-file",
  Bh as "nodes-by-file-skim",
  Hh as "nodes-by-info",
  Wm as "nodes-by-label",
  Bm as "nodes-by-star",
  Fh as "nodes-by-supervision",
  Jh as "nodes-by-update",
  gp as "note-bookmark-list",
  kp as "note-cate-add",
  Tp as "note-cate-del",
  qp as "note-cate-list",
  vp as "note-cate-list2",
  Ep as "note-cate-update",
  Sp as "note-del",
  Op as "note-del2",
  Pp as "note-detail",
  Gp as "note-detail2",
  Ap as "note-edit-attaches",
  zp as "note-fav-list",
  Np as "note-fav-set",
  er as "note-get-pic-url",
  tr as "note-get-pic-url2",
  jp as "note-is-fav",
  Ip as "note-list",
  Up as "note-list2",
  Rp as "note-save",
  Cp as "note-save2",
  Dp as "note-search",
  Mp as "note-set-cate",
  Lp as "note-set-cate2",
  Wp as "note-set-tag",
  Bp as "note-tag-color",
  Hp as "note-tag-latest",
  Fp as "note-user-setting",
  Jp as "note-user-setting-set",
  oc as offline,
  Xr as "open-clouddownload-quota-info",
  Yr as "open-clouddownload-task-add-bt",
  Zr as "open-clouddownload-task-add-urls",
  Qr as "open-clouddownload-task-clear",
  ea as "open-clouddownload-task-del",
  fi as "open-clouddownload-task-list",
  ta as "open-clouddownload-torrent",
  ia as "open-fs-copy",
  oa as "open-fs-delete",
  no as "open-fs-files",
  ra as "open-fs-info",
  aa as "open-fs-mkdir",
  na as "open-fs-move",
  la as "open-fs-rename",
  sa as "open-fs-search",
  pa as "open-fs-star-set",
  hi as "open-fs-update",
  da as "open-fs-video",
  ua as "open-fs-video-history",
  ca as "open-fs-video-history-set",
  _a as "open-fs-video-push",
  fa as "open-fs-video-subtitle",
  ha as "open-recyclebin-clean",
  ya as "open-recyclebin-list",
  ma as "open-recyclebin-revert",
  u_ as "open-refresh-access-token",
  ba as "open-upload-gettoken-open",
  wa as "open-upload-init",
  Dc as "open-upload-resume",
  lo as "open-user-info",
  xa as "open-vip-qr-url",
  Y_ as "path-ancestors",
  Z_ as "path-get-length",
  Q_ as "path-get-parent",
  ef as "path-get-parents",
  tf as "path-id",
  of as "path-inode",
  rf as "path-is-absolute",
  af as "path-is-dir",
  nf as "path-is-file",
  lf as "path-is-symlink",
  sf as "path-join",
  pf as "path-joinpath",
  df as "path-match",
  uf as "path-media-type",
  cf as "path-parent",
  _f as "path-parents",
  ff as "path-parts",
  hf as "path-path",
  yf as "path-patht",
  mf as "path-root",
  bf as "path-stem",
  wf as "path-suffix",
  xf as "path-suffixes",
  gf as "path-with-name",
  kf as "path-with-stem",
  Tf as "path-with-suffix",
  Ef as "path-wrap-path-iter",
  $p as "photo-album",
  Kp as "photo-album-add",
  Vp as "photo-album-group",
  Xp as "photo-album-list",
  Yp as "photo-album-update",
  Zp as "photo-bind",
  Qp as "photo-list",
  ld as "photo-share-list",
  sd as "photo-share-remove",
  pd as "photo-share-save",
  dd as "photo-share-timeline",
  ed as "photo-sharealbum",
  td as "photo-sharealbum-add",
  id as "photo-sharealbum-list",
  od as "photo-sharealbum-member",
  rd as "photo-sharealbum-record-list",
  ad as "photo-sharealbum-record-update",
  nd as "photo-sharealbum-update",
  ud as "photo-timeline",
  tc as "profile-avatar",
  ir as "recyclebin-clean",
  _d as "recyclebin-clean-app",
  cd as "recyclebin-clean2",
  fd as "recyclebin-info",
  hd as "recyclebin-list",
  yd as "recyclebin-list-app",
  or as "recyclebin-revert",
  md as "recyclebin-revert-app",
  bd as "share-access-user-list",
  wd as "share-activate",
  xd as "share-batch-renewal-long-skip",
  gd as "share-batch-skip-login-down",
  kd as "share-downlist",
  Td as "share-downlist-app",
  Oc as "share-download-url",
  Ed as "share-download-url-app",
  rr as "share-download-url-web",
  jf as "share-fs-create-time",
  If as "share-fs-create-timestamp",
  Wf as "share-fs-from-url",
  Uf as "share-fs-get-share-data",
  Lf as "share-fs-receive",
  Rf as "share-fs-share-data",
  Cf as "share-fs-share-info",
  Df as "share-fs-share-user-id",
  Mf as "share-fs-snap-id",
  qd as "share-info",
  vd as "share-info-app",
  ar as "share-list",
  Sd as "share-list-app",
  Od as "share-notlogin-dl-quota",
  Pd as "share-notlogin-dl-quota-app",
  nr as "share-receive",
  Gd as "share-receive-app",
  Ad as "share-recvcode",
  zd as "share-recvcode-app",
  Nd as "share-reshare",
  lr as "share-search",
  jd as "share-send",
  Id as "share-send-app",
  Ud as "share-setting",
  Rd as "share-skip-login-check",
  Cd as "share-skip-login-down",
  Md as "share-skip-login-down-details",
  Dd as "share-skip-login-down-first",
  Pc as "share-skip-login-download-url",
  Ac as "share-skip-login-download-url-app",
  Gc as "share-skip-login-download-url-web",
  ki as "share-snap",
  Ld as "share-snap-app",
  Wd as "share-update",
  Bd as "share-update-app",
  ic as shares,
  x1 as "support-check-url",
  Ym as "support-constant",
  b1 as "support-error",
  w1 as "support-throw",
  m1 as "support-value",
  Qf as "tool-batch-copy",
  Hm as "tool-batch-copy-files",
  th as "tool-batch-delete",
  Jm as "tool-batch-delete-files",
  ih as "tool-batch-hide",
  ah as "tool-batch-label",
  mh as "tool-batch-makedir",
  eh as "tool-batch-move",
  Fm as "tool-batch-move-files",
  oh as "tool-batch-recyclebin-clean",
  rh as "tool-batch-recyclebin-revert",
  gm as "tool-batch-unstar",
  xm as "tool-check-sha1-existence",
  _m as "tool-check-upload-existence",
  Hd as "tool-clear-empty-folder",
  $m as "tool-copyfile",
  hm as "tool-download-file",
  fm as "tool-download-nodes",
  Em as "tool-download-upload-blocks",
  Ur as "tool-download-urls",
  wm as "tool-ensure-path",
  Pm as "tool-extract-progress",
  Sm as "tool-extract-push",
  Om as "tool-extract-push-progress",
  vm as "tool-extract-raw",
  Mh as "tool-files-page",
  Mm as "tool-get-url",
  Ff as "tool-history-page",
  Lh as "tool-iterdir-skim",
  mm as "tool-life-list",
  Jf as "tool-life-page",
  $h as "tool-life-show",
  $f as "tool-offline-page",
  Kf as "tool-offline-restart-page",
  Kh as "tool-open-app-check",
  Vh as "tool-open-app-name",
  Tm as "tool-open-capacity",
  bm as "tool-open-deauth",
  Ir as "tool-pic-url",
  hh as "tool-post-event",
  Km as "tool-renamefile",
  Fd as "tool-repeat",
  Jd as "tool-repeat-delete",
  $d as "tool-repeat-delete-status",
  Kd as "tool-repeat-list",
  Vd as "tool-repeat-status",
  Vf as "tool-search-page",
  Xf as "tool-share-search-page",
  Xd as "tool-space",
  km as "tool-subtitles",
  Li as "tool-transfer-file",
  fh as "tool-update-abstract",
  _h as "tool-update-category-shortcut",
  nh as "tool-update-cover",
  lh as "tool-update-desc",
  sh as "tool-update-label",
  yh as "tool-update-name",
  uh as "tool-update-score",
  ph as "tool-update-show-play-long",
  dh as "tool-update-star",
  ch as "tool-update-top",
  qm as "tool-upload-block",
  cm as "tool-upload-host-image",
  um as "tool-upload-init",
  Zf as "tool-wish-aid-page",
  Yf as "tool-wish-page",
  Vm as "transfer-files",
  Xm as "transfer-files-resume",
  Rh as "tree-extract-iter-files",
  Ch as "tree-extract-iterdir",
  Oh as "tree-get-id-to-dirnode",
  Ph as "tree-iter-3-ancestor-names",
  Gh as "tree-iter-dirs",
  Ah as "tree-iter-files",
  zh as "tree-iter-files-skim",
  Nh as "tree-iter-keyed-dupfiles",
  jh as "tree-iter-keyed-ids",
  Ih as "tree-share-iter-files",
  Uh as "tree-share-iterdir",
  Dh as "tree-traverse-tree",
  Nc as "upload-avatar",
  Xc as "upload-chat-image",
  sr as "upload-chat-image-init",
  cc as "upload-cookie-file",
  uc as "upload-cookie-prepare",
  Yc as "upload-file-image",
  Sc as "upload-form-file",
  vc as "upload-form-init",
  jc as "upload-image",
  pr as "upload-image-init",
  Le as "upload-info",
  Yd as "upload-info-app",
  Mc as "upload-init",
  Lc as "upload-key",
  xc as "upload-open-file",
  wc as "upload-open-prepare",
  Cc as "upload-resume",
  Zd as "upload-sample-init",
  Qd as "user-base-info",
  eu as "user-card",
  tu as "user-count-space-nums",
  iu as "user-display-uid-list",
  ou as "user-fingerprint",
  ru as "user-info",
  pu as "user-info-set",
  au as "user-info2",
  nu as "user-info3",
  lu as "user-info4",
  su as "user-info4-app",
  du as "user-interests-list",
  uu as "user-my",
  cu as "user-my-info",
  _u as "user-points-balance",
  fu as "user-points-sign",
  hu as "user-points-sign-post",
  yu as "user-points-transaction",
  mu as "user-public",
  bu as "user-public-set",
  wu as "user-relation-info",
  xu as "user-security-key-check",
  gu as "user-setting",
  vu as "user-setting-app",
  Su as "user-setting-app-set",
  Tu as "user-setting-set",
  Eu as "user-setting-web",
  qu as "user-setting-web-set",
  ku as "user-setting2",
  Ou as "user-sign",
  Pu as "user-sign-set",
  Gu as "user-space-info",
  Au as "user-teen-mode-state",
  zu as "user-teen-mode-state-set",
  Nu as "user-vip-check-spw",
  ju as "user-vip-limit",
  Ru as "usershare-action",
  Cu as "usershare-action-app",
  Iu as "usershare-add-folder",
  Uu as "usershare-add-folder-app",
  Du as "usershare-copy",
  Mu as "usershare-copy-app",
  Lu as "usershare-delete",
  Wu as "usershare-delete-app",
  Qc as "usershare-download-url",
  Zc as "usershare-download-urls",
  Bu as "usershare-file-list",
  Hu as "usershare-file-list-app",
  Fu as "usershare-info",
  Ju as "usershare-info-app",
  $u as "usershare-invite",
  Ku as "usershare-invite-app",
  Vu as "usershare-list",
  Xu as "usershare-list-app",
  Yu as "usershare-member",
  Zu as "usershare-member-app",
  Qu as "usershare-share",
  ec as "usershare-share-app",
  Zm as "util-call-with-lock",
  Qm as "util-complete-url",
  e1 as "util-determine-part-size",
  t1 as "util-get-stable-point",
  i1 as "util-get-user-key",
  o1 as "util-is-valid-id",
  r1 as "util-is-valid-name",
  a1 as "util-is-valid-pickcode",
  n1 as "util-is-valid-sha1",
  l1 as "util-load-final-image",
  s1 as "util-max-image-quality",
  p1 as "util-normalize-pickcode",
  d1 as "util-posix-escape-name",
  u1 as "util-reduce-image-url-layers",
  c1 as "util-set-stable-point",
  _1 as "util-set-user-key",
  f1 as "util-share-extract-payload",
  h1 as "util-to-cdn-url",
  y1 as "util-unescape-115-charref",
  c_ as "vfs-as-path",
  zf as "vfs-attr-to-stat",
  qf as "vfs-chdir",
  N_ as "vfs-copy",
  Bf as "vfs-create",
  S_ as "vfs-dictdir",
  Pf as "vfs-dictdir-path",
  P_ as "vfs-dirlen",
  H_ as "vfs-download",
  ym as "vfs-ed2k",
  w_ as "vfs-exists",
  y_ as "vfs-get-ancestors",
  __ as "vfs-get-attr",
  f_ as "vfs-get-id",
  h_ as "vfs-get-parent-id",
  m_ as "vfs-get-path",
  b_ as "vfs-get-patht",
  R_ as "vfs-get-url",
  vf as "vfs-getcid",
  Sf as "vfs-getcwd",
  T_ as "vfs-glob",
  z_ as "vfs-has-child",
  W_ as "vfs-hash",
  B_ as "vfs-hashes",
  G_ as "vfs-is-empty",
  x_ as "vfs-isdir",
  g_ as "vfs-isfile",
  k_ as "vfs-iter",
  q_ as "vfs-iterdir",
  v_ as "vfs-listdir",
  Of as "vfs-listdir-path",
  Ft as "vfs-mkdir",
  j_ as "vfs-move",
  Af as "vfs-open",
  Hf as "vfs-path-class",
  C_ as "vfs-read",
  D_ as "vfs-read-block",
  M_ as "vfs-read-range",
  L_ as "vfs-read-text",
  O_ as "vfs-readdir",
  I_ as "vfs-remove",
  U_ as "vfs-rename",
  E_ as "vfs-rglob",
  A_ as "vfs-stat",
  dm as "vfs-upload",
  Nf as "vfs-user-id",
  Gf as "vfs-walk",
  oy as "wish-adopt",
  iy as "wish-answer",
  ry as "wish-del",
  ey as "wish-info",
  ty as "wish-make",
  Nm as "zip-extract",
  jm as "zip-extract-many",
  Am as "zip-id-to-path",
  Gm as "zip-load",
  zm as "zip-path-to-id"
};
