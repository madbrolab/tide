// JSON filesystem views. IDs are decimal strings; traversal is resumable and
// bounded by both the caller's page limit and the host's action deadline.
function integerOrText(value) {
  if(typeof value!=="string"||!/^[-+]?\d+$/.test(value))return value;
  const n=Number(value);return Number.isSafeInteger(n)?n:value;
}
function optionalInteger(value){return typeof value==="string"&&/^-?(?:0|[1-9]\d*)$/.test(value)?integerOrText(value):value;}
function fileType(value) {
  if(!value)return 0;
  if(typeof value==="string")return suffixTypes[fileSuffix(value)]??99;
  if(value.is_dir)return 0;
  return classTypes[value.class]??suffixTypes[fileSuffix(String(value.name)).toLowerCase()]??(value.is_video||Object.hasOwn(value,"defination")?4:99);
}
function fileSuffix(name){const pos=name.lastIndexOf(".");return pos>0&&/[^.]/.test(name.slice(0,pos))?name.slice(pos):"";}
function normalizeEntry(info, options={}) {
  if(info.id!==undefined&&info.name!==undefined&&info.is_dir!==undefined)return {...info,id:remoteId(info.id),parent_id:remoteId(info.parent_id??0)};
  const kind=options.kind??(Object.hasOwn(info,"fn")?"app":Object.hasOwn(info,"file_id")||Object.hasOwn(info,"category_id")?"app2":"web");
  const isDir=Object.hasOwn(info,"fc")?Number(info.fc)===0:Object.hasOwn(info,"file_category")?Number(info.file_category)===0:Object.hasOwn(info,"sha")?!info.sha:Object.hasOwn(info,"sha1")?!info.sha1:Object.hasOwn(info,"file_sha1")?!info.file_sha1:kind==="web"&&Object.hasOwn(info,"cid")?!Object.hasOwn(info,"fid"):kind==="app2"&&Object.hasOwn(info,"category_id")?!Object.hasOwn(info,"file_id"):!["s","fs","file_size","size"].some(k=>Object.hasOwn(info,k));
  const out={...options.default,is_dir:isDir,
    id:remoteId(kind==="web"?(isDir?info.cid:info.fid):kind==="app"?info.fid:info.file_id??info.category_id),
    parent_id:remoteId(kind==="web"?(isDir?info.pid:info.cid):kind==="app"?info.pid:info.parent_id??info.category_id??0),
    name:kind==="web"?info.n||info.fn||info.file_name:kind==="app"?info.fn||info.n||info.file_name:info.file_name??info.category_name,
    sha1:kind==="web"?info.sha||info.sha1||"":info.sha1||info.sha||info.file_sha1||"",size:integerOrText(kind==="app2"?info.file_size||0:kind==="app"?info.fs||info.s||0:info.s||info.fs||0)};
  if(typeof out.name!=="string")throw connectorError("115 文件信息缺少名称","upstream");
  const pc=kind==="app2"?info.pick_code:info.pc;
  if(pc!==undefined)out.pickcode=pc;
  const times=kind==="web"?{ctime:info.tp,mtime:info.te}:kind==="app"?{ctime:info.uppt,mtime:info.upt}:{ctime:info.user_pptime??info.pptime,mtime:info.user_ptime??info.ptime};
  for(const[k,v]of Object.entries(times))if(v!==undefined)out[k]=integerOrText(v);
  const collect=kind==="web"?info.c:kind==="app"?info.ic:info.is_collect;
  if(collect!==undefined)out.is_collect=integerOrText(collect);
  if(!options.simple){
    out.ico=info.ico??(isDir?"folder":"");
    if(pc!==undefined)out.pick_code=pc;
    if(out.ctime!==undefined)out.user_ptime=out.ctime;
    if(out.mtime!==undefined)out.user_utime=out.mtime;
    for(const[k,name]of attrMappings[kind])if(Object.hasOwn(info,k))out[name]=optionalInteger(info[k]);
    if(kind==="web"){
      if(info.to!==undefined)out.atime=out.user_otime=integerOrText(info.to);
      if(info.tu!==undefined)out.utime=integerOrText(info.tu);
      if(info.t)out.time=integerOrText(info.t);
      if(info.fdes!==undefined){if(typeof info.fdes==="string")out.desc=info.fdes;out.has_desc=info.fdes?1:0;}
      if(info.vdi){out.defination=info.vdi;out.defination_str=({1:"video-sd",2:"video-hd",3:"video-fhd",4:"video-1080p",5:"video-4k",100:"video-origin"})[info.vdi]??"video-sd";}
    }else if(kind==="app"){
      if(info.uet!==undefined)out.utime=integerOrText(info.uet);
      if(info.thumb!==undefined)out.thumb=info.thumb.startsWith("?")?"https://imgjump.115.com"+info.thumb+"&size=0&sha1="+out.sha1:info.thumb;
    }else{
      if(info.user_utime!==undefined||info.utime!==undefined)out.utime=integerOrText(info.user_utime??info.utime);
      if(info.real_user_ptime!==undefined)out.time=integerOrText(info.real_user_ptime);
      const desc=isDir?info.category_desc:info.file_description,cover=isDir?info.category_cover:info.music_cover;
      if(desc!==undefined)out.desc=desc;if(cover!==undefined)out.cover=cover;
      if(!isDir&&info.thumb_url!==undefined)out.thumb=info.thumb_url;
      if(!isDir&&info.file_tag!==undefined)out.file_type=integerOrText(info.file_tag);
      if(info.fl!==undefined)out.labels=info.fl;
      if(out.is_mark!==undefined)out.star=out.is_mark;
    }
  }
  if(kind==="web"&&info.star_time!==undefined)out.star_time=integerOrText(info.star_time||0);
  out.type=kind==="app2"&&info.type!==undefined?info.type:isDir?0:kind==="web"&&(info.iv||Object.hasOwn(info,"vdi"))?4:kind==="app"&&info.thumb?.startsWith("?")||kind==="app2"&&Object.hasOwn(info,"thumb_url")?2:kind==="app"&&Object.hasOwn(info,"muc")||kind==="app2"&&(Object.hasOwn(info,"music_cover")||Object.hasOwn(info,"play_url"))?3:kind==="app"&&(info.isv||["def","def2","v_img"].some(k=>Object.hasOwn(info,k)))||kind==="app2"&&(info.is_video||["definition","definition2","video_img_url"].some(k=>Object.hasOwn(info,k)))?4:fileType(out);
  if(options.keep_raw)out.raw=info;
  return out;
}
function escapeName(name){return String(name).replace(/\\/g,"\\\\").replace(/\//g,"\\/").replace(/^\.{1,2}$/,s=>"\\"+s);}
function pathTokens(path){
  if(Array.isArray(path))return path.map(name=>({name:String(name),quoted:true}));
  const parts=[];let current="",escaped=false,quoted=false;
  for(const c of String(path)){if(escaped){current+=c;escaped=false;quoted=true;}else if(c==="\\")escaped=true;else if(c==="/"){parts.push({name:current,quoted});current="";quoted=false;}else current+=c;}
  if(escaped)current+="\\";parts.push({name:current,quoted});
  const result=[];for(const p of parts){if(!p.name||p.name==="."&&!p.quoted)continue;result.push(p);}
  return result;
}
function pathParts(path){return pathTokens(path).map(p=>p.name);}
function rootEntry(){return {id:"0",parent_id:"0",name:"",is_dir:true,sha1:"",size:0,pickcode:"",type:0};}
async function entryById(ctx,id,options={}){
  id=remoteId(id);if(id==="0")return rootEntry();
  const r=ensureOK(await do_fs_file(ctx,{payload:{file_id:id}}));
  const value=Array.isArray(r.data)?r.data[0]:r.data;
  if(!value)throw connectorError("文件或目录不存在","not_found");
  return normalizeEntry(value,options);
}
async function directoryPage(ctx,a){
  const scope=a.scope??{},cid=scope.kind==="zip"?String(a.id??a.path??"/"):remoteId(a.id??a.cid??0),offset=bounded(a.cursor?.offset??a.offset??0,0,Number.MAX_SAFE_INTEGER),limit=bounded(a.limit??200,1,1000);
  let r,rawItems,total,next;
  if(scope.kind==="share"){
    r=ensureOK(await do_share_snap(ctx,{payload:{...shareFields(scope.url??scope.share_code),receive_code:scope.receive_code??shareFields(scope.url??scope.share_code).receive_code,cid,offset,limit,...a.payload}}));
    rawItems=r.data?.list??[];total=Number(r.data?.count??r.count??rawItems.length);next=offset+rawItems.length<total?offset+rawItems.length:null;
  }else if(scope.kind==="zip"){
    const parent=cid==="0"?"/":cid;
    r=ensureOK(await archiveList(ctx,{pickcode:scope.pickcode,path:pathParts(parent).join("/"),nextMarker:a.cursor?.marker??a.marker??"",pageCount:limit,app:a.app}));
    rawItems=(r.data?.list??[]).map(n=>({...n,file_id:n.file_id??n.file_name,parent_id:cid}));
    // Archive IDs are paths, exposed separately from numeric cloud IDs.
    const items=rawItems.map(n=>({id:(parent==="/"?"":parent)+"/"+escapeName(n.file_name),parent_id:parent,name:n.file_name,is_dir:Number(n.file_category)===0,size:integerOrText(n.file_size??0),sha1:n.sha1??""}));
    next=r.data?.next_marker||null;return {items,next,cursor:next===null?null:{marker:next},complete:next===null,total:null,...(a.get_raw?{raw:r}:{})};
  }else{
    const kind=(await ctx.connection()).kind;
    r=ensureOK(await(kind==="bearer"?do_open_fs_files(ctx,{payload:{cid,offset,limit,show_dir:1,...a.payload}}):do_fs_files(ctx,{payload:{cid,offset,limit,show_dir:1,...a.payload}})));
    rawItems=Array.isArray(r.data)?r.data:r.data?.list??[];
    total=Number(r.count??r.data?.count??rawItems.length);
    next=r.has_next_page===true||r.has_next_page===1||offset+rawItems.length<total?offset+rawItems.length:null;
  }
  if(next!==null&&!rawItems.length)throw connectorError("115 分页为空但仍有后续结果","upstream");
  return {items:rawItems.map(v=>normalizeEntry(v,{simple:a.simple??false,keep_raw:a.keep_raw})),next,cursor:next===null?null:{offset:next},complete:next===null,total,...(a.get_raw?{raw:r}:{})};
}
async function directoryAll(ctx,a){
  const items=[],seen=new Set(),cursors=new Set();let offset=a.scope?.kind==="zip"?"":0;
  do{const page=await directoryPage(ctx,{...a,cursor:undefined,...(a.scope?.kind==="zip"?{marker:offset}:{offset}),limit:1000});for(const item of page.items)if(!seen.has(item.id)){seen.add(item.id);items.push(item);}
    if(page.next!==null&&(cursors.has(page.next)||page.next===offset))throw connectorError("115 分页游标未前进","upstream");cursors.add(offset);offset=page.next;
    if(items.length>(a.maxItems??20000))throw connectorError("目录过大，请使用分页目录接口","conflict");
  }while(offset!==null);
  return items;
}
async function resolveEntry(ctx,value=0,a={}){
  if(value&&typeof value==="object"&&!Array.isArray(value))return value.name!==undefined&&value.is_dir!==undefined?{...value,id:String(value.id),parent_id:String(value.parent_id??0)}:await resolveEntry(ctx,value.id??value.path,a);
  const scope=a.scope??{},root=scope.kind==="zip"?{...rootEntry(),id:"/",parent_id:"/"}:rootEntry();
  if(value===0||value==="0"||value==="/"||Array.isArray(value)&&!value.length)return root;
  if(typeof value==="number"||typeof value==="string"&&/^\d+$/.test(value)){if(scope.kind==="zip")throw connectorError("压缩包文件使用路径 ID");return scope.kind==="share"?await shareLookup(ctx,String(value),a):await entryById(ctx,value);}
  let current=typeof value==="string"&&value.startsWith("/")||!a.pid?root:await resolveEntry(ctx,a.pid,{...a,pid:0});
  for(const token of pathTokens(value)){
    const part=token.name;if(part===".."&&!token.quoted){current=await resolveEntry(ctx,current.parent_id,{...a,pid:0});continue;}
    if(!current.is_dir)throw connectorError("路径中包含文件","not_found");
    const matches=(await directoryAll(ctx,{id:current.id,scope:a.scope})).filter(e=>e.name===part);
    if(!matches.length)throw connectorError("路径不存在","not_found");
    if(matches.length>1)throw connectorError("路径名称不唯一，请改用文件 ID","conflict");
    current=matches[0];
  }
  return current;
}
async function entryAncestors(ctx,value,a={}){
  let entry=await resolveEntry(ctx,value,a);const result=[entry],seen=new Set([entry.id]);
  while(entry.id!=="0"&&entry.id!=="/"){
    if(seen.has(entry.parent_id))throw connectorError("115 父目录关系存在循环","upstream");
    entry=await resolveEntry(ctx,entry.parent_id,{...a,pid:0});seen.add(entry.id);result.unshift(entry);
    if(result.length>1024)throw connectorError("目录层级过深","upstream");
  }
  return result;
}
function globPattern(pattern,ignoreCase=false){
  let out="^";const text=String(pattern);
  for(let i=0;i<text.length;i++){
    const c=text[i];if(c==="*"&&text[i+1]==="*"){i++;if(text[i+1]==="/"){i++;out+="(?:.*/)?";}else out+=".*";}
    else if(c==="*")out+="[^/]*";else if(c==="?")out+="[^/]";
    else if(c==="["){const end=text.indexOf("]",i+1);if(end<0)out+="\\[";else{const part=text.slice(i+1,end);out+="["+(part.startsWith("!")?"^"+part.slice(1):part)+"]";i=end;}}
    else out+=/[\\^$+?.()|{}]/.test(c)?"\\"+c:c;
  }
  return new RegExp(out+"$",ignoreCase?"i":"");
}
function matchEntry(entry,filter={}){
  if(filter.type!==undefined&&entry.type!==filter.type)return false;
  if(filter.is_dir!==undefined&&entry.is_dir!==filter.is_dir)return false;
  if(filter.minSize!==undefined&&Number(entry.size)<filter.minSize)return false;
  if(filter.maxSize!==undefined&&Number(entry.size)>filter.maxSize)return false;
  if(filter.name&&!globPattern(filter.name,filter.ignore_case).test(entry.name))return false;
  return true;
}
async function treePage(ctx,a){
  const limit=bounded(a.limit??100,1,1000),maxDepth=a.max_depth??-1,minDepth=a.min_depth??1;
  const root=a.cursor?null:await resolveEntry(ctx,a.top??a.id??0,a);
  const queue=a.cursor?JSON.parse(JSON.stringify(a.cursor.queue)):[{id:root.id,path:"",depth:0,offset:0}];
  if(!Array.isArray(queue)||queue.length>20000)throw connectorError("遍历游标无效");
  const items=[];const pattern=a.pattern?globPattern(a.pattern,a.ignore_case):null;
  while(queue.length&&items.length<limit&&ctx.remaining()>1000){
    const node=queue[0];const page=await directoryPage(ctx,{id:node.id,...(a.scope?.kind==="zip"?{marker:node.offset||""}:{offset:node.offset}),limit:Math.min(200,limit-items.length),scope:a.scope,payload:a.payload});
    for(const item of page.items){
      const depth=node.depth+1,path=node.path+"/"+escapeName(item.name);
      if(item.is_dir&&(maxDepth<0||depth<maxDepth))queue.push({id:item.id,path,depth,offset:0});
      if(depth>=minDepth&&(maxDepth<0||depth<=maxDepth)&&matchEntry(item,a.filter)&&(!pattern||pattern.test(path.slice(1))))items.push({...item,path,depth});
    }
    if(page.next===null)queue.shift();else{if(page.next===node.offset||typeof page.next==="number"&&page.next<node.offset)throw connectorError("遍历游标未前进","upstream");node.offset=page.next;}
    if(queue.length>20000||utf8Bytes(JSON.stringify(queue)).length>160000)throw connectorError("遍历队列过大，请分目录处理","conflict");
  }
  return {items,cursor:queue.length?{queue}:null,complete:queue.length===0};
}
async function fileAction(ctx,a,operation){
  const input=a.id_or_path??a.path??a.id??0;
  if(operation==="exists"||operation==="isdir"||operation==="isfile"){
    try{const e=await resolveEntry(ctx,input,a);return operation==="exists"?true:operation==="isdir"?e.is_dir:!e.is_dir;}catch(error){if(error.code==="not_found")return false;throw error;}
  }
  if(operation==="iter"||operation==="glob"||operation==="rglob")return await treePage(ctx,{...a,top:input,pattern:operation==="rglob"?"**/"+(a.pattern??"*"):a.pattern});
  const entry=await resolveEntry(ctx,input,a);
  if(["get_attr","as_path"].includes(operation))return entry;
  if(operation==="get_id")return entry.id;
  if(operation==="get_parent_id")return entry.parent_id;
  if(operation==="get_ancestors"||operation==="get_path"||operation==="get_patht"){
    const path=await entryAncestors(ctx,entry.id,a);
    return operation==="get_ancestors"?path:operation==="get_patht"?path.map(n=>n.name):"/"+path.slice(1).map(n=>escapeName(n.name)).join("/");
  }
  if(["iterdir","listdir","dictdir","readdir","dirlen","is_empty"].includes(operation)){
    if(!entry.is_dir){if(operation==="is_empty")return Number(entry.size)===0;throw connectorError("目标不是目录");}
    if(operation==="iterdir")return await directoryPage(ctx,{...a,id:entry.id});
    const list=await directoryAll(ctx,{...a,id:entry.id});
    return operation==="listdir"?list.map(n=>n.name):operation==="dictdir"?Object.fromEntries(list.map(n=>[n.id,n])):operation==="dirlen"?list.length:operation==="is_empty"?!list.length:list;
  }
  if(operation==="stat")return entryStat(entry,a.scope);
  if(operation==="has_child")return (await entryAncestors(ctx,a.child,a)).some(n=>n.id===entry.id);
  if(["copy","move","remove","rename"].includes(operation)&&a.scope?.kind&&a.scope.kind!=="drive")throw connectorError("分享和压缩包视图只读","forbidden");
  if(operation==="remove")return ensureOK(await do_fs_delete(ctx,{payload:{"fid[0]":entry.id}}));
  if(operation==="rename")return ensureOK(await do_fs_rename(ctx,{payload:{["files_new_name["+entry.id+"]"]:a.name}}));
  if(operation==="copy"||operation==="move"){
    const dest=await resolveEntry(ctx,a.to_dir??a.to_pid??0,a);if(!dest.is_dir)throw connectorError("目标不是目录");
    return ensureOK(await(operation==="copy"?do_fs_copy:do_fs_move)(ctx,{payload:{pid:dest.id,"fid[0]":entry.id}}));
  }
  if(operation==="get_url")return await entryURL(ctx,entry,a);
  if(["read","read_block","read_range","read_text","hash","hashes"].includes(operation)){
    const hashing=["hash","hashes"].includes(operation);
    let start=a.start??a.offset??0,length=a.size??a.length??(hashing?Number(entry.size)-start:Math.min(65536,Number(entry.size)-start));
    if(a.stop!==undefined)length=a.stop-start;
    if(a.bytes_range){const m=/^(\d*)-(\d*)$/.exec(String(a.bytes_range).replace(/^bytes=/,""));if(!m)throw connectorError("无效字节区间");start=m[1]?Number(m[1]):Math.max(0,Number(entry.size)-Number(m[2]));length=m[1]&&m[2]?Number(m[2])-start+1:Number(entry.size)-start;}
    if(a.scope?.kind==="share"||a.scope?.kind==="zip")return await scopedContent(ctx,entry,{...a,offset:start,length},operation);
    return await contentView(ctx,{pickcode:entry.pickcode,offset:start,length,digests:a.digests??(a.digest?[a.digest]:undefined),userAgent:a.userAgent},(await ctx.connection()).kind==="bearer"?"open":"cookie",operation==="read_text"?"text":hashing?"hash":"range");
  }
  if(operation==="download"){
    const link=await entryURL(ctx,entry,a);if(typeof a.destination!=="string"||!a.destination.startsWith("/"))throw connectorError("需要绝对路径 destination");
    const r=await ctx.net.request({url:link.url,headers:link.headers,outputPath:a.destination,followRedirects:true});
    if(r.status<200||r.status>=300)throw connectorError("下载失败，HTTP "+r.status,"upstream");return {path:r.path,bytes:r.bytes};
  }
  throw connectorError("未知文件操作");
}
async function makeDirectories(ctx,a){
  if(a.scope?.kind&&a.scope.kind!=="drive")throw connectorError("分享和压缩包视图只读","forbidden");
  let parent=await resolveEntry(ctx,a.pid??0);const parts=a.name!==undefined?[a.name]:pathParts(a.path??a.id_or_path??"");
  if(!parts.length)throw connectorError("目录名不能为空");
  for(const name of parts){
    if(!name||/[\x00\r\n]/.test(name))throw connectorError("目录名无效");
    const matches=(await directoryAll(ctx,{id:parent.id})).filter(n=>n.name===name);
    if(matches.length>1)throw connectorError("目录名称不唯一","conflict");
    if(matches.length){if(!matches[0].is_dir)throw connectorError("同名文件已存在","conflict");parent=matches[0];continue;}
    const r=ensureOK(await do_fs_mkdir(ctx,{payload:{pid:parent.id,cname:name}}));
    parent={id:remoteId(r.cid??r.data?.category_id??r.data?.file_id),parent_id:parent.id,name,is_dir:true,size:0,sha1:"",type:0};
  }
  return parent;
}
async function shareLookup(ctx,id,a){
  const cached=a.scope?.entries?.find(n=>String(n.id)===id);if(cached)return cached;
  let cursor=null;
  do{
    const page=await treePage(ctx,{scope:a.scope,top:0,cursor,limit:200});
    const entry=page.items.find(n=>n.id===id);if(entry)return entry;
    cursor=page.cursor;
    if(cursor&&ctx.remaining()<1500)throw connectorError("查找尚未完成，请提供分享路径或已列出的文件信息","busy");
  }while(cursor);
  throw connectorError("分享中不存在该文件","not_found");
}
function entryStat(entry,scope){return {st_mode:(entry.is_dir?0o40000:0o100000)|(["share","zip"].includes(scope?.kind)?0o444:0o777),st_ino:entry.id,st_dev:entry.parent_id,st_nlink:1,st_uid:0,st_gid:0,st_size:entry.is_dir?0:entry.size,st_atime:entry.atime??0,st_mtime:entry.mtime??0,st_ctime:entry.ctime??0};}
function shareScope(a){
  const s=a.scope??a,f=shareFields(s.url??s.share_code);
  return {kind:"share",...f,receive_code:s.receive_code??f.receive_code};
}
async function entryURL(ctx,entry,a){
  if(entry.is_dir)throw connectorError("目录没有下载链接");
  if(a.scope?.kind==="share")return await shareDirect(ctx,{payload:{...shareScope(a),file_id:entry.id},strict:true,app:a.app},"regular");
  if(a.scope?.kind==="zip"){
    const r=ensureOK(await webLink(ctx,{app:a.app,userAgent:a.userAgent,payload:{pick_code:a.scope.pickcode,full_name:pathParts(entry.id).join("/")}},["","web","desktop","aps"].includes(a.app??"web")?"extract-web":"extract-app"));
    const url=r.data?.url?.url??r.data?.url??r.url;
    if(typeof url!=="string")throw connectorError("压缩包下载链接缺失","upstream");
    return {...entry,url,headers:r.headers??{}};
  }
  return await downloadLinks(ctx,{pickcode:entry.pickcode,strict:true,userAgent:a.userAgent},(await ctx.connection()).kind==="bearer"?"open":"cookie",true);
}
async function scopedContent(ctx,entry,a,op){
  const url=a.url?{url:a.url,headers:a.headers??{},size:entry.size}:await entryURL(ctx,entry,a),offset=bounded(a.offset,0,Number(entry.size)),length=bounded(a.length,0,Number(entry.size)-offset);
  if(op==="hash"||op==="hashes")return await streamDigests(ctx,url,{offset,length,digests:a.digests??[a.digest??"sha1"],cursor:a.cursor});
  if(length>65536)throw connectorError("单次读取最多 65536 字节，请继续 nextOffset");
  let data=new Uint8Array();
  if(length){
    const r=await ctx.net.request({url:url.url,headers:{...url.headers,Range:"bytes="+offset+"-"+(offset+length-1)},responseType:"bytes",maxBytes:65536,followRedirects:true});
    if(r.status!==206&&!(r.status===200&&offset===0&&Number(entry.size)<=length))throw connectorError("上游没有返回请求的范围","upstream");
    data=r.body;if(data.length!==length)throw connectorError("读取长度与文件信息不符","upstream");
  }
  return {bytes:data.length,...(op==="read_text"?{text:decodeURIComponent(Array.from(data,b=>"%"+hexByte(b)).join(""))}:{base64:base64(data)}),nextOffset:offset+length<Number(entry.size)?offset+length:null};
}
async function pathAction(ctx,a,operation){
  if(operation==="wrap_path_iter"){
    const items=[];for(const value of a.items??[])items.push(await pathAction(ctx,{...a,id_or_path:value},"path"));return items;
  }
  const entry=await resolveEntry(ctx,a.id_or_path??a.path??a.id??0,a);
  if(operation==="id"||operation==="inode")return entry.id;
  if(operation==="is_dir")return entry.is_dir;
  if(operation==="is_file")return !entry.is_dir;
  if(operation==="is_absolute")return true;
  if(operation==="is_symlink")return false;
  if(operation==="get_length")return entry.is_dir?(await directoryAll(ctx,{...a,id:entry.id})).length:entry.size;
  const suffix=fileSuffix(entry.name),stem=suffix?entry.name.slice(0,-suffix.length):entry.name;
  if(operation==="stem")return stem;
  if(operation==="suffix")return suffix;
  if(operation==="suffixes"){const name=entry.name.replace(/^\.+/,"");return name.endsWith(".")?[]:name.split(".").slice(1).map(s=>"."+s);}
  if(operation==="media_type")return mimeTypes[suffix.toLowerCase()]??null;
  const ancestors=await entryAncestors(ctx,entry,a),parts=ancestors.map(n=>n.name),path="/"+parts.slice(1).map(escapeName).join("/");
  if(operation==="ancestors")return ancestors;
  if(["parts","patht"].includes(operation))return parts;
  if(operation==="path")return path;
  if(operation==="root")return ancestors[0];
  if(["parent","get_parent"].includes(operation))return ancestors.at(-2)??ancestors[0];
  if(["parents","get_parents"].includes(operation))return ancestors.slice(0,-1).reverse();
  if(operation==="match")return globPattern(a.pattern,a.ignore_case).test(a.pattern.startsWith("/")?path:path.slice(1))||(!a.pattern.includes("/")&&globPattern(a.pattern,a.ignore_case).test(entry.name));
  if(["join","joinpath"].includes(operation))return await resolveEntry(ctx,pathParts(path).concat(a.parts??[]),{...a,pid:0});
  if(["with_name","with_stem","with_suffix"].includes(operation)){
    const name=operation==="with_name"?a.name:operation==="with_stem"?a.stem+suffix:stem+a.suffix;
    if(typeof name!=="string"||!name)throw connectorError("新名称不能为空");
    if(operation==="with_suffix"&&a.suffix!==""&&(!a.suffix.startsWith(".")||a.suffix.includes("/")))throw connectorError("后缀必须以点开头");
    return await resolveEntry(ctx,parts.slice(1,-1).concat(name),{...a,pid:0});
  }
  throw connectorError("未知路径操作");
}
const mimeTypes={".mp4":"video/mp4",".mkv":"video/x-matroska",".avi":"video/x-msvideo",".mov":"video/quicktime",".mp3":"audio/mpeg",".flac":"audio/flac",".wav":"audio/wav",".m4a":"audio/mp4",".ogg":"audio/ogg",".jpg":"image/jpeg",".jpeg":"image/jpeg",".png":"image/png",".gif":"image/gif",".webp":"image/webp",".svg":"image/svg+xml",".pdf":"application/pdf",".zip":"application/zip",".7z":"application/x-7z-compressed",".rar":"application/vnd.rar",".txt":"text/plain",".html":"text/html",".json":"application/json",".srt":"text/plain",".ass":"text/plain"};
async function filesystemState(ctx,a,operation){
  const state=a.state??{},scope=a.scope??state.scope??{kind:"drive"},pid=a.pid??state.cid??0,options={...a,pid,scope};
  if(operation==="create")return {scope,cid:String(pid),cwd:await fileAction(ctx,{id:pid,scope},"get_path")};
  if(operation==="getcid")return String(pid);
  if(operation==="getcwd")return await fileAction(ctx,{id:pid,scope},"get_path");
  if(operation==="user_id")return String(await remoteUser(ctx,a));
  if(operation==="attr_to_stat")return entryStat(a.attr,scope);
  const input=a.id_or_path??a.path??a.id??pid,entry=await resolveEntry(ctx,input,options);
  if(operation==="chdir"){
    if(!entry.is_dir)throw connectorError("当前目录必须是目录");
    return {scope,cid:entry.id,cwd:await fileAction(ctx,{...options,id_or_path:entry},"get_path")};
  }
  if(operation==="open")return {entry,scope,offset:a.start??0,length:entry.size,readAction:"vfs-read-block",seekable:true};
  if(operation==="listdir_path"||operation==="dictdir_path"){
    const items=await directoryAll(ctx,{...options,id:entry.id});
    return operation==="listdir_path"?items:Object.fromEntries(items.map(n=>[n.id,n]));
  }
  if(operation==="walk"){
    const queue=a.cursor?.queue??[{id:entry.id,path:await fileAction(ctx,{...options,id_or_path:entry},"get_path"),depth:0}];
    const items=[],limit=bounded(a.limit??20,1,100);
    while(queue.length&&items.length<limit&&ctx.remaining()>1500){
      const dir=queue.shift(),children=await directoryAll(ctx,{...options,id:dir.id});
      const dirs=children.filter(n=>n.is_dir),files=children.filter(n=>!n.is_dir);
      items.push({path:dir.path,dirs,files});
      if(a.max_depth===undefined||a.max_depth<0||dir.depth<a.max_depth)queue.push(...dirs.map(n=>({id:n.id,path:dir.path.replace(/\/$/,"")+"/"+escapeName(n.name),depth:dir.depth+1})));
      if(queue.length>20000)throw connectorError("遍历队列过大，请分目录处理","conflict");
    }
    return {items,cursor:queue.length?{queue}:null,complete:!queue.length};
  }
  throw connectorError("未知文件系统状态操作");
}
async function shareFilesystem(ctx,a,operation){
  const scope=shareScope(a);
  if(operation==="from_url")return {scope,cid:"0",cwd:"/"};
  if(operation==="receive"){
    const ids=a.ids??[(await resolveEntry(ctx,a.id_or_path??a.id??0,{...a,scope})).id];
    return ensureOK(await do_share_receive(ctx,{payload:{share_code:scope.share_code,receive_code:scope.receive_code,file_id:ids.map(remoteId).join(","),cid:remoteId(a.to_pid??0)}}));
  }
  const data=ensureOK(await do_share_snap(ctx,{payload:{share_code:scope.share_code,receive_code:scope.receive_code,limit:1}})).data;
  if(["share_data","get_share_data"].includes(operation))return data;
  if(operation==="share_info")return data.share_info;
  if(operation==="snap_id")return String(data.share_info.snap_id);
  if(operation==="share_user_id")return String(data.userinfo.user_id);
  if(operation==="create_timestamp")return Number(data.share_info.create_time);
  if(operation==="create_time")return new Date(Number(data.share_info.create_time)*1000).toISOString();
  throw connectorError("未知分享操作");
}
