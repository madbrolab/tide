// Stream from a delegated source for the lifetime of one call.
function uploadInitForSource(ctx, args, mode, file, sha1) {
  const filename = args.filename,
    pid = remoteId(args.pid ?? "0");
  const base = {
    filename,
    sizeBytes: file.size,
    sha1,
    remoteDir: pid,
    dirname: args.dirname ?? "",
  };
  const info = mode === "cookie" ? ensureOK(do_upload_info(ctx, {})) : null;
  const challenge = {};
  for (let i = 0; i < 2; i++) {
    const r = info
      ? cookieInit(ctx, base, info, challenge)
      : ensureOK(
          send(ctx, open + "/upload/init", "POST", null, {
            file_name: filename,
            fileid: sha1,
            file_size: file.size,
            target: "U_1_" + pid,
            path: base.dirname,
            topupload: 1,
            ...challenge,
          }),
        ).data;
    if (!r || failed(r)) throw Error("115 拒绝初始化上传");
    if (r.status === 1 || r.status === 2) return r;
    const range = /^(?:bytes=)?(\d+)-(\d+)$/.exec(r.sign_check);
    if (i || r.status !== 7 || !r.sign_key || !range)
      throw Error("115 上传挑战无效");
    const start = Number(range[1]),
      end = Number(range[2]);
    challenge.sign_key = r.sign_key;
    challenge.sign_val = ctx.fs
      .hashRange("@source", start, end - start + 1, "sha1")
      .toUpperCase();
  }
}
function ossTicket(ctx, mode) {
  const r =
    mode === "open"
      ? ensureOK(send(ctx, open + "/upload/get_token", "GET", null, null))
      : do_common_upload_gettoken(ctx, {});
  const t = r.data ?? r;
  const token = t.SecurityToken ?? t.security_token,
    key = t.AccessKeyId ?? t.access_key_id,
    secret = t.AccessKeySecret ?? t.access_key_secret;
  if (!token || !key || !secret) throw Error("OSS 短期签名凭据无效");
  return { token, key, secret };
}
function ossRequest(ctx, ticket, remote, method, query = {}, opts = {}) {
  if (
    remote.bucket !== "fhnfile" ||
    typeof remote.object !== "string" ||
    !/^[\w./-]+$/.test(remote.object) ||
    remote.object.split("/").some((s) => !s || s === "..")
  )
    throw Error("未授权的 OSS 对象");
  const qs = form(query),
    signedQuery = form(Object.fromEntries(Object.entries(query).filter(([key])=>!['max-parts','part-number-marker'].includes(key)))),
    path = "/" + remote.object,
    date = new Date().toUTCString();
  const headers = {
    "x-oss-security-token": ticket.token,
    ...(opts.ossHeaders ?? {}),
  };
  const canonical = Object.keys(headers)
    .sort()
    .map((k) => k + ":" + headers[k])
    .join("\n");
  const contentType = opts.type ?? "",
    text = [
      method,
      "",
      contentType,
      date,
      canonical,
      "/" + remote.bucket + path + (signedQuery ? "?" + signedQuery : ""),
    ].join("\n");
  headers.date = date;
  headers.authorization =
    "OSS " +
    ticket.key +
    ":" +
    base64(bytes(ctx.crypto.hmacSHA1(ticket.secret, text)));
  if (contentType) headers["content-type"] = contentType;
  const url =
    "https://fhnfile.oss-cn-shenzhen.aliyuncs.com" +
    path +
    (qs ? "?" + qs : "");
  const reply = ctx.http.request({
    url,
    method,
    transfer: true,
    headers,
    ...(opts.body ? { body: opts.body } : {}),
    ...(opts.range ? { sourceRange: opts.range } : {}),
  });
  if (reply.status < 200 || reply.status >= 300)
    throw Error("OSS HTTP " + reply.status);
  return reply;
}
function callbacks(remote) {
  if (
    typeof remote.callback?.callback !== "string" ||
    typeof remote.callback.callback_var !== "string"
  )
    throw Error("缺少上传回调");
  return {
    "x-oss-callback": base64(utf8Bytes(remote.callback.callback)),
    "x-oss-callback-var": base64(utf8Bytes(remote.callback.callback_var)),
  };
}
function uploadSource(ctx,args,mode){
 const init=prepareUpload(ctx,args,mode),file=ctx.fs.sourceInfo();
 const pickcode=init.pickcode??init.pick_code??null;
 if(init.status===2)return {outcome:"reused",pickcode,size:file.size,data:init};
 const remote={bucket:init.bucket,object:init.object,callback:init.callback};
 const part=bounded(args.partSize??8388608,102400,134217728);
 if(Math.ceil(file.size/part)>2000)throw Error("请提高 partSize，分片最多 2000 个");
 const ticket=ossTicket(ctx,mode),ossHeaders=callbacks(remote);
 let reply;
 if(!file.size)reply=ossRequest(ctx,ticket,remote,"PUT",{},{ossHeaders,range:{offset:0,length:0}});
 else {
   const begin=ossRequest(ctx,ticket,remote,"POST",{sequential:"1",uploads:"1"});
   const id=/<UploadId>([A-Za-z0-9._-]+)<\/UploadId>/.exec(begin.body)?.[1];
   if(!id)throw Error("OSS 未返回上传 ID");
   const parts=[];
   try{
    for(let offset=0;offset<file.size;offset+=part){
     const number=parts.length+1;
     const r=ossRequest(ctx,ticket,remote,"PUT",{partNumber:number,uploadId:id},{range:{offset,length:Math.min(part,file.size-offset)}});
     if(!/^"?(?:[A-Fa-f0-9]{32})"?$/.test(r.etag??""))throw Error("分片 ETag 无效");
     parts.push("<Part><PartNumber>"+number+"</PartNumber><ETag>"+r.etag+"</ETag></Part>");
    }
   }catch(error){try{ossRequest(ctx,ticket,remote,"DELETE",{uploadId:id});}catch{} throw error;}
   reply=ossRequest(ctx,ticket,remote,"POST",{uploadId:id},{ossHeaders,type:"text/xml",body:"<CompleteMultipartUpload>"+parts.join("")+"</CompleteMultipartUpload>"});
 }
 return {outcome:"uploaded",pickcode,size:file.size,data:ensureOK(losslessJSON(reply.body))};
}
function prepareUpload(ctx, args, mode) {
  if (
    typeof args.filename !== "string" ||
    !args.filename ||
    args.filename.length > 255 ||
    /[\/\\\x00\r\n]/.test(args.filename)
  )
    throw Error("需要有效文件名");
  const file = ctx.fs.sourceInfo(),
    sha1 = ctx.fs.sourceSHA1().toUpperCase();
  if (args.sha1 && String(args.sha1).toUpperCase() !== sha1)
    throw Error("源文件 SHA-1 不匹配");
  return uploadInitForSource(ctx, args, mode, file, sha1);
}
