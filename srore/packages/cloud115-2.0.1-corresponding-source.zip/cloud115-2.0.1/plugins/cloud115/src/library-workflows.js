async function extractTool(ctx,a,operation){
  if(operation==="raw"){
    const r=ensureOK(await archiveList(ctx,{pickcode:a.pickcode,path:a.path??"",nextMarker:a.cursor?.marker??"",pageCount:a.limit??100,app:a.app}));return pageResult(r.data.list,r.data.next_marker?{marker:r.data.next_marker}:null);
  }
  const app=a.app??"web",mobile=!["","web","desktop","aps"].includes(app);let fn,payload;
  if(operation==="push"){fn=mobile?do_extract_push_app:do_extract_push;payload={pick_code:a.pickcode,secret:a.secret??""};}
  else if(operation==="push_progress"){fn=mobile?do_extract_push_progress_app:do_extract_push_progress;payload={pick_code:a.pickcode};}
  else{fn=mobile?do_extract_progress_app:do_extract_progress;payload={extract_id:a.extract_id};}
  return ensureOK(await fn(ctx,{payload,...(mobile?{app}:{})}));
}
async function zipTool(ctx,a,operation){
  const scope={kind:"zip",pickcode:a.pickcode};
  if(operation==="load")return await treePage(ctx,{...a,top:"/",scope});
  if(operation==="id_to_path"||operation==="path_to_id")return (await resolveEntry(ctx,a.path??a.id??"/",{...a,scope})).id;
  const files=[],dirs=[];for(const value of a.paths??[a.path??a.id??"/"]){const entry=await resolveEntry(ctx,value,{...a,scope});(entry.is_dir?dirs:files).push(pathParts(entry.id).join("/"));}
  return await extendedExtract(ctx,{pickcode:a.pickcode,files,dirs,to_pid:a.to_pid??0,app:a.app});
}
async function exportWorkflow(ctx,a,operation){
  let state=a.cursor??{},exportId=a.export_id??state.export_id;
  if((operation==="parse"||operation==="export")&&!state.file_id){
    const id=exportId===undefined?"0":pickToId(exportId);
    if(a.file_id!==undefined||BigInt(id)>=(1n<<60n))state={...state,file_id:pickToId(a.file_id??id),offset:0,parser:null};
  }
  if(operation==="start"||operation==="export"&&!exportId&&!state.file_id){
    const target=String(a.target??0),r=ensureOK(await do_fs_export_dir(ctx,{payload:{file_ids:(a.file_ids??[0]).map(pickToId).join(","),target:target.startsWith("U_")?target:"U_1_"+pickToId(target),...(a.layer_limit?{layer_limit:a.layer_limit}:{})}}));
    exportId=r.data.export_id;state={export_id:exportId};if(operation==="start")return exportId;
  }
  if(!state.file_id){
    const r=ensureOK(await do_fs_export_dir_status(ctx,{payload:{export_id:exportId}}));
    if(operation==="status")return r.data||{export_id:exportId};
    if(!r.data||!r.data.file_id)return {items:[],complete:false,stage:"exporting",cursor:{export_id:exportId}};
    if(operation==="result")return r.data;
    state={...state,file_id:String(r.data.file_id),offset:0,parser:null};
  }
  const entry=await entryById(ctx,state.file_id),link=await entryURL(ctx,entry,a),length=Math.min(32768,Number(entry.size)-state.offset);
  const r=length?await ctx.net.request({url:link.url,headers:{...link.headers,Range:"bytes="+state.offset+"-"+(state.offset+length-1)},responseType:"bytes",maxBytes:32768,followRedirects:true}):{status:200,body:new Uint8Array()};
  if(r.status!==206&&!(r.status===200&&state.offset===0&&Number(entry.size)<=32768))throw connectorError("无法读取导出的目录树","upstream");
  if(r.body.length!==length||length%2)throw connectorError("目录树 UTF-16 数据长度错误","upstream");
  let text="";for(let i=0;i<r.body.length;i+=2)text+=String.fromCharCode(r.body[i]|r.body[i+1]<<8);
  const end=state.offset+length>=Number(entry.size),parsed=parseExportText({text,cursor:state.parser,final:end,format:a.format??"path",escape:a.escape});
  if(end&&a.delete)ensureOK(await do_fs_delete(ctx,{payload:indexedFields([state.file_id])}));
  return {items:parsed.items,complete:end,stage:end?"complete":"reading",cursor:end?null:{export_id:exportId,file_id:state.file_id,offset:state.offset+length,parser:parsed.cursor}};
}
async function picURLs(ctx,a){
  const list=Array.isArray(a.sha1)?a.sha1:[a.sha1],hashes=list.map(value=>{const v=String(value);if(/^[0-9a-f]{40}$/i.test(v))return v.toUpperCase();if(/^fhn[a-z]+_/.test(v))return v;if(/^[A-Z2-7]{32}$/i.test(v)){let bits=0,buffer=0,out="";for(const c of v.toUpperCase()){buffer=buffer<<5|"ABCDEFGHIJKLMNOPQRSTUVWXYZ234567".indexOf(c);bits+=5;if(bits>=8){bits-=8;out+=hexByte(buffer>>>bits&255);}}return out.toUpperCase();}return "fhnfile_"+v;});
  const type=a.select??"life_v1",fn={life_v1:do_life_get_pic_url,life_v2:do_life_get_pic_url2,note_v1:do_note_get_pic_url,note_v2:do_note_get_pic_url2}[type];if(!fn)throw connectorError("图片接口类型无效");
  const payload=hashes.length===1?{rs:hashes[0]}:indexedFields(hashes,"rs"),r=ensureOK(await fn(ctx,{payload}));let urls;
  if(type==="life_v1")urls=r.data.map(v=>v.json.replace("&i=0","&i=1"));
  else if(type==="life_v2")urls=r.data.json.map(v=>v+"&i=1");
  else urls=r.data.map(v=>"https://q.115.com/imgload?"+v.slice(v.indexOf("&")+1)+"&i=1");
  return Array.isArray(a.sha1)?urls:urls[0];
}
async function downloadNodePage(ctx,a){
  if(!a.pickcode)return await treePage(ctx,{...a,top:a.top??0,filter:{is_dir:a.files===false}});
  const payload={pickcode:a.pickcode,page:a.cursor?.page??1,per_page:bounded(a.limit??200,1,1000)};
  const r=ensureOK(await(a.files===false?do_download_folders:do_download_files)(ctx,{payload})),data=r.data;
  const items=[];for(const n of data.list??[]){
    let entry=a.files===false?{is_dir:true,id:String(n.fid),parent_id:String(n.pid),name:n.fn}:{is_dir:false,id:pickToId(n.pc),pickcode:n.pc,parent_id:String(n.pid),size:n.fs,sha1:n.sha1??"",...(n.fn?{name:n.fn}:{})};
    if(a.ensure_name&&!entry.name)entry={...entry,...await entryById(ctx,entry.id)};items.push(a.get_raw?n:entry);
  }
  return pageResult(items,data.has_next_page?{page:payload.page+1}:null);
}
async function urlPage(ctx,a){
  const mode=(await ctx.connection()).kind==="bearer"?"open":"cookie";
  if(Array.isArray(a.pickcodes)){
    const offset=a.cursor?.offset??0,list=a.pickcodes.slice(offset,offset+Math.min(a.limit??10,64)),pickcodes=[];
    for(const value of list)pickcodes.push(typeof value==="string"&&/^[a-f]/.test(value)?value:(await resolveEntry(ctx,value)).pickcode);
    const items=pickcodes.length?await downloadLinks(ctx,{pickcode:pickcodes.join(","),strict:false,userAgent:a.userAgent},mode,false):[];
    return pageResult(items,offset+list.length<a.pickcodes.length?{offset:offset+list.length}:null);
  }
  const page=await treePage(ctx,{...a,top:a.top??a.id??0,filter:{is_dir:false},limit:Math.min(a.limit??10,64)}),items=[];
  for(const n of page.items)items.push(await entryURL(ctx,n,a));return {...page,items};
}
async function downloadFile(ctx,a){
  const entry=await resolveEntry(ctx,a.entry??a.id_or_path??a.id??0,a),link=await entryURL(ctx,entry,a),destination=a.destination;
  if(typeof destination!=="string"||!destination.startsWith("/"))throw connectorError("需要绝对目标路径");
  let offset=0,exists=false;try{const stat=await ctx.fs.stat(destination);offset=stat.size;exists=true;}catch(e){if(!/not exist|不存在|no such/i.test(e.message)&&e.code!=="not_found")throw e;}
  if(exists&&!a.resume&&!a.cursor)throw connectorError("目标文件已存在","conflict");
  if(offset>Number(entry.size))throw connectorError("目标文件长度超过源文件","conflict");
  if(offset){
    for(const start of [...new Set([0,Math.max(0,offset-65536)])]){
      const length=Math.min(65536,offset-start),local=await ctx.fs.hashRange(destination,start,length,"sha1"),remote=await streamDigests(ctx,link,{offset:start,length,digests:["sha1"]});
      if(!remote.complete||local!==remote.digests.sha1)throw connectorError("目标文件与源文件不匹配","conflict");
    }
  }else if(!exists)await ctx.fs.writeBytes(destination,new Uint8Array());
  let chunks=0;
  while(offset<Number(entry.size)&&ctx.remaining()>1500&&chunks++<bounded(a.chunks??8,1,64)){
    const length=Math.min(1048576,Number(entry.size)-offset),r=await ctx.net.request({url:link.url,headers:{...link.headers,Range:"bytes="+offset+"-"+(offset+length-1)},responseType:"bytes",maxBytes:length,followRedirects:true});
    if(r.status!==206&&!(r.status===200&&offset===0&&Number(entry.size)===length)||r.body.length!==length)throw connectorError("下载区间响应不匹配","upstream");
    await ctx.fs.writeAt(destination,r.body,offset);offset+=length;
  }
  return {destination,bytes:offset,total:entry.size,complete:offset===Number(entry.size),cursor:offset===Number(entry.size)?null:{offset,id:entry.id,size:entry.size}};
}
async function ed2kFile(ctx,a){
  const entry=await resolveEntry(ctx,a.id_or_path??a.id??0,a),link=await entryURL(ctx,entry,a),size=Number(entry.size),state=a.cursor??{id:entry.id,size,offset:0,block:newDigest("md4"),all:newDigest("md4")};
  if(state.id!==entry.id||state.size!==size)throw connectorError("ED2K 游标与文件不匹配");
  let reads=0;
  while(state.offset<size&&ctx.remaining()>1500&&reads++<32){
    const length=Math.min(262144,size-state.offset,9728000-state.block.total),r=await ctx.net.request({url:link.url,headers:{...link.headers,Range:"bytes="+state.offset+"-"+(state.offset+length-1)},responseType:"bytes",maxBytes:length,followRedirects:true});
    if(r.status!==206&&!(r.status===200&&state.offset===0&&size===length)||r.body.length!==length)throw connectorError("ED2K 读取范围错误","upstream");
    digestUpdate(state.block,r.body);state.offset+=length;
    if(state.block.total===9728000){digestUpdate(state.all,bytes(digestEnd(state.block)));state.block=newDigest("md4");}
  }
  if(state.offset<size)return {complete:false,bytes:state.offset,cursor:state};
  // p115C's pinned ed2k implementation hashes the concatenation even for one chunk.
  digestUpdate(state.all,bytes(digestEnd(state.block)));const hash=digestEnd(state.all),name=(a.name??entry.name).replaceAll("%","%25").replaceAll("/","%2F").replaceAll("|","%7C");
  return {complete:true,cursor:null,bytes:size,hash,url:"ed2k://|file|"+name+"|"+size+"|"+hash+"|/"};
}
async function readAfterEdit(ctx,a,mode){
  const ids=idsArray(a.ids??[]);if(ids.length>1000)throw connectorError("每次最多 1000 个文件");
  if(mode==="star")await editBatch(ctx,{ids,value:true,batch_size:1000},"star");
  else if(mode==="event"){ensureOK(await do_life_calendar_setoption(ctx,{}));await editBatch(ctx,{ids,batch_size:1000,type:a.type??"img"},"post_event");}
  else{
    const created=ensureOK(await extendedLabels(ctx,{payload:"tide-"+ctx.runId},false));
    const label=String(created.data?.[0]?.id??created.data?.list?.[0]?.id??created.data?.id??"");if(!label)throw connectorError("创建临时标签失败","upstream");
    try{
      await editBatch(ctx,{ids,batch_size:1000,label,mode:a.replace_label===false?"add":"reset"},"batch_label");
      const r=ensureOK(await do_fs_search(ctx,{payload:{file_label:label,limit:Math.max(1,ids.length),offset:0}}));
      return pageResult((r.data??[]).map(n=>normalizeEntry(n)),null);
    }finally{ensureOK(await do_fs_label_del(ctx,{payload:{id:label}}));}
  }
  if(mode==="event"){
    const page=await collectionPage(ctx,{...a,type:a.type==="doc"?"browse_document":"browse_image",yield_latest:true},"life");return {...page,items:page.items.filter(n=>ids.includes(String(n.file_id)))};
  }
  return await selectNodes(ctx,{...a,ids},"file");
}
async function lifeListPage(ctx,a){
  const from=a.cursor?.start_time??a.start_time??Math.floor(Date.now()/1000)-2,to=a.cursor?.end_time??a.end_time??Math.floor(Date.now()/1000);
  const items=[],pending=JSON.parse(JSON.stringify(a.cursor?.pending??[]));
  const r=pending.length?null:ensureOK(await do_life_list(ctx,{payload:{show_type:0,start_time:from,end_time:to},app:a.app??"web"}));
  for(const group of r?.data.list??[]){
    if(!group.items){if(Number(group.update_time)>from&&Number(group.update_time)<to)items.push(group);continue;}
    items.push(...group.items.map(n=>({...n,behavior_type:group.behavior_type,date:group.date})));
    if(group.total>group.items.length||group.behavior_type.startsWith("upload_"))pending.push({type:group.behavior_type,date:group.date,offset:0,seen:group.items.map(n=>String(n.id))});
  }
  while(pending.length&&ctx.remaining()>1500&&items.length<200){
    const group=pending[0],raw=ensureOK(await do_life_behavior_detail(ctx,{payload:{type:group.type,date:group.date,offset:group.offset,limit:32}})).data;
    for(const event of raw.list??[])if(!group.seen.includes(String(event.id))&&Number(event.update_time)>from&&Number(event.update_time)<to){items.push({...event,behavior_type:group.type,date:group.date});group.seen.push(String(event.id));}
    if(raw.next_page)group.offset+=32;else pending.shift();
  }
  if(utf8Bytes(JSON.stringify(pending)).length>150000)throw connectorError("事件游标过大，请缩小时间段","conflict");
  return {items,complete:!pending.length,cursor:{start_time:pending.length?from:to,...(pending.length?{end_time:to}:{}),pending},nextPollAfterMS:1000};
}
async function deauthOpen(ctx,a){
  const r=ensureOK(await do_login_open_auth_list(ctx,{})),items=[];
  for(const app of r.data??[])if(!a.app_ids||a.app_ids.map(String).includes(String(app.app_id))){items.push({auth_id:app.auth_id,result:ensureOK(await do_login_open_deauth(ctx,{payload:{auth_id:app.auth_id}}))});}return items;
}
async function ensurePaths(ctx,a){const items=[];for(const entry of a.items??[]){const ancestors=await entryAncestors(ctx,entry,a);items.push({...entry,ancestors,path:"/"+ancestors.slice(1).map(n=>escapeName(n.name)).join("/")});}return items;}
async function sha1Exists(ctx,a){const url=await picURLs(ctx,{sha1:a.sha1,select:"note_v1"}),r=await ctx.net.request({url,method:"HEAD",followRedirects:true,responseType:"bytes",maxBytes:1024});return r.status!==404&&r.status>=200&&r.status<400;}
async function copyRenameFile(ctx,a,rename){
  const entry=await resolveEntry(ctx,a.entry??a.id??0,a),pid=String(a.pid??entry.parent_id),name=a.name??entry.name;
  if(entry.is_dir)throw connectorError("此组合动作只接受文件");
  if(pid===entry.parent_id&&name===entry.name)return {state:true,unchanged:true};
  if(!rename&&name===entry.name)return ensureOK(await do_fs_copy(ctx,{payload:{...indexedFields([entry.id]),pid}}));
  if(rename&&fileSuffix(name)===fileSuffix(entry.name)){
    if(pid!==entry.parent_id)ensureOK(await do_fs_move(ctx,{payload:{...indexedFields([entry.id]),pid}}));
    return name===entry.name?{state:true}:ensureOK(await do_fs_rename(ctx,{payload:{["files_new_name["+entry.id+"]"]:name}}));
  }
  const r=await transferInit(ctx,{entry,pid,name});
  if(rename&&Number(r.status)===2)ensureOK(await do_fs_delete(ctx,{payload:indexedFields([entry.id])}));
  return r;
}
async function filesJob(ctx,a,operation){
  const account=String(await remoteUser(ctx,a));let state=a.cursor?await loadCheckpoint(ctx,"p115-file-job",a.cursor.state):null;
  if(!state)state={job:ctx.runId,account,phase:"plan",scan:null,top:a.top??0,pid:String(a.pid??0),flatten:Boolean(a.flatten),operation,planned:0,done:0};
  if(state.account!==account||state.operation!==operation)throw connectorError("批处理游标与账号或操作不匹配");
  if(!a.cursor){const expired=Date.now()-30*86400000;await ctx.db.exec("DELETE FROM file_jobs WHERE job IN (SELECT job FROM file_job_runs WHERE created<?)",[expired]);await ctx.db.exec("DELETE FROM file_job_runs WHERE created<?",[expired]);await ctx.db.exec("INSERT INTO file_job_runs(job,created) VALUES(?,?)",[state.job,Date.now()]);}
  const run=(await ctx.db.query("SELECT complete,planned,processed FROM file_job_runs WHERE job=? LIMIT 1",[state.job]))[0];
  if(!run)throw connectorError("批处理记录已过期","not_found");if(run.complete)return {planned:run.planned,processed:run.processed,complete:true,cursor:null};
  if(state.phase==="plan"){
    const page=await treePage(ctx,{top:state.top,cursor:state.scan,filter:{is_dir:false},limit:Math.min(a.limit??100,200)});
    for(const entry of page.items){await ctx.db.exec("INSERT OR IGNORE INTO file_jobs(job,id,data,status) VALUES(?,?,?,'pending')",[state.job,entry.id,JSON.stringify(entry)]);state.planned++;}
    state.scan=page.cursor;if(page.complete)state.phase="apply";
    state.planned=Number((await ctx.db.query("SELECT COUNT(*) AS count FROM file_jobs WHERE job=?",[state.job]))[0].count);
    await ctx.db.exec("UPDATE file_job_runs SET planned=? WHERE job=?",[state.planned,state.job]);
    return {phase:state.phase,planned:state.planned,processed:state.done,complete:false,cursor:{state:await saveCheckpoint(ctx,"p115-file-job",state)}};
  }
  if(a.resolve_id){
    if(!["done","pending"].includes(a.resolution))throw connectorError("resolution 必须为 done 或 pending");
    await ctx.db.exec("UPDATE file_jobs SET status=? WHERE job=? AND id=? AND status='running'",[a.resolution,state.job,remoteId(a.resolve_id)]);
  }
  const rows=await ctx.db.query("SELECT id,data,status FROM file_jobs WHERE job=? AND status!='done' ORDER BY id LIMIT ?",[state.job,Math.min(a.limit??10,100)]),items=[];
  for(const row of rows){
    if(row.status==="running")throw connectorError("上次写入结果不确定，请核对该文件后用 resolve_id 标记结果","conflict");
    const entry=losslessJSON(row.data);let pid=state.pid;
    if(operation!=="delete"&&!state.flatten){const parts=pathParts(entry.path).slice(0,-1);if(parts.length)pid=(await makeDirectories(ctx,{pid,path:parts})).id;}
    if(!await ctx.db.exec("UPDATE file_jobs SET status='running' WHERE job=? AND id=? AND status='pending'",[state.job,row.id]))throw connectorError("该批处理已在其他调用中执行","busy");
    const r=ensureOK(await(operation==="copy"?do_fs_copy:operation==="move"?do_fs_move:do_fs_delete)(ctx,{payload:{...indexedFields([row.id]),...(operation!=="delete"?{pid}:{})}}));
    await ctx.db.exec("UPDATE file_jobs SET status='done' WHERE job=? AND id=?",[state.job,row.id]);state.done++;items.push({id:row.id,result:r});
  }
  const pending=await ctx.db.query("SELECT COUNT(*) AS count FROM file_jobs WHERE job=? AND status!='done'",[state.job]);
  const complete=Number(pending[0].count)===0;state.done=state.planned-Number(pending[0].count);
  await ctx.db.exec("UPDATE file_job_runs SET complete=?,processed=? WHERE job=?",[Number(complete),state.done,state.job]);
  return {items,planned:state.planned,processed:state.done,complete,cursor:complete?null:{state:await saveCheckpoint(ctx,"p115-file-job",state)}};
}
async function batchUnstar(ctx,a){
  const page=await directoryPage(ctx,{id:0,offset:0,limit:a.limit??100,payload:{cur:0,star:1,...(a.ensure_file!==undefined?{show_dir:Number(!a.ensure_file)}:{})}});
  if(page.items.length)await editBatch(ctx,{ids:page.items.map(n=>n.id),value:false,batch_size:1000},"star");
  return {processed:page.items.length,complete:page.next===null,cursor:page.next===null?null:{continue:true}};
}
async function transferFiles(ctx,a,resume){
  const offset=a.cursor?.offset??0;let page;
  if(a.entries){const entries=a.entries.slice(offset,offset+Math.min(a.limit??10,50));page=pageResult(entries,offset+entries.length<a.entries.length?{offset:offset+entries.length}:null);}
  else{
    if(!a.source?.uuid||!a.source?.credential)throw connectorError("需要源账号 source.uuid 与 source.credential");
    page=(await ctx.invoke({version:1,target:"com.tide.cloud115",operation:"vfs-iter",uuid:a.source.uuid,credential:a.source.credential,args:{id:a.top??0,filter:{is_dir:false},limit:Math.min(a.limit??5,20),...(a.cursor?{cursor:a.cursor}:{})}})).data;
  }
  const items=[];
  for(const entry of page.items){
    let pid=String(a.pid??0);const parts=entry.path?pathParts(entry.path).slice(0,-1):[];
    if(!a.flatten&&parts.length)pid=(await makeDirectories(ctx,{pid,path:parts})).id;
    if(resume){const exists=(await directoryAll(ctx,{id:pid})).find(n=>n.name===entry.name&&n.sha1===entry.sha1&&String(n.size)===String(entry.size));if(exists){items.push({source:entry.id,outcome:"existing",id:exists.id});continue;}}
    let link=entry.url?{url:entry.url,headers:entry.headers}:null;
    if(!link&&a.source)link=(await ctx.invoke({version:1,target:"com.tide.cloud115",operation:"vfs-get-url",uuid:a.source.uuid,credential:a.source.credential,args:{id_or_path:entry}})).data;
    const result=await transferInit(ctx,{entry,pid,source_url:link?.url,source_headers:link?.headers});items.push({source:entry.id,result});
  }
  return {...page,items};
}
async function subtitlePage(ctx,a){
  let page;
  if(Array.isArray(a.file_ids)){const offset=a.cursor?.offset??0,list=a.file_ids.slice(offset,offset+Math.min(a.limit??50,200));page=pageResult(list.map(id=>({id})),offset+list.length<a.file_ids.length?{offset:offset+list.length}:null);}
  else{page=await treePage(ctx,{...a,top:a.top??a.file_ids??0,filter:{is_dir:false}});page.items=page.items.filter(n=>/\.(srt|ass|ssa)$/i.test(n.name));}
  if(!page.items.length)return page;
  const folder=ensureOK(await do_fs_mkdir(ctx,{payload:{pid:0,cname:"subtitle-"+ctx.runId}})),id=String(folder.cid??folder.data?.file_id??folder.data?.category_id);
  try{
    ensureOK(await do_fs_copy(ctx,{payload:{...indexedFields(page.items.map(n=>String(n.id))),pid:id}}));
    const items=await directoryPage(ctx,{id,limit:1});if(!items.items[0])return {...page,items:[]};
    const r=ensureOK(await do_fs_video_subtitle(ctx,{payload:{pickcode:items.items[0].pickcode}}));return {...page,items:(r.data.list??[]).filter(n=>n.file_id!==undefined)};
  }finally{ensureOK(await do_fs_delete(ctx,{payload:indexedFields([id])}));}
}
async function probeOpenCount(ctx,a){
  const limit=bounded(a.limit??16,1,64),sockets=[],items=a.urls??(await urlPage(ctx,{top:a.top??0,limit})).items;let count=0,reason="limit";
  try{
    for(const link of items.slice(0,limit)){
      if(ctx.remaining()<2000){reason="deadline";break;}
      const m=/^https:\/\/([^/:]+)(?::443)?(\/.*)?$/.exec(typeof link==="string"?link:link.url);if(!m)throw connectorError("下载链接必须是 HTTPS");
      try{
        const peer=await ctx.net.connect({address:m[1]+":443",tls:true,timeoutMs:5000});sockets.push(peer.handle);
        const headers=typeof link==="string"?{}:link.headers??{};
        if(Object.values(headers).some(v=>/[\r\n]/.test(String(v))))throw connectorError("下载请求头无效");
        const request="GET "+(m[2]??"/")+" HTTP/1.1\r\nHost: "+m[1]+"\r\nConnection: keep-alive\r\n"+Object.entries(headers).map(([k,v])=>k+": "+v+"\r\n").join("")+"\r\n";
        await ctx.net.write({handle:peer.handle,data:new Uint8Array(utf8Bytes(request)),timeoutMs:5000});const first=await ctx.net.readBytes({handle:peer.handle,length:256,timeoutMs:5000});
        const text=String.fromCharCode(...first.data);if(!/^HTTP\/1\.[01] 20[06]/.test(text)){reason="refused";break;}count++;
      }catch(e){reason=e.code??"unavailable";break;}
    }
    return {count,complete:reason==="refused",bounded:true,stopReason:reason};
  }finally{for(const handle of sockets)try{await ctx.net.close({handle});}catch{}}
}
async function downloadUploadBlocks(ctx,a){
  if(typeof a.temp_dir!=="string"||!a.temp_dir.startsWith("/"))throw connectorError("需要 temp_dir 保存单个传输块");
  const entry=await resolveEntry(ctx,a.id??pickToId(a.pickcode),a),link=await entryURL(ctx,entry,a),blockSize=bounded(a.block_size??52428800,1,268435456),number=a.cursor?.block_number??a.start_block_number??1,offset=(number-1)*blockSize;
  if(offset>=Number(entry.size))return pageResult([],null);
  const length=Math.min(blockSize,Number(entry.size)-offset),path=a.temp_dir.replace(/\/$/,"")+"/tide-block-"+ctx.runId;
  let downloaded=false;
  try{
    const r=await ctx.net.request({url:link.url,headers:{...link.headers,Range:"bytes="+offset+"-"+(offset+length-1)},outputPath:path,followRedirects:true});downloaded=true;
    if(r.bytes!==length||r.status!==206&&!(r.status===200&&offset===0&&length===Number(entry.size)))throw connectorError("源文件范围响应错误","upstream");
    const state={};for(const alg of a.hashmethods??["sha1","md5"])state[alg]=newDigest(alg);
    for(let off=0;off<length;off+=1048576){const data=await ctx.fs.readBytes(path,off,Math.min(1048576,length-off));for(const s of Object.values(state))digestUpdate(s,data);}
    const hashes=Object.fromEntries(Object.entries(state).map(([k,v])=>[k,digestEnd(v)]));
    const source=await ctx.fs.source(path),self=await ctx.invoke({version:1,target:"com.tide.cloud115",operation:"tool-upload-block",uuid:a.account.uuid,credential:a.account.credential,args:{sourceRef:source,filename:"block-"+number}});
    return pageResult([{block_number:number,block_size:length,hashes,result:self.data}],offset+length<Number(entry.size)?{block_number:number+1}:null);
  }finally{if(downloaded)await ctx.fs.remove(path);}
}
async function uploadBlock(ctx,a){
  const ticket=ensureOK(await send(ctx,"https://uplb.115.com/3.0/sampleinitupload.php","POST",null,{filename:a.filename,path:"",target:"U_12_0"}));
  const r=await ctx.http.request({url:String(ticket.host).replace(/^http:/,"https:"),method:"POST",multipart:{filename:a.filename,fields:{name:a.filename,key:ticket.object,policy:ticket.policy,OSSAccessKeyId:ticket.accessid,success_action_status:"200",callback:ticket.callback,signature:ticket.signature}}});
  if(r.status!==200)throw connectorError("块上传结果需核对","upstream");return ensureOK(losslessJSON(r.body));
}
