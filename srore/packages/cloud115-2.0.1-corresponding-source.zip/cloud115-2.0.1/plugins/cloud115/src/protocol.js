function localDay(offset) {
  return new Date(Date.now() + (8 + offset * 24) * 3600000).toISOString().slice(0,10);
}
function connectorError(message, code = "invalid_input") {
  return Object.assign(new Error(message), {code, retryable: ["busy", "timeout", "unavailable", "upstream"].includes(code)});
}
// Helpers shared by the generated, individually authorized P115C operations.
function opt(obj, key, fallback) {
  return Object.hasOwn(obj, key) ? obj[key] : fallback;
}
function get(obj, key, fallback = null) {
  return opt(obj, key, fallback);
}
function setdefault(obj, key, value = null) {
  if (!Object.hasOwn(obj, key)) obj[key] = value;
  return obj[key];
}
function item(value, key) {
  if (!Object.hasOwn(value, key)) throw Error("缺少协议字段 " + key);
  return value[key];
}
function size(value) {
  return typeof value === "object" && value !== null
    ? Object.keys(value).length
    : value.length;
}
function truth(value) {
  return value && (typeof value !== "object" || size(value) > 0);
}
function contains(obj, key) {
  return typeof obj === "string" || Array.isArray(obj)
    ? obj.includes(key)
    : Object.hasOwn(obj, key);
}
function startswith(s, prefix) {
  return (Array.isArray(prefix) ? prefix : [prefix]).some((p) =>
    s.startsWith(p),
  );
}
function endswith(s, suffix) {
  return (Array.isArray(suffix) ? suffix : [suffix]).some((p) => s.endsWith(p));
}
function lstrip(s, chars) {
  if (chars === undefined) return s.trimStart();
  let i = 0;
  while (i < s.length && chars.includes(s[i])) i++;
  return s.slice(i);
}
function rstrip(s, chars) {
  if (chars === undefined) return s.trimEnd();
  let i = s.length;
  while (i && chars.includes(s[i - 1])) i--;
  return s.slice(0, i);
}
function strip(s, chars) {
  return rstrip(lstrip(s, chars), chars);
}
function pyInt(x) {
  const n = Number(x);
  if (!Number.isFinite(n)) throw Error("无效整数");
  return Math.trunc(n);
}
function secretPassword(ctx, value) {
  if (!value) return "670b14728ad9902aecba32e22fa4f6bd";
  const s = String(value);
  return s.length === 32 ? s : ctx.crypto.digest("md5", s.padStart(6, "0"));
}
function protocolArgs(args, fields, hasPayload) {
  for (const k of Object.keys(args)) {
    if (!(hasPayload && k === "payload") && !fields.includes(k))
      throw Error("未知方法参数 " + k);
  }
  const p = opt(args, "payload", {});
  if (p === null || typeof p !== "object" || Array.isArray(p))
    throw Error("payload 应为协议字段对象");
  for (const [k, v] of Object.entries(p)) {
    // A caller may not switch a shared endpoint's server-side action or transport.
    if (
      !/^[a-zA-Z0-9_][a-zA-Z0-9_.\[\]-]{0,120}$/.test(k) ||
      /^(?:__proto__|constructor|prototype|ac|ct|action|method|_method|callback|base_url|headers|url_override)(?:\[|$)/i.test(
        k,
      )
    )
      throw Error("受保护的协议字段");
    if (
      typeof v !== "string" &&
      !(typeof v === "number" && Number.isSafeInteger(v)) &&
      typeof v !== "boolean"
    )
      throw Error("协议字段应为字符串、安全整数或布尔值；长文件 ID 使用字符串");
  }
  return {...p};
}
function wireForm(fields) {
  return (Array.isArray(fields) ? fields : Object.entries(fields))
    .map(
      ([k, v]) =>
        quote(k) + "=" + quote(v === true ? "True" : v === false ? "False" : v),
    )
    .join("&");
}
function losslessJSON(text) {
  // JSON has no bigint type. Preserve integral IDs outside JS's safe range as strings.
  const safe = text.replace(
    /"(?:\\[\s\S]|[^"\\])*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g,
    (token) => {
      if (
        token[0] === '"' ||
        /[.eE]/.test(token) ||
        Number.isSafeInteger(Number(token))
      )
        return token;
      return '"' + token + '"';
    },
  );
  return JSON.parse(safe);
}
function sendPublic(ctx, url, method, params, data, json = false) {
  return send(ctx, url, method, params, data, json, false);
}
function send(ctx, url, method, params, data, json = false, credential = true) {
  if (params !== null) {
    setdefault(params, "app_ver", version);
    const q = wireForm(params);
    if (q) url += (url.includes("?") ? "&" : "?") + q;
  }
  const opts = {
    url,
    method,
    credential,
    originReferer: true,
    headers: { "User-Agent": "Mozilla/5.0" },
  };
  if (data !== null) {
    opts.headers["Content-Type"] = json
      ? "application/json"
      : "application/x-www-form-urlencoded";
    opts.body = json ? JSON.stringify(data) : wireForm(data);
  }
  const r = ctx.http.request(opts);
  if (r.status < 200 || r.status >= 300) throw connectorError("115 HTTP " + r.status, "upstream");
  const value = losslessJSON(r.body);
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw Error("115 响应类型不匹配");
  return value;
}
function offlineWire(ctx, action, method, fields) {
  fields.ac = action;
  return send(
    ctx,
    "https://clouddownload.115.com/web/",
    method,
    method === "GET" ? fields : null,
    method === "GET" ? null : fields,
  );
}

// Upstream accepts alternate client identities; endpoint families stay fixed.
const platforms = [
  "web",
  "desktop",
  "chrome",
  "aps",
  "android",
  "115android",
  "ios",
  "115ios",
  "115ipad",
  "ipad",
  "harmony",
  "windows",
  "mac",
  "linux",
  "os_windows",
  "os_mac",
  "os_linux",
  "tv",
  "wechatmini",
  "alipaymini",
];
function platform(args, fallback, normalize) {
  const app = opt(args, "app", fallback);
  if (!platforms.includes(app) && app !== fallback)
    throw Error("未知客户端 app");
  if (!normalize) return app;
  if (["windows", "mac", "linux"].includes(app)) return "os_" + app;
  if (
    [
      "ios",
      "115ios",
      "115ipad",
      "android",
      "115android",
      "harmony",
      "os_windows",
      "os_mac",
      "os_linux",
    ].includes(app)
  )
    return app;
  if (app.endsWith("ios")) return "ios";
  if (app.endsWith("ipad")) return "115ipad";
  return "android";
}
function appEndpoint(args, defaultApp, table) {
  return item(table, platform(args, defaultApp, false));
}
function remoteUser(ctx, args) {
  return pyUID(args.userId ?? ensureOK(do_upload_info(ctx, {})).user_id);
}
function requestUUID(ctx) {
  const s = ctx.runId;
  return (
    s.slice(0, 8) +
    "-" +
    s.slice(8, 12) +
    "-4" +
    s.slice(13, 16) +
    "-" +
    ((parseInt(s[16], 16) & 3) | 8).toString(16) +
    s.slice(17, 20) +
    "-" +
    s.slice(20)
  );
}
function sendBytes(ctx, url, method, params, body, credential) {
  if (params !== null) {
    setdefault(params, "app_ver", version);
    url += (url.includes("?") ? "&" : "?") + wireForm(params);
  }
  const opts = {
    url,
    method,
    response: "hex",
    credential,
    originReferer: true,
    headers: { "User-Agent": "Mozilla/5.0" },
  };
  if (body !== null) {
    opts.body = wireForm(body);
    opts.headers["Content-Type"] = "application/x-www-form-urlencoded";
  }
  const r = ctx.http.request(opts);
  if (r.status !== 200) throw Error("115 HTTP " + r.status);
  return { hex: r.body };
}
function remoteId(v) {
  if (
    (typeof v === "number" && !Number.isSafeInteger(v)) ||
    !/^(0|[1-9][0-9]{0,29})$/.test(String(v))
  )
    throw Error("远端 ID 无效");
  return String(v);
}
function bounded(v, min, max) {
  if (!Number.isSafeInteger(v) || v < min || v > max)
    throw Error("分页或深度超出范围");
  return v;
}
function shareFields(link) {
  const value=String(link).trim().replace(/^[\/#]+|[\/#]+$/g,"");
  const short=/^([a-z0-9]+)(?:-([a-z0-9]+))?$/i.exec(value);
  if(short)return {share_code:short[1],receive_code:short[2]??""};
  const url=/^https?:\/\/[^/?#]+\/(?:[^?#]*\/)?([a-z0-9]+)\/?(?:\?([^#]*))?(?:#.*)?$/i.exec(value);
  if(!url)throw Error("分享链接无效");
  const pass=/(?:^|&)password=([^&]*)/.exec(url[2]??"");
  return {share_code:url[1],receive_code:pass?decodeURIComponent(pass[1]):""};
}

function qrLoginResult(ctx, {uid, app = "alipaymini", loginExchange = true}) {
  if (!qrDevices.includes(app)) throw Error("未知扫码设备");
  const apple = {ios:"UPhone", qios:"OfficePhone", ipad:"UPad", qipad:"OfficePad"}[app];
  const target = apple ? "ios" : app === "desktop" ? "web" :
    ["windows","mac","linux"].includes(app) ? "os_" + app : app;
  const headers = {"Content-Type":"application/x-www-form-urlencoded"};
  if (apple) headers["User-Agent"] = apple + "/1.0.0";
  const r = ctx.http.request({url:"https://qrcodeapi.115.com/app/1.0/" + target + "/1.0/login/qrcode/",
    method:"POST", headers, credential:false, loginExchange, body:wireForm({account:uid})});
  if (r.status !== 200) throw Error("115 HTTP " + r.status);
  const out = losslessJSON(r.body);
  if (out.data && r.cookies && Object.keys(r.cookies).length) {
    const body = out.data.cookie;
    const fields = typeof body === "string" ? Object.fromEntries(body.split(/;\s*/).flatMap(pair => {
      const eq = pair.indexOf("=");
      return eq > 0 ? [[pair.slice(0,eq).trim(),pair.slice(eq+1)]] : [];
    })) : body || {};
    // Prefer the signed-in session returned in the body over a response cookie of the same name.
    const merged = {};
    for (const source of [r.cookies, fields])
      for (const [k,v] of Object.entries(source))
        if (/^(uid|cid|seid|kid)$/i.test(k) && v) merged[k.toUpperCase()] = v;
    out.data.cookie = {...Object.fromEntries(Object.entries(fields).filter(([k])=>!/^(uid|cid|seid|kid)$/i.test(k))), ...merged};
  }
  return out;
}

function qrSnapshot(ctx, payload) {
  const result = sendPublic(ctx,"https://qrcodeapi.115.com/api/1.0/web/1.0/status","GET",
    {uid:item(payload,"uid"),_:Date.now()},null);
  const code = Number(result.code || result.errno || 0);
  const reason = String(result.message || result.error || "");
  let status = {90038:0,90039:1,90032:-1}[code];
  if (status === undefined) {
    if (/取消|拒绝|cancel|denied|refused/i.test(reason)) status = -2;
    else if (/key invalid|expired|已过期|已失效/i.test(reason)) status = -1;
    else if (result.data?.status != null && [-2,-1,0,1,2].includes(Number(result.data.status))) status = Number(result.data.status);
    else if (!code && [true,1,"1"].includes(result.state) && result.key) status = 2;
    else return result;
  }
  return {state:true,data:{status}};
}

function profileAvatar(ctx, url) {
  if (typeof url !== "string" || url.length > 2048 || !/^https:\/\/avatars\.115\.com\/[a-zA-Z0-9_%./?=&+-]+$/.test(url)) throw Error("无效的官方头像地址");
  const r = ctx.http.request({url, method:"GET", response:"hex", credential:false});
  if (r.status !== 200 || !r.body || r.body.length > 98304) throw Error("头像不可用或超过 48 KiB");
  const h = r.body;
  const mime = h.startsWith("ffd8ff") ? "jpeg" : h.startsWith("89504e470d0a1a0a") ? "png" :
    h.startsWith("52494646") && h.slice(16,24)==="57454250" ? "webp" : /^47494638(37|39)61/.test(h) ? "gif" : "";
  if (!mime) throw Error("不支持的头像图片格式");
  return {image:"data:image/"+mime+";base64,"+base64(bytes(h))};
}
