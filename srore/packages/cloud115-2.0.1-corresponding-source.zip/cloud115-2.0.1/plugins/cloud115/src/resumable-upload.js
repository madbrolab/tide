async function uploadCheckpoint(ctx,a,operation){
  const mode=(await ctx.connection()).kind==="bearer"?"open":"cookie";
  const account=await currentAccount(ctx);
  let state=a.state?await loadCheckpoint(ctx,"p115-upload",a.state):null;
  if(operation==="init"){
    const file=await ctx.fs.sourceInfo(),init=await prepareUpload(ctx,a,mode);
    state={v:1,mode,account,size:file.size,stamp:file.stamp,filename:a.filename,partSize:bounded(a.partSize??8388608,102400,5368709120),pickcode:init.pickcode??init.pick_code??null,remote:{bucket:init.bucket,object:init.object,callback:init.callback},parts:[]};
    if(Math.ceil(file.size/state.partSize)>10000)throw connectorError("请增大分片，单文件最多 10000 片");
    if(Number(init.status)===2){state.result=init;state.complete=true;}
    else{
      const ticket=await ossTicket(ctx,mode);
      if(file.size===0){const r=await ossRequest(ctx,ticket,state.remote,"PUT",{},{ossHeaders:callbacks(state.remote),range:{offset:0,length:0}});state.result=ensureOK(losslessJSON(r.body));state.complete=true;}
      else{const r=await ossRequest(ctx,ticket,state.remote,"POST",{sequential:"1",uploads:"1"});state.uploadId=/<UploadId>([A-Za-z0-9._-]+)<\/UploadId>/.exec(r.body)?.[1];if(!state.uploadId)throw connectorError("OSS 上传 ID 缺失","upstream");}
    }
  }else{
    if(!state||state.v!==1||state.mode!==mode||state.account!==account)throw connectorError("上传状态与账号不匹配");
    if(operation==="completed")return Boolean(state.complete);
    if(operation==="succeeded")return Boolean(state.complete&&state.result&&!failed(state.result));
    if(operation==="result")return state.result??null;
    if(!state.complete){
      const ticket=await ossTicket(ctx,mode);
      if(operation==="list"||operation==="step"||operation==="complete"){
        const remote=await listUploadParts(ctx,ticket,state),known=new Map(state.parts.map(p=>[p.number,p]));
        for(const part of remote){const old=known.get(part.number);part.verified=Boolean(old?.verified&&old.etag.toLowerCase().replaceAll('"','')===part.etag.toLowerCase().replaceAll('"',''));}
        state.parts=remote;
      }
      if(operation==="list"){const start=bounded(a.part_number_start??1,1,10000)-1,limit=bounded(a.limit??100,1,500);return {parts:state.parts.slice(start,start+limit),next_part_number:start+limit<state.parts.length?start+limit+1:null,state:await saveCheckpoint(ctx,"p115-upload",state)};}
      if(operation==="step"){
        const file=await ctx.fs.sourceInfo();if(file.size!==state.size||file.stamp!==state.stamp)throw connectorError("续传源文件发生变化","conflict");
        for(const part of state.parts)if(!part.verified){
          if(ctx.remaining()<2500)break;
          if(part.size>16777216)break;
          const md5=await ctx.fs.hashRange("@source",(part.number-1)*state.partSize,part.size,"md5");
          if(md5.toLowerCase()!==part.etag.replaceAll('"','').toLowerCase())throw connectorError("服务器分片与源文件摘要不符","conflict");part.verified=true;
        }
        // An interrupted PUT may exist remotely without a locally acknowledged
        // ETag. Rewrite the unverified suffix from the unchanged delegated source.
        const uncertain=state.parts.findIndex(p=>!p.verified);if(uncertain>=0)state.parts=state.parts.slice(0,uncertain);
        let offset=state.parts.reduce((n,p)=>n+p.size,0),count=0;
        while(offset<state.size&&ctx.remaining()>2500&&count++<bounded(a.parts_per_call??1,1,16)){
          const number=state.parts.length+1,length=Math.min(state.partSize,state.size-offset),r=await ossRequest(ctx,ticket,state.remote,"PUT",{partNumber:number,uploadId:state.uploadId},{range:{offset,length}});
          if(!/^"?[a-fA-F0-9]{32}"?$/.test(r.etag??""))throw connectorError("OSS 分片 ETag 无效","upstream");
          state.parts.push({number,size:length,etag:r.etag,verified:true});offset+=length;
        }
      }
      if(operation==="complete"){
        if(state.parts.some(p=>!p.verified)||state.parts.reduce((n,p)=>n+p.size,0)!==state.size)throw connectorError("分片尚未全部上传或校验，请先调用 multipart-step","conflict");
        const body="<CompleteMultipartUpload>"+state.parts.map(p=>"<Part><PartNumber>"+p.number+"</PartNumber><ETag>"+p.etag+"</ETag></Part>").join("")+"</CompleteMultipartUpload>";
        const r=await ossRequest(ctx,ticket,state.remote,"POST",{uploadId:state.uploadId},{body,type:"text/xml",ossHeaders:callbacks(state.remote)});state.result=ensureOK(losslessJSON(r.body));state.complete=true;
      }
      if(operation==="url"||operation==="urls"){
        const first=bounded(a.part_number??a.part_number_start??1,1,10000),items=[];
        for(let number=first;number<first+(operation==="url"?1:bounded(a.limit??10,1,100));number++)items.push(await uploadPartURL(ctx,ticket,state,number));
        return operation==="url"?items[0]:pageResult(items,{part_number_start:first+items.length});
      }
    }
  }
  return {state:await saveCheckpoint(ctx,"p115-upload",state),pickcode:state.pickcode,size:state.size,uploaded:state.complete?state.size:state.parts.reduce((n,p)=>n+p.size,0),complete:Boolean(state.complete),readyToComplete:state.parts.reduce((n,p)=>n+p.size,0)===state.size,result:state.result??null};
}
async function listUploadParts(ctx,ticket,state){
  const parts=[];let marker=0;
  do{
    const r=await ossRequest(ctx,ticket,state.remote,"GET",{uploadId:state.uploadId,"max-parts":1000,...(marker?{"part-number-marker":marker}:{})});
    for(const m of r.body.matchAll(/<Part>([\s\S]*?)<\/Part>/g)){
      const number=Number(/<PartNumber>(\d+)<\/PartNumber>/.exec(m[1])?.[1]),size=Number(/<Size>(\d+)<\/Size>/.exec(m[1])?.[1]),etag=/<ETag>(["\w-]+)<\/ETag>/.exec(m[1])?.[1];
      if(number!==parts.length+1||!Number.isSafeInteger(size)||size!==Math.min(state.partSize,state.size-(number-1)*state.partSize)||!/^"?[a-fA-F0-9]{32}"?$/.test(etag??""))throw connectorError("服务器分片与源文件计划不一致","conflict");
      parts.push({number,size,etag});
    }
    if(!/<IsTruncated>true<\/IsTruncated>/.test(r.body))break;
    const next=Number(/<NextPartNumberMarker>(\d+)<\/NextPartNumberMarker>/.exec(r.body)?.[1]);if(next<=marker||parts.length>10000)throw connectorError("OSS 分片游标无效","upstream");marker=next;
  }while(true);return parts;
}
async function uploadPartURL(ctx,ticket,state,number){
  const query={partNumber:number,uploadId:state.uploadId},qs=form(query),date=new Date().toUTCString();
  const signature=base64(bytes(await ctx.crypto.hmacSHA1(ticket.secret,["PUT","","",date,"x-oss-security-token:"+ticket.token,"/"+state.remote.bucket+"/"+state.remote.object+"?"+qs].join("\n"))));
  return {method:"PUT",url:"https://fhnfile.oss-cn-shenzhen.aliyuncs.com/"+state.remote.object+"?"+qs,headers:{date,"x-oss-security-token":ticket.token,authorization:"OSS "+ticket.key+":"+signature},part_number:number,offset:(number-1)*state.partSize,length:Math.max(0,Math.min(state.partSize,state.size-(number-1)*state.partSize))};
}
async function transferInit(ctx,a){
  const entry=a.entry??await resolveEntry(ctx,a.id??a.path??0,a),pid=remoteId(a.pid??0),filename=a.name??entry.name;
  if(entry.is_dir)throw connectorError("秒传复制需要文件");
  const mode=(await ctx.connection()).kind==="bearer"?"open":"cookie",base={filename,sha1:entry.sha1,sizeBytes:Number(entry.size),remoteDir:pid,dirname:a.dirname??""};
  let challenge={};const info=mode==="cookie"?ensureOK(await do_upload_info(ctx,{})):null;
  for(let attempt=0;attempt<2;attempt++){
    const r=info?await cookieInit(ctx,base,info,challenge):ensureOK(await send(ctx,open+"/upload/init","POST",null,{file_name:filename,fileid:entry.sha1,file_size:entry.size,target:"U_1_"+pid,...challenge})).data;
    if(Number(r.status)===2)return r;
    if(Number(r.status)===7&&attempt===0){
      const m=/^(\d+)-(\d+)$/.exec(r.sign_check??"");if(!m)throw connectorError("秒传校验区间无效","upstream");
      const link=a.source_url?{url:a.source_url,headers:a.source_headers??{},size:entry.size}:await entryURL(ctx,entry,a),result=await streamDigests(ctx,link,{offset:Number(m[1]),length:Number(m[2])-Number(m[1])+1,digests:["sha1"]});
      if(!result.complete)throw connectorError("秒传挑战超出本次期限，请提供源文件续传","timeout");challenge={sign_key:r.sign_key,sign_val:result.digests.sha1.toUpperCase()};continue;
    }
    return r;
  }
}
