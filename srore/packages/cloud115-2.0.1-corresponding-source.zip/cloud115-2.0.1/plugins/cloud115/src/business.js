// Protocol reference: p115client 856e4f8 and its p115cipher upload wire format.
const web = "https://webapi.115.com";
const open = "https://proapi.115.com/open";
const version = "36.2.28";
const userAgent =
  "Mozilla/5.0 115disk/" +
  version +
  " 115Browser/" +
  version +
  " 115wangpan_android/" +
  version;
const aesKey = "fb1a19d652f5aaf7bc651d0f69bf422f";
const aesIV = "69bf422f49960550a0ad44ec3446cb4c";

function quote(value) {
  return encodeURIComponent(String(value))
    .replace(
      /[!'()*]/g,
      (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase(),
    )
    .replace(/%20/g, "+");
}
function form(fields) {
  return Object.keys(fields)
    .sort()
    .map((k) => quote(k) + "=" + quote(fields[k]))
    .join("&");
}
function parseReply(body) {
  try {
    const value = losslessJSON(body);
    if (value && typeof value === "object" && !Array.isArray(value))
      return value;
  } catch {}
  throw Error("115 响应格式无效");
}
function request(ctx, url, opts = {}) {
  const reply = ctx.http.request({ url, credential: true, ...opts });
  if (reply.status === 401 || reply.status === 403)
    return { state: false, errno: reply.status };
  if (reply.status < 200 || reply.status >= 300)
    throw connectorError("115 HTTP " + reply.status, "upstream");
  if (opts.response === "hex") return reply.body;
  return parseReply(reply.body);
}
function failed(r) {
  return r.state === false || r.state === 0 || r.state === "0";
}
function code(r) {
  const n = Number(r.errno ?? r.errNo ?? r.errcode ?? r.errCode ?? r.code ?? r.msg_code ?? r.status);
  return Number.isSafeInteger(n) ? n : 0;
}
function ensureOK(r) {
  if (!r || typeof r !== "object" || Array.isArray(r)) throw connectorError("115 响应不是对象", "upstream");
  if (failed(r)) {
    const n=code(r),kind=[10014,20009,20013,20018,31001,31003,31004,50003,50015,70005,70008,90008,231011,430004,800001].includes(n)?"not_found":
      [99,911,401,403,50038,51011,990001,40140125].includes(n)?"forbidden":
      [1001,10004,20001,20002,20003,20020,20021,320001,990002].includes(n)?"invalid_input":
      n===20004?"conflict":[51012,590075].includes(n)?"busy":"upstream";
    throw Object.assign(connectorError("115 拒绝请求（"+n+"）",kind),{upstreamCode:n});
  }
  return r;
}

function hexByte(v) {
  return (v & 255).toString(16).padStart(2, "0");
}
function bytes(hex) {
  return (hex.match(/../g) || []).map((n) => parseInt(n, 16));
}
function little(n) {
  return [n, n >>> 8, n >>> 16, n >>> 24].map(hexByte).join("");
}
function base64(data) {
  const alphabet =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let out = "";
  for (let i = 0; i < data.length; i += 3) {
    const v = (data[i] << 16) | ((data[i + 1] || 0) << 8) | (data[i + 2] || 0);
    out +=
      alphabet[(v >> 18) & 63] +
      alphabet[(v >> 12) & 63] +
      (i + 1 < data.length ? alphabet[(v >> 6) & 63] : "=") +
      (i + 2 < data.length ? alphabet[v & 63] : "=");
  }
  return out;
}
function uploadToken(t) {
  const key = "1d030e80a178dceececda377de128d8ed9ddcf55ae61ed46ea121a1cfc81";
  const packed =
    key.slice(0, 30) + "0073000000" + little(t) + key.slice(30) + "0001000000";
  let crc = -1;
  for (const b of [
    ...Array.from("^j>WD3Kr?J2gLFjD4W2y@", (c) => c.charCodeAt(0)),
    ...bytes(packed),
  ]) {
    crc ^= b;
    for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  return base64(bytes(packed + little(~crc)));
}
// The CDNs return independently compressed LZ4 blocks, each with a 16-bit length.
function uploadReply(hex) {
  const src = bytes(hex),
    plain = [];
  const pad = src[src.length - 1];
  if (pad > 0 && pad < 16 && src.slice(-pad).every((v) => v === pad))
    src.length -= pad;
  const invalid = () => {
    throw Error("秒传响应压缩格式无效");
  };
  for (let pos = 0; pos + 2 <= src.length; ) {
    const size = src[pos] | (src[pos + 1] << 8);
    pos += 2;
    if (!size) break;
    const end = pos + size,
      start = plain.length;
    if (end > src.length) invalid();
    function length(n) {
      if (n === 15) {
        let k;
        do {
          if (pos >= end) invalid();
          k = src[pos++];
          n += k;
        } while (k === 255);
      }
      return n;
    }
    while (pos < end) {
      const token = src[pos++],
        literal = length(token >> 4);
      if (pos + literal > end || plain.length - start + literal > 8192)
        invalid();
      for (let i = 0; i < literal; i++) plain.push(src[pos++]);
      if (pos === end) break;
      if (pos + 2 > end) invalid();
      const distance = src[pos] | (src[pos + 1] << 8);
      pos += 2;
      const count = 4 + length(token & 15);
      if (
        !distance ||
        distance > plain.length - start ||
        plain.length - start + count > 8192
      )
        invalid();
      for (let i = 0; i < count; i++)
        plain.push(plain[plain.length - distance]);
    }
    if (plain.length > 262144) invalid();
  }
  return parseReply(
    decodeURIComponent(plain.map((v) => "%" + hexByte(v)).join("")),
  );
}
function cookieInit(ctx, input, info, challenge) {
  const id = String(info.user_id),
    fileid = input.sha1.toUpperCase(),
    target = "U_1_" + input.remoteDir;
  const t = Math.floor(Date.now() / 1000),
    sha = (s) => ctx.crypto.digest("sha1", s),
    md5 = (s) => ctx.crypto.digest("md5", s);
  const signKey = challenge.sign_key || "",
    signVal = challenge.sign_val || "";
  const sig = sha(
    info.userkey + sha(id + fileid + target + "0") + "000000",
  ).toUpperCase();
  const token = md5(
    "Qclm8MGWUv59TnrR0XPg" +
      fileid +
      input.sizeBytes +
      signKey +
      signVal +
      id +
      t +
      md5(id) +
      version,
  );
  const fields = {
    appversion: version,
    fileid,
    filename: input.filename,
    target,
    topupload: "true",
    userid: id,
    userkey: info.userkey,
    t,
    sig,
    token,
  };
  if (input.sizeBytes) fields.filesize = input.sizeBytes;
  if (input.dirname) fields.path = input.dirname;
  if (signKey) {
    fields.sign_key = signKey;
    fields.sign_val = signVal;
  }
  const ascii = form(fields),
    n = (16 - (ascii.length % 16)) % 16;
  const padded =
    Array.from(ascii, (c) => hexByte(c.charCodeAt(0))).join("") +
    hexByte(n).repeat(n);
  const reply = request(
    ctx,
    "https://uplb.115.com/4.0/initupload.php?k_ec=" + quote(uploadToken(t)),
    {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": userAgent,
      },
      bodyHex: ctx.crypto.aesCBC("encrypt", aesKey, aesIV, padded),
      response: "hex",
    },
  );
  if (typeof reply !== "string") return reply;
  return uploadReply(ctx.crypto.aesCBC("decrypt", aesKey, aesIV, reply));
}
function instant(ctx, input) {
  const connection=ctx.connection();
  if(typeof input.filename!=="string"||!input.filename||!Number.isSafeInteger(input.sizeBytes)||input.sizeBytes<0||!/^[a-fA-F0-9]{40}$/.test(input.sha1??""))throw Error("需要文件名、字节数和 SHA-1");
  input={...input, remoteDir:remoteId(input.remoteDir??"0"), mode:connection.kind==="cookie"?"cookie":"open",hasSource:connection.hasSource};
  let info;
  if (input.mode === "cookie") {
    info = request(ctx, web + "/files/uploadinfo");
    if (failed(info))
      return { outcome: "rejected", reason: "115 错误 " + code(info) };
    if (!info.userkey || !/^\d+$/.test(String(info.user_id)))
      throw Error("上传账号信息无效");
  }
  const challenge = {};
  for (let attempt = 0; attempt < 2; attempt++) {
    let r;
    if (info) r = cookieInit(ctx, input, info, challenge);
    else {
      const result = request(ctx, open + "/upload/init", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: form({
          file_name: input.filename,
          fileid: input.sha1.toUpperCase(),
          file_size: input.sizeBytes,
          target: "U_1_" + input.remoteDir,
          path: input.dirname ?? "",
          topupload: 1,
          ...challenge,
        }),
      });
      r = failed(result) ? result : result.data;
    }
    if (!r) throw Error("秒传响应无效");
    if (failed(r))
      return { outcome: "rejected", reason: "115 错误 " + code(r) };
    if (r.status === 2 || r.status === 1)
      return {
        outcome: r.status === 2 ? "reused" : "not_reused",
        data: r,
      };
    if (r.status !== 7) throw Error("秒传状态未确认");
    if (!input.hasSource) return { outcome: "needs_source" };
    const m = /^(?:bytes=)?(\d+)-(\d+)$/.exec(r.sign_check);
    if (attempt !== 0 || !m || !r.sign_key) throw Error("秒传区间挑战无效");
    const start = Number(m[1]),
      end = Number(m[2]);
    if (
      !Number.isSafeInteger(start) ||
      !Number.isSafeInteger(end) ||
      end < start
    )
      throw Error("秒传校验区间无效");
    challenge.sign_key = r.sign_key;
    challenge.sign_val = ctx.fs
      .hashRange("@source", start, end - start + 1, "sha1")
      .toUpperCase();
  }
}
