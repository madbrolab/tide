// JavaScript port of p115pickcode 0.0.5 by ChenyangGao, GPL-3.0.
// Corresponding source and complete license are included with this plugin.
const pickAlphabet="0123456789abcdefghijklmnopqrstuvwxyz";
const pickTables={a:"fuln1ytpj3smg8d5a094qh7cxkbi62zvewro",b:"sk721n9a0emlfpcrzbqdw3gjh6ty5xui48vo",c:"ywcz3hite6f1j0guoakvdb2ns7p8qr9ml5x4",d:"rq2vl5o7wsken9u8tp4jg3zbyc6xmhifd01a",e:"ljm9eqbcfhw7ktv3x1dgp5ua8y6s4znr2io0",fa:"fumk0ytpj3sng8d5a194qh7cxlbi62zvewro",fb:"sk732o9a1enmfpcrzbqdw4gjh6ty5xui08vl",fc:"ywcz6hite9f4j3gup2kvdb5osal0qr1nm8x7",fd:"on6vl0r2wpkeq9u3ts8jg7zbyc1xmhifd45a",fe:"ljm0es2cfhwakqv6x4dgp8r1by9u7znt5io3"};
function pickPrefix(value){return value.startsWith("f")?value.slice(0,2):value[0];}
function pickTranslate(value,prefix,reverse=false){const table=pickTables[prefix];if(!table)throw connectorError("提取码前缀无效");const from=reverse?pickAlphabet:table,to=reverse?table:pickAlphabet;return Array.from(value,c=>{const pos=from.indexOf(c);if(pos<0)throw connectorError("提取码字符无效");return to[pos];}).join("");}
function pickStable(value){
  value=String(value);if(value.length<4)return value.padStart(4,"0");
  const prefix=pickPrefix(value),known=pickTables[prefix]&&value.length>=prefix.length+4;
  if(!known&&value.at(-4)==="0")return value.slice(-4);
  const p=known?prefix:Object.keys(pickTables).find(k=>pickTranslate("0",k)===value.at(-4));
  return pickTranslate(value.slice(-4),p,true);
}
function pickToId(value){
  if(value===0||value==="")return "0";
  if(typeof value==="number"||/^\d+$/.test(value))return remoteId(value);
  const prefix=pickPrefix(value),plain=pickTranslate(value.slice(prefix.length,-4),prefix,true);
  if(!plain)throw connectorError("提取码中没有文件 ID");let n=0n;for(const c of plain)n=n*36n+BigInt(pickAlphabet.indexOf(c));return n.toString();
}
function idToPick(value,stable="0000",prefix="a"){
  if(typeof value==="string"&&/^[a-f]/.test(value)){pickToId(value);return value;}
  const id=BigInt(remoteId(value));if(!id)return "";
  const p=prefix||(pickTables[pickPrefix(stable)]&&stable.length>4?pickPrefix(stable):Object.keys(pickTables).find(k=>pickTranslate("0",k)===stable.at(-4))??"a");
  return p+pickTranslate(id.toString(36)+pickStable(stable),p);
}
async function accountStable(ctx,a){
  if(a.stable_point)return pickStable(a.stable_point);
  if(a.pickcode)return pickStable(a.pickcode);
  const page=await directoryPage(ctx,{id:0,limit:1});if(page.items[0]?.pickcode)return pickStable(page.items[0].pickcode);
  throw connectorError("账号没有可用提取码，请传入 stable_point","not_found");
}
