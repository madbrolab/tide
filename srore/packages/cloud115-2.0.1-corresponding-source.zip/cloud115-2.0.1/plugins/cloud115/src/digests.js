// Incremental digests for binary ranges. State consists only of small JSON
// arrays and counters, so a deadline can suspend and resume a large-file hash.
const sha256K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
const md5K=Array.from({length:64},(_,i)=>Math.floor(Math.abs(Math.sin(i+1))*4294967296)|0);
function rotate32(x,n){return (x<<n)|(x>>>(32-n));}
function newDigest(alg){
  if(!["sha1","sha256","md5","md4"].includes(alg))throw connectorError("不支持的摘要算法 "+alg);
  return {alg,total:0,tail:[],h:alg==="sha256"?[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]:[0x67452301,0xefcdab89,0x98badcfe,0x10325476,...(alg==="sha1"?[0xc3d2e1f0]:[])]};
}
function digestBlock(s,data,start){
  const w=new Int32Array(80),big=s.alg.startsWith("sha");
  for(let i=0;i<16;i++){
    const p=start+i*4;
    w[i]=big?(data[p]<<24)|(data[p+1]<<16)|(data[p+2]<<8)|data[p+3]:data[p]|(data[p+1]<<8)|(data[p+2]<<16)|(data[p+3]<<24);
  }
  let [a,b,c,d,e,f,g,h]=s.h;
  if(s.alg==="sha1"){
    for(let i=16;i<80;i++)w[i]=rotate32(w[i-3]^w[i-8]^w[i-14]^w[i-16],1);
    for(let i=0;i<80;i++){
      const group=Math.floor(i/20),fn=group===0?(b&c)|(~b&d):group===2?(b&c)|(b&d)|(c&d):b^c^d;
      const t=(rotate32(a,5)+fn+e+[0x5a827999,0x6ed9eba1,0x8f1bbcdc,0xca62c1d6][group]+w[i])|0;
      e=d;d=c;c=rotate32(b,30);b=a;a=t;
    }
  }else if(s.alg==="sha256"){
    for(let i=16;i<64;i++){
      const x=w[i-15],y=w[i-2];
      w[i]=(w[i-16]+(rotate32(x,25)^rotate32(x,14)^(x>>>3))+w[i-7]+(rotate32(y,15)^rotate32(y,13)^(y>>>10)))|0;
    }
    for(let i=0;i<64;i++){
      const t1=(h+(rotate32(e,26)^rotate32(e,21)^rotate32(e,7))+((e&f)^(~e&g))+sha256K[i]+w[i])|0;
      const t2=((rotate32(a,30)^rotate32(a,19)^rotate32(a,10))+((a&b)^(a&c)^(b&c)))|0;
      h=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;
    }
  }else if(s.alg==="md5"){
    for(let i=0;i<64;i++){
      const round=i>>>4,fn=round===0?(b&c)|(~b&d):round===1?(d&b)|(~d&c):round===2?b^c^d:c^(b|~d);
      const k=round===0?i:round===1?(5*i+1)%16:round===2?(3*i+5)%16:7*i%16;
      const shift=[[7,12,17,22],[5,9,14,20],[4,11,16,23],[6,10,15,21]][round][i%4];
      const t=(b+rotate32((a+fn+md5K[i]+w[k])|0,shift))|0;a=d;d=c;c=b;b=t;
    }
  }else{
    for(let i=0;i<48;i++){
      const round=Math.floor(i/16),j=i%16,k=round===0?j:round===1?(j%4)*4+(j>>>2):[0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15][j];
      const fn=round===0?(b&c)|(~b&d):round===1?(b&c)|(b&d)|(c&d):b^c^d;
      const shift=[[3,7,11,19],[3,5,9,13],[3,9,11,15]][round][i%4];
      const t=rotate32((a+fn+w[k]+[0,0x5a827999,0x6ed9eba1][round])|0,shift);a=d;d=c;c=b;b=t;
    }
  }
  const result=[a,b,c,d,e,f,g,h];s.h=s.h.map((v,i)=>(v+result[i])|0);
}
function digestUpdate(s,input){
  s.total+=input.length;let index=0;
  if(s.tail.length){const count=Math.min(64-s.tail.length,input.length);s.tail.push(...input.slice(0,count));index=count;if(s.tail.length===64){digestBlock(s,s.tail,0);s.tail=[];}}
  while(index+64<=input.length){digestBlock(s,input,index);index+=64;}
  if(index<input.length)s.tail.push(...input.slice(index));return s;
}
function digestEnd(state){
  const s=JSON.parse(JSON.stringify(state)),big=s.alg.startsWith("sha"),pad=[...s.tail,128];
  while(pad.length%64!==56)pad.push(0);
  const bits=BigInt(s.total)*8n,length=Array.from({length:8},(_,i)=>Number(bits>>BigInt(i*8)&255n));
  pad.push(...(big?length.reverse():length));for(let i=0;i<pad.length;i+=64)digestBlock(s,pad,i);
  return s.h.map(v=>Array.from({length:4},(_,i)=>hexByte(v>>>(big?24-i*8:i*8))).join("")).join("");
}
async function streamDigests(ctx,link,a){
  const offset=bounded(a.offset??0,0,Number.MAX_SAFE_INTEGER),length=bounded(a.length,0,Number.MAX_SAFE_INTEGER-offset);
  const algorithms=a.digests??["sha1"],cursor=a.cursor;
  if(!Array.isArray(algorithms)||!algorithms.length||algorithms.length>4)throw connectorError("摘要算法列表无效");
  const state=cursor?JSON.parse(JSON.stringify(cursor)):{offset,length,done:0,states:algorithms.map(newDigest)};
  if(state.offset!==offset||state.length!==length||state.states.map(s=>s.alg).join()!==algorithms.join()||state.done<0||state.done>length)throw connectorError("摘要游标与文件范围不一致");
  let calls=0;
  while(state.done<length&&ctx.remaining()>1500&&calls++<32){
    const start=offset+state.done,count=Math.min(262144,length-state.done);
    const r=await ctx.net.request({url:link.url,headers:{...link.headers,Range:"bytes="+start+"-"+(start+count-1)},responseType:"bytes",maxBytes:count,followRedirects:true});
    if(r.status!==206&&!(r.status===200&&start===0&&Number(link.size)===count))throw connectorError("上游没有返回摘要所需范围","upstream");
    if(r.body.length!==count)throw connectorError("摘要读取长度错误","upstream");
    for(const s of state.states)digestUpdate(s,r.body);state.done+=count;
  }
  return {bytes:state.done,complete:state.done===length,cursor:state.done===length?null:state,digests:state.done===length?Object.fromEntries(state.states.map(s=>[s.alg,digestEnd(s)])):null};
}
