// SDK 2 implementations for upstream operations requiring multiple requests,
// repeated form fields, binary decoding or an explicit login continuation.
async function shareDownloadAppRaw(ctx,a){
  const payload={...a.payload,...(a.shareUrl?shareFields(a.shareUrl):{})},r=await send(ctx,"https://proapi.115.com/app/share/downurl","POST",null,{data:rsaEncode(JSON.stringify(payload))});
  if(!failed(r)&&r.data)r.data=losslessJSON(rsaDecode(r.data));return r;
}
async function extendedResume(ctx, a, mode) {
  const key = mode === "open" ? "pick_code" : "pickcode";
  const p = typeof a.payload === "string" ? {[key]: a.payload} : {...a.payload};
  p[key] ??= p[mode === "open" ? "pickcode" : "pick_code"];
  const callback = p.callback_var ?? p.callback?.callback_var;
  if (callback) {
    const c = typeof callback === "string" ? losslessJSON(callback) : callback;
    p[key] = c["x:pick_code"]; p.target = c["x:target"];
    if (mode === "cookie") p.userid = c["x:user_id"];
  }
  delete p.callback; delete p.callback_var;
  p.fileid ??= "0".repeat(40);
  p[mode === "open" ? "file_size" : "filesize"] ??= 1;
  p.target ??= "U_1_0";
  if (mode === "cookie") p.userid ??= await remoteUser(ctx, a);
  return await send(ctx, mode === "open" ? open + "/upload/resume" : "https://uplb.115.com/3.0/resumeupload.php", "POST", null, p);
}
async function extendedUploadInit(ctx, a) {
  const p = {appid:0,target:"U_1_0",sign_key:"",sign_val:"",topupload:"true",appversion:version,...a.payload};
  if (!p.userid || !p.userkey) {
    const info = ensureOK(await do_upload_info(ctx, {}));
    p.userid ??= info.user_id; p.userkey ??= info.userkey;
  }
  p.t = Math.floor(Date.now() / 1000);
  p.sig = (await ctx.crypto.digest("sha1", p.userkey + await ctx.crypto.digest("sha1", String(p.userid)+p.fileid+p.target+"0") + "000000")).toUpperCase();
  p.token = await ctx.crypto.digest("md5", "Qclm8MGWUv59TnrR0XPg" + p.fileid + p.filesize + p.sign_key + p.sign_val + p.userid + p.t + await ctx.crypto.digest("md5",String(p.userid)) + p.appversion);
  const text = form(Object.fromEntries(Object.entries(p).filter(([,v]) => truth(v))));
  const pad = (16-utf8Bytes(text).length%16)%16;
  const encrypted = await ctx.crypto.aesCBC("encrypt",aesKey,aesIV,utf8Bytes(text).map(hexByte).join("")+hexByte(pad).repeat(pad));
  const r = await request(ctx,"https://uplb.115.com/4.0/initupload.php?k_ec="+quote(uploadToken(p.t)),{
    method:"POST",bodyHex:encrypted,response:"hex",headers:{"Content-Type":"application/x-www-form-urlencoded","User-Agent":"Mozilla/5.0 115disk/"+p.appversion+" 115Browser/"+p.appversion+" 115wangpan_android/"+p.appversion}
  });
  return typeof r === "string" ? uploadReply(await ctx.crypto.aesCBC("decrypt",aesKey,aesIV,r)) : r;
}
function expandedForm(value, prefix, indexed=true, out=[]) {
  for (const [key, item] of Object.entries(value)) {
    const name = prefix && !key.startsWith(prefix+"[") ? prefix+"["+key+"]" : key;
    if (Array.isArray(item)) item.forEach((v,i) => {
      const k = name+"["+(indexed?i:"")+"]";
      if (v && typeof v === "object") expandedForm(v,k,indexed,out); else out.push([k,v]);
    });
    else if (item && typeof item === "object") expandedForm(item,name,indexed,out);
    else out.push([name,item]);
  }
  return out;
}
async function extendedDiary(ctx,a,edit) {
  const p = typeof a.payload === "string" ? [["form[content]",a.payload]] : expandedForm(a.payload,"form");
  if (!edit && !p.some(([k])=>k==="form[user_time]")) p.push(["form[user_time]",Math.floor(Date.now()/1000)]);
  return await send(ctx,"https://life.115.com/api/1.0/"+platform(a,"web",false)+"/1.0/diary/"+(edit?"edit":"add"),"POST",null,p);
}
async function extendedLabels(ctx,a,app) {
  const p = typeof a.payload === "string" ? [["name[]",a.payload]] : Array.isArray(a.payload) ? a.payload.map(v=>Array.isArray(v)?v:["name[]",v]) : a.payload;
  return await send(ctx,app?"https://proapi.115.com/"+platform(a,"android",true)+"/label/add_multi":web+"/label/add_multi","POST",null,p);
}
async function extendedVideo(ctx,a) {
  const p = typeof a.payload === "string" ? {pickcode:a.payload} : {...a.payload};
  p.user_id = await remoteUser(ctx,a);
  const r = await send(ctx,"https://proapi.115.com/"+platform(a,"android",true)+"/2.0/video/play","POST",null,{data:rsaEncode(JSON.stringify(p))});
  if ((!failed(r)||Number(r.errno)===409) && r.data) r.data=losslessJSON(rsaDecode(r.data));
  return r;
}
async function extendedExtractLink(ctx,a) {
  if(typeof a.pickcode!=="string"||typeof a.path!=="string")throw connectorError("需要压缩包提取码和文件路径");
  const path=a.path.replace(/\/+$/,""),app=a.app??"android";
  const r=ensureOK(await webLink(ctx,{app,userAgent:a.user_agent,payload:{pick_code:a.pickcode,full_name:path.replace(/^\/+/,"")}},["web","desktop"].includes(app)?"extract-web":"extract-app"));
  if(typeof r.data?.url!=="string")throw connectorError("文件不存在、是目录或者不支持下载","not_found");
  const url=encodeURI(r.data.url).replace(/[!'()*;,@+$]/g,c=>"%"+c.charCodeAt(0).toString(16).toUpperCase()).replaceAll("%25","%");
  return {url,name:path.slice(path.lastIndexOf("/")+1),path,headers:r.headers};
}
async function extendedExtract(ctx,a) {
  const dirname=String(a.dirname??"").replace(/^\/+|\/+$/g,"");
  const files=typeof a.files==="string"?[a.files]:a.files??[];
  const dirs=typeof a.dirs==="string"?[a.dirs]:a.dirs??[];
  const p=[["pick_code",a.pickcode],["paths",dirname?"文件/"+dirname:"文件"],["to_pid",a.to_pid??"0"]];
  let items=[...files.filter(Boolean).map(name=>({name,dir:false})),...dirs.filter(Boolean).map(name=>({name,dir:true}))];
  if (!items.length) {
    let marker="";const seen=new Set();
    do {
      const r=ensureOK(await archiveList(ctx,{pickcode:a.pickcode,path:dirname,nextMarker:marker,app:a.app}));
      items.push(...r.data.list.map(n=>({name:n.file_name,dir:!Number(n.file_category)})));
      marker=r.data.next_marker??"";
      if(marker && seen.has(marker))throw connectorError("压缩包分页未前进","upstream");
      seen.add(marker);
      if(items.length>10000)throw connectorError("请按 files/dirs 分批解压","conflict");
    }while(marker);
  }
  p.push(...items.map(n=>[n.dir?"extract_dir[]":"extract_file[]",n.name.replace(/^\/+|\/+$/g,"")]));
  return await send(ctx,["","web","desktop","aps"].includes(a.app??"web")?web+"/files/add_extract_file":"https://proapi.115.com/"+platform(a,"android",true)+"/2.0/ufile/add_extract_file","POST",null,p);
}
async function extendedImageUpload(ctx,a,chat) {
  const target=/^[US]_/.test(a.pid??"")?a.pid:a.share_id?"S_"+a.share_id+"_"+(a.pid??0):a.pid!==undefined?"U_1_"+a.pid:chat?"U_3_-1":"U_4_-1";
  const p={filename:a.filename??"1.jpg",path:a.dirname??"",target};
  const ticket=ensureOK(await (chat?do_upload_chat_image_init:do_upload_image_init)(ctx,{payload:p}));
  const fields={key:ticket.object,policy:ticket.policy,OSSAccessKeyId:ticket.accessid,signature:ticket.signature,callback:ticket.callback,...(chat?{host:ticket.host}:{name:p.filename,success_action_status:"200"})};
  const r=await ctx.http.request({url:ticket.host.replace(/^http:/,"https:"),method:"POST",multipart:{filename:p.filename,field:"file",fields}});
  if(r.status!==200)throw connectorError("图片上传结果需核对，HTTP "+r.status,"upstream");
  return {...losslessJSON(r.body),oss_info:ticket};
}
async function extendedLoginDevice(ctx) {
  const r=await do_login_devices(ctx,{});
  return failed(r)?null:r.data?.list?.find(d=>Number(d.is_current)===1)??null;
}
async function extendedLoginAuto(ctx,a,openMode,infoOnly=false) {
  const token=ensureOK(await (openMode?do_common_login_qrcode_token_open(ctx,{payload:{client_id:a.app_id??100195125}}):do_common_login_qrcode_token(ctx,{}))).data;
  const uid=token.uid;
  const scan=ensureOK(await do_common_login_qrcode_scan(ctx,{payload:{uid}}));
  if(infoOnly)return {app_id:a.app_id??100195125,name:String(scan.data.tip_txt??"").replace(/^\uFEFF/,"").slice(0,-10),icon:scan.data.icon};
  ensureOK(await do_common_login_qrcode_scan_confirm(ctx,{payload:{uid}}));
  if(a.uidOnly)return uid;
  return openMode?await do_common_login_qrcode_access_token_open(ctx,{payload:{uid}}):await qrLoginResult(ctx,{uid,app:a.app??(await extendedLoginDevice(ctx))?.icon??"alipaymini",loginExchange:false});
}
async function extendedQR(ctx,a,openMode) {
  if(!a.session){
    const r=ensureOK(await (openMode?do_common_login_qrcode_token_open(ctx,{payload:{client_id:a.app_id??100195125}}):do_common_login_qrcode_token(ctx,{})));
    return {stage:"scan",session:r.data,qrcode:r.data.qrcode??"https://115.com/scan/dg-"+r.data.uid};
  }
  const status=ensureOK(await qrSnapshot(ctx,a.session)).data?.status;
  if(status===-1||status===-2)return {stage:status===-1?"expired":"cancelled",session:a.session};
  if(status!==2)return {stage:status===1?"confirm":"scan",session:a.session};
  const result=await(openMode?do_common_login_qrcode_access_token_open(ctx,{payload:{uid:a.session.uid}}):qrLoginResult(ctx,{uid:a.session.uid,app:a.app??"alipaymini"}));
  return {stage:"complete",result:ensureOK(result)};
}
