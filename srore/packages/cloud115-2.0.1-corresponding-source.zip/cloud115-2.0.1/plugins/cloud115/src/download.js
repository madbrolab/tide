// 115's private download protocol uses a 1024-bit RSA public operation in both directions.
const modulus =
  0x8686980c0f5a24c4b9d43020cd2c22703ff3f450756529058b1cf88f09b8602136477198a6e2683149659bd122c33592fdb5ad47944ad1ea4d36c6b172aad6338c3bb6ac6227502d010993ac967d1aef00f0c8e038de2e4d3bc2ec368af2e9f10a6f1eda4f7262f136420c07c331b871bf139f74f3010e3c4fe57df3afb71683n;
const mixTable = bytes(
  "f0e569aebfdcbf8a1a45e8be7da673b8de8fe7c445da86c49b648b146ab4f1aa3801359e26692c86006b4fa5363462a62a966818f24afdbd6b978f4d8f8913b76c8e93ed0e0d483ed72f88d8fefe7e8650954fd1eb832634db667b9c7e9d7a8132eab633de3aa95934663baaba816048b9d5819cf86c8477ff5478265fbee81e369f34805c452c9b76d51b8fccc3b8f5",
);
function xorStream(o, key) {
  const prefix = o.length % 4;
  return o.map((b, i) => b ^ key[(i < prefix ? i : i - prefix) % key.length]);
}
function publicBlock(chunk) {
  const x = BigInt("0x" + chunk.map(hexByte).join(""));
  let y = x;
  for (let i = 0; i < 16; i++) y = (y * y) % modulus;
  return bytes(((y * x) % modulus).toString(16).padStart(256, "0"));
}
function from64(s) {
  const alphabet =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  if (
    typeof s !== "string" ||
    !s.length ||
    s.length % 4 !== 0 ||
    !/^[A-Za-z0-9+/]+={0,2}$/.test(s)
  )
    throw Error("115 密文编码无效");
  const out = [];
  for (let i = 0; i < s.length; i += 4) {
    const n =
      (alphabet.indexOf(s[i]) << 18) |
      (alphabet.indexOf(s[i + 1]) << 12) |
      (Math.max(0, alphabet.indexOf(s[i + 2])) << 6) |
      Math.max(0, alphabet.indexOf(s[i + 3]));
    out.push(n >> 16);
    if (s[i + 2] !== "=") out.push((n >> 8) & 255);
    if (s[i + 3] !== "=") out.push(n & 255);
  }
  return out;
}
function utf8Bytes(text) {
  const out = [];
  for (const c of encodeURIComponent(text).match(/%[0-9A-F]{2}|./g) || [])
    out.push(c.length === 3 ? parseInt(c.slice(1), 16) : c.charCodeAt(0));
  return out;
}
function rsaEncode(text) {
  const masked = xorStream(utf8Bytes(text), [141, 165, 165, 141]).reverse();
  const msg = Array(16)
    .fill(0)
    .concat(
      xorStream(masked, [120, 6, 173, 76, 51, 134, 93, 24, 76, 1, 63, 70]),
    );
  const cipher = [];
  for (let i = 0; i < msg.length; i += 117) {
    const block = msg.slice(i, i + 117);
    cipher.push(
      ...publicBlock([0, ...Array(126 - block.length).fill(2), 0, ...block]),
    );
  }
  return base64(cipher);
}
function rsaDecode(s) {
  const cipher = from64(s),
    msg = [];
  if (cipher.length % 128 || cipher.length > 128 * 512)
    throw Error("115 密文分块无效");
  for (let i = 0; i < cipher.length; i += 128) {
    const block = publicBlock(cipher.slice(i, i + 128));
    let first = 0;
    while (first < 128 && block[first] === 0) first++;
    const sep = block.indexOf(0, first);
    if (sep < 0) throw Error("115 响应填充无效");
    msg.push(...block.slice(sep + 1));
  }
  if (msg.length < 16) throw Error("115 响应缺少密钥前缀");
  const key = Array.from(
    { length: 12 },
    (_, i) => ((msg[i] + mixTable[i * 12]) & 255) ^ mixTable[(11 - i) * 12],
  );
  const plain = xorStream(
    xorStream(msg.slice(16), key).reverse(),
    [141, 165, 165, 141],
  );
  return decodeURIComponent(plain.map((v) => "%" + hexByte(v)).join(""));
}
function downloadInfo(ctx, args, mode) {
  const pc = args.pickcode;
  if (
    typeof pc !== "string" ||
    !/^[a-z0-9]+(?:,[a-z0-9]+){0,63}$/.test(pc) ||
    pc.length > 2000
  )
    throw Error("提取码无效");
  const ua = args.userAgent ?? ctx.connection().userAgent ?? "";
  if (typeof ua !== "string" || ua.length > 512 || /[\r\n]/.test(ua))
    throw Error("User-Agent 无效");
  let url, fields;
  if (mode === "open") {
    url = open + "/ufile/downurl";
    fields = { pick_code: pc };
  } else {
    const id = args.userId ?? ensureOK(do_upload_info(ctx, {})).user_id;
    fields = {
      data: rsaEncode(
        JSON.stringify({
          pickcode: pc,
          ...(args.shareId ? { share_id: args.shareId } : {}),
          user_id: pyUID(id),
        }),
      ),
    };
    url = "https://proapi.115.com/app/chrome/downurl";
  }
  const r = ctx.http.request({
    url,
    method: "POST",
    credential: true,
    originReferer: true,
    headers: {
      "User-Agent": ua,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: wireForm(fields),
  });
  if (r.status !== 200) throw Error("115 HTTP " + r.status);
  const v = losslessJSON(r.body);
  if (mode === "cookie" && !failed(v) && v.data)
    v.data = losslessJSON(rsaDecode(v.data));
  v.headers = { "user-agent": ua };
  return v;
}
function pyUID(id) {
  const s = remoteId(id),
    n = Number(s);
  if (!Number.isSafeInteger(n)) throw Error("账号 ID 超出范围");
  return n;
}
function downloadLinks(ctx, args, mode, single) {
  const r = ensureOK(downloadInfo(ctx, args, mode)),
    data = r.data;
  if (!data || typeof data !== "object" || Array.isArray(data))
    throw Error("下载链接响应无效");
  const items = [];
  for (const [id, entry] of Object.entries(data)) {
    const link = entry.url?.url ?? "";
    if (link && !/^https?:\/\//i.test(link)) throw Error("下载链接协议无效");
    if (!link && args.strict !== false && single) throw Error("所选项目是目录");
    items.push({
      id: remoteId(id),
      pickcode: entry.pick_code,
      name: entry.file_name,
      size: entry.file_size,
      sha1: entry.sha1 ?? "",
      is_dir: !link,
      url: link,
      headers: r.headers,
    });
  }
  if (single && items.length !== 1)
    throw Error("单文件动作需要恰好一个下载结果");
  return single ? items[0] : items;
}
function sampleInit(ctx, args) {
  const name = args.filename;
  if (
    typeof name !== "string" ||
    !name ||
    name.length > 255 ||
    /[/\\\r\n\x00]/.test(name)
  )
    throw Error("需要有效文件名");
  return ensureOK(
    send(ctx, "https://uplb.115.com/3.0/sampleinitupload.php", "POST", null, {
      filename: name,
      path: args.dirname ?? "",
      target: "U_1_" + remoteId(args.pid ?? "0"),
    }),
  );
}
function sampleUpload(ctx, args) {
  const ticket = sampleInit(ctx, args);
  const fields = {
    name: args.filename,
    key: ticket.object,
    policy: ticket.policy,
    OSSAccessKeyId: ticket.accessid,
    success_action_status: "200",
    callback: ticket.callback,
    signature: ticket.signature,
  };
  if (Object.values(fields).some((v) => typeof v !== "string" || !v))
    throw Error("115 上传票据缺少必要字段");
  const uploadHost = String(ticket.host).replace(/^http:\/\//, "https://");
  const reply = ctx.http.request({
    method: "POST",
    url: uploadHost,
    multipart: { filename: args.filename, fields },
  });
  if (reply.status !== 200)
    throw Error("OSS 上传结果需核对，HTTP " + reply.status);
  return ensureOK(losslessJSON(reply.body));
}
function contentView(ctx, args, mode, view) {
  const link = downloadLinks(ctx, args, mode, true);
  const size = Number(link.size),
    start = bounded(args.offset ?? 0, 0, size);
  if (!Number.isSafeInteger(size)) throw Error("文件长度超出安全整数范围");
  const hashMode = view === "hash";
  const length = bounded(
    args.length ?? (hashMode ? size - start : Math.min(65536, size - start)),
    0,
    hashMode ? size - start : Math.min(65536, size - start),
  );
  const req = {
    url: link.url.replace(/^http:\/\//i, "https://"),
    userAgent: link.headers["user-agent"],
    offset: start,
    length,
  };
  if (hashMode) req.digests = args.digests ?? ["sha1"];
  if (hashMode && (!Array.isArray(req.digests) || !req.digests.length))
    throw Error("至少选择一个摘要算法");
  const r = ctx.http.readContent(req);
  if (hashMode) return r;
  const result = {
    ...r,
    nextOffset: start + length < size ? start + length : null,
  };
  if (view === "text") {
    // Independently decodable UTF-8 blocks; callers can use raw bytes across arbitrary character boundaries.
    const data = r.base64 ? from64(r.base64) : [];
    result.text = decodeURIComponent(
      data.map((v) => "%" + hexByte(v)).join(""),
    );
    delete result.base64;
  }
  return result;
}
function webLink(ctx, args, mode) {
  const ua = args.userAgent ?? ctx.connection().userAgent ?? "",
    headers = { "User-Agent": ua },
    input = { ...(args.payload ?? {}) };
  const req = {
    method: "GET",
    headers,
    linkMeta: true,
    credential: true,
    originReferer: true,
  };
  if (mode === "redirect") {
    req.url =
      "https://115.com/?ct=download&ac=video&" +
      wireForm({ pickcode: args.pickcode, app_ver: version });
  } else if (mode === "team") {
    req.url = web + "/usershare/download";
    req.method = "POST";
    req.body = wireForm({ share_id: args.shareId, pick_code: args.pickcode });
  } else if (mode === "extract-app" || mode === "extract-web") {
    const url =
      mode === "extract-app"
        ? "https://proapi.115.com/" +
          platform(args, "android", true) +
          "/2.0/ufile/extract_down_file"
        : web + "/files/extract_down_file";
    req.url =
      url +
      "?" +
      wireForm({
        ...protocolArgs({ payload: input }, [], true),
        app_ver: version,
      });
  } else {
    const payload = { pickcode: args.pickcode };
    req.method = args.method ?? "POST";
    req.url = web + "/files/download";
    if (req.method === "POST")
      req.body = wireForm({ data: rsaEncode(JSON.stringify(payload)) });
    else if (req.method === "GET")
      req.url += "?" + wireForm({ ...payload, app_ver: version });
    else throw Error("仅允许 GET 或 POST");
  }
  if (req.method === "POST")
    headers["Content-Type"] = "application/x-www-form-urlencoded";
  const r = ctx.http.request(req),
    downloadHeaders = { "user-agent": ua };
  if (r.mediaCookie) downloadHeaders.cookie = r.mediaCookie;
  if (mode === "redirect")
    return r.status === 302 && r.location
      ? { state: true, url: r.location, headers: downloadHeaders }
      : { state: false, errno: 31003, response: { status: r.status } };
  if (r.status !== 200) throw Error("获取下载链接 HTTP " + r.status);
  const result = losslessJSON(r.body);
  if (
    mode === "file" &&
    req.method === "POST" &&
    !failed(result) &&
    result.data
  )
    result.data = losslessJSON(rsaDecode(result.data));
  return { ...result, headers: downloadHeaders };
}

function shareDirect(ctx,a,mode){
  const payload={...a.payload,...(a.shareUrl?shareFields(a.shareUrl):{})};
  const app=a.app===""?"":platform(a,mode==="regular"?"android":"chrome",false);
  let response;
  if(mode==="regular"){
    if(app==="web"||app==="desktop")response=do_share_download_url_web(ctx,{payload});
    else if(app===""||app==="chrome"){
      response=send(ctx,"https://proapi.115.com/app/share/downurl","POST",null,{data:rsaEncode(JSON.stringify(payload))});
      if(!failed(response)&&response.data)response.data=losslessJSON(rsaDecode(response.data));
    }else{
      const osApp=["windows","mac","linux","os_windows","os_mac","os_linux"].includes(app)?platform(a,"android",true):"os_windows";
      response=send(ctx,"https://proapi.115.com/"+osApp+"/2.0/share/downurl","GET",payload,null);
    }
  }else if(mode==="web"||(mode==="skip"&&["web","desktop"].includes(app))){
    response=sendPublic(ctx,web+"/share/skip_login_downurl","POST",null,payload);
  }else{
    const encrypted=app==="chrome"||app==="";
    response=sendPublic(ctx,encrypted?"https://proapi.115.com/app/share/skip_login_downurl":"https://proapi.115.com/"+platform(a,"chrome",true)+"/2.0/share/skip_login_downurl","POST",null,encrypted?{data:rsaEncode(JSON.stringify(payload))}:payload);
    if(encrypted&&!failed(response)&&response.data)response.data=losslessJSON(rsaDecode(response.data));
  }
  if(mode==="app"||mode==="web")return response;
  const data=ensureOK(response).data;if(!data)throw Error("分享文件不存在");
  if(!data.url&&a.strict!==false)throw Error("所选项目是目录");
  return {url:data.url?.url||"",id:String(data.fid),name:data.fn,size:data.fs,sha1:data.sha1||"",is_dir:!data.url};
}
function archiveList(ctx,a){
  const payload={pick_code:a.pickcode,file_name:(a.path||"").replace(/^\/+|\/+$/g,""),paths:"文件",next_marker:a.nextMarker||"",page_count:Number.isInteger(a.pageCount)&&a.pageCount>=1&&a.pageCount<=999?a.pageCount:999};
  return ["","web","desktop","aps"].includes(a.app??"web")?do_extract_info(ctx,{payload}):do_extract_info_app(ctx,{payload,app:a.app});
}
function uploadPicture(ctx,a,avatar){
  const app=platform(a,"web",false);
  const url=avatar?"https://ictxl.115.com/app/1.1/"+app+"/1.2/upload/set_avatar":"https://credentials.115.com/api/1.0/"+app+"/1.0/credentials/upload_images";
  const r=ctx.http.request({url,method:"POST",credential:true,multipart:{filename:"a.jpg",field:avatar?"file":"image"}});
  if(r.status!==200)throw Error("115 HTTP "+r.status);return losslessJSON(r.body);
}
function captchaVerify(ctx,a){
  const p={ac:"security_code",type:"web",ctype:"web",client:"web",...a.payload};
  if(!Object.hasOwn(p,"sign"))p.sign=do_captcha_sign(ctx,{}).sign;
  return send(ctx,web+"/user/captcha","POST",null,p);
}
