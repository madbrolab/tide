// Each caller chooses an index name. Cloud IDs are TEXT, never SQLite numbers
// marshalled through a JavaScript double. All values use bound SQL parameters.
function indexKey(a){if(typeof a.index!=="string"||!a.index||a.index.length>128)throw connectorError("需要 index（每个账号使用不同索引名）");return a.index;}
function dbEntry(row){if(!row)return row;const raw=row.extra?losslessJSON(row.extra):{};return {...raw,...row,is_dir:Boolean(row.is_dir),is_alive:Boolean(row.is_alive),extra:raw};}
async function indexAttr(ctx,index,id){
  id=remoteId(id);if(id==="0")return {...rootEntry(),is_alive:true};
  const rows=await ctx.db.query("SELECT * FROM nodes WHERE index_key=? AND id=? LIMIT 1",[index,id]);
  if(!rows.length)throw connectorError("索引中不存在该文件","not_found");return dbEntry(rows[0]);
}
async function indexAncestors(ctx,index,id){
  const result=[],seen=new Set();let node=await indexAttr(ctx,index,id);
  while(true){if(seen.has(node.id))throw connectorError("索引中存在父目录循环","conflict");seen.add(node.id);result.unshift(node);if(node.id==="0")return result;node=await indexAttr(ctx,index,node.parent_id);if(result.length>1024)throw connectorError("索引目录层级过深","conflict");}
}
async function indexPathIds(ctx,index,a){
  const parts=pathTokens(a.path??""),alive=a.is_alive===false?"":" AND is_alive=1";let parent=String(a.parent_id??0);
  if(!parts.length)return [parent];
  for(let i=0;i<parts.length;i++){
    if(parts[i].name===".."&&!parts[i].quoted){parent=(await indexAttr(ctx,index,parent)).parent_id;if(i===parts.length-1)return [parent];continue;}
    const final=i===parts.length-1,filter=final?(a.ensure_file===undefined?"":a.ensure_file?" AND is_dir=0":" AND is_dir=1"):" AND is_dir=1";
    const rows=await ctx.db.query("SELECT id FROM nodes WHERE index_key=? AND parent_id=? AND name=?"+alive+filter+" ORDER BY is_dir DESC,id LIMIT 200",[index,parent,parts[i].name]);
    if(!rows.length)return [];if(final)return rows.map(r=>r.id);parent=rows[0].id;
  }
}
async function indexQuery(ctx,a,operation){
  const index=indexKey(a),id=remoteId(a.id??a.parent_id??0),alive=a.is_alive===false?"":" AND is_alive=1";
  if(operation==="get_attr")return await indexAttr(ctx,index,id);
  if(["get_ancestors","get_path","get_patht"].includes(operation)){
    const list=await indexAncestors(ctx,index,id);return operation==="get_ancestors"?list:operation==="get_patht"?list.map(n=>n.name):"/"+list.slice(1).map(n=>escapeName(n.name)).join("/");
  }
  if(operation==="has_id"||operation==="is_alive"){
    if(id==="0")return true;const rows=await ctx.db.query("SELECT is_alive FROM nodes WHERE index_key=? AND id=?"+(operation==="has_id"?alive:"")+" LIMIT 1",[index,id]);return operation==="has_id"?Boolean(rows.length):rows.length?Boolean(rows[0].is_alive):true;
  }
  if(operation==="get_parent_id")return (await indexAttr(ctx,index,id)).parent_id;
  if(["get_id","path_to_id","get_pickcode","get_sha1"].includes(operation)){
    let node;
    if(a.id!==undefined&&operation!=="path_to_id")node=await indexAttr(ctx,index,a.id);
    else if(a.pickcode||a.sha1){const field=a.pickcode?"pickcode":"sha1",rows=await ctx.db.query("SELECT * FROM nodes WHERE index_key=? AND "+field+"=?"+alive+" LIMIT 1",[index,a[field]]);node=dbEntry(rows[0]);}
    else{const ids=await indexPathIds(ctx,index,a);if(ids.length)node=await indexAttr(ctx,index,ids[0]);}
    if(!node)throw connectorError("索引查询没有结果","not_found");return operation==="get_pickcode"?node.pickcode:operation==="get_sha1"?node.sha1:node.id;
  }
  if(operation==="get_count_tree")return await indexCountTree(ctx,index,id,a.cursor);
  if(operation==="iter_descendants"||operation==="iter_descendants_bfs")return await indexTreePage(ctx,index,id,a);
  if(operation==="iter_dangling_ids"||operation==="select_na_ids")return await indexDangling(ctx,index,a,operation==="select_na_ids");
  if(operation==="iter_count_dir"||operation==="iter_count_tree")return await indexCountPage(ctx,index,id,a,operation==="iter_count_tree");
  if(operation==="iter_id_to_parent_id"&&a.recursive)return await indexParentPairs(ctx,index,a);
  const offset=bounded(a.cursor?.offset??a.offset??0,0,Number.MAX_SAFE_INTEGER),limit=bounded(a.limit??100,1,199);let sql,params=[],project=r=>dbEntry(r);
  if(operation==="iter_id_to_path"){
    const ids=await indexPathIds(ctx,index,a);return pageResult(ids.slice(offset,offset+limit),offset+limit<ids.length?{offset:offset+limit}:null);
  }
  if(operation==="iter_children"){
    sql="SELECT * FROM nodes WHERE index_key=? AND parent_id=?"+alive+(a.ensure_file===undefined?"":a.ensure_file?" AND is_dir=0":" AND is_dir=1");params=[index,id];
  }else if(operation==="iter_dup_files"){
    sql="SELECT n.*,(SELECT COUNT(*) FROM nodes d WHERE d.index_key=n.index_key AND d.sha1=n.sha1 AND d.size=n.size AND d.is_dir=0 AND d.is_alive=1) AS total,(SELECT COUNT(*) FROM nodes d WHERE d.index_key=n.index_key AND d.sha1=n.sha1 AND d.size=n.size AND d.is_dir=0 AND d.is_alive=1 AND d.id<=n.id) AS nth FROM nodes n WHERE n.index_key=? AND n.is_dir=0 AND n.is_alive=1 AND total>1";params=[index];
  }else if(operation==="iter_dangling_parent_ids"){
    sql="SELECT DISTINCT n.parent_id AS id FROM nodes n LEFT JOIN nodes p ON n.index_key=p.index_key AND n.parent_id=p.id WHERE n.index_key=? AND n.parent_id!='0' AND p.id IS NULL";params=[index];project=r=>r.id;
  }else if(["iter_existing_id","iter_id_to_parent_id","iter_parent_id"].includes(operation)){
    const ids=idsArray(a.ids??[]);if(ids.length>1000)throw connectorError("每次最多查询 1000 个 ID");
    const marks=ids.map(()=>"?").join(",")||"NULL";
    sql="SELECT * FROM nodes WHERE index_key=? AND id IN ("+marks+")"+(operation==="iter_existing_id"?alive:"");params=[index,...ids];
    project=operation==="iter_existing_id"?r=>r.id:operation==="iter_parent_id"?r=>r.parent_id:r=>[r.id,r.parent_id];
  }else throw connectorError("未知索引查询");
  const rows=await ctx.db.query(sql+" ORDER BY "+(operation==="iter_descendants_bfs"?"depth,":"")+"id LIMIT ? OFFSET ?",[...params,limit+1,offset]),items=[];
  for(const row of rows.slice(0,limit)){
    let entry=project(row);
    if(operation==="iter_children"&&Array.isArray(a.fields)&&a.fields.length)entry=Object.fromEntries(a.fields.map(k=>[k,entry[k]??null]));
    items.push(entry);
  }
  return pageResult(items,rows.length>limit?{offset:offset+limit}:null);
}
function checkedCursor(cursor){if(utf8Bytes(JSON.stringify(cursor)).length>150000)throw connectorError("索引游标过大，请分目录查询","conflict");return cursor;}
async function indexTreePage(ctx,index,id,a){
  const limit=bounded(a.limit??100,1,199),max=a.max_depth??-1,min=a.min_depth??1;
  if(max>=0&&max<min)return pageResult([],null);
  const queue=JSON.parse(JSON.stringify(a.cursor?.queue??[{id,depth:0,after:"",parents:[id]}])),items=[];
  while(queue.length&&items.length<limit&&ctx.remaining()>1500){
    const parent=queue[0],size=Math.min(100,limit-items.length),rows=await ctx.db.query("SELECT * FROM nodes WHERE index_key=? AND parent_id=? AND is_alive=1 AND id>? ORDER BY id LIMIT ?",[index,parent.id,parent.after,size]);
    for(const row of rows){
      parent.after=row.id;const depth=parent.depth+1;
      if(parent.parents.includes(row.id))throw connectorError("索引中存在父目录循环","conflict");
      if(row.is_dir&&(max<0||depth<max))queue.push({id:row.id,depth,after:"",parents:[...parent.parents,row.id]});
      if(depth<min||a.ensure_file!==undefined&&Boolean(row.is_dir)===a.ensure_file)continue;
      let entry=dbEntry(row);
      if(a.fields!==false){const ancestors=await indexAncestors(ctx,index,row.id);entry.depth=depth;entry.ancestors=ancestors.map(n=>({id:n.id,parent_id:n.parent_id,name:n.name}));entry.path="/"+ancestors.slice(1).map(n=>escapeName(n.name)).join("/");entry.relpath=ancestors.slice(ancestors.findIndex(n=>n.id===id)+1).map(n=>escapeName(n.name)).join("/");}
      if(typeof a.fields==="string")entry=entry[a.fields]??null;else if(Array.isArray(a.fields)&&a.fields.length)entry=Object.fromEntries(a.fields.map(k=>[k,entry[k]??null]));items.push(entry);
    }
    if(rows.length<size)queue.shift();
  }
  return pageResult(items,queue.length?checkedCursor({queue}):null);
}
async function indexCountTree(ctx,index,id,cursor){
  const state=cursor?JSON.parse(JSON.stringify(cursor)):{queue:[id],seen:[],dir_count:0,file_count:0};
  let calls=0;
  while(state.queue.length&&ctx.remaining()>1500&&calls++<100){
    const current=state.queue[0];if(!state.after){if(state.seen.includes(current))throw connectorError("索引中存在父目录循环","conflict");state.seen.push(current);const r=(await ctx.db.query("SELECT COALESCE(SUM(is_dir),0) AS dirs,COALESCE(SUM(1-is_dir),0) AS files FROM nodes WHERE index_key=? AND parent_id=? AND is_alive=1",[index,current]))[0];state.dir_count+=Number(r.dirs);state.file_count+=Number(r.files);}
    const rows=await ctx.db.query("SELECT id FROM nodes WHERE index_key=? AND parent_id=? AND is_dir=1 AND is_alive=1 AND id>? ORDER BY id LIMIT 199",[index,current,state.after??""]);
    state.queue.push(...rows.map(r=>r.id));if(rows.length===199)state.after=rows.at(-1).id;else{state.queue.shift();delete state.after;}
  }
  return {dir_count:state.dir_count,file_count:state.file_count,complete:!state.queue.length,cursor:state.queue.length?checkedCursor(state):null};
}
async function indexCountPage(ctx,index,id,a,recursive){
  const state=JSON.parse(JSON.stringify(a.cursor??{tree:null,root:id!=="0"?id:null,pending:[]})),items=[],limit=bounded(a.limit??50,1,100);
  if(state.root){state.pending.push({id:state.root});state.root=null;}
  while(items.length<limit&&ctx.remaining()>1500){
    if(!state.pending.length){if(state.finished)break;const page=await indexTreePage(ctx,index,id,{cursor:state.tree,ensure_file:false,limit:Math.min(limit-items.length,50),fields:false});state.tree=page.cursor;state.finished=page.complete;state.pending.push(...page.items);if(!state.pending.length)break;}
    const dir=state.pending[0],counts=(await ctx.db.query("SELECT COALESCE(SUM(is_dir),0) AS dir_count,COALESCE(SUM(1-is_dir),0) AS file_count FROM nodes WHERE index_key=? AND parent_id=? AND is_alive=1",[index,dir.id]))[0];
    if(Number(counts.dir_count)+Number(counts.file_count)){
      const row={id:dir.id,parent_id:(await indexAttr(ctx,index,dir.id)).parent_id,...counts};
      if(recursive){const result=await indexCountTree(ctx,index,dir.id,state.count);if(!result.complete){state.count=result.cursor;break;}row.tree_dir_count=result.dir_count;row.tree_file_count=result.file_count;delete state.count;}items.push(row);
    }state.pending.shift();
  }
  return pageResult(items,state.finished&&!state.pending.length?null:checkedCursor(state));
}
async function indexDangling(ctx,index,a,onlyAlive){
  const rows=await ctx.db.query("SELECT id,parent_id,is_alive FROM nodes WHERE index_key=? AND id>?"+(onlyAlive?" AND is_alive=1":"")+" ORDER BY id LIMIT ?",[index,a.cursor?.after??"",bounded(a.limit??100,1,199)]),items=[];let after=a.cursor?.after??"",processed=0;
  for(const row of rows){if(ctx.remaining()<1500)break;let node=row;const seen=new Set();while(node.parent_id!=="0"){
    if(seen.has(node.id))throw connectorError("索引中存在父目录循环","conflict");seen.add(node.id);
    const parents=await ctx.db.query("SELECT id,parent_id,is_alive FROM nodes WHERE index_key=? AND id=? LIMIT 1",[index,node.parent_id]);
    if(!parents.length){items.push(row.id);break;}node=parents[0];if(onlyAlive&&!node.is_alive)break;
  }after=row.id;processed++;}
  return pageResult(items,rows.length&& (processed<rows.length||rows.length===(a.limit??100))?{after}:null);
}
async function indexParentPairs(ctx,index,a){
  const state=JSON.parse(JSON.stringify(a.cursor??{queue:idsArray(a.ids??[]),seen:[]})),items=[],limit=bounded(a.limit??100,1,199);
  while(state.queue.length&&items.length<limit&&ctx.remaining()>1500){const id=state.queue.shift();if(id==="0"||state.seen.includes(id))continue;state.seen.push(id);let row;try{row=await indexAttr(ctx,index,id);}catch(e){if(e.code==="not_found")continue;throw e;}items.push([row.id,row.parent_id]);state.queue.push(row.parent_id);}
  return pageResult(items,state.queue.length?checkedCursor(state):null);
}
async function indexUpsert(ctx,index,entry,generation){
  const e=entry.id!==undefined?entry:normalizeEntry(entry);
  await ctx.db.exec("INSERT INTO nodes(index_key,id,parent_id,name,sha1,size,pickcode,mtime,is_dir,is_alive,generation,extra) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(index_key,id) DO UPDATE SET parent_id=excluded.parent_id,name=excluded.name,sha1=excluded.sha1,size=excluded.size,pickcode=excluded.pickcode,mtime=excluded.mtime,is_dir=excluded.is_dir,is_alive=excluded.is_alive,generation=excluded.generation,extra=excluded.extra",[index,String(e.id),String(e.parent_id??0),e.name??"",e.sha1??"",String(e.size??0),e.pickcode??"",Number(e.mtime??0),Number(Boolean(e.is_dir)),e.is_alive===false?0:1,generation,JSON.stringify(e)]);
}
async function indexUpdate(ctx,a,mode){
  const index=indexKey(a);
  if(mode==="init")return {index,ready:true};
  if(mode==="events"){
    const page=await collectionPage(ctx,a,"life");
    for(const event of page.items){
      const id=String(event.file_id);let old={};try{old=await indexAttr(ctx,index,id);}catch(e){if(e.code!=="not_found")throw e;}
      const entry={...old,id,parent_id:String(event.parent_id??old.parent_id??0),name:event.file_name??old.name??"",sha1:event.sha1??old.sha1??"",size:event.file_size??old.size??0,mtime:Number(event.update_time??0),is_alive:Number(event.type)!==22};entry.is_dir=!entry.sha1;
      await indexUpsert(ctx,index,entry,"event");await ctx.db.exec("INSERT OR IGNORE INTO cloud_events(index_key,event_id,data) VALUES(?,?,?)",[index,String(event.id),JSON.stringify(event)]);
    }
    return page;
  }
  if(mode==="import"){
    const entries=a.entries??[];if(entries.length>200)throw connectorError("每次导入最多 200 个条目");for(const e of entries)await indexUpsert(ctx,index,e,"import");return {count:entries.length};
  }
  const state=a.cursor?JSON.parse(JSON.stringify(a.cursor)):{queue:[{id:remoteId(a.cid??0),offset:0}],generation:ctx.runId,processed:0};
  if(!Array.isArray(state.queue)||state.queue.length>20000)throw connectorError("索引同步游标无效");
  let rounds=0;
  while(state.queue.length&&ctx.remaining()>2000&&rounds++<(a.pages??1)){
    const node=state.queue[0],page=await directoryPage(ctx,{id:node.id,offset:node.offset,limit:Math.min(a.limit??100,200)});
    for(const entry of page.items){await indexUpsert(ctx,index,entry,state.generation);if(entry.is_dir&&a.recursive!==false)state.queue.push({id:entry.id,offset:0});state.processed++;}
    if(page.next===null){
      if(!a.only_alive)await ctx.db.exec("UPDATE nodes SET is_alive=0 WHERE index_key=? AND parent_id=? AND generation!=?",[index,node.id,state.generation]);state.queue.shift();
    }else node.offset=page.next;
  }
  return {index,processed:state.processed,complete:!state.queue.length,cursor:state.queue.length?state:null};
}
