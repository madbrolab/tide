function splitURL(value){const m=/^(https?):\/\/([^/?#]+)([^?#]*)(?:\?([^#]*))?(?:#(.*))?$/.exec(value);if(!m)throw connectorError("URL 格式无效");return {scheme:m[1],host:m[2],path:m[3]||"/",query:m[4]??"",hash:m[5]??""};}
function queryObject(text){const out={};for(const field of text.split("&")){if(!field)continue;const[k,...v]=field.split("=");out[decodeURIComponent(k.replaceAll("+"," "))]=decodeURIComponent(v.join("=").replaceAll("+"," "));}return out;}
function joinURL(u){return u.scheme+"://"+u.host+u.path+(u.query?"?"+u.query:"")+(u.hash?"#"+u.hash:"");}
function supportURL(a){
  let path=String(a.path??""),app=a.app??"",base=a.base_url??"",domain=a.domain??"";
  if(!path.startsWith("/"))path="/"+path;if(a.version)path="/"+a.version+path;
  let query=typeof a.query==="string"?a.query:wireForm(a.query??{});
  if(/^https?:\/\/[fn]\.115\.com\/api\/proxy\/115/.test(base))return base+(base.includes("?")?"":"?")+(domain?"&domain="+domain:"")+"&path="+path+(query?"?"+query:"");
  let force=Array.isArray(a.force_app)?a.force_app.includes(app):a.force_app;if(app.startsWith("=")){force=true;app=app.slice(1);}
  if(!base)base=app||path.startsWith("/open/")?"https://proapi.115.com":domain?(domain==="web.api"||domain==="pro.api"?"http://":"https://")+domain+".115.com":"https://webapi.115.com";
  if(["windows","mac","linux"].includes(app))app="os_"+app;
  if(app&&!path.startsWith("/open/")){
    if(!force&&!["ios","115ios","115ipad","android","115android","harmony","os_windows","os_mac","os_linux"].includes(app))app=app.endsWith("ios")?"ios":app.endsWith("ipad")?"115ipad":"android";
    path="/"+app+path;
  }
  if(typeof a.query==="string")query=wireForm(queryPairs(a.query));
  path=path.replace(/[?#]/g,c=>c==="?"?"%3F":"%23");return base+path+(query?(base.includes("?")?"&":"?")+query:"");
}
function queryPairs(text){return text.split("&").filter(v=>v.includes("=")&&v.slice(v.indexOf("=")+1)).map(v=>{const i=v.indexOf("=");return [v.slice(0,i),v.slice(i+1)].map(s=>decodeURIComponent(s.replaceAll("+"," ")));});}
function imageURL(value,operation,a={}){
  const u=splitURL(value),q=queryObject(u.query),thumb=["thumb.115.com","thumbapi.115.com"].includes(u.host);
  if(operation==="reduce"){
    if(!thumb)return value;const [sha1,size]=u.path.split("/").at(-1).split("_");return "https://imgjump.115.com/?sha1="+sha1+"&size="+(a.size!==undefined&&a.size!==""?a.size:size||"0")+"&"+u.query;
  }
  if(operation==="cdn"){
    const prefix=u.host==="115.com"?"site":/^([^.]+)\.115\.com$/.exec(u.host)?.[1];if(!prefix||prefix==="proapi")return value;
    return joinURL({...u,host:a.host??"115cdn.com",path:"/"+prefix+u.path,query:"",hash:""});
  }
  if(Object.hasOwn(q,"x-oss-process"))delete q["x-oss-process"];
  else if(u.host==="imgjump.115.com")q.size="0";
  else if(thumb){q.sha1=u.path.split("/").at(-1).split("_")[0];q.size="0";return "https://imgjump.115.com/?"+wireForm(q);}
  else if(u.path.endsWith("/imgload"))q.i="1";else return value;
  return joinURL({...u,query:wireForm(q)});
}
async function finalImage(ctx,a){
  let url=a.url;const seen=new Set();
  for(let i=0;i<16;i++){
    if(seen.has(url))throw connectorError("图片跳转循环","upstream");seen.add(url);
    const error=/\/([1-5]\d\d)\.jpg/.exec(url);if(error)return Number(error[1]);
    const u=splitURL(url),q=queryObject(u.query);
    if(Object.hasOwn(q,"x-oss-process"))return imageURL(url,"max");
    if(["thumb.115.com","thumbapi.115.com"].includes(u.host)){url=imageURL(url,"reduce");continue;}
    if(u.host!=="imgjump.115.com"&&!u.path.endsWith("/imgload")&&q.ct!=="imgload")return url;
    const r=await ctx.net.request({url,method:"HEAD",followRedirects:false,responseType:"bytes",maxBytes:1024});
    if(r.status===404)return 404;const next=r.headers.location?.[0]??r.headers.Location?.[0];if(!next)return url;url=next;
  }
  throw connectorError("图片跳转次数过多","upstream");
}
async function supportValue(ctx,a,operation){
  const v=a.value;
  if(operation==="is_valid_id")return (typeof v==="number"&&Number.isSafeInteger(v)&&v>=0)||typeof v==="string"&&/^(0|[1-9]\d*)$/.test(v);
  if(operation==="is_valid_name")return typeof v==="string"&&!/[>/]/.test(v);
  if(operation==="is_valid_sha1")return typeof v==="string"&&/^(?:[a-f\d]{40}|[a-z2-7]{32})$/i.test(v);
  if(operation==="is_valid_pickcode"){if(v==="")return true;const prefix=typeof v==="string"?pickPrefix(v):"";return Boolean(pickTables[prefix]&&v.length>=prefix.length+5&&/^[a-z0-9]+$/.test(v)&&pickTranslate("0",prefix)===v.at(-4));}
  if(operation==="normalize_pickcode")return String(v).startsWith("f")?idToPick(pickToId(v),v):v;
  if(operation==="posix_escape_name")return String(v).replaceAll("/",a.repl??"|");
  if(operation==="unescape_115_charref")return String(v).replace(/\[\x02(\d+)\]/g,(_,n)=>String.fromCodePoint(Number(n)));
  if(operation==="determine_part_size"){const size=Number(a.size),min=a.min_part_size??10485760,count=a.max_part_count??10000;if(!Number.isSafeInteger(size)||size<0||min<=0||count<=0)throw connectorError("分片参数无效");if(size<=min)return size;let part=min;while(part<Math.ceil(size/count))part*=2;return part;}
  if(operation==="complete_url")return supportURL(a);
  if(operation==="share_extract_payload")return shareFields(v);
  if(operation==="reduce_image_url_layers")return imageURL(v,"reduce",a);
  if(operation==="max_image_quality")return imageURL(v,"max",a);
  if(operation==="to_cdn_url")return imageURL(v,"cdn",a);
  if(operation==="load_final_image")return await finalImage(ctx,{url:v});
  if(operation==="get_stable_point"||operation==="set_stable_point"||operation==="get_user_key"||operation==="set_user_key"){
    const key=(operation.endsWith("user_key")?"key:":"point:")+remoteId(a.user_id);
    if(operation.startsWith("set")){const value=operation.endsWith("user_key")?String(v):pickStable(v);await ctx.db.exec("INSERT INTO support_cache(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",[key,await ctx.secrets.seal("p115-cache",value)]);return value;}
    const rows=await ctx.db.query("SELECT value FROM support_cache WHERE key=? LIMIT 1",[key]);if(!rows.length)throw connectorError("尚未缓存该账号的数据","not_found");return await ctx.secrets.open("p115-cache",rows[0].value);
  }
  if(operation==="call_with_lock"){
    const lease=await clientLock(ctx,a);if(!lease.acquired)throw connectorError("锁正被使用","busy");
    try{return (await ctx.invoke(a.call)).data;}finally{await clientLock(ctx,{key:a.key,token:lease.token,release:true});}
  }
  throw connectorError("未知支持函数");
}
function jsonType(a){
  const value=a.value??{},operation=a.operation??"of";
  if(operation==="geturl"||operation==="url")return typeof value==="string"?value:value.url;
  if(operation==="get")return Object.hasOwn(value,a.key)?value[a.key]:a.default??null;
  if(operation==="keys")return Object.keys(value);if(operation==="values")return Object.values(value);if(operation==="items")return Object.entries(value);
  if(operation==="derive"||operation==="derive_backend")return {...value,...a.updates};
  if(operation==="UID"){const uid=String(value.UID??value);return {value:uid,user_id:uid.split("_")[0],ssoent:uid.split("_")[1]??"",mtime:uid.split("_")[2]??""};}
  if(["CID","SEID","KID"].includes(operation))return value[operation]??"";
  return value;
}
async function supportConstant(ctx,a){
  const rows=await ctx.db.query("SELECT value FROM support_constants WHERE name=? LIMIT 1",[a.name]);
  if(!rows.length)throw connectorError("常量不存在","not_found");const value=losslessJSON(rows[0].value);
  if(a.key!==undefined){if(!Object.hasOwn(value,a.key))throw connectorError("常量键不存在","not_found");return value[a.key];}return value;
}
function supportError(a,raise=false){
  if(a.url!==undefined){if(/^https?:\/\/\//.test(a.url))throw connectorError("115 返回无效下载地址","upstream");return a.url;}
  const kind=a.type??"P115OSError",code=/FileNotFound/.test(kind)?"not_found":/Authentication|Login|AccessToken|AccessError|AuthLimit/.test(kind)?"forbidden":/Busy/.test(kind)?"busy":/InvalidArgument/.test(kind)?"invalid_input":/NotSupported/.test(kind)?"unavailable":"upstream";
  const result={type:kind,code,errno:a.errno??5,message:a.message??null};if(!raise)return result;
  const error=connectorError(typeof result.message==="string"?result.message:JSON.stringify(result.message),code);error.name=kind;throw error;
}
let checkpointSerial=0;
async function saveCheckpoint(ctx,purpose,state){
  const id=ctx.runId+"-"+(++checkpointSerial),now=Date.now(),text=JSON.stringify(state),parts=[];let part="";
  if(utf8Bytes(text).length>2*1024*1024)throw connectorError("检查点过大，请缩小任务","conflict");
  for(const c of text){part+=c;if(part.length>=10000){parts.push(part);part="";}}if(part)parts.push(part);
  await ctx.db.exec("DELETE FROM checkpoints WHERE created<?",[now-30*86400000]);
  for(let i=0;i<parts.length;i++)await ctx.db.exec("INSERT INTO checkpoints(id,part,created,value) VALUES(?,?,?,?)",[id,i,now,await ctx.secrets.seal(purpose,parts[i])]);
  return await ctx.secrets.seal(purpose,JSON.stringify({checkpoint:id,parts:parts.length}));
}
async function loadCheckpoint(ctx,purpose,token){
  const ref=losslessJSON(await ctx.secrets.open(purpose,token));if(!ref.checkpoint)return ref;
  let text="";for(let i=0;i<ref.parts;i++){const row=await ctx.db.query("SELECT value FROM checkpoints WHERE id=? AND part=? LIMIT 1",[ref.checkpoint,i]);if(!row.length)throw connectorError("检查点已过期或被清除","not_found");text+=await ctx.secrets.open(purpose,row[0].value);}return losslessJSON(text);
}
