function idsArray(value){return (Array.isArray(value)?value:[value]).map(v=>remoteId(v&&typeof v==="object"?v.id??v.file_id:v));}
function indexedFields(ids,key="fid"){return Object.fromEntries(ids.map((id,i)=>[key+"["+i+"]",id]));}
function pageResult(items,next,extra={}){return {items,cursor:next,complete:next===null,...extra};}
async function collectionPage(ctx,a,kind){
  const offset=a.cursor?.offset??a.offset??0,limit=bounded(a.limit??a.page_size??100,1,1000),page=a.cursor?.page??a.page??a.page_start??1;
  let r,items,total,next;
  if(kind==="offline"||kind==="offline-restart"){
    r=ensureOK(await ((await ctx.connection()).kind==="bearer"?do_open_clouddownload_task_list:do_clouddownload_task_list)(ctx,{payload:{page,page_size:limit,stat:kind==="offline-restart"?9:a.stat??0}}));
    const data=Array.isArray(r.tasks)?r:r.data;items=data.tasks??[];total=Number(data.count??0);
    next=items.length&&page<Number(data.page_count??page)&&(a.page_stop===undefined||a.page_stop<0||page+1<a.page_stop)?{page:page+1}:null;
    if(kind==="offline-restart"){
      const results=[];for(const task of items){if(!task.available_actions?.includes("retry")){if(a.begins_with_retryable){next=null;break;}continue;}results.push({task,result:await do_clouddownload_task_restart(ctx,{payload:{info_hash:task.info_hash}})});}items=results;
    }
  }else if(kind==="wish"||kind==="wish-aid"){
    r=ensureOK(await(kind==="wish"?do_act_xys_my_desire:do_act_xys_desire_aid_list)(ctx,{payload:{page,limit,...(kind==="wish"?{type:a.type??0}:{id:a.wish_id})}}));
    items=r.data.list??[];next=items.length?{page:page+1}:null;
  }else if(kind==="history"||kind==="life"){
    const app=a.app??"web",mobile=!["","web","desktop","chrome","aps"].includes(app);
    const fn=kind==="history"?(mobile?do_fs_history_list_app:do_fs_history_list):(mobile?do_life_behavior_detail_app:do_life_behavior_detail);
    const payload={offset,limit,type:a.type??(kind==="history"?0:""),...(kind==="life"?{date:a.date??""}:{})};
    r=ensureOK(await fn(ctx,{payload,...(mobile?{app}:{})}));
    const raw=r.data.list??[],seen=new Set(a.cursor?.seen??[]);total=Number(r.data.total??r.data.count??raw.length);
    let stop=false;items=[];
    const names=kind==="history"?historyNames:behaviorNames;
    for(const event of raw){
      if(a.from_id&&BigInt(event.id)<=BigInt(a.from_id)||a.from_time&&Number(event.update_time)<a.from_time){stop=true;break;}
      const key=String(kind==="life"&&a.yield_latest!==false?event.file_id:event.id);
      if(!seen.has(key)&&!a.ignore_types?.includes(Number(event.type)))items.push({...event,event_name:names[event.type]??""});seen.add(key);
    }
    next=!stop&&raw.length&&offset+raw.length<total?{offset:offset+raw.length,seen:[...seen]}:null;
    if(next?.seen.length>10000)throw connectorError("事件去重状态过大，请缩小时间区间","conflict");
    return pageResult(items,next,{total,watermark:{from_id:items[0]?.id??a.from_id??"0",from_time:Number(items[0]?.update_time??a.from_time??0)}});
  }else if(kind==="search"||kind==="share-search"){
    const payload={cid:a.cid??a.id??0,offset,limit,search_value:a.search_value??a.name??"",...a.payload};
    if(kind==="share-search")Object.assign(payload,shareScope(a));
    delete payload.kind;
    r=ensureOK(await(kind==="search"?do_fs_search:do_share_search)(ctx,{payload}));
    const data=r.data;const raw=Array.isArray(data)?data:data?.list??[];items=raw.map(n=>normalizeEntry(n,a));total=Number(r.count??data?.count??raw.length);
    next=raw.length&&offset+raw.length<total?{offset:offset+raw.length}:null;
  }else throw connectorError("未知集合类型");
  if(a.raise_for_update&&a.cursor?.count!==undefined&&a.cursor.count!==total)throw connectorError("列表总数发生变化","conflict");
  if(next&&a.raise_for_update)next.count=total;
  return pageResult(items,next,{...(total!==undefined?{total}:{})});
}
const historyNames={0:"all",2:"offline_download",3:"browse_video",4:"upload",7:"receive",8:"move"};
const behaviorNames={1:"upload_image_file",2:"upload_file",3:"star_image",4:"star_file",5:"move_image_file",6:"move_file",7:"browse_image",8:"browse_video",9:"browse_audio",10:"browse_document",14:"receive_files",17:"new_folder",18:"copy_folder",19:"folder_label",20:"folder_rename",22:"delete_file",23:"copy_file",24:"file_rename"};
async function editBatch(ctx,a,operation){
  const ids=idsArray(a.ids??[]),offset=bounded(a.cursor?.offset??0,0,ids.length),size=bounded(a.batch_size??100,1,1000),batch=ids.slice(offset,offset+size);
  if(!batch.length)return pageResult([],null,{processed:offset});
  const payload=indexedFields(batch);let r;
  if(["copy","move","delete"].includes(operation)){
    if(operation!=="delete")payload.pid=remoteId(a.pid??0);
    r=await(operation==="copy"?do_fs_copy:operation==="move"?do_fs_move:do_fs_delete)(ctx,{payload});
  }else if(["cover","desc","label","show_play_long"].includes(operation)){
    const key={cover:"fid_cover",desc:"file_desc",label:"file_label",show_play_long:"show_play_long"}[operation];
    r=await do_fs_edit(ctx,{payload:{...indexedFields(batch),[key]:a.value??(operation==="show_play_long"?1:"")}});
  }else if(operation==="star"||operation==="top"){
    r=await(operation==="star"?do_fs_star_set:do_fs_top_set)(ctx,{payload:{file_id:batch.join(","),[operation]:Number(a.value??true)}});
  }else if(operation==="score")r=await send(ctx,web+"/files/score","POST",null,{file_id:batch.join(","),score:a.value??0});
  else if(operation==="category_shortcut")r=await do_fs_category_shortcut_set(ctx,{payload:{file_id:batch.join(","),op:a.value===false?"delete":"add"}});
  else if(operation==="hide")r=await do_fs_hide(ctx,{payload:{...payload,hidden:Number(a.hidden??true)}});
  else if(operation==="recyclebin_clean"||operation==="recyclebin_revert"){
    const fields=indexedFields(batch,"rid");
    r=await(operation==="recyclebin_clean"?do_recyclebin_clean:do_recyclebin_revert)(ctx,{payload:fields,...(operation==="recyclebin_clean"&&a.password?{password:a.password}:{})});
  }else if(operation==="batch_label"){
    const mode=a.mode??"add";if(!["add","remove","reset","replace"].includes(mode))throw connectorError("标签操作无效");
    r=await send(ctx,web+"/files/batch_label","POST",null,{...a.payload,action:mode,file_ids:batch.join(","),file_label:a.label??a.value??""});
  }else if(operation==="post_event"){
    r=await(a.type==="img"?do_life_behavior_img_post_app:do_life_behavior_doc_post_app)(ctx,{payload:indexedFields(batch,"file_id"),app:a.app??"android"});
  }else throw connectorError("不支持的批处理方法");
  ensureOK(r);const done=offset+batch.length;
  return pageResult([{ids:batch,result:r}],done<ids.length?{offset:done}:null,{processed:done});
}
async function editNames(ctx,a,directories){
  const pairs=a.pairs??[],offset=bounded(a.cursor?.offset??0,0,pairs.length),limit=bounded(a.limit??50,1,200),batch=pairs.slice(offset,offset+limit),items=[];
  if(directories){for(const pair of batch){const pid=Array.isArray(pair)?pair[0]:a.pid??0,name=Array.isArray(pair)?pair[1]:pair;items.push(await makeDirectories(ctx,{pid,...(a.contain_dir?{path:name}:{name})}));}}
  else{
    const payload={};for(const [id,name] of batch){if(typeof name!=="string"||!name)throw connectorError("文件名不能为空");payload["files_new_name["+remoteId(id)+"]"]=name;}
    if(batch.length)items.push(ensureOK(await do_fs_rename(ctx,{payload})));
  }
  return pageResult(items,offset+batch.length<pairs.length?{offset:offset+batch.length}:null);
}
async function attrLookup(ctx,a,operation){
  if(operation==="get_info")return ensureOK(await do_fs_category_get(ctx,{payload:{cid:remoteId(a.id??0)}}));
  if(operation==="get_file_count"||operation==="get_dir_count"){
    const r=await directoryPage(ctx,{id:a.id??0,limit:1,get_raw:true,payload:{cur:a.recursive?0:1,count_folders:1,show_dir:1}});
    return operation==="get_dir_count"?Number(r.raw.folder_count??r.raw.data?.folder_count??0):Number(r.raw.file_count??((r.raw.count??r.total)-Number(r.raw.folder_count??0)));
  }
  if(operation==="get_id_to_sha1"){
    const r=ensureOK(await do_fs_shasearch(ctx,{payload:{sha1:a.sha1}}));const id=r.data?.file_id??r.data?.fid??r.file_id;
    if(id===undefined)throw connectorError("找不到该 SHA1 对应文件","not_found");return String(id);
  }
  if(operation==="get_id_to_name"||operation==="share_get_id_to_name"){
    let cursor=null;do{const page=a.recursive?await treePage(ctx,{...a,id:a.cid??a.pid??0,cursor,filter:{name:a.name,...(a.ensure_file!==undefined?{is_dir:!a.ensure_file}:{})}}):await directoryPage(ctx,{...a,id:a.cid??a.pid??0,offset:cursor?.offset??0});
      const entry=page.items.find(n=>n.name===a.name&&(a.ensure_file===undefined||n.is_dir!==a.ensure_file));if(entry)return entry.id;
      cursor=a.recursive?page.cursor:page.next===null?null:{offset:page.next};
    }while(cursor&&ctx.remaining()>1000);
    if(cursor)throw connectorError("查找尚未完成，请缩小起始目录","busy");throw connectorError("文件名不存在","not_found");
  }
  const entry=await resolveEntry(ctx,a.path??a.id_or_path??a.id??0,a);
  if(operation==="dir_getid"&&!entry.is_dir)throw connectorError("路径不是目录","not_found");return entry.id;
}
async function selectNodes(ctx,a,mode){
  const list=a.ids??a.pickcodes??[],offset=a.cursor?.offset??0,batch=list.slice(offset,offset+bounded(a.limit??100,1,200)),items=[];
  if(mode==="skim"){
    if(batch.length)items.push(...ensureOK(await do_fs_file_skim(ctx,{method:"POST",payload:{file_id:idsArray(batch).join(",")}})).data);
  }else for(const value of batch){
    const id=typeof value==="object"?value.id:value;
    try{
      if(mode==="info")items.push(ensureOK(await do_fs_category_get(ctx,{payload:{cid:remoteId(id)}})));
      else if(mode==="supervision")items.push(ensureOK(await do_fs_supervision(ctx,{payload:{pickcode:typeof value==="object"?value.pickcode:value}})).data);
      else if(mode==="update")items.push(ensureOK(await do_fs_files_update_app(ctx,{payload:{file_id:remoteId(id)},app:a.app??"android"})).data);
      else items.push(await entryById(ctx,id));
    }catch(e){if(e.code!=="not_found")throw e;}
  }
  return pageResult(items,offset+batch.length<list.length?{offset:offset+batch.length}:null);
}
async function treeTool(ctx,a,operation){
  const scope=operation.startsWith("share_")?shareScope(a):operation.startsWith("extract_")?{kind:"zip",pickcode:a.pickcode}:a.scope;
  if(operation==="share_iterdir"||operation==="extract_iterdir"){
    const page=await directoryPage(ctx,{...a,id:a.path??a.cid??a.id??0,scope,offset:a.cursor?.offset??a.offset??0,marker:a.cursor?.marker??""});
    return pageResult(page.items,page.next===null?null:scope.kind==="zip"?{marker:page.next}:{offset:page.next});
  }
  const filter={...a.filter};if(operation.includes("files"))filter.is_dir=false;if(operation==="iter_dirs")filter.is_dir=true;
  const page=await treePage(ctx,{...a,top:a.top??a.cid??a.id??0,scope,filter});
  if(operation==="iter_3_ancestor_names"){
    const items=[];for(const n of page.items){const ancestors=await entryAncestors(ctx,n,{...a,scope});items.push({id:n.id,names:ancestors.slice(-3).map(x=>x.name)});}return {...page,items};
  }
  if(operation==="get_id_to_dirnode")return {...page,items:page.items.filter(n=>n.is_dir).map(n=>({id:n.id,name:n.name,parent_id:n.parent_id}))};
  if(operation==="iter_keyed_ids"||operation==="iter_keyed_dupfiles"){
    const groups={...(a.cursor?.groups??{})},output=[];
    for(const n of page.items){const key=a.key==="name"?n.name:a.key==="size"?String(n.size):n.sha1+":"+n.size;
      if(operation==="iter_keyed_ids")output.push({key,id:n.id});else if(groups[key])output.push({key,first:groups[key],duplicate:n});else groups[key]=n;
    }
    if(JSON.stringify(groups).length>150000)throw connectorError("去重状态过大，请使用本地索引查询重复文件","conflict");
    return {...page,items:output,cursor:page.cursor?{...page.cursor,...(operation==="iter_keyed_dupfiles"?{groups}:{})}:null};
  }
  return page;
}
function parseExportText(a){
  const state=a.cursor?JSON.parse(JSON.stringify(a.cursor)):{depth:0,line:"",pending:"",stack:[],serial:0};
  const input=(state.pending+String(a.text??"")).replace(/^\uFEFF/,""),lines=input.split("\n"),items=[];
  state.pending=a.final===false?lines.pop():"";if(a.final!==false&&lines.at(-1)==="")lines.pop();
  function emit(transition=false){
    const depth=state.depth,name=transition&&depth===0&&state.line==="根目录"?"":state.line;
    if(depth>state.stack.length)throw connectorError("目录树层级跳跃");
    const parent=depth?state.stack[depth-1]:null,id=++state.serial,path=(parent?parent.path+"/":"")+(a.escape===true?escapeName(name):a.escape===false?name.replaceAll("/","|"):name);
    const parts=[...state.stack.slice(0,depth).map(n=>n.name),name];state.stack[depth]={id,name,path};state.stack.length=depth+1;
    items.push(a.format==="depth_name"?[depth,name]:a.format==="dict"?{id,parent_id:parent?.id??0,depth,name}:a.format==="patht"?parts:path||"/");
  }
  for(const raw of lines){
    const line=raw.replace(/\r$/,"");const match=/^((?:\| )+)\|-(.*)$/.exec(line);
    if(match){emit(true);state.depth=match[1].length/2;state.line=match[2];}
    else if(!state.line&&line.startsWith("|——"))state.line=line.slice(3);
    else state.line+="\n"+line;
  }
  if(a.final!==false&&state.line)emit();
  return pageResult(items,a.final===false?state:null);
}
