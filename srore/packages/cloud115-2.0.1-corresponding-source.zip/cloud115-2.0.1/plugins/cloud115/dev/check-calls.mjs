import {readFileSync,readdirSync} from 'node:fs';
import {parse} from '@babel/parser';
const root=new URL('../',import.meta.url),ops=JSON.parse(readFileSync(new URL('operations.json',root))),issues=[];
function walk(n,file){
 if(!n||typeof n!=='object')return;if(Array.isArray(n)){for(const v of n)walk(v,file);return;}
 if(n.type==='CallExpression'&&n.callee.type==='Identifier'&&n.callee.name.startsWith('do_')&&n.arguments[1]?.type==='ObjectExpression'){
  const name=n.callee.name.slice(3).replaceAll('_','-'),fields=ops[name]?.input.properties;
  if(!fields)issues.push(file+': missing '+name);
  else for(const p of n.arguments[1].properties)if(p.type==='ObjectProperty'&&!p.computed){const key=p.key.name??p.key.value;if(!(key in fields))issues.push(`${file}:${n.loc.start.line}: ${name} rejects ${key}`);}
 }
 for(const [k,v] of Object.entries(n))if(!['loc','start','end','extra'].includes(k))walk(v,file);
}
for(const file of readdirSync(new URL('src',root)).filter(n=>n.endsWith('.js')))walk(parse(readFileSync(new URL('src/'+file,root),'utf8'),{sourceType:'module'}),file);
if(process.argv.includes('--generated'))walk(parse(readFileSync(0,'utf8'),{sourceType:'module'}),'generated wrappers');
console.log(issues.join('\n')||'All literal internal protocol calls match their action contracts');process.exitCode=issues.length?1:0;
