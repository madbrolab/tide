import json
from library_ops import FIELDS,PATH
from shapes import RAW,TEXT,NUMBER,INT,BOOL,array

def extend(reg):
    add=reg.add
    fields={'state':TEXT,'filename':TEXT,'pid':NUMBER,'sha1':TEXT,'partSize':INT,'parts_per_call':INT,'part_number':INT,'part_number_start':INT,'limit':INT,'dirname':TEXT}
    for op,refs in [('init',['tool.upload.P115MultipartUpload.from_path']),('step',['tool.upload.P115MultipartUpload.iter_upload']),('complete',['tool.upload.P115MultipartUpload.complete']),('list',['tool.upload.P115MultipartUpload.list_parts']),('url',['tool.upload.P115MultipartUpload.upload_url']),('urls',['tool.upload.P115MultipartUpload.iter_upload_url']),('completed',['tool.upload.P115MultipartUpload.completed']),('succeeded',['tool.upload.P115MultipartUpload.succeeded']),('result',['tool.upload.P115MultipartUpload.result'])]:
        add('multipart-'+op,'await uploadCheckpoint(ctx,args,'+json.dumps(op)+')',fields,refs,kind='any',file=op in ('init','step'),required=['filename'] if op=='init' else ['state'])
    add('vfs-upload','await uploadSource(ctx,{...args,pid:(await resolveEntry(ctx,args.pid??0)).id},(await ctx.connection()).kind==="bearer"?"open":"cookie")',{'filename':TEXT,'pid':PATH,'dirname':TEXT,'partSize':INT},['fs.fs.P115FileSystem.upload'],kind='any',file=True,required=['filename'])
    add('tool-upload-init','await prepareUpload(ctx,args,(await ctx.connection()).kind==="bearer"?"open":"cookie")',{'filename':TEXT,'pid':NUMBER,'sha1':TEXT,'dirname':TEXT},['tool.upload.upload_init'],kind='any',file=True,required=['filename'])
    add('tool-transfer-file','await transferInit(ctx,args)',{'entry':RAW,'id':PATH,'path':PATH,'pid':NUMBER,'name':TEXT,'source_url':TEXT,'source_headers':RAW},['tool.edit.transferfile'],kind='any')
    add('tool-upload-host-image','await extendedImageUpload(ctx,{...args,filename:"x.jpg"},false)',{},['tool.upload.upload_host_image'],file=True)
    add('tool-check-upload-existence','[2,7].includes(Number((await extendedUploadInit(ctx,{payload:{fileid:args.sha1.toUpperCase(),filesize:args.size,filename:"?"}})).status))',{'sha1':TEXT,'size':INT},['tool.upload.upload_for_check_existence'],required=['sha1','size'])
