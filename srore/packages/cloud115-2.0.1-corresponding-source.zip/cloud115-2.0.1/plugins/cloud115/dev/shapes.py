def typ(t, desc, **kw):
    return dict(type=t.split("|"), description=desc, **kw)


def obj(desc, props, required=()):
    return typ("object", desc, properties=props, required=list(required))


def array(desc, items):
    return typ("array", desc, items=items)


ID = typ("string", "十进制网盘 ID，使用字符串保存全部精度")
TEXT = typ("string", "Unicode 文本")
INT = typ("integer", "整数")
NUMBER = typ("integer|string", "整数或无损十进制字符串")
BOOL = typ("boolean", "布尔结果")
RAW = typ("object", "上游随版本变化的字段", additionalProperties=True)
