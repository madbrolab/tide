"""Deterministic public utility and pickcode comparisons against pinned sources."""
import importlib,json,random,socket,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
sys.path.insert(0,str(Path(sys.argv[1]).resolve()/'modules/p115pickcode'))
socket.create_connection=lambda *a,**kw: (_ for _ in ()).throw(RuntimeError('offline test'))
from p115client import util
exports=importlib.import_module('p115client.tool.export_dir')
import p115pickcode as pick
cases=[]
def add(action,args,result):cases.append(dict(action=action,args=args,result=result))
for app in ('','web','android','115ipad','customios','=special','windows'):
 for path in ('','/files','open/list','/name?#'):
  for query in ({'q':'电影 & x'},'x=1&empty=&x=2'):
   kw=dict(app=app,query=query)
   add('util-complete-url',dict(path=path,**kw),util.complete_url(path,**kw))
for base in ('https://f.115.com/api/proxy/115','https://n.115.com/api/proxy/115?x=1','http://web.api.115.com'):
 add('util-complete-url',dict(path='/file',base_url=base,domain='webapi',query={'x':1}),util.complete_url('/file',base_url=base,domain='webapi',query={'x':1}))
for name,values in [('is_valid_id',[0,1,-1,'0','00','01','9007199254740993','abc']),('is_valid_name',['','..','a/b','a>b','a\\b','中文']),('is_valid_sha1',['A'*40,'F'*32,'2'*32,'z'*40,''])]:
 for value in values:add('util-'+name.replace('_','-'),{'value':value},getattr(util,name)(value))
for size in [0,1,10485760,10485761,1000000000000]:add('util-determine-part-size',{'size':size},util.determine_part_size(size))
for value in ['a/b','字[\x0219970]符','[\x02128512]']:
 for name in ['unescape_115_charref','posix_escape_name']:add('util-'+name.replace('_','-'),{'value':value},getattr(util,name)(value))
for url in ['https://thumb.115.com/path/ABCD_200?k=1','https://thumbapi.115.com/ABCD?k=1','https://imgjump.115.com/?size=2&x=1','https://img.115.com/a?x-oss-process=resize&b=1','https://115.com/a?foo=bar','https://proapi.115.com/a','https://webapi.115.com/a#x']:
 for name in ['reduce_image_url_layers','max_image_quality','to_cdn_url']:add('util-'+name.replace('_','-'),{'value':url},getattr(util,name)(url))
for text in ['|——根目录\n','|——根目录\n| |-a\n| | |-b\n| |-c\n','|——目录\n| |-a/b\n| |-..\n','|——根目录\n| |-多行\n文件名\n| |-最后\n']:
 for fmt in ['depth_name','dict','path','patht']:
  for escape in ([None,True,False] if fmt=='path' else [None]):
   kw={'escape':escape} if fmt=='path' else {}
   result=list(getattr(exports,'export_dir_parse_iter_'+fmt)(text.splitlines(True),**kw))
   add('export-parse-'+fmt.replace('_','-'),{'text':text,**({'escape':escape} if escape is not None else {})},{'items':result,'cursor':None,'complete':True})
rng=random.Random(115)
for prefix in ['a','b','c','d','e','fa','fb','fc','fd','fe']:
 for _ in range(30):
  id=rng.randrange(1,2**62);point='0'+''.join(rng.choices(pick.ALPHABET,k=3));code=pick.to_pickcode(id,stable_point=point,prefix=prefix)
  add('client-to-id',{'value':code},str(id));add('client-to-pickcode',{'value':str(id),'stable_point':point,'prefix':prefix},code)
  add('util-normalize-pickcode',{'value':code},util.normalize_pickcode(code));add('util-is-valid-pickcode',{'value':code},pick.is_valid_pickcode(code))
root=Path(__file__).resolve().parents[1]
p=subprocess.run(['node',str(root/'dev/library-conformance.mjs')],input=json.dumps(cases),text=True)
raise SystemExit(p.returncode)
