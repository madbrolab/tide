import json
from library_ops import FIELDS, PATH, VALUE
from shapes import RAW,TEXT,NUMBER,INT,BOOL,array,typ

def extend(reg):
    add=reg.add
    page={**FIELDS,'page':INT,'page_size':INT,'type':typ('integer|string','事件或列表类型'),'date':TEXT,'app':TEXT,
          'from_id':NUMBER,'from_time':INT,'yield_latest':BOOL,'ignore_types':array('忽略的类型',INT),'raise_for_update':BOOL}
    for family,refs in [('history',['tool.history.iter_history','tool.history.iter_history_once','tool.history.iter_history_list']),('life',['tool.life.iter_life_behavior','tool.life.iter_life_behavior_once','tool.life.iter_life_behavior_list']),('offline',['tool.clouddownload.clouddownload_iter']),('offline-restart',['tool.clouddownload.clouddownload_restart_iter']),('search',['tool.iterdir.search_iter']),('share-search',['tool.iterdir.share_search_iter']),('wish',['tool.xys.wish_iter']),('wish-aid',['tool.xys.wish_aid_iter'])]:
        add('tool-'+family+'-page','await collectionPage(ctx,args,'+json.dumps(family)+')',{**page,'wish_id':TEXT,'page_start':INT,'page_stop':INT,'stat':INT,'begins_with_retryable':BOOL,'search_value':TEXT,'name':TEXT,'cid':NUMBER},refs)
    edit={**page,'ids':array('文件 ID',NUMBER),'batch_size':INT,'value':typ('string|integer|boolean','新值'),'label':TEXT,'hidden':BOOL,'password':TEXT,'mode':TEXT}
    for name in 'copy move delete hide recyclebin_clean recyclebin_revert label'.split():
        add('tool-batch-'+name.replace('_','-'),'await editBatch(ctx,args,'+json.dumps('batch_label' if name=='label' else name)+')',edit,['tool.edit.batch_'+name])
    for name in 'cover desc label show_play_long star score top category_shortcut'.split():
        add('tool-update-'+name.replace('_','-'),'await editBatch(ctx,args,'+json.dumps(name)+')',edit,['tool.edit.update_'+name])
    add('tool-update-abstract','await editBatch(ctx,args,args.method.replace(/^fs_/," ").trim().replace(/_set$/, ""))',{**edit,'method':TEXT},['tool.edit.update_abstract'])
    add('tool-post-event','await editBatch(ctx,args,"post_event")',edit,['tool.edit.post_event'])
    add('tool-update-name','await editNames(ctx,args,false)',{**page,'pairs':array('ID 与新名称',array('键值对',NUMBER))},['tool.edit.update_name'])
    add('tool-batch-makedir','await editNames(ctx,args,true)',{**page,'pairs':typ('array','名称或父目录与名称',items=typ('string|array','名称或二元组',items=NUMBER)),'contain_dir':BOOL},['tool.edit.batch_makedir','tool.edit.iter_batch_makedir'])
    for method in 'dir_getid get_id_to_name get_id_to_path get_id_to_sha1 get_info get_file_count get_dir_count share_get_id share_get_id_to_name share_get_id_to_path'.split():
        expr='await attrLookup(ctx,'+('{...args,scope:shareScope(args)}' if method.startswith('share_') else 'args')+','+json.dumps(method)+')'
        add('attr-'+method.replace('_','-'),expr,{**page,'name':TEXT,'sha1':TEXT,'cid':NUMBER,'recursive':BOOL,'ensure_file':BOOL},['tool.attr.'+method])
    for method in 'get_id_to_dirnode iter_3_ancestor_names iter_dirs iter_files iter_files_skim iter_keyed_dupfiles iter_keyed_ids share_iter_files share_iterdir extract_iter_files extract_iterdir traverse_tree'.split():
        add('tree-'+method.replace('_','-'),'await treeTool(ctx,args,'+json.dumps(method)+')',{**page,'top':PATH,'cid':NUMBER,'pickcode':TEXT,'key':TEXT},['tool.iterdir.'+method])
    add('tool-files-page','await directoryPage(ctx,{...args,offset:args.cursor?.offset??args.offset??0})',page,['tool.fs_files.fs_files','tool.fs_files.fs_files_iter','tool.iter_nodes.iter_nodes'])
    add('tool-iterdir-skim','await directoryPage(ctx,{...args,simple:true})',page,['tool.iterdir.iterdir_skim'])
    for method,mode in [('file','file'),('file_skim','skim'),('info','info'),('supervision','supervision'),('update','update')]:
        add('nodes-by-'+method.replace('_','-'),'await selectNodes(ctx,args,'+json.dumps(mode)+')',{**page,'ids':array('ID',PATH),'pickcodes':array('提取码',TEXT)},['tool.iter_nodes.iter_nodes_by_'+method])
    add('tool-life-show','await do_life_calendar_setoption(ctx,{})',{},['tool.life.life_show'])
    add('tool-open-app-check','args.app_id>0&&args.app_id%2===1&&!failed(await do_common_login_qrcode_token_open(ctx,{payload:{client_id:args.app_id}}))',{'app_id':INT},['tool.auth.open_app_check'],kind=None)
    add('tool-open-app-name','args.app_id>0&&args.app_id%2===1?(await extendedLoginAuto(ctx,args,true,true)).name:null',{'app_id':INT},['tool.auth.open_app_name'])
    for method in ['depth_name','dict','path','patht']:
        add('export-parse-'+method.replace('_','-'),'parseExportText({...args,format:'+json.dumps(method)+'})',{'text':TEXT,'cursor':RAW,'final':BOOL,'escape':BOOL},['tool.export_dir.export_dir_parse_iter_'+method],kind=None)
    add('wish-info','ensureOK(await do_act_xys_get_desire_info(ctx,{payload:{id:args.wish_id}})).data',{'wish_id':TEXT},['tool.xys.wish_info'])
    add('wish-make','ensureOK(await do_act_xys_wish(ctx,{payload:{rewardSpace:args.size??5,content:args.content??"随便许个愿"}})).data',{'size':INT,'content':TEXT},['tool.xys.wish_make'])
    add('wish-answer','ensureOK(await do_act_xys_aid_desire(ctx,{payload:{id:args.wish_id,content:args.content??"帮你助个愿",file_ids:idsArray(args.file_ids??[]).join(",")}})).data',{'wish_id':TEXT,'content':TEXT,'file_ids':array('分享的 ID',NUMBER)},['tool.xys.wish_answer'])
    add('wish-adopt','ensureOK(await do_act_xys_adopt(ctx,{payload:{did:args.wish_id,aid:args.aid_id,to_cid:args.to_cid??0}}))',{'wish_id':TEXT,'aid_id':NUMBER,'to_cid':NUMBER},['tool.xys.wish_adopt'])
    add('wish-del','ensureOK(await do_act_xys_wish_del(ctx,{payload:{ids:Array.isArray(args.wish_id)?args.wish_id.join(","):args.wish_id}}))',{'wish_id':typ('string|array','愿望 ID',items=TEXT)},['tool.xys.wish_del'])
