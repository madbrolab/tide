import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const sdk=await import('data:text/javascript;base64,'+readFileSync(new URL('../main.js',import.meta.url)).toString('base64'));
let failed=0;const fixtures=JSON.parse(readFileSync(0,'utf8'));
for(const v of fixtures){try{assert.deepEqual(await sdk[v.action]({},v.args),v.result);}catch(e){failed++;if(failed<6)console.error(v.action,JSON.stringify(v.args),e.message);}}
console.log(`${fixtures.length} normalizer comparisons, ${failed} failures`);
process.exitCode=failed?1:0;
