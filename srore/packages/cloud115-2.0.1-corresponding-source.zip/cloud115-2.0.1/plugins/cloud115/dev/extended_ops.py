"""Explicit extra bindings. Coverage is added only alongside executable code."""
import json
from shapes import typ, obj, array, RAW, TEXT, NUMBER, INT, BOOL

def extend(ops,manifest,src,coverage,rows):
    definitions={r[1]:r[2] for r in rows}
    payload=typ('object|string|array','上游参数或重复表单字段',additionalProperties=True,items=typ('string|array','字段或键值对',items=typ('string|integer|boolean','字段值')))
    output=typ('object|array|string|integer|boolean|null','上游结果；大整数 ID 为字符串',additionalProperties=True,items=RAW)
    common={'payload':payload,'app':TEXT,'userId':NUMBER}
    def add(name,expression,fields,refs,kind='cookie',file=False,bootstrap=False,sample=None):
        label=refs[0].split('.')[-1].replace('_',' ')
        action=dict(label=label,external=True,immediateOnly=True)
        if kind:action['inlineCredential']=kind
        if bootstrap:action['bootstrap']=True
        if file:action['sourceFile']=True;fields={**fields,'sourceRef':TEXT,'sourcePath':TEXT}
        manifest['actions'][name]=action
        ops[name]=dict(summary=label,input=obj('参数',fields),output=output,notes='对应 '+', '.join(refs)+'；SDK 2；无自动重试。',example=dict(args=sample or {},result={}))
        fn='extra_'+name.replace('-','_')
        src.append('async function '+fn+'(ctx,args){return await '+expression+';}export{'+fn+' as '+json.dumps(name)+'};')
        for ref in refs:
            if ref not in definitions:raise ValueError(ref)
            coverage[definitions[ref]]=(name,'纯 JS 组合与协议适配')
    add('upload-resume','extendedResume(ctx,args,"cookie")',common,['client.cookie.upload_resume'])
    add('open-upload-resume','extendedResume(ctx,args,"open")',common,['client.open.upload_resume','client.open.upload_resume_open'],kind='bearer')
    add('upload-init','extendedUploadInit(ctx,args)',common,['client.cookie.upload_init'])
    add('upload-key','send(ctx,"https://proapi.115.com/"+platform(args,"android",true)+"/2.0/user/upload_key","GET",null,null)',{'app':TEXT},['client.cookie.upload_key'])
    add('diary-add','extendedDiary(ctx,args,false)',common,['client.cookie.diary_add'])
    add('diary-edit','extendedDiary(ctx,args,true)',common,['client.cookie.diary_edit'])
    add('fs-label-add','extendedLabels(ctx,args,false)',common,['client.cookie.fs_label_add'])
    add('fs-label-add-app','extendedLabels(ctx,args,true)',common,['client.cookie.fs_label_add_app'])
    add('fs-folder-playlong-set','do_fs_batch_edit(ctx,{payload:Object.fromEntries((Array.isArray(args.ids)?args.ids:[args.ids]).map(id=>["show_play_long["+remoteId(id)+"]",args.is_set??1]))})',{'ids':typ('string|integer|array','文件 ID',items=NUMBER),'is_set':INT},['client.cookie.fs_folder_playlong_set'])
    add('fs-space-report','send(ctx,web+"/user/report","GET",{month:args.month??new Date(Date.UTC(Number(localDay(0).slice(0,4)),Number(localDay(0).slice(5,7))-2,1)).toISOString().slice(0,7).replace("-","")},null)',{'month':TEXT},['client.cookie.fs_space_report'])
    add('fs-video-app','extendedVideo(ctx,args)',common,['client.cookie.fs_video_app'])
    add('extract-file','extendedExtract(ctx,args)',{'pickcode':TEXT,'files':typ('string|array','文件名',items=TEXT),'dirs':typ('string|array','目录名',items=TEXT),'dirname':TEXT,'to_pid':NUMBER,'app':TEXT},['client.cookie.extract_file','tool.extract.extract_file'])
    for name,chat in [('upload-chat-image',True),('upload-file-image',False)]:
        add(name,'extendedImageUpload(ctx,args,'+json.dumps(chat)+')',{'pid':TEXT,'share_id':NUMBER,'filename':TEXT,'dirname':TEXT},['client.cookie.'+name.replace('-','_')],file=True)
    add('usershare-download-urls','downloadLinks(ctx,{...args,pickcode:Array.isArray(args.pickcodes)?args.pickcodes.join(","):args.pickcodes,shareId:args.share_id,userAgent:args.user_agent},"cookie",false)',{'pickcodes':typ('string|array','提取码',items=TEXT),'share_id':NUMBER,'userId':NUMBER,'user_agent':TEXT,'strict':BOOL},['client.cookie.usershare_download_urls'])
    add('usershare-download-url','downloadLinks(ctx,{...args,shareId:args.share_id,userAgent:args.user_agent},"cookie",true)',{'pickcode':TEXT,'share_id':NUMBER,'userId':NUMBER,'user_agent':TEXT,'strict':BOOL},['client.cookie.usershare_download_url'])
    add('extract-download-url','extendedExtractLink(ctx,args)',{'pickcode':TEXT,'path':TEXT,'app':TEXT,'user_agent':TEXT},['client.cookie.extract_download_url'])
    add('login-device','extendedLoginDevice(ctx)',{},['client.cookie.login_device'])
    add('login-app','(await extendedLoginDevice(ctx))?.icon??null',{},['client.cookie.login_app'])
    add('login-status','Boolean((await send(ctx,"https://my.115.com/?ct=guide&ac=status","GET",null,null)).state)',{},['client.cookie.login_status'])
    add('login-without-app','extendedLoginAuto(ctx,{...args,uidOnly:true},false)',{},['client.cookie.login_without_app'])
    add('login-with-app','extendedLoginAuto(ctx,args,false)',{'app':TEXT},['client.cookie.login_with_app','client.cookie.login_another_app'])
    add('login-with-open','extendedLoginAuto(ctx,args,true)',{'app_id':INT},['client.cookie.login_with_open','client.cookie.login_another_open'])
    add('login-info-open','extendedLoginAuto(ctx,args,true,true)',{'app_id':INT},['client.cookie.login_info_open'])
    add('login-bind-app','qrLoginResult(ctx,args)',{'uid':TEXT,'app':TEXT},['client.cookie.login_bind_app'],kind=None,bootstrap=True)
    add('login-with-qrcode','extendedQR(ctx,args,false)',{'app':TEXT,'session':RAW},['client.common.login_with_qrcode','client.cookie.login'],kind=None,bootstrap=True)
    add('login-with-app-id','extendedQR(ctx,args,true)',{'app_id':INT,'session':RAW},['client.common.login_with_app_id'],kind=None,bootstrap=True)
    add('open-refresh-access-token','do_common_login_refresh_token_open(ctx,{payload:{refresh_token:args.refresh_token}})',{'refresh_token':TEXT},['client.open.refresh_access_token'],kind=None,bootstrap=True)
