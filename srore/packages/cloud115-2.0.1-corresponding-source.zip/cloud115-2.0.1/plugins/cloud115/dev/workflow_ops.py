import json
from library_ops import FIELDS,PATH
from shapes import RAW,TEXT,NUMBER,INT,BOOL,array,typ

def extend(reg):
    add=reg.add
    fields={**FIELDS,'pickcode':TEXT,'extract_id':NUMBER,'secret':TEXT,'app':TEXT,'paths':array('压缩包路径',TEXT),'to_pid':NUMBER}
    for method in ('raw','push','push_progress','progress'):
        add('tool-extract-'+method.replace('_','-'),'await extractTool(ctx,args,'+json.dumps(method)+')',fields,['tool.extract.extract_iterdir_raw' if method=='raw' else 'tool.extract.extract_'+method])
    for method in ('load','id_to_path','path_to_id','extract','extract_many'):
        add('zip-'+method.replace('_','-'),'await zipTool(ctx,args,'+json.dumps(method)+')',fields,['fs.fs_zip.P115ZipFileSystem.'+method])
    for method in ('start','status','result','parse','export'):
        ref='export_dir' if method=='export' else 'export_dir_parse_iter' if method=='parse' else 'export_dir_'+method
        add('export-'+method,'await exportWorkflow(ctx,args,'+json.dumps(method)+')',{'file_ids':array('导出目录',NUMBER),'target':TEXT,'layer_limit':INT,'export_id':NUMBER,'file_id':NUMBER,'cursor':RAW,'format':TEXT,'escape':BOOL,'delete':BOOL},['tool.export_dir.'+ref])
    add('tool-pic-url','await picURLs(ctx,args)',{'sha1':typ('string|array','图片 SHA1',items=TEXT),'select':TEXT},['tool.download.get_pic_url'],required=['sha1'])
    add('tool-download-nodes','await downloadNodePage(ctx,args)',{**fields,'files':BOOL,'ensure_name':BOOL,'get_raw':BOOL,'top':PATH},['tool.download.iter_download_nodes'])
    add('tool-download-urls','await urlPage(ctx,args)',{**fields,'pickcodes':array('提取码或文件信息',PATH),'top':PATH,'userAgent':TEXT},['tool.download.iter_urls'])
    add('tool-download-file','await downloadFile(ctx,args)',{**fields,'entry':RAW,'destination':TEXT,'resume':BOOL,'chunks':INT},['tool.download.download_file'],required=['destination'])
    add('tool-get-url','await entryURL(ctx,await resolveEntry(ctx,args.value??args.id_or_path??args.id??0,args),args)',{**fields,'value':PATH,'userAgent':TEXT},['tool.download.get_url'])
    add('vfs-ed2k','await ed2kFile(ctx,args)',{**fields,'name':TEXT},['fs.fs_base.P115FileSystemBase.ed2k'])
    for mode in ('event','label','star'):
        add('nodes-by-'+mode,'await readAfterEdit(ctx,args,'+json.dumps(mode)+')',{**fields,'ids':array('文件 ID',NUMBER),'type':TEXT,'replace_label':BOOL},['tool.iter_nodes.iter_nodes_by_'+mode])
    add('tool-life-list','await lifeListPage(ctx,args)',{**fields,'start_time':INT,'end_time':INT},['tool.life.iter_life_list'])
    add('tool-open-deauth','await deauthOpen(ctx,args)',{'app_ids':array('仅撤销选中的应用；省略表示全部',NUMBER)},['tool.auth.open_deauth'])
    add('tool-ensure-path','await ensurePaths(ctx,args)',{**fields,'items':array('文件属性',RAW)},['tool.iterdir.ensure_path'])
    add('tool-check-sha1-existence','await sha1Exists(ctx,args)',{'sha1':TEXT},['tool.upload.sha1_for_check_existence'],required=['sha1'])
    for operation in ('copy','move','delete'):
        add('tool-batch-'+operation+'-files','await filesJob(ctx,args,'+json.dumps(operation)+')',{**FIELDS,'top':PATH,'flatten':BOOL,'resolve_id':NUMBER,'resolution':TEXT},['tool.edit.batch_'+operation+'_files'])
    add('tool-batch-unstar','await batchUnstar(ctx,args)',{**FIELDS,'ensure_file':BOOL},['tool.edit.batch_unstar'])
    for rename in (False,True):
        method='renamefile' if rename else 'copyfile'
        add('tool-'+method,'await copyRenameFile(ctx,args,'+json.dumps(rename)+')',{**FIELDS,'entry':RAW,'name':TEXT},['tool.edit.'+method])
    for resume in (False,True):
        name='transfer-files-resume' if resume else 'transfer-files'
        add(name,'await transferFiles(ctx,args,'+json.dumps(resume)+')',{**FIELDS,'entries':array('源文件信息',RAW),'source':RAW,'top':PATH,'flatten':BOOL},['tool.upload.iter_115_to_115_resume' if resume else 'tool.upload.iter_115_to_115'])
    add('tool-subtitles','await subtitlePage(ctx,args)',{**FIELDS,'file_ids':typ('string|integer|array','目录或字幕文件列表',items=NUMBER),'top':PATH},['tool.download.iter_subtitles'])
    add('tool-open-capacity','await probeOpenCount(ctx,args)',{**FIELDS,'top':PATH,'urls':array('直链或直链信息',typ('string|object','直链',additionalProperties=True))},['tool.download.get_remaining_open_count'],notes='按 limit 和动作期限探测；complete=false 表示只得到下界。连接在返回前关闭。')
    add('tool-download-upload-blocks','await downloadUploadBlocks(ctx,args)',{**FIELDS,'pickcode':TEXT,'block_size':INT,'start_block_number':INT,'hashmethods':array('摘要算法',TEXT),'temp_dir':TEXT,'account':RAW},['tool.upload.iter_download_upload'],required=['temp_dir','account'])
    add('tool-upload-block','await uploadBlock(ctx,args)',{'filename':TEXT},[],file=True,required=['filename'])
