"""Offline oracle for the pure JS attribute translations."""
import json, random, sys, subprocess
from pathlib import Path
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
from p115client.tool.attr import normalize_attr_web, normalize_attr_app, normalize_attr_app2
rng=random.Random(115)
fixtures=[]
for kind,fn in [('web',normalize_attr_web),('app',normalize_attr_app),('app2',normalize_attr_app2)]:
    for i in range(80):
        directory=i%3==0
        large='9007199254740993' if i%2 else '7'
        name=['.hidden','..','电影.mkv','无后缀','a..b.PDF','a.tar.gz'][i%6]
        if kind=='web':
            info={'cid':large if directory else '9','pid':'9','n':name,'sha':'' if directory else 'ABCD','s':'3'}
            if not directory:info['fid']=large
            optional={'tp':'123','te':'124','to':'125','tu':'126','t':'昨天','pc':'ab','c':'1','vdi':4,'iv':1,'class':'DOC','fl':[{'id':1}],'cc':'001','fdes':'说明','star_time':'0','ico':'file'}
        elif kind=='app':
            info={'fid':large,'pid':'9','fn':name,'fc':'0' if directory else '1','sha1':'' if directory else 'ABCD','fs':'3'}
            optional={'uppt':'123','upt':'124','uet':'125','pc':'ab','ic':'1','def':'4','isv':1,'muc':'','thumb':'?t=1','fl':[{'id':1}],'fco':'001','fdesc':'说明','ico':'file'}
        else:
            info={'file_id':large,'parent_id':'9','file_name':name,'file_category':'0' if directory else '1','sha1':'' if directory else 'ABCD','file_size':'3'}
            optional={'user_pptime':'123','user_ptime':'124','user_utime':'125','pick_code':'ab','is_collect':'1','definition':'4','is_video':1,'thumb_url':'https://img','music_cover':'','fl':[{'id':1}],'category_cover':'001','file_description':'说明','ico':'file','is_mark':'1','type':3}
        info.update({k:v for k,v in optional.items() if rng.random()<.5})
        for simple in [False,True]:
            args={'info':info,'simple':simple,'keep_raw':i%2==0,'default':{'custom':'kept'}}
            result=fn(info,simple=simple,keep_raw=args['keep_raw'],default=args['default'])
            for field in ('id','parent_id'):result[field]=str(result[field])
            fixtures.append({'action':'attr-normalize-'+kind,'args':args,'result':result})
result=subprocess.run(['node',str(Path(__file__).with_name('library-conformance.mjs'))],input=json.dumps(fixtures),text=True)
raise SystemExit(result.returncode)
