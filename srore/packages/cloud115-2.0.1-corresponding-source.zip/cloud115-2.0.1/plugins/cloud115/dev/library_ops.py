"""JSON interfaces for p115C's filesystem and composition layer.

The deployed plugin is JavaScript only. Upstream constants are read as literals
at build time; Python classes, iterators and handles become JSON values/cursors.
"""
import ast
import json
import re
from shapes import typ, obj, array, RAW, TEXT, NUMBER, INT, BOOL

VALUE = typ('object|string|number|boolean|null', 'JSON 值；长整数使用字符串', additionalProperties=True)
for _ in range(6):
    VALUE = typ('object|array|string|number|boolean|null', 'JSON 值；长整数使用字符串', additionalProperties=True, items=VALUE)
PATH = typ('string|integer|array|object', '文件 ID、转义路径、名称数组或文件信息', additionalProperties=True, items=TEXT)
FIELDS = {'id_or_path':PATH,'path':PATH,'id':NUMBER,'pid':NUMBER,'cid':NUMBER,'scope':RAW,'app':TEXT,'userAgent':TEXT,'get_raw':BOOL,
          'offset':INT,'limit':INT,'cursor':RAW,'payload':RAW,'simple':BOOL,'keep_raw':BOOL,
          'pattern':TEXT,'ignore_case':BOOL,'filter':RAW,'min_depth':INT,'max_depth':INT}

class Registry:
    def __init__(self,ops,manifest,src,coverage,rows):
        self.ops,self.manifest,self.src,self.coverage=ops,manifest,src,coverage
        self.definitions={r[1]:r[2] for r in rows}
    def add(self,name,expression,fields,refs=(),kind='cookie',file=False,required=(),notes='',example=None):
        if name in self.ops:raise ValueError('duplicate action '+name)
        action=dict(label=name,external=True,immediateOnly=True)
        if kind:action['inlineCredential']=kind
        if file:action['sourceFile']=True;fields={**fields,'sourceRef':TEXT,'sourcePath':TEXT}
        self.manifest['actions'][name]=action
        sample={k:({} if 'object' in fields[k]['type'] else [] if 'array' in fields[k]['type'] else '' if 'string' in fields[k]['type'] else 0) for k in required}
        self.ops[name]=dict(summary=name,input=obj('参数',fields,required),output=VALUE,
            notes='纯 JS / SDK 2。迭代器返回 items 与 cursor；继续调用时保留参数并传回 cursor。路径与 ID 保持字符串。'+notes,
            example=example or dict(args=sample,result={}))
        fn='library_'+name.replace('-','_')
        simple=re.fullmatch(r'await (\w+)\(ctx,args,("[a-z_]+")\)',expression)
        direct=re.fullmatch(r'await (\w+)\(ctx,args\)',expression)
        if direct:
            self.src.append('export{'+direct[1]+' as '+json.dumps(name)+'};')
        elif simple:
            self.src.append('const '+fn+'=/* @__PURE__ */libraryDispatch('+simple[1]+','+simple[2]+');export{'+fn+' as '+json.dumps(name)+'};')
        else:
            self.src.append('async function '+fn+'(ctx,args){return '+expression+';}export{'+fn+' as '+json.dumps(name)+'};')
        for ref in refs:
            if ref not in self.definitions:raise ValueError(ref)
            source=self.definitions[ref]
            if self.coverage.get(source,('',))[0]:raise ValueError('already covered '+ref)
            self.coverage[source]=(name,'纯 JS；JSON 值、分页游标或显式状态适配')

def constants(src,checkout):
    tree=ast.parse((checkout/'const.py').read_text())
    for py,js in [('SUFFIX_TO_TYPE','suffixTypes'),('CLASS_TO_TYPE','classTypes')]:
        node=next(n for n in tree.body if isinstance(n,ast.AnnAssign) and ast.unparse(n.target)==py)
        src.append('const '+js+'=/* @__PURE__ */JSON.parse('+json.dumps(json.dumps(ast.literal_eval(node.value),ensure_ascii=False,separators=(',',':')),ensure_ascii=False)+');')
    tree=ast.parse((checkout/'tool/attr.py').read_text())
    mappings={}
    for kind in ('web','app','app2'):
        fn=next(n for n in tree.body if getattr(n,'name','')=='normalize_attr_'+kind)
        loop=next(n for n in ast.walk(fn) if isinstance(n,ast.For) and isinstance(n.iter,ast.Tuple))
        values=ast.literal_eval(loop.iter)
        mappings[kind]=[(v,v) if isinstance(v,str) else v for v in values]
    src.append('const attrMappings=/* @__PURE__ */JSON.parse('+json.dumps(json.dumps(mappings,ensure_ascii=False,separators=(',',':')),ensure_ascii=False)+');')

def extend(ops,manifest,src,coverage,rows,checkout):
    src.append('function libraryDispatch(fn,operation){return (ctx,args)=>fn(ctx,args,operation);}')
    constants(src,checkout)
    reg=Registry(ops,manifest,src,coverage,rows)
    add=reg.add
    operations=[r[1] for r in rows]
    def refs(method,extra=(),scopes=None):
        return [r for r in operations if r.startswith('fs.') and r.rsplit('.',1)[1]==method and (scopes is None or any(s in r for s in scopes))]+list(extra)
    basic='as_path get_attr get_id get_parent_id get_ancestors get_path get_patht exists isdir isfile iter glob rglob iterdir listdir dictdir readdir dirlen is_empty stat has_child copy move remove rename get_url read read_block read_range read_text hash hashes download'.split()
    for method in basic:
        fields={**FIELDS}
        if method in ('copy','move'):fields.update(to_dir=PATH,to_pid=NUMBER)
        if method=='rename':fields['name']=TEXT
        if method=='has_child':fields['child']=PATH
        if method=='download':fields['destination']=TEXT
        if method in ('read','read_block','read_range','read_text','hash','hashes'):
            fields.update(start=INT,stop=INT,size=INT,length=INT,bytes_range=TEXT,digests=array('摘要算法',TEXT),digest=TEXT,userAgent=TEXT)
        extra=['tool.attr.'+method] if method in ('get_attr','get_id','get_parent_id','get_ancestors','get_path') else []
        if method=='iterdir':extra+=['tool.iterdir.iterdir']
        add('vfs-'+method.replace('_','-'),'await fileAction(ctx,args,'+json.dumps(method)+')',fields,refs(method,extra))
    add('vfs-mkdir','await makeDirectories(ctx,args)',{**FIELDS,'name':TEXT},refs('mkdir',['tool.edit.makedir']))
    add('attr-normalize','normalizeEntry(args.info,args)',{'info':RAW,'simple':BOOL,'keep_raw':BOOL,'default':RAW},['tool.attr.normalize_attr'],kind=None,required=['info'])
    for kind in ('web','app','app2','simple'):
        opts='{...args,simple:true}' if kind=='simple' else '{...args,kind:'+json.dumps(kind)+'}'
        add('attr-normalize-'+kind,'normalizeEntry(args.info,'+opts+')',{'info':RAW,'simple':BOOL,'keep_raw':BOOL,'default':RAW},['tool.attr.normalize_attr_'+kind],kind=None,required=['info'])
    add('attr-type','fileType(args.attr)',{'attr':typ('string|object','文件名或规范化属性',additionalProperties=True)},['tool.attr.type_of_attr'],kind=None,required=['attr'])
    for method in 'ancestors get_length get_parent get_parents id inode is_absolute is_dir is_file is_symlink join joinpath match media_type parent parents parts path patht root stem suffix suffixes with_name with_stem with_suffix wrap_path_iter'.split():
        add('path-'+method.replace('_','-'),'await pathAction(ctx,args,'+json.dumps(method)+')',
            {**FIELDS,'name':TEXT,'stem':TEXT,'suffix':TEXT,'parts':array('追加的名称',TEXT),'items':array('文件属性',RAW)},refs(method))
    for method in 'chdir getcid getcwd listdir_path dictdir_path walk open attr_to_stat user_id'.split():
        add('vfs-'+method.replace('_','-'),'await filesystemState(ctx,args,'+json.dumps(method)+')',
            {**FIELDS,'state':RAW,'attr':RAW,'start':INT},refs(method))
    for method in 'create_time create_timestamp get_share_data share_data share_info share_user_id snap_id receive from_url'.split():
        add('share-fs-'+method.replace('_','-'),'await shareFilesystem(ctx,args,'+json.dumps(method)+')',
            {**FIELDS,'url':TEXT,'share_code':TEXT,'receive_code':TEXT,'ids':array('转存的文件 ID',NUMBER),'to_pid':NUMBER},refs(method))
    add('vfs-create','await filesystemState(ctx,args,"create")',{'scope':RAW,'pid':NUMBER},['client.cookie.get_fs','client.cookie.fs'])
    add('vfs-path-class','({kind:args.scope?.kind??"drive",representation:"JSON",pathEscape:"backslash",idType:"string"})',{'scope':RAW},refs('path_class'),kind=None)
    return reg
