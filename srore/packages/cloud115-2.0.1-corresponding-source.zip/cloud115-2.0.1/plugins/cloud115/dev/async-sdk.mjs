// Lift the reviewed protocol graph to SDK 2 promises, including nested signing
// helpers. Fail closed on async callbacks: Array.map does not await its callback.
import { readFileSync } from 'node:fs';
import { parse } from '@babel/parser';
import MagicString from 'magic-string';

const source = readFileSync(0, 'utf8');
const ast = parse(source, { sourceType: 'module' });
const functions = [], calls = [], bindings = new Map();
function walk(node, owner, parent) {
  if (!node || typeof node !== 'object') return;
  if (Array.isArray(node)) { for (const child of node) walk(child, owner, parent); return; }
  if (['FunctionDeclaration', 'FunctionExpression', 'ArrowFunctionExpression'].includes(node.type)) {
    const name = node.id?.name || (parent?.type === 'VariableDeclarator' ? parent.id.name : null);
    owner = { node, parent, name, async: node.async };
    functions.push(owner);
    if (name) {
      if (bindings.has(name)) throw Error('Ambiguous function binding: ' + name);
      bindings.set(name, owner);
    }
  }
  if (node.type === 'CallExpression') calls.push({ node, owner, parent });
  for (const [key, child] of Object.entries(node)) {
    if (!['loc', 'start', 'end', 'extra', 'comments', 'tokens'].includes(key)) walk(child, owner, node);
  }
}
walk(ast);
function isSDK(node) {
  if (node.type !== 'MemberExpression') return false;
  if (node.object.type === 'Identifier' && node.object.name === 'ctx') return node.property.name !== 'remaining';
  return isSDK(node.object);
}
function isAsync(node) {
  if (node.type === 'Identifier') return bindings.get(node.name)?.async;
  if (node.type === 'ConditionalExpression') return isAsync(node.consequent) || isAsync(node.alternate);
  return isSDK(node);
}
let changed;
do {
  changed = false;
  for (const { node, owner } of calls) if (isAsync(node.callee)) {
    if (!owner) throw Error('SDK call at module top level');
    if (!owner.async) { owner.async = true; changed = true; }
  }
} while (changed);
const output = new MagicString(source);
for (const { node, parent, async } of functions) if (async) {
  if (parent?.type === 'CallExpression') throw Error('Async callback requires explicit scheduling at ' + node.start);
  if (!node.async) output.appendLeft(node.start, 'async ');
}
for (const { node, parent } of calls) if (isAsync(node.callee) && parent?.type !== 'AwaitExpression') {
  output.appendLeft(node.start, '(await ');
  output.appendRight(node.end, ')');
}
// A tail return already adopts the promise. Keep await inside try/catch/finally,
// where it affects error handling and cleanup. Avoid redundant bytecode elsewhere.
const lifted=output.toString(),tail=new MagicString(lifted);
function trim(node,protectedReturn=false){
  if(!node||typeof node!=='object')return;
  if(Array.isArray(node)){for(const n of node)trim(n,protectedReturn);return;}
  if(['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node.type))protectedReturn=false;
  if(node.type==='TryStatement')protectedReturn=true;
  if(node.type==='ReturnStatement'&&node.argument?.type==='AwaitExpression'&&!protectedReturn)tail.remove(node.argument.start,node.argument.argument.start);
  for(const [key,child] of Object.entries(node))if(!['loc','start','end','extra','comments','tokens'].includes(key))trim(child,protectedReturn);
}
trim(parse(lifted,{sourceType:'module'}));
const finalSource=tail.toString(),compact=new MagicString(finalSource);
function hasAwait(node,root=true){
  if(!node||typeof node!=='object')return false;
  if(Array.isArray(node))return node.some(n=>hasAwait(n,false));
  if(node.type==='AwaitExpression'||node.type==='ForOfStatement'&&node.await)return true;
  if(!root&&['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node.type))return false;
  return Object.entries(node).some(([k,v])=>!['loc','start','end','extra','comments','tokens'].includes(k)&&hasAwait(v,false));
}
function syncTail(node){
  if(!node||typeof node!=='object')return;
  if(Array.isArray(node)){for(const n of node)syncTail(n);return;}
  if(['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node.type)&&node.async&&!hasAwait(node))compact.remove(node.start,node.start+6);
  for(const [key,child] of Object.entries(node))if(!['loc','start','end','extra','comments','tokens'].includes(key))syncTail(child);
}
syncTail(parse(finalSource,{sourceType:'module'}));
process.stdout.write(compact.toString());
