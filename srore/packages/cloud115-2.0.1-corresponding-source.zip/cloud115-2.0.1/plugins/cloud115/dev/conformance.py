"""Compare original P115C methods against exported JS; no network is permitted."""

import copy
import hashlib
import inspect
import json
import socket
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlencode, parse_qsl

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(sys.argv[1]).resolve()))


def offline(*_, **__):
    raise RuntimeError("network disabled in parity test")


socket.socket.connect = socket.socket.connect_ex = socket.create_connection = offline
from p115client import client as upstream

if (
    hashlib.sha256(Path(upstream.__file__).read_bytes()).hexdigest()
    != "0ee3510bdaf63e8c1294a63eecfe7e41cb823e259748e7f04712d5a4d2ed865f"
):
    raise SystemExit("incorrect upstream source")
ops = json.loads((ROOT / "operations.json").read_text())
classes = {
    k: getattr(upstream, k)
    for k in ("P115Client", "P115OpenClient", "ClientRequestMixin")
}
from uuid import UUID

upstream.uuid4 = lambda: UUID("12345678-1234-4234-9234-123456789012")
upstream.time = lambda: 1700000000
from datetime import date, datetime, timezone, timedelta
class FrozenDate(date):
    @classmethod
    def today(cls):return cls(2023,11,15)
class FrozenDatetime(datetime):
    @classmethod
    def fromtimestamp(cls,value,tz=None):
        result=datetime.fromtimestamp(value,tz or timezone(timedelta(hours=8)))
        return cls(result.year,result.month,result.day,result.hour,result.minute,result.second,tzinfo=tz)
    @classmethod
    def now(cls,tz=None):return cls.fromtimestamp(1700000000,tz)
    def timestamp(self):return datetime.timestamp(self if self.tzinfo else self.replace(tzinfo=timezone(timedelta(hours=8))))
upstream.date=FrozenDate
upstream.datetime=FrozenDatetime
calls = []


def capture(url, method="GET", payload=None, **kwargs):
    if "params" not in kwargs and payload is not None and method == "GET":
        kwargs["params"] = payload
    if "data" not in kwargs and payload is not None and method != "GET":
        kwargs["data"] = payload
    if isinstance(kwargs.get("params"), dict):
        kwargs["params"] = {**kwargs["params"]}
        kwargs["params"].setdefault("app_ver", "36.2.28")
    if (
        "files" in kwargs
        or kwargs.get("parse") not in (None, False)
    ):
        raise ValueError("custom wire/decoder")
    data = kwargs.get("data") or {}
    pairs = lambda x: parse_qsl(urlencode(x), keep_blank_values=True)
    calls.append(
        dict(
            ecdh=bool(kwargs.get('ecdh_encrypt')),
            binary=kwargs.get("parse") is False,
            deviceUA=(kwargs.get("headers") or {}).get("user-agent") if "/login/qrcode/" in url else None,
            url=url,
            method=method,
            params=pairs(kwargs.get("params") or {}),
            data=kwargs["json"] if "json" in kwargs else pairs(data),
            encoding="json" if "json" in kwargs else "form",
        )
    )
    return {"state": True}


upstream.ClientRequestMixin.request = lambda self, *args, **kw: capture(*args, **kw)


def get_request(*args, **kw):
    return lambda **more: capture(*args, **{**kw, **more}), {}


upstream.get_request = get_request
fail = []
vectors = []
for action, doc in ops.items():
    symbol = doc.get("notes", "").split(" · ")[0].split(".")
    if len(symbol) != 4 or symbol[:2] != ["p115client", "client"]:
        continue
    cls, method = symbol[-2:]
    obj = object.__new__(
        classes["P115OpenClient" if cls == "P115OpenClient" else "P115Client"]
    )
    obj.__dict__["user_id"] = 123
    func = getattr(obj, method)
    argspec = inspect.signature(func).parameters
    props = doc["input"]["properties"]
    has_payload = "payload" in props
    # Exercise non-default pagination, sorting and form escaping as well as the minimal form.
    samples = [doc["example"]["args"]]
    if has_payload:
        samples += [
            {
                **samples[0],
                "payload": {
                    **samples[0].get("payload", {}),
                    "probe": "a / + & 中文",
                    "offset": 7,
                    "limit": 2,
                    "asc": 1,
                },
            }
        ]
    if "app" in props:
        apps = props["app"]["enum"] if method == "login_qrcode_scan_result" else ("ios", "linux", "web")
        samples.extend([{**samples[0], "app": app} for app in apps])
    if "method" in props:
        samples.extend([{**samples[0], "method": m} for m in ("GET", "POST")])
    if "shareUrl" in props:
        samples.append(
            {**samples[0], "shareUrl": "https://115.com/s/example?password=abcd"}
        )
    for args in samples:
        calls.clear()
        p = copy.deepcopy(args.get("payload", {}))
        dynamic = (
            {"type": "web"}
            if method.startswith("clouddownload_") and "type" in argspec
            else {}
        )
        try:
            dynamic.update(
                {k: v for k, v in args.items() if k not in ("payload", "userId")}
            )
            if "shareUrl" in dynamic:
                dynamic["share_url"] = dynamic.pop("shareUrl")
            # A positional-only upstream argument is named in our JSON ABI.
            positional = [p] if has_payload else []
            for k in list(dynamic):
                if (
                    k in argspec
                    and argspec[k].kind == inspect.Parameter.POSITIONAL_ONLY
                ):
                    positional.append(dynamic.pop(k))
            func(*positional, **dynamic)
            if len(calls) != 1:
                raise ValueError("expected one HTTP request")
            vectors.append(
                dict(
                    action=action,
                    args=args,
                    public="无需账号凭据" in doc["notes"],
                    **calls[0],
                )
            )
        except Exception as e:
            fail.append((action, str(e)[:90]))
for row in sorted(set(fail)):
    print("oracle:", *row)
js = subprocess.run(
    ["node", str(ROOT / "dev/conformance.mjs")], input=json.dumps(vectors), text=True
)
print(
    len(set(v["action"] for v in vectors)),
    "distinct actions compared;",
    len(fail),
    "oracle failures",
)
sys.exit(bool(fail) or js.returncode)
