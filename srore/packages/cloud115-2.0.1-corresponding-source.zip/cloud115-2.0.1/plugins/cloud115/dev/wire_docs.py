"""Response projections for the frequently composed wire-level methods."""

from shapes import typ, array, RAW, NUMBER, TEXT, INT


def describe(ops):
    row = typ(
        "object",
        "115 Web 文件或目录记录；fid 表示文件，目录自身 ID 位于 cid",
        additionalProperties=True,
        properties={
            "fid": NUMBER,
            "cid": NUMBER,
            "pid": NUMBER,
            "n": TEXT,
            "s": NUMBER,
            "sha": TEXT,
            "pc": TEXT,
            "te": INT,
            "tp": INT,
            "fc": NUMBER,
        },
    )
    file_example = {
        "fid": "9007199254740995",
        "cid": "0",
        "n": "example.txt",
        "s": 10,
        "pc": "example",
        "sha": "A" * 40,
    }
    openrow = typ(
        "object",
        "115 Open 文件记录",
        additionalProperties=True,
        properties={
            "fid": NUMBER,
            "pid": NUMBER,
            "fn": TEXT,
            "fc": NUMBER,
            "fs": NUMBER,
            "sha1": TEXT,
            "pc": TEXT,
        },
    )

    def document(name, properties, example, args=None):
        if name not in ops:
            return
        op = ops[name]
        op["output"]["properties"].update(properties)
        op["example"]["result"] = {"state": True, **example}
        if args is not None:
            op["example"]["args"]["payload"] = args

    for name in ["fs-files", "fs-search", "fs-file"]:
        args = (
            {"cid": "0", "offset": 0, "limit": 20}
            if name == "fs-files"
            else {"cid": "0", "search_value": "example", "limit": 20}
            if name == "fs-search"
            else {"file_id": "9007199254740995"}
        )
        props = {"data": array("上游记录", row)}
        example = {"data": [file_example]}
        if name != "fs-file":
            props.update(count=NUMBER, offset=NUMBER)
            example.update(count=1, offset=0)
        document(name, props, example, args)
    for name in ["open-fs-files", "open-fs-search"]:
        document(
            name,
            {"data": array("开放平台记录", openrow), "count": NUMBER},
            {
                "data": [
                    {
                        "fid": "123",
                        "pid": "0",
                        "fn": "example.txt",
                        "fc": "1",
                        "fs": "10",
                        "pc": "sample",
                    }
                ],
                "count": 1,
            },
            {
                "cid": "0",
                "limit": 20,
                **({"search_value": "example"} if "search" in name else {}),
            },
        )
    share = typ(
        "object",
        "个人分享",
        additionalProperties=True,
        properties={
            "share_code": TEXT,
            "share_title": TEXT,
            "share_state": NUMBER,
            "receive_code": TEXT,
        },
    )
    document(
        "share-list",
        {"list": array("分享条目", share), "count": NUMBER},
        {
            "list": [
                {
                    "share_code": "example",
                    "share_title": "example.txt",
                    "share_state": 1,
                }
            ],
            "count": 1,
        },
        {"offset": 0, "limit": 20},
    )
    task = typ(
        "object",
        "离线任务",
        additionalProperties=True,
        properties={
            "info_hash": TEXT,
            "name": TEXT,
            "status": NUMBER,
            "percentDone": typ("number|string", "已完成百分比"),
        },
    )
    document(
        "clouddownload-task-list",
        {"tasks": array("任务条目", task), "page_count": NUMBER},
        {
            "tasks": [{"info_hash": "A" * 40, "name": "example", "status": 2}],
            "page_count": 1,
        },
        {"page": 1},
    )
    document(
        "recyclebin-list",
        {"data": array("回收站条目", RAW), "count": NUMBER},
        {"data": [], "count": 0},
        {"offset": 0, "limit": 20},
    )
    examples = {
        "fs-copy": {"fid[0]": "123", "pid": "456"},
        "fs-move": {"fid[0]": "123", "pid": "456"},
        "fs-delete": {"fid[0]": "123"},
        "fs-mkdir": {"cname": "Documents", "pid": "0"},
        "fs-rename": {"files_new_name[123]": "example.txt"},
        "fs-star-set": {"file_id": "123", "star": 1},
        "share-send": {"file_ids": "123"},
        "share-snap": {
            "share_code": "example",
            "receive_code": "abcd",
            "cid": "0",
            "offset": 0,
            "limit": 20,
        },
        "clouddownload-add-url": {"url": "https://example.org/sample.txt"},
    }
    for name, payload in examples.items():
        if name in ops:
            ops[name]["example"]["args"]["payload"] = payload
