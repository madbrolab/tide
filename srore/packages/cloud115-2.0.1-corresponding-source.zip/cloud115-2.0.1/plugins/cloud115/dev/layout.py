"""Deployment metadata shared by the generator and the signed package."""

def apply_layout(manifest):
    manifest["cards"] = [
        {"id":"calls","title":"115 调用量","metric":"calls","style":"line","tone":"primary"},
        {"id":"reuse","title":"秒传成功文件","metric":"reused-files","style":"bar","tone":"success"},
    ]
    for name, action in manifest["actions"].items():
        if name.startswith("p115-"):
            continue
        prefix = name.split("-", 1)[0]
        if name in {"user-my-info","open-user-info","user-space-info","profile-avatar"}:
            group = "profile"
        elif name in {"fs-files","fs-files-app","open-fs-list","fs-files-aps"}:
            group = "directory"
        elif prefix == "fs":
            group = "fs-" + name.split("-")[1]
        else:
            group = prefix
        action["entry"] = group
    # Keep less common filesystem commands grouped rather than emitting one file per alias.
    for action in manifest["actions"].values():
        group = action["entry"]
        if group.startswith("fs-") and group not in {"fs-files","fs-search","fs-file","fs-folder","fs-copy","fs-move","fs-edit"}:
            action["entry"] = "fs-other"
