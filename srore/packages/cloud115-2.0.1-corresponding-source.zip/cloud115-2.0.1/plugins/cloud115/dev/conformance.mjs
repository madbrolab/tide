import { readFileSync } from "node:fs";
import { createHash,createCipheriv,createDecipheriv } from "node:crypto";
import assert from "node:assert/strict";
const src = readFileSync(new URL("../main.js", import.meta.url));
const sdk = await import(
  "data:text/javascript;base64," + src.toString("base64")
);
const vectors = JSON.parse(readFileSync(0, "utf8"));
const RealDate=Date;
globalThis.Date=class extends RealDate {constructor(...args){super(...(args.length?args:[1700000000000]));}static now(){return 1700000000000;}};
let failed = 0;
function pairs(search) {
  return [...new URLSearchParams(search)].sort(([a], [b]) =>
    a.localeCompare(b),
  );
}
for (const {
  action,
  deviceUA,
  args,
  url,
  method,
  params,
  data,
  encoding,
  result,
  fixture,
  binary,
  ecdh,
  public: publicAction,
} of vectors) {
  let called = 0;
  const ctx = {
    runId: "12345678123442349234123456789012",
    crypto: { digest: async (alg, x) => createHash(alg).update(x).digest("hex"), aesCBC:async(mode,key,iv,hex)=>{const cipher=(mode==='encrypt'?createCipheriv:createDecipheriv)('aes-128-cbc',Buffer.from(key,'hex'),Buffer.from(iv,'hex'));cipher.setAutoPadding(false);return Buffer.concat([cipher.update(Buffer.from(hex,'hex')),cipher.final()]).toString('hex')} },
    http: {
      async request(options) {
        await new Promise(resolve => setTimeout(resolve, 0));
        called++;
        const actual = new URL(options.url),
          expected = new URL(url);
        if(ecdh){assert.ok(actual.searchParams.has('k_ec'));actual.searchParams.delete('k_ec');assert.equal(options.response,'hex');}
        assert.equal(
          actual.origin + actual.pathname,
          expected.origin + expected.pathname,
        );
        assert.deepEqual(
          pairs(actual.search),
          pairs([...expected.searchParams, ...params]),
        );
        if (deviceUA) assert.equal(options.headers["User-Agent"],deviceUA);
        assert.equal(options.method, method);
        if (encoding === "json")
          assert.deepEqual(JSON.parse(options.body), data);
        else assert.deepEqual(pairs(options.body || ""), pairs(data));
        assert.equal(options.credential, !publicAction);
        const body=binary?"0102":fixture||'{"state":true,"id":9007199254740993,"nested":{"k":[false,1]}}';
        if(ecdh){const json=Buffer.from(body),literal=Buffer.concat([Buffer.from([240,json.length-15]),json]),chunk=Buffer.alloc(literal.length+2);chunk.writeUInt16LE(literal.length);literal.copy(chunk,2);const pad=(16-chunk.length%16)%16,plain=Buffer.concat([chunk,Buffer.alloc(pad,pad)]);return {status:200,body:await ctx.crypto.aesCBC('encrypt','fb1a19d652f5aaf7bc651d0f69bf422f','69bf422f49960550a0ad44ec3446cb4c',plain.toString('hex'))};}
        return {
          status: 200,
          body: binary
            ? "0102"
            : fixture ||
              '{"state":true,"id":9007199254740993,"nested":{"k":[false,1]}}',
        };
      },
    },
  };
  try {
    const out = await sdk[action](ctx, args);
    assert.equal(called, 1);
    assert.deepEqual(
      out,
      binary
        ? { hex: "0102" }
        : result || {
            state: true,
            id: "9007199254740993",
            nested: { k: [false, 1] },
          },
    );
  } catch (err) {
    failed++;
    console.error(
      action + ": " + err.message.split("\n").slice(0, 12).join(" "),
    );
  }
}
console.log(vectors.length + " wire comparisons, " + failed + " failures");
process.exitCode = failed ? 1 : 0;
