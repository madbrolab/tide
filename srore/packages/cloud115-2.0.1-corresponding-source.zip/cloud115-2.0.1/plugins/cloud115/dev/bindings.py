"""Specialize pinned P115C methods to the JSON-object ABI at build time.

Only translate understood AST nodes. An unsupported branch omits the entire
method, including its aliases. No Python code or URL supplied at run time.
"""

import ast
import json
import re


class Unsupported(ValueError):
    pass


def js(x):
    return json.dumps(x, ensure_ascii=False, separators=(",", ":"))


PLATFORMS = "web desktop chrome aps android 115android ios 115ios 115ipad ipad harmony windows mac linux os_windows os_mac os_linux tv wechatmini alipaymini".split()


class Binding:
    def __init__(self, node, complete_url):
        self.node = node
        self.complete_url = complete_url
        self.domains = set()
        self.locals = set()
        self.values = {"async_": False}
        self.params = {}
        self.account_id = False
        self.binary = False
        self.dependencies = set()
        self.required = set()
        self.has_payload = False
        args = node.args.posonlyargs + node.args.args
        defaults = [None] * (len(args) - len(node.args.defaults)) + node.args.defaults
        for arg, default in zip(
            args + node.args.kwonlyargs, defaults + node.args.kw_defaults
        ):
            k = arg.arg
            if k in ("self", "cls", "async_"):
                continue
            if k == "payload":
                # Scalar conveniences are expressed as their documented wire fields.
                self.has_payload = True
                continue
            try:
                d = ast.literal_eval(default)
            except (ValueError, TypeError):
                if k not in (
                    "uid",
                    "account",
                    "password",
                    "pickcode",
                    "filename",
                    "ids",
                    "cid",
                    "id",
                    "file_id",
                    "app_id",
                ):
                    raise Unsupported("required non-payload parameter " + k)
                self.required.add(k)
                d = None
            self.values[k] = d
            if k not in ("base_url", "method", "type", "app", "version", "share_url"):
                self.params[k] = d
        # Offer an app override only if all app-dependent expressions feed the pinned URL builder.
        self.platform = False
        if isinstance(self.values.get("app"), str):
            occurrences = {
                id(x)
                for stmt in node.body[1:]
                for x in ast.walk(stmt)
                if isinstance(x, ast.Name) and x.id == "app"
            }
            in_urls = {
                id(x)
                for stmt in node.body[1:]
                for call in ast.walk(stmt)
                if isinstance(call, ast.Call)
                and ast.unparse(call.func) == "complete_url"
                for x in ast.walk(call)
                if isinstance(x, ast.Name) and x.id == "app"
            }
            self.platform = bool(occurrences) and occurrences == in_urls
        self.public = "self" not in {a.arg for a in args}
        self.required_fields = set()
        self.transport = None
        self.needs_payload = False
        self.ecdh = False

    def literal(self, n):
        if isinstance(n, ast.Name) and n.id in self.values and n.id not in self.params:
            return self.values[n.id]
        if isinstance(n, ast.JoinedStr):
            return "".join(
                str(self.literal(v.value))
                if isinstance(v, ast.FormattedValue)
                else v.value
                for v in n.values
            )
        return ast.literal_eval(n)

    def test(self, n):
        # Compute predicates whose type/values were fixed by the JSON ABI.
        if isinstance(n, ast.Call) and ast.unparse(n) == "callable(base_url)":
            return False
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.Not):
            v = self.test(n.operand)
            return None if v is None else not v
        if isinstance(n, ast.BoolOp):
            vals = [self.test(v) for v in n.values]
            if isinstance(n.op, ast.And):
                return False if False in vals else (None if None in vals else True)
            return True if True in vals else (None if None in vals else False)
        if isinstance(n, ast.Call) and ast.unparse(n.func) == "isinstance":
            name = ast.unparse(n.args[0])
            types = {p.id for p in ast.walk(n.args[1]) if isinstance(p, ast.Name)}
            if name == "payload":
                return "dict" in types
            if name == "self" and types == {"ClientRequestMixin"}:
                return True
        if isinstance(n, ast.Compare) and len(n.ops) == 1:
            if (
                ast.unparse(n.left) == "payload"
                and ast.unparse(n.comparators[0]) == "None"
            ):
                return isinstance(n.ops[0], (ast.IsNot, ast.NotEq))
            try:
                a, b = self.literal(n.left), self.literal(n.comparators[0])
                op = n.ops[0]
                if isinstance(op, (ast.Eq, ast.Is)):
                    return a == b
                if isinstance(op, (ast.NotEq, ast.IsNot)):
                    return a != b
                if isinstance(op, ast.In):
                    return a in b
                if isinstance(op, ast.NotIn):
                    return a not in b
            except (TypeError, ValueError, KeyError):
                pass
        try:
            return bool(self.literal(n))
        except (ValueError, TypeError, KeyError):
            return None

    def expr(self, n):
        try:
            return js(self.literal(n))
        except (TypeError, ValueError, KeyError):
            pass
        expr = ast.unparse(n)
        if expr == "date.today()":
            return "localDay(0)"
        if expr == "today + timedelta(days=1)":
            return "localDay(1)"
        if expr == "date.today().year":
            return "new Date().getFullYear()"
        if expr == "datetime(this_year, 1, 1).timestamp()":
            return "(new Date(this_year,0,1).getTime()/1000)"
        if expr == "datetime(this_year + 1, 1, 1).timestamp()":
            return "(new Date(this_year+1,0,1).getTime()/1000)"
        if expr == "datetime.fromtimestamp(int(payload['start_time'])).year":
            return "new Date(pyInt(payload.start_time)*1000).getFullYear()"
        if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Sub):
            return "(" + self.expr(n.left) + "-" + self.expr(n.right) + ")"
        if isinstance(n, ast.JoinedStr) and all(isinstance(x,ast.Constant) or x.format_spec is None and x.conversion == -1 for x in n.values):
            return "(" + "+".join("String("+self.expr(x.value)+")" if isinstance(x,ast.FormattedValue) else self.expr(x) for x in n.values) + ")"
        if expr == "sha1(b'%d-Points_Sign@#115-%d' % (self.user_id, t)).hexdigest()":
            self.account_id = True
            return 'ctx.crypto.digest("sha1",remoteUser(ctx,args)+"-Points_Sign@#115-"+t)'
        if expr == "md5(f'{passwd:>04}{self.user_id}62454aa2c6fd4'.encode('ascii')).hexdigest()":
            self.account_id = True
            return 'ctx.crypto.digest("md5",String(passwd).padStart(4,"0")+remoteUser(ctx,args)+"62454aa2c6fd4")'
        if isinstance(n, ast.Attribute) and ast.unparse(n) == "self.user_id":
            self.account_id = True
            return "remoteUser(ctx,args)"
        if isinstance(n, ast.Name):
            if n.id == "_app_version":
                return "version"
            if n.id in self.params:
                return "opt(args," + js(n.id) + "," + js(self.params[n.id]) + ")"
            if n.id == "payload" or n.id in self.locals:
                return n.id
        if isinstance(n, ast.Dict):
            return (
                "{"
                + ",".join(
                    "..." + self.expr(v)
                    if k is None
                    else "[" + self.expr(k) + "]:" + self.expr(v)
                    for k, v in zip(n.keys, n.values)
                )
                + "}"
            )
        if isinstance(n, (ast.Tuple, ast.List, ast.Set)):
            return "[" + ",".join(map(self.expr, n.elts)) + "]"
        if isinstance(n, ast.Subscript):
            if isinstance(n.value, (ast.Tuple, ast.List)):
                return self.expr(n.value) + "[Number(" + self.expr(n.slice) + ")]"
            return "item(" + self.expr(n.value) + "," + self.expr(n.slice) + ")"
        if isinstance(n, ast.Compare) and len(n.ops) == 1:
            a, b = self.expr(n.left), self.expr(n.comparators[0])
            if isinstance(n.ops[0], (ast.In, ast.NotIn)):
                return (
                    ("!" if isinstance(n.ops[0], ast.NotIn) else "")
                    + "contains("
                    + b
                    + ","
                    + a
                    + ")"
                )
            op = {
                ast.Eq: "===",
                ast.Is: "===",
                ast.NotEq: "!==",
                ast.IsNot: "!==",
                ast.Gt: ">",
                ast.GtE: ">=",
                ast.Lt: "<",
                ast.LtE: "<=",
            }.get(type(n.ops[0]))
            if op:
                return "(" + a + op + b + ")"
        if isinstance(n, ast.BoolOp):
            return (
                "("
                + ("||" if isinstance(n.op, ast.Or) else "&&").join(
                    map(self.expr, n.values)
                )
                + ")"
            )
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.Not):
            return "!truth(" + self.expr(n.operand) + ")"
        if isinstance(n, ast.IfExp):
            return (
                "(truth("
                + self.expr(n.test)
                + ")?"
                + self.expr(n.body)
                + ":"
                + self.expr(n.orelse)
                + ")"
            )
        if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Add):
            return "(" + self.expr(n.left) + "+" + self.expr(n.right) + ")"
        if (
            isinstance(n, ast.BinOp)
            and isinstance(n.op, ast.BitAnd)
            and ast.unparse(n.left) == "payload.keys()"
        ):
            return self.expr(n.right) + ".some(k=>Object.hasOwn(payload,k))"
        if isinstance(n, ast.NamedExpr) and isinstance(n.target, ast.Name):
            self.locals.add(n.target.id)
            return "(" + n.target.id + "=" + self.expr(n.value) + ")"
        if isinstance(n, ast.Call):
            fn = ast.unparse(n.func)
            if fn == "complete_url":
                try:
                    u = self.complete_url(
                        *[self.literal(a) for a in n.args],
                        **{k.arg: self.literal(k.value) for k in n.keywords},
                    )
                except (ValueError, TypeError, KeyError):
                    raise Unsupported("variable endpoint")
                from urllib.parse import urlsplit

                parts = urlsplit(u)
                if parts.scheme != "https" or not (
                    parts.netloc == "115.com" or parts.netloc.endswith(".115.com")
                ):
                    raise Unsupported("non-HTTPS or external endpoint")
                self.domains.add(parts.netloc)
                if self.platform and any(
                    isinstance(x, ast.Name) and x.id == "app" for x in ast.walk(n)
                ):
                    return self.platform_url(n, u)
                return js(u)
            if fn == "isinstance":
                v = self.test(n)
                if v is not None:
                    return js(v)
            if fn == "dict" and len(n.args) <= 1 and all(k.arg for k in n.keywords):
                items = ["..." + self.expr(a) for a in n.args] + [
                    "[" + js(k.arg) + "]:" + self.expr(k.value) for k in n.keywords
                ]
                return "{" + ",".join(items) + "}"
            if fn == "request_kwargs.get" and self.literal(n.args[0]) == "method":
                return self.expr(n.args[1]) if len(n.args) > 1 else js("")
            if fn == "time":
                return "(Date.now()/1000)"
            if fn == "uuid4":
                return "requestUUID(ctx)"
            if fn == "format" and self.literal(n.args[1]) == ">06":
                return "String(" + self.expr(n.args[0]) + ').padStart(6,"0")'
            if fn == "cast":
                return self.expr(n.args[1])
            if fn in ("str", "int", "bool", "len", "frozenset"):
                f = {
                    "str": "String",
                    "int": "pyInt",
                    "bool": "truth",
                    "len": "size",
                    "frozenset": "",
                }[fn]
                return f + "(" + self.expr(n.args[0]) + ")"
            if isinstance(n.func, ast.Attribute) and n.func.attr in (
                "get",
                "setdefault",
                "upper",
                "lower",
                "startswith",
                "endswith",
                "strip",
                "rstrip",
                "lstrip",
            ):
                arg = ",".join(self.expr(a) for a in n.args)
                owner = self.expr(n.func.value)
                f = n.func.attr
                if f in (
                    "get",
                    "setdefault",
                    "startswith",
                    "endswith",
                    "strip",
                    "rstrip",
                    "lstrip",
                ):
                    return f + "(" + owner + ("," + arg if arg else "") + ")"
                return (
                    owner
                    + "."
                    + ("toUpperCase" if f == "upper" else "toLowerCase")
                    + "()"
                )
            if fn == "md5_secret_password":
                return "secretPassword(ctx," + self.expr(n.args[0]) + ")"
        raise Unsupported("expression " + ast.unparse(n)[:75])

    def platform_url(self, n, original):
        default = self.values["app"]
        urls = {}
        try:
            for app in dict.fromkeys([default] + PLATFORMS):
                self.values["app"] = app
                urls[app] = self.complete_url(
                    *(self.literal(a) for a in n.args),
                    **{k.arg: self.literal(k.value) for k in n.keywords},
                )
        finally:
            self.values["app"] = default
        if len(set(urls.values())) == 1:
            return js(original)
        # Literal path segments and normalised /{app}/ prefixes are the two upstream forms.
        for match in re.finditer("ios", urls["ios"]):
            pos = match.start()
            before, after = urls["ios"][:pos], urls["ios"][pos + 3 :]
            for normalize in (False, True):

                def segment(a):
                    if not normalize:
                        return a
                    if a in ("windows", "mac", "linux"):
                        return "os_" + a
                    if a in (
                        "ios",
                        "115ios",
                        "115ipad",
                        "android",
                        "115android",
                        "harmony",
                        "os_windows",
                        "os_mac",
                        "os_linux",
                    ):
                        return a
                    return (
                        "ios"
                        if a.endswith("ios")
                        else "115ipad"
                        if a.endswith("ipad")
                        else "android"
                    )

                if all(u == before + segment(a) + after for a, u in urls.items()):
                    return (
                        js(before)
                        + "+platform(args,"
                        + js(default)
                        + ","
                        + js(normalize)
                        + ")+"
                        + js(after)
                    )
        return "appEndpoint(args," + js(default) + "," + js(urls) + ")"

    def request(self, call):
        kw = {k.arg: k.value for k in call.keywords if k.arg not in ("async_", None)}
        if len(call.args) == 1 and "url" not in kw:
            kw["url"] = call.args[0]
        if len(call.args) > 1 or set(kw) - {
            "url",
            "method",
            "params",
            "data",
            "json",
            "payload",
        }:
            raise Unsupported("special HTTP transport")
        url = self.expr(kw["url"])
        method = self.literal(kw["method"]) if "method" in kw else "GET"
        if method not in ("GET", "POST", "PUT", "DELETE", "PATCH"):
            raise Unsupported("HTTP method")
        if "payload" in kw:
            kw["data" if method in ("PUT", "POST") else "params"] = kw.pop("payload")
        p = self.expr(kw["params"]) if "params" in kw else "query"
        b = self.expr(kw["data"]) if "data" in kw else "body"
        if self.ecdh:
            return 'encryptedSend(ctx,'+url+','+js(method)+','+p+','+b+','+js(self.public)+')'
        if self.binary:
            return (
                "sendBytes(ctx,"
                + url
                + ","
                + js(method)
                + ","
                + p
                + ","
                + b
                + ","
                + js(not self.public)
                + ")"
            )
        if "json" in kw:
            return (
                ("sendPublic" if self.public else "send")
                + "(ctx,"
                + url
                + ","
                + js(method)
                + ","
                + p
                + ","
                + self.expr(kw["json"])
                + ",true)"
            )
        return (
            ("sendPublic" if self.public else "send")
            + "(ctx,"
            + url
            + ","
            + js(method)
            + ","
            + p
            + ","
            + b
            + ")"
        )

    def statements(self, block):
        out = []
        for n in block:
            if isinstance(n, ast.If):
                t = self.test(n.test)
                if t is not None:
                    out += self.statements(n.body if t else n.orelse)
                else:
                    test = self.expr(n.test)
                    a = self.statements(n.body)
                    b = self.statements(n.orelse)
                    out.append(
                        "if(truth("
                        + test
                        + ")){"
                        + "".join(a)
                        + "}"
                        + ("else{" + "".join(b) + "}" if b else "")
                    )
            elif isinstance(n, ast.Assign) and len(n.targets) == 1:
                target = n.targets[0]
                if (
                    isinstance(target, ast.Tuple)
                    and isinstance(n.value, ast.Call)
                    and ast.unparse(n.value.func) == "get_request"
                ):
                    self.transport = self.request(n.value)
                    continue
                if (
                    ast.unparse(target) == "request_kwargs['self']"
                    and ast.unparse(n.value) == "self"
                ):
                    continue
                v = self.expr(n.value)
                if isinstance(target, ast.Name):
                    k = target.id
                    if k in self.values and k not in self.params:
                        self.values[k] = self.literal(n.value)
                        continue
                    if k != "payload":
                        self.locals.add(k)
                    out.append(k + "=" + v + ";")
                elif isinstance(target, ast.Subscript):
                    if ast.unparse(target.value) == "request_kwargs":
                        k = self.literal(target.slice)
                        if k not in ("data", "params"):
                            raise Unsupported("request options")
                        out.append(("body" if k == "data" else "query") + "=" + v + ";")
                    elif ast.unparse(target.value) == "payload":
                        out.append(
                            "payload[" + self.expr(target.slice) + "]=" + v + ";"
                        )
                    else:
                        raise Unsupported("indirect assignment")
                else:
                    raise Unsupported("assignment")
            elif isinstance(n, ast.Expr):
                call = n.value
                if (
                    isinstance(call, ast.Call)
                    and ast.unparse(call.func) == "request_kwargs.setdefault"
                ):
                    if (
                        ast.unparse(call.args[0]) == "'parse'"
                        and ast.unparse(call.args[1]) == "False"
                    ):
                        self.binary = True
                        continue
                    if (
                        ast.unparse(call.args[0]) == "'follow_redirects'"
                        and ast.unparse(call.args[1]) == "False"
                    ):
                        continue
                    if ast.unparse(call.args[0]) == "'ecdh_encrypt'" and ast.unparse(call.args[1]) == 'True':
                        self.ecdh = True
                        continue
                out.append(self.expr(n.value) + ";")
            elif isinstance(n, ast.Return) and isinstance(n.value, ast.Call):
                call = n.value
                fn = ast.unparse(call.func)
                if fn == "self.request":
                    out.append("return " + self.request(call) + ";")
                elif fn == "request" and self.transport:
                    out.append("return " + self.transport + ";")
                elif fn == "self.clouddownload_request":
                    action = self.literal(
                        call.args[1]
                        if len(call.args) > 1
                        else next(k.value for k in call.keywords if k.arg == "action")
                    )
                    method = self.values.get("method", "POST")
                    self.domains.add("clouddownload.115.com")
                    p = "payload" if call.args else "{}"
                    out.append(
                        "return offlineWire(ctx,"
                        + js(action)
                        + ","
                        + js(method)
                        + ","
                        + p
                        + ");"
                    )
                elif fn in ("self._fs_edit_set", "self._fs_edit_set_app"):
                    extras=''.join(','+k.arg+':'+self.expr(k.value) for k in call.keywords if k.arg=='app')
                    attr = self.literal(call.args[1])
                    value = (
                        call.args[2]
                        if len(call.args) > 2
                        else next(k.value for k in call.keywords if k.arg == "default")
                    )
                    route = "fs_files_update_app" if fn.endswith("_app") else "fs_edit"
                    domain = (
                        "proapi.115.com" if fn.endswith("_app") else "webapi.115.com"
                    )
                    self.domains.add(domain)
                    self.dependencies.add(route)
                    out.append(
                        "setdefault(payload,"
                        + js(attr)
                        + ","
                        + self.expr(value)
                        + ");return do_"
                        + route
                        + "(ctx,{payload"+extras+"});"
                    )
                elif fn in (
                    "self.fs_update_open",
                    "self.life_glist",
                    "self.life_set_top",
                    "self.fs_folder_update_app",
                    "self.fs_dir_getid2",
                    "self.fs_batch_edit",
                ):
                    extras=''.join(','+k.arg+':'+self.expr(k.value) for k in call.keywords if k.arg=='app')
                    route = "open_fs_update" if fn == "self.fs_update_open" else fn[5:]
                    self.domains.add(
                        "proapi.115.com"
                        if "open" in route or "app" in route
                        else "life.115.com"
                        if "life_" in route
                        else "webapi.115.com"
                    )
                    self.dependencies.add(route)
                    if route == "fs_folder_update_app":
                        self.account_id = True
                        out.append(
                            "return do_"
                            + route
                            + "(ctx,{payload,userId:remoteUser(ctx,args)"+extras+"});"
                        )
                    else:
                        out.append("return do_" + route + "(ctx,{payload"+extras+"});")
                else:
                    raise Unsupported("delegation " + fn)
            elif isinstance(n, ast.Pass):
                continue
            else:
                raise Unsupported(type(n).__name__)
        return out

    def compile(self):
        if self.node.name in ("request", "clouddownload_request"):
            raise Unsupported("transport control")
        if not ast.get_docstring(self.node):
            raise Unsupported("no public protocol documentation")
        block = self.statements(self.node.body[1:])
        if not any("return " in line for line in block) or not self.domains:
            raise Unsupported("no concrete endpoint")
        if self.locals - {"api", "payload", "query", "body"} & {
            "default",
            "class",
            "new",
            "var",
            "let",
            "const",
            "delete",
        }:
            raise Unsupported("reserved local")
        return "".join(block)
