"""Package only plugin preferred source and its public build dependencies."""
from pathlib import Path
import json, sys, zipfile

plugin = Path(__file__).resolve().parents[1]
root = plugin.parents[1]
version = json.loads((plugin / 'manifest.json').read_text())['version']
target = Path(sys.argv[1])
files = []
for name in ('manifest.json','operations.json','migrations.json','icon.png','main.js','qr-devices.json','NOTICE.txt','README.md','package.json','package-lock.json'):
    files.append(plugin / name)
for directory, extensions in (('src',{'.js'}),('dev',{'.py','.mjs'}),('tests',{'.mjs'})):
    files.extend(p for p in (plugin / directory).iterdir() if p.is_file() and p.suffix in extensions)
files.extend((root / 'docs/115模块').glob('P115C*.tsv'))
for name in ('pack.mjs','package.json','package-lock.json','recipient-public.pem'):
    files.append(root / 'sdk/packager' / name)
files.append(root / 'sdk/tide.d.ts')
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for file in sorted(files):
        archive.write(file, f'cloud115-{version}/' + str(file.relative_to(root)))
    archive.writestr(f'cloud115-{version}/BUILD.txt',
        f'Corresponding source for cloud115 {version} (GPL-3.0-only).\n'
        'Only plugin source, public SDK types and public developer packager are included.\n'
        'Install Node.js 22+ (24 recommended); npm ci --prefix plugins/cloud115; npm ci --prefix sdk/packager.\n'
        'Build: node sdk/packager/pack.mjs --dir plugins/cloud115 --out cloud115.zip\n'
        'Generation and optional offline protocol comparisons need Python 3.12+; see plugins/cloud115/README.md.\n'
        'Upstream source: https://github.com/ChenyangGao/p115client/tree/856e4f8f09ce034534bd458f06d3dee4474a1698\n'
        'Encryption uses a fresh nonce; byte-for-byte encrypted ZIP reproducibility is not expected.\n')
print(target.name, target.stat().st_size)
