"""JSON equivalents of public utilities, constants and Python value types."""
import ast
import csv
import json
import re
from pathlib import Path
from shapes import RAW, TEXT, INT, BOOL, NUMBER, array, typ
from library_ops import VALUE

def literal_constants(path):
    values={}
    for node in ast.parse(path.read_text()).body:
        if not isinstance(node,ast.AnnAssign):continue
        try:values[ast.unparse(node.target)]=ast.literal_eval(node.value)
        except (ValueError,TypeError):pass
    return values

def extend(reg,checkout,doc):
    values=literal_constants(checkout/'const.py')
    values['SSOENT_TO_APP']={v:k for k,v in reversed(values['APP_TO_SSOENT'].items())}
    values['TYPE_TO_SUFFIXES']={}
    for k,v in values['SUFFIX_TO_TYPE'].items():values['TYPE_TO_SUFFIXES'].setdefault(v,[]).append(k)
    # Reproduce the pinned client's final reflection pass without importing it.
    inherited={}
    classes=[n for n in ast.parse((checkout/'client.py').read_text()).body if isinstance(n,ast.ClassDef)]
    for name in ('ClientRequestMixin','P115OpenClient','P115Client'):
        cls=next(n for n in classes if n.name==name)
        for n in cls.body:
            if isinstance(n,ast.FunctionDef):inherited[n.name]=ast.get_docstring(n) or ''
            elif isinstance(n,ast.Assign) and isinstance(n.value,ast.Name):
                for target in n.targets:
                    if isinstance(target,ast.Name):inherited[target.id]=inherited.get(n.value.id,'')
    methods={}
    for name,description in sorted(inherited.items()):
        match=re.search(r'^ *((?:GET|POST|PUT|DELETE|PATCH) +.+)',description,re.M)
        if match:methods['P115Client.'+name]=match[1]
    values['CLIENT_METHOD_API_MAP']=methods
    values['CLIENT_API_METHODS_MAP']={}
    for name,api in methods.items():values['CLIENT_API_METHODS_MAP'].setdefault(api,[]).append(name)
    for filename,prefix in [('history','HISTORY'),('life','BEHAVIOR')]:
        names=literal_constants(checkout/('tool/'+filename+'.py'))[prefix+'_NAME_TO_TYPE']
        values[prefix+'_NAME_TO_TYPE']=names;values[prefix+'_TYPE_TO_NAME']={v:k for k,v in names.items()}
    values['errno2error']={'EACCES':'P115AccessError','EBADF':'P115BadFile','EFBIG':'P115FileTooBig','EAUTH':'P115AuthenticationError','EBUSY':'P115BusyOSError','ENODATA':'P115DataError','ENOENT':'P115FileNotFoundError','EINVAL':'P115InvalidArgumentError','ENOSPC':'P115NoSpaceError','ENOTSUP':'P115NotSupportedError','ENOSYS':'P115NotSupportedError','ERANGE':'P115ExceededError'}
    values['STAT_MODE']={'drive':0o777,'share':0o444,'zip':0o444}
    values['NO_INCREMENT']={'drive':False,'share':True,'zip':True}
    reg.migrations+=['CREATE TABLE IF NOT EXISTS support_cache(key TEXT PRIMARY KEY,value TEXT NOT NULL)', 'CREATE TABLE IF NOT EXISTS support_constants(name TEXT PRIMARY KEY,value TEXT NOT NULL)']
    for name,value in sorted(values.items()):
        encoded=json.dumps(value,ensure_ascii=False,separators=(',',':')).replace("'","''")
        reg.migrations.append("INSERT INTO support_constants(name,value) VALUES('"+name+"','"+encoded+"')")
    reg.migrations.append('CREATE TABLE IF NOT EXISTS checkpoints(id TEXT NOT NULL,part INTEGER NOT NULL,created INTEGER NOT NULL,value TEXT NOT NULL,PRIMARY KEY(id,part))')
    reg.migrations.append('CREATE TABLE IF NOT EXISTS file_job_runs(job TEXT PRIMARY KEY,created INTEGER NOT NULL,complete INTEGER NOT NULL DEFAULT 0,planned INTEGER NOT NULL DEFAULT 0,processed INTEGER NOT NULL DEFAULT 0)')
    reg.add('support-constant','await supportConstant(ctx,args)',{'name':TEXT,'key':TEXT},kind=None,required=['name'],notes='常量按名称读取；可用 key 只返回单个键。ID_TO_DIRNODE_CACHE 对应 index-import / index-*，按 index 隔离。')
    fields={'value':VALUE,'path':TEXT,'base_url':TEXT,'app':TEXT,'version':TEXT,'domain':TEXT,'force_app':typ('boolean|array','强制客户端前缀',items=TEXT),'query':typ('string|object|array','查询字符串、字典或键值对',additionalProperties=True,items=array('键值对',VALUE)),'size':NUMBER,'min_part_size':INT,'max_part_count':INT,'repl':TEXT,'host':TEXT,'user_id':NUMBER,'key':TEXT,'ttl_ms':INT,'call':RAW}
    functions='call_with_lock complete_url determine_part_size get_stable_point get_user_key is_valid_id is_valid_name is_valid_pickcode is_valid_sha1 load_final_image max_image_quality normalize_pickcode posix_escape_name reduce_image_url_layers set_stable_point set_user_key share_extract_payload to_cdn_url unescape_115_charref'.split()
    for name in functions:
        required=['key','call'] if name=='call_with_lock' else ['size'] if name=='determine_part_size' else ['user_id'] if name.startswith('get_') else [] if name=='complete_url' else ['value']
        if name.startswith('set_'):required+=['user_id']
        reg.add('util-'+name.replace('_','-'),'await supportValue(ctx,args,'+json.dumps(name)+')',fields,kind=None,required=required)
    reg.add('support-value','jsonType(args)',{'operation':TEXT,'value':VALUE,'key':TEXT,'default':VALUE,'updates':RAW},kind=None,notes='Python 数据类型以普通 JSON 值表示；of / mapping / derive / derive_backend / keys / values / items / get / geturl / UID / CID / KID / SEID。')
    for name,expr in [('error','supportError(args)'),('throw','supportError(args,true)'),('check-url','supportError(args)')]:
        reg.add('support-'+name,expr,{'type':TEXT,'errno':INT,'message':VALUE,'url':TEXT},kind=None)

    inventory=list(csv.DictReader((doc/'P115C能力清单.tsv').open(),delimiter='\t'))
    extra={}
    for row in inventory:
        ref=row['源码标识'];suffix=ref.rsplit('.',1)[-1]
        if ref in reg.coverage:continue
        if row['层级']=='仓库扩展':
            extra[ref]=('', '独立仓库程序；挂载/协议服务不打包，库内算法另列动作')
        elif ref.startswith('p115client.util.'):
            extra[ref]=('client-lock' if suffix=='lock_as_async' else 'util-'+suffix.replace('_','-'),'JSON 参数；锁为有期限的跨调用租约')
        elif suffix=='ID_TO_DIRNODE_CACHE':extra[ref]=('index-import / index-*','SQLite 目录缓存，按 index 隔离，替代进程全局字典')
        elif suffix in values:extra[ref]=('support-constant', 'name='+suffix)
        elif ref.startswith('p115client.exception.'):
            extra[ref]=('support-check-url' if suffix=='raise_for_bad' else 'support-throw' if suffix=='throw' else 'support-error','异常类型以 {type,code,errno,message} 表示；抛出时转换为 SDK 错误')
        elif ref.startswith('p115client.type.'):extra[ref]=('support-value','普通 JSON 值保留字段；映射方法由 operation 指定，不创建 Python 对象')
        elif ref.startswith('p115client.client.'):
            extra[ref]=('client-from-path' if suffix=='cookies_path' else 'client-init','显式加密 session；app_id / path 为输入字段')
        elif 'P115QueryDB' in ref:extra[ref]=('index-init','以 index 名称标识持久查询实例')
        elif 'P115MultipartUpload' in ref:extra[ref]=('multipart-init','以加密 state 标识分片会话')
        elif ref.startswith('p115client.fs.'):
            extra[ref]=('vfs-path-class' if suffix=='path_class' else 'vfs-create','文件系统为 scope / cid 状态，路径为 JSON 属性；每次刷新读取，full_loaded 不作跨调用隐式缓存')
        else:raise ValueError('unclassified public definition '+ref)
    with (doc/'P115C完整覆盖.tsv').open('w') as file:
        writer=csv.writer(file,delimiter='\t',lineterminator='\n')
        writer.writerow(['源码标识','层级','宿主动作或表示','适配说明','固定版本源码'])
        for row in inventory:
            action,note=reg.coverage.get(row['源码标识'],extra.get(row['源码标识'],('','未分类')))
            writer.writerow([row['源码标识'],row['层级'],action,note,row['固定版本源码']])
