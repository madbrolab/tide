"""Small connection helpers whose wire protocol needs signing, crypto, or an open file."""

import json
from shapes import typ, obj, array, RAW, TEXT, NUMBER, ID, INT, BOOL


def extend(ops, manifest, src, coverage, rows):
    definitions = {r[1]: r[2] for r in rows}

    def add(
        name,
        label,
        kind,
        expression,
        params,
        result,
        sample,
        output,
        refs=(),
        required=(),
        file=False,
        optional=False,
        metric=None,
    ):
        action = dict(
            label=label, external=True, immediateOnly=True
        )
        if kind:
            action["inlineCredential"] = kind
        if file:
            action["sourceFile"] = True
        if optional:
            action["optionalSource"] = True
        if metric:
            action["countWhen"] = [
                dict(metric="reused-files", path=metric[0], equals=metric[1])
            ]
        manifest["actions"][name] = action
        ops[name] = dict(
            summary=label,
            input=obj("调用参数", params, required),
            output=result,
            notes=("uuid 标识 115 账号，credential.inline 只用于本次调用。" if kind else "传入账号 uuid 共享限速，图片请求不携带账号凭据。")
            + (" 文件句柄在本次调用结束时释放。" if file else ""),
            example=dict(args=sample, result=output),
        )
        checks = "".join("item(args," + json.dumps(k) + ");" for k in required)
        fn = "op_" + name.replace("-", "_")
        src.append(
            "function "
            + fn
            + "(ctx,args){"
            + checks
            + "return "
            + expression
            + ";}export{"
            + fn
            + " as "
            + json.dumps(name)
            + "};"
        )
        for ref in refs:
            coverage[definitions[ref]] = (name, "无状态连接适配")

    add("profile-avatar", "读取官方账号头像缩略图", None, "profileAvatar(ctx,args.url)",
        {"url": TEXT}, obj("头像图片", {"image": TEXT}, ["image"]),
        {"url": "https://avatars.115.com/example.jpg"}, {"image":"data:image/jpeg;base64,/9j/"}, required=["url"])
    source = dict(
        sourceRef=typ("string", "调用方通过 ctx.fs.source 委托的文件"),
        sourcePath=typ("string", "管理员直接调用时可指定 NAS 文件"),
    )
    pick = dict(
        pickcode=typ("string", "115 文件提取码，批量可用逗号分隔"),
        userAgent=typ("string", "获取直链及读取内容时使用的 UA"),
        strict=BOOL,
    )
    links = obj(
        "直链与下载请求头",
        dict(
            id=ID,
            name=TEXT,
            size=NUMBER,
            is_dir=BOOL,
            pickcode=TEXT,
            sha1=TEXT,
            url=TEXT,
            headers=RAW,
        ),
    )
    example = dict(
        id="1",
        name="a",
        size=1,
        is_dir=False,
        pickcode="sample",
        sha1="",
        url="https://example.invalid/a",
        headers={"user-agent": ""},
    )
    add(
        "shares",
        "我的分享",
        "cookie",
        "do_share_list(ctx,{payload:{offset:args.offset??0,limit:args.limit??30,...args.payload}})",
        dict(limit=INT, offset=INT, payload=RAW),
        ops["share-list"]["output"],
        {"limit": 20},
        {"state": True, "list": []},
    )
    add(
        "offline",
        "离线列表",
        "any",
        '(ctx.connection().kind==="cookie"?do_clouddownload_task_list:do_open_clouddownload_task_list)(ctx,{payload:{page:args.page??1,page_size:args.pageSize??30,stat:args.stat??0,...args.payload}})',
        dict(page=INT, pageSize=INT, stat=INT, payload=RAW),
        RAW,
        {"page": 2},
        {"state": True},
    )
    add(
        "instant",
        "秒传",
        "any",
        "instant(ctx,args)",
        dict(
            filename=TEXT,
            sha1=TEXT,
            sizeBytes=INT,
            remoteDir=ID,
            dirname=TEXT,
            **source,
        ),
        obj("秒传确认", dict(outcome=TEXT, data=RAW, reason=TEXT)),
        dict(
            filename="a", sizeBytes=0, sha1="DA39A3EE5E6B4B0D3255BFEF95601890AFD80709"
        ),
        {"outcome": "reused"},
        required=["filename", "sizeBytes", "sha1"],
        file=True,
        optional=True,
        metric=("outcome", "reused"),
    )
    for mode, kind in [("cookie", "cookie"), ("open", "bearer")]:
        prefix = "client." + mode + "."
        modearg = json.dumps(mode)
        opts = dict(pick)
        if mode == "cookie":
            opts.update(userId=ID, shareId=ID)
        for k, exp, out, ex, method in [
            (
                "one",
                "downloadLinks(ctx,args," + modearg + ",true)",
                links,
                example,
                "download_url",
            ),
            (
                "many",
                "downloadLinks(ctx,args," + modearg + ",false)",
                array("直链", links),
                [example],
                "download_urls",
            ),
            (
                "info",
                "downloadInfo(ctx,args," + modearg + ")",
                RAW,
                {"state": True},
                "download_url_app" if mode == "cookie" else "download_url_info",
            ),
        ]:
            refs = [prefix + method] + (
                [prefix + method + "_open"] if mode == "open" else []
            )
            add(
                "link-" + mode + "-" + k,
                "文件下载链接 · " + k,
                kind,
                exp,
                opts,
                out,
                {"pickcode": "sample"},
                ex,
                refs,
                ["pickcode"],
            )
        for k in ("range", "text", "hash"):
            fields = dict(opts, offset=INT, length=INT)
            if k == "hash":
                fields["digests"] = array("摘要算法", TEXT)
            add(
                "content-" + mode + "-" + k,
                "直链内容 · " + k,
                kind,
                "contentView(ctx,args," + modearg + "," + json.dumps(k) + ")",
                fields,
                RAW,
                {"pickcode": "sample", "length": 1},
                {"bytes": 1},
                required=["pickcode"],
            )
        opts = dict(
            source, filename=TEXT, pid=ID, dirname=TEXT, sha1=TEXT, partSize=INT
        )
        for k, fn, method, ex, metric in [
            (
                "prepare",
                "prepareUpload",
                "upload_file_init",
                {"status": 2},
                ("status", "2"),
            ),
            (
                "file",
                "uploadSource",
                "upload_file",
                {"outcome": "uploaded"},
                ("outcome", "reused"),
            ),
        ]:
            add(
                "upload-" + mode + "-" + k,
                "委托文件上传 · " + k,
                kind,
                fn + "(ctx,args," + modearg + ")",
                opts,
                RAW,
                {"filename": "a", "sourceRef": "run.handle"},
                ex,
                [prefix + method]
                + ([prefix + method + "_open"] if mode == "open" else []),
                ["filename"],
                True,
                metric=metric,
            )
    for mode, ref in [
        ("file", "download_url_web"),
        ("redirect", "download_url_web2"),
        ("team", "usershare_download_url_web"),
        ("extract-web", "extract_download_url_web"),
        ("extract-app", "extract_download_url_app"),
    ]:
        form = dict(pick, shareId=ID, method=TEXT, payload=RAW, app=TEXT)
        add(
            "download-" + mode,
            "Web / 应用端下载信息 · " + mode,
            "cookie",
            "webLink(ctx,args," + json.dumps(mode) + ")",
            form,
            RAW,
            {"pickcode": "sample"},
            {"state": True},
            ["client.cookie." + ref],
        )
    for name, fn, ref, file in [
        ("upload-form-init", "sampleInit", "upload_sample_init", False),
        ("upload-form-file", "sampleUpload", "upload_file_sample", True),
    ]:
        add(
            name,
            "表单上传",
            "cookie",
            fn + "(ctx,args)",
            dict(source, filename=TEXT, pid=ID, dirname=TEXT),
            RAW,
            {"filename": "a"},
            {"state": True},
            ["client.cookie." + ref],
            ["filename"],
            file,
        )
    for suffix, kind, mode in [
        ("share-download-url","cookie","regular"),
        ("share-skip-login-download-url",None,"skip"),
        ("share-skip-login-download-url-web",None,"web"),
        ("share-skip-login-download-url-app",None,"app"),
    ]:
        add(suffix, "分享文件直链", kind, "shareDirect(ctx,args,"+json.dumps(mode)+")",
            dict(payload=RAW, shareUrl=TEXT, app=TEXT, strict=BOOL), RAW,
            {"payload":{"share_code":"demo","receive_code":"abcd","file_id":"1"}}, {},
            ["client.cookie."+suffix.replace("-","_")], ["payload"])
    add("extract-list","读取压缩包目录的一页","cookie","archiveList(ctx,args)",
        dict(pickcode=TEXT,path=TEXT,nextMarker=TEXT,pageCount=INT,app=TEXT),RAW,
        {"pickcode":"sample","pageCount":20},{"state":True},["client.cookie.extract_list"],["pickcode"])
    for name,avatar in [("upload-avatar",True),("upload-image",False)]:
        add(name, "上传账号头像" if avatar else "上传认证图片", "cookie",
            "uploadPicture(ctx,args,"+json.dumps(avatar)+")",dict(source,app=TEXT),RAW,
            {"sourceRef":"run.handle"},{"state":True},["client.cookie."+name.replace("-","_")],file=True)
    add("captcha-verify","验证验证码","cookie","captchaVerify(ctx,args)",dict(payload=RAW),RAW,
        {"payload":{"code":"1234"}},{"state":True},["client.cookie.captcha_verify"],["payload"])
    add("fs-score-set","设置文件评分","cookie",
        'send(ctx,web+"/files/score","POST",null,{file_id:(Array.isArray(args.fileId)?args.fileId:[args.fileId]).map(remoteId).join(","),score:args.score??0})',
        {"fileId":typ("string|integer|array","文件 ID 或 ID 列表",items=NUMBER),"score":INT},RAW,
        {"fileId":"123","score":4},{"state":True},["client.cookie.fs_score_set"],["fileId"])
    add("fs-video-m3u8","读取视频播放列表","cookie",
        'sendBytes(ctx,"https://115.com/api/video/m3u8/"+encodeURIComponent(args.pickcode) +".m3u8?definition="+encodeURIComponent(args.definition??0),"GET",null,null,true)',
        {"pickcode":TEXT,"definition":INT},RAW,{"pickcode":"sample"},{"hex":"234558544d3355"},["client.cookie.fs_video_m3u8"],["pickcode"])
    if "open-upload-init" in manifest["actions"]:
        manifest["actions"]["open-upload-init"]["countWhen"] = [
            dict(metric="reused-files", path="data.status", equals="2")
        ]
