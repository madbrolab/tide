import json
from shapes import RAW,TEXT,NUMBER,INT,BOOL,typ

def extend(reg):
    add=reg.add
    session={'session':TEXT,'kind':TEXT,'cookies':typ('string|object|null','显式 Cookie，不读取其他模块私密数据',additionalProperties=True),'headers':RAW,'uuid':TEXT,'path':TEXT,'access_token':TEXT,'refresh_token':TEXT,'app':TEXT,'app_id':INT}
    for method,refs in [('init',['client.cookie.init','client.open.init']),('from_path',['client.cookie.from_path']),('cookies',['client.common.cookies']),('cookies_str',['client.common.cookies_str']),('headers',['client.common.headers']),('update_cookies',['client.common.update_cookies']),('user_id',['client.common.user_id']),('login_ssoent',['client.cookie.login_ssoent'])]:
        add('client-'+method.replace('_','-'),'await clientState(ctx,args,'+json.dumps(method)+')',session,refs,kind=None)
    add('client-lock','await clientLock(ctx,args)',{'key':TEXT,'ttl_ms':INT,'release':BOOL,'token':TEXT},['client.common.request_lock','client.common.request_alock'],kind=None,required=['key'],notes='跨动作互斥锁使用有期限的 JSON 租约，释放必须提供 token。')
    add('client-request','await genericRequest(ctx,args)',{'url':TEXT,'method':TEXT,'headers':RAW,'payload':RAW,'body':TEXT,'raw':BOOL,'check':BOOL,'ecdh_encrypt':BOOL,'credential':BOOL},['client.common.request'],kind='any',required=['url'])
    add('clouddownload-request','await offlineRequest(ctx,args)',{'payload':RAW,'action':TEXT,'method':TEXT,'type':TEXT},['client.cookie.clouddownload_request'])
    add('client-user-key','ensureOK(await do_upload_info(ctx,{})).userkey',{},['client.cookie.user_key'])
    add('client-check-response','ensureOK(args.response)',{'response':RAW},['client.support.check_response'],kind=None,required=['response'])
    add('client-to-id','pickToId(args.value)',{'value':NUMBER},['client.open.to_id'],kind=None,required=['value'])
    add('client-to-pickcode','idToPick(args.value,await accountStable(ctx,args),args.prefix??"a")',{'value':NUMBER,'stable_point':TEXT,'prefix':TEXT},['client.open.to_pickcode'],required=['value'])
    add('client-pickcode-stable-point','await accountStable(ctx,args)',{'pickcode':TEXT,'stable_point':TEXT},['client.open.pickcode_stable_point','tool.attr.get_pickcode_stable_point'])
    for method,refs in [('area',['client.common.app_area_list']),('face',['client.common.app_face_codes']),('authorize',['client.common.login_authorize_open']),('logout',['client.cookie.logout_by_app']),('avatar2',['client.cookie.upload_avatar2'])]:
        add('client-'+method,'await clientStatic(ctx,args,'+json.dumps(method)+')',{'payload':RAW,'app':TEXT,'path':TEXT,'base64':TEXT},refs,kind='cookie' if method in ('logout','avatar2') else None)
    add('client-password-login','await passwordLogin(ctx,args)',{'app':TEXT,'account':TEXT,'password':TEXT,'device_id':TEXT,'code':TEXT,'code_id':TEXT,'sms_code':TEXT,'session':RAW},['client.common.login_with_password'],kind=None,required=['account'],notes='返回短信/验证码状态；后续显式调用续接。')
    add('client-open','({url:args.url,headers:args.headers??{},offset:args.start??0,readAction:"client-read-range",seekable:true})',{'url':TEXT,'headers':RAW,'start':INT},['client.common.open'],kind=None,required=['url'])
    add('client-read-range','await scopedContent(ctx,{size:args.size,id:"external",is_dir:false},{...args,offset:args.start??0,length:args.length??65536},"read")',{'url':TEXT,'headers':RAW,'size':INT,'start':INT,'length':INT},[],kind=None,required=['url','size'])
    # Login actions are public discovery flows and never queued with credentials.
    for name in ['client-init','client-from-path','client-password-login','client-authorize']:
        reg.manifest['actions'][name]['bootstrap']=True
    reg.manifest['domains']=sorted(set(reg.manifest['domains'])|{'cdnres.115.com','job.115.com','my.115.com'})
