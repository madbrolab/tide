import json
from library_ops import FIELDS,PATH
from shapes import RAW,TEXT,NUMBER,INT,BOOL,array,typ

MIGRATIONS=[
    "CREATE TABLE IF NOT EXISTS nodes(index_key TEXT NOT NULL,id TEXT NOT NULL,parent_id TEXT NOT NULL DEFAULT '0',name TEXT NOT NULL DEFAULT '',sha1 TEXT NOT NULL DEFAULT '',size TEXT NOT NULL DEFAULT '0',pickcode TEXT NOT NULL DEFAULT '',mtime INTEGER NOT NULL DEFAULT 0,is_dir INTEGER NOT NULL DEFAULT 0,is_alive INTEGER NOT NULL DEFAULT 1,generation TEXT NOT NULL DEFAULT '',extra TEXT NOT NULL DEFAULT '{}',PRIMARY KEY(index_key,id))",
    "CREATE INDEX IF NOT EXISTS nodes_parent_name ON nodes(index_key,parent_id,name)",
    "CREATE INDEX IF NOT EXISTS nodes_hash ON nodes(index_key,sha1,size)",
    "CREATE TABLE IF NOT EXISTS cloud_events(index_key TEXT NOT NULL,event_id TEXT NOT NULL,data TEXT NOT NULL,PRIMARY KEY(index_key,event_id))",
    "CREATE TABLE IF NOT EXISTS index_events(seq INTEGER PRIMARY KEY AUTOINCREMENT,index_key TEXT NOT NULL,event TEXT NOT NULL,file_id TEXT NOT NULL,before_data TEXT,after_data TEXT)",
    "CREATE TABLE IF NOT EXISTS client_locks(lock_key TEXT PRIMARY KEY,token TEXT NOT NULL,expires INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS file_jobs(job TEXT NOT NULL,id TEXT NOT NULL,data TEXT NOT NULL,status TEXT NOT NULL,PRIMARY KEY(job,id))"
]
def extend(reg,root):
    reg.migrations=list(MIGRATIONS)
    fields={**FIELDS,'index':TEXT,'parent_id':NUMBER,'ids':array('ID',NUMBER),'is_alive':BOOL,'ensure_file':BOOL,'recursive':BOOL,'pickcode':TEXT,'sha1':TEXT,'fields':typ('string|array|boolean','返回字段',items=TEXT)}
    for ref in reg.definitions:
        if ref.startswith('tool.querydb.P115QueryDB.'):
            method=ref.rsplit('.',1)[-1]
            reg.add('index-'+method.replace('_','-'),'await indexQuery(ctx,args,'+json.dumps(method)+')',fields,[ref],kind=None,required=['index'])
    for mode,refs in [('init',['tool.updatedb.updatedb_initdb','tool.tinydb.tinydb_initdb']),('scan',['tool.updatedb.updatedb','tool.tinydb.tinydb_update']),('events',['tool.updatedb.updatedb_event_iter','tool.tinydb.tinydb_update_event']),('import',[])]:
        reg.add('index-'+mode,'await indexUpdate(ctx,args,'+json.dumps(mode)+')',{**fields,'cid':NUMBER,'pages':INT,'only_alive':BOOL,'entries':array('文件属性',RAW),'from_id':NUMBER,'from_time':INT,'date':TEXT},refs,kind='cookie' if mode in ('scan','events') else None,required=['index'])
