// plugins/cloud-common/normalize.js
function fail(message, code = "invalid_input", retryable = false) {
  const e = new Error(message);
  e.code = code;
  e.retryable = retryable;
  throw e;
}
var object = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
var has = (v, k) => typeof v === "string" || Array.isArray(v) ? v.includes(k) : Object.hasOwn(v || {}, k);
var get = (v, k, d = null) => has(v, k) ? v[k] : d;
function setDefault(v, k, d = null) {
  if (!has(v, k)) v[k] = d;
  return v[k];
}
function completeURL(path, base = "") {
  if (/^https?:\/\//.test(path)) return path;
  if (path.startsWith("//")) return "https:" + path;
  return base.replace(/\/+$/, "") + "/" + path.replace(/^\/+/, "");
}
function escapeName(s) {
  return String(s).replace(/[\"\\/:*?|><]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 65248));
}
function valid(v) {
  if (typeof v === "number" && (!Number.isFinite(v) || Number.isInteger(v) && !Number.isSafeInteger(v))) fail("\u6570\u5B57\u5FC5\u987B\u4E3A\u5B89\u5168\u6574\u6570\uFF0C\u957F ID \u8BF7\u4F7F\u7528\u5B57\u7B26\u4E32");
  if (v && typeof v === "object") for (const [k, x] of Object.entries(v)) {
    if (["__proto__", "constructor", "prototype"].includes(k)) fail("\u4E0D\u5141\u8BB8\u7684\u53C2\u6570\u952E");
    valid(x);
  }
  return v;
}
function text(v, n) {
  if (typeof v !== "string" || !v.length) fail(n + " \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32");
  return v;
}
function integer(v, n, min = 0, max = Number.MAX_SAFE_INTEGER) {
  if (!Number.isSafeInteger(v) || v < min || v > max) fail(n + " \u8D85\u51FA\u5141\u8BB8\u8303\u56F4");
  return v;
}
function utf8(s) {
  const a = [];
  for (const c of s) {
    const n = c.codePointAt(0);
    if (n < 128) a.push(n);
    else if (n < 2048) a.push(192 | n >> 6, 128 | n & 63);
    else if (n < 65536) a.push(224 | n >> 12, 128 | n >> 6 & 63, 128 | n & 63);
    else a.push(240 | n >> 18, 128 | n >> 12 & 63, 128 | n >> 6 & 63, 128 | n & 63);
  }
  return new Uint8Array(a);
}
function base64(a) {
  const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let s = "";
  for (let i = 0; i < a.length; i += 3) {
    const n = a[i] << 16 | (a[i + 1] || 0) << 8 | (a[i + 2] || 0);
    s += t[n >>> 18] + t[n >>> 12 & 63] + (i + 1 < a.length ? t[n >>> 6 & 63] : "=") + (i + 2 < a.length ? t[n & 63] : "=");
  }
  return s;
}
function unbase64(s) {
  const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let n = 0, bits = 0, a = [];
  for (const c of s.replace(/-/g, "+").replace(/_/g, "/").replace(/=+$/, "")) {
    const v = t.indexOf(c);
    if (v < 0) fail("\u65E0\u6548 Base64");
    n = n << 6 | v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      a.push(n >> bits & 255);
    }
  }
  return new Uint8Array(a);
}
var hex = (a) => Array.from(a, (b) => b.toString(16).padStart(2, "0")).join("");
var unhex = (s) => Uint8Array.from(s.match(/../g) || [], (b) => parseInt(b, 16));
function parseJSON(s) {
  return JSON.parse(s.replace(/"(?:[^"\\]|\\.)*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g, (t) => t[0] !== '"' && /^-?\d+$/.test(t) && !Number.isSafeInteger(Number(t)) ? JSON.stringify(t) : t));
}
var query = (p) => Object.entries(p || {}).flatMap(([k, v]) => (Array.isArray(v) ? v : [v]).map((x) => encodeURIComponent(k) + "=" + encodeURIComponent(x === null ? "" : String(x)))).join("&");
var firstHeader = (h, k) => {
  for (const [n, v] of Object.entries(h || {})) if (n.toLowerCase() === k.toLowerCase()) return Array.isArray(v) ? v[0] : v;
  return "";
};
function endpoint(url, { http = false } = {}) {
  const m = /^(https?):\/\/(\[[a-fA-F0-9:]+\]|[a-zA-Z0-9.-]+)(?::(\d+))?(\/[^#]*)?$/.exec(text(url, "URL"));
  if (!m || !http && m[1] !== "https" || /%0[ad]/i.test(url) || /[\r\n\\]/.test(url)) fail("\u65E0\u6548\u670D\u52A1\u5730\u5740");
  return { scheme: m[1], host: m[2].toLowerCase(), port: Number(m[3] || (m[1] === "https" ? 443 : 80)), path: m[4] || "/", origin: m[1] + "://" + m[2] + (m[3] ? ":" + m[3] : "") };
}
function randomID() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.floor(Math.random() * 16);
    return (c === "x" ? r : r & 3 | 8).toString(16);
  });
}
function providerURL(provider, path, base) {
  if (/^https?:\/\//.test(path)) return path;
  if (provider === "cloud123") return completeURL(path.startsWith("/") ? path : "/api/" + path, base || "https://www.123pan.com/b");
  if (provider === "cloud189") return tianyiURL(path, base || "https://cloud.189.cn");
  return completeURL(path, base);
}
function tianyiURL(path, base = "https://cloud.189.cn", family = false, open = true) {
  if (/^https?:\/\//.test(path)) return path;
  let prefix = family ? !path.includes("/") ? "/family/file" : path.startsWith("file/") ? "/family" : "" : open && !path.includes("/") ? "/file" : "";
  if (path.startsWith("api/")) path = "/" + path;
  if (!path.startsWith("/")) {
    if (base.startsWith("https://api.")) {
      if (open && !/^(portal|open)\//.test(path)) prefix = "/open" + prefix;
    } else if (/^(portal|open)\//.test(path)) prefix = "/api" + prefix;
    else if (open) prefix = "/api/open" + prefix;
    prefix += "/";
  }
  return base + prefix + path;
}

// plugins/cloud189/builders.js
function completeURL2(path, base) {
  return providerURL("cloud189", path, base);
}
var builders_default = {
  "login-with-token": (args) => {
    let app_id, token;
    const request_kwargs = { headers: {} };
    token = args["token"] === void 0 ? void 0 : args["token"];
    app_id = args["app_id"] === void 0 ? "8025431004" : args["app_id"];
    return { call: "login-session-pc", args: { ...args, "payload": { ["accessToken"]: token, ["appId"]: app_id } } };
  },
  "app-encrypt-conf": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? {} : args["payload"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    base_url = args["base_url"] === void 0 ? "https://open.e.189.cn" : args["base_url"];
    api = completeURL2("/api/logbox/config/encryptConf.do", base_url);
    if (!object(payload)) {
      payload = { ["appId"]: payload };
    }
    if (method.toUpperCase() === "POST") {
      request_kwargs["data"] = payload;
    } else {
      request_kwargs["params"] = payload;
    }
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "login-app-conf": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? "cloud" : args["payload"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    base_url = args["base_url"] === void 0 ? "https://open.e.189.cn" : args["base_url"];
    api = completeURL2("/api/logbox/oauth2/appConf.do", base_url);
    if (!object(payload)) {
      payload = { ["appId"]: payload };
    }
    payload = { ["appId"]: "cloud", ...payload };
    if (method.toUpperCase() === "POST") {
      request_kwargs["data"] = payload;
    } else {
      request_kwargs["params"] = payload;
    }
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "login-qrcode-uuid": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? "cloud" : args["payload"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    base_url = args["base_url"] === void 0 ? "https://open.e.189.cn" : args["base_url"];
    api = completeURL2("/api/logbox/oauth2/getUUID.do", base_url);
    if (!object(payload)) {
      payload = { ["appId"]: payload };
    }
    if (method.toUpperCase() === "POST") {
      request_kwargs["data"] = payload;
    } else {
      request_kwargs["params"] = payload;
    }
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "login-refresh-token": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    base_url = args["base_url"] === void 0 ? "https://open.e.189.cn" : args["base_url"];
    api = completeURL2("/api/oauth2/refreshToken.do", base_url);
    if (!object(payload)) {
      payload = { ["refreshToken"]: payload };
    }
    payload = { ["clientId"]: "8025431004", ["grantType"]: "refresh_token", ["format"]: "json", ...payload };
    if (method.toUpperCase() === "POST") {
      request_kwargs["data"] = payload;
    } else {
      request_kwargs["params"] = payload;
    }
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "login-session-pc": (args) => {
    let api, base_url, headers, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://api.cloud.189.cn" : args["base_url"];
    api = completeURL2("/getSessionForPC.action", base_url);
    if (typeof payload === "string") {
      if (payload.startsWith(["http://", "https://"])) {
        payload = { ["redirectURL"]: payload };
      } else {
        payload = { ["accessToken"]: payload };
      }
    }
    payload = { ["appId"]: "8025431004", ["clientType"]: "TELEPC", ["version"]: "1.0.0", ["channelId"]: "web_cloud.189.cn", ...payload };
    request_kwargs["headers"] = headers = Object.assign({}, get(request_kwargs, "headers") || [], {});
    setDefault(headers, "accept", "application/json;charset=UTF-8");
    return { "url": api, "params": payload, "method": "GET", "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "login-submit": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    base_url = args["base_url"] === void 0 ? "https://open.e.189.cn" : args["base_url"];
    api = completeURL2("/api/logbox/oauth2/loginSubmit.do", base_url);
    payload = { ["appKey"]: "8025431004", ["validateCode"]: "", ["dynamicCheck"]: "FALSE", ["clientType"]: "1", ["cb_SaveName"]: "3", ["isOauth2"]: "false", ["mailSuffix"]: "@189.cn", ["returnUrl"]: "https://m.cloud.189.cn/zhuanti/2020/loginErrorPc/index.html", ...payload };
    if (payload["appKey"] === "cloud") {
      setDefault(payload, "accountType", "01");
    } else {
      setDefault(payload, "accountType", "02");
    }
    if (method.toUpperCase() === "POST") {
      request_kwargs["data"] = payload;
    } else {
      request_kwargs["params"] = payload;
    }
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "api-download-url-info": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["fileId"]: payload };
    }
    return { "use_access_token": use_access_token, "url": "getFileDownloadUrl.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "api-download-url-video": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["fileId"]: payload };
    }
    if (!has(payload, "type")) {
      if (has(payload, "familyId")) {
        payload["type"] = 1;
      } else {
        if (has(payload, "shareId")) {
          payload["type"] = 4;
        } else {
          payload["type"] = 2;
        }
      }
    }
    return { "use_access_token": use_access_token, "url": "getNewVlcVideoPlayUrl.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "api-fs-list": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? {} : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["folderId"]: payload };
    }
    payload = { ["pageNum"]: 1, ["pageSize"]: 100, ...payload };
    if (!has(payload, "familyId")) {
      setDefault(payload, "folderId", -11);
    }
    return { "use_access_token": use_access_token, "url": "listFiles.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "api-upload-generate-rsakey": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "security/generateRsaKey.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "api-upload-init": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    return { "payload": { ["fileName"]: String(randomID()), ["resumePolicy"]: 1, ...payload }, "use_access_token": use_access_token, "url": "createUploadFile.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "download-url-info": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["fileId"]: payload };
    }
    return { "use_access_token": use_access_token, "url": "file/getFileDownloadUrl.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "download-url-video": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["fileId"]: payload };
    }
    if (!has(payload, "type")) {
      if (has(payload, "familyId")) {
        payload["type"] = 1;
      } else {
        if (has(payload, "shareId")) {
          payload["type"] = 4;
        } else {
          payload["type"] = 2;
        }
      }
    }
    return { "use_access_token": use_access_token, "url": "file/getNewVlcVideoPlayUrl.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "download-url-video-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/getNewVlcVideoPlayUrl.action", base_url);
    if (!object(payload)) {
      payload = { ["fileId"]: payload };
    }
    if (!has(payload, "type")) {
      if (has(payload, "familyId")) {
        payload["type"] = 1;
      } else {
        if (has(payload, "shareId")) {
          payload["type"] = 4;
        } else {
          payload["type"] = 2;
        }
      }
    }
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-batch-cancel": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    return { "use_access_token": use_access_token, "url": "batch/cancelBatchTask.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-batch-check": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    return { "use_access_token": use_access_token, "url": "batch/checkBatchTask.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-batch-conflict": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    return { "use_access_token": use_access_token, "url": "batch/getConflictTaskInfo.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-clear-recycle": (args) => {
    let payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    if (!(object(payload) && (has(payload, "taskInfos") || has(payload, "targetFolderId")))) {
      payload = { ["taskInfos"]: payload };
    }
    payload["type"] = "CLEAR_RECYCLE";
    return { call: "fs-batch", args: { ...args, "use_access_token": use_access_token, "payload": payload } };
  },
  "fs-copy": (args) => {
    let payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    if (!(object(payload) && (has(payload, "taskInfos") || has(payload, "targetFolderId")))) {
      payload = { ["taskInfos"]: payload };
    }
    payload["type"] = "COPY";
    return { call: "fs-batch", args: { ...args, "use_access_token": use_access_token, "payload": payload } };
  },
  "fs-delete": (args) => {
    let payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    if (!(object(payload) && (has(payload, "taskInfos") || has(payload, "targetFolderId")))) {
      payload = { ["taskInfos"]: payload };
    }
    payload["type"] = "DELETE";
    return { call: "fs-batch", args: { ...args, "use_access_token": use_access_token, "payload": payload } };
  },
  "fs-dirs": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? -11 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["id"]: payload };
    }
    return { "use_access_token": use_access_token, "url": "open/file/getObjectFolderNodes.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-dirs-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? -11 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/getObjectFolderNodes.action", base_url);
    if (!object(payload)) {
      payload = { ["id"]: payload };
    }
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-empty-recycle": (args) => {
    let payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? {} : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    if (object(payload)) {
      payload = { ...payload };
    } else {
      payload = { ["familyId"]: payload };
    }
    payload["type"] = "EMPTY_RECYCLE";
    return { call: "fs-batch", args: { ...args, "use_access_token": use_access_token, "payload": payload } };
  },
  "fs-family-from": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? true : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    return { "use_access_token": use_access_token, "url": "family/file/shareFileToFamily.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-family-list": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? true : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "family/manage/getFamilyList.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-family-to": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? true : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    return { "use_access_token": use_access_token, "url": "family/manage/saveFileToMember.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-folder-info": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? -11 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["folderId"]: payload };
    }
    return { "use_access_token": use_access_token, "url": "file/getFolderInfo.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-info": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? -11 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["fileId"]: payload };
    }
    return { "use_access_token": use_access_token, "url": "file/getFileInfo.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-info-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/getFileInfo.action", base_url);
    if (!object(payload)) {
      payload = { ["fileId"]: payload };
    }
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-info-v2-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/v2/getFileInfo.action", base_url);
    if (!object(payload)) {
      payload = { ["fileId"]: payload };
    }
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-list": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? {} : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["folderId"]: payload };
    }
    payload = { ["pageNum"]: 1, ["pageSize"]: 100, ...payload };
    if (!has(payload, "familyId")) {
      setDefault(payload, "folderId", -11);
    }
    return { "use_access_token": use_access_token, "url": "file/listFiles.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-list-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? -11 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/listFiles.action", base_url);
    if (!object(payload)) {
      payload = { ["fileId"]: payload };
    }
    payload = { ["fileId"]: "", ["pageNum"]: 1, ["pageSize"]: 100, ...payload };
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-mkdir": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    if (!object(payload)) {
      payload = { ["folderName"]: payload };
    }
    return { "use_access_token": use_access_token, "url": "file/createFolder.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-mkdir-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    api = completeURL2("portal/v2/createFolder.action", base_url);
    if (!object(payload)) {
      payload = { ["fileName"]: payload };
    }
    if (!has(payload, "familyId")) {
      setDefault(payload, "parentId", -11);
    }
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-move": (args) => {
    let payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    if (!(object(payload) && (has(payload, "taskInfos") || has(payload, "targetFolderId")))) {
      payload = { ["taskInfos"]: payload };
    }
    payload["type"] = "MOVE";
    return { call: "fs-batch", args: { ...args, "use_access_token": use_access_token, "payload": payload } };
  },
  "fs-recyclebin-list": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? 1 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["pageNum"]: payload };
    }
    payload = { ["pageNum"]: 1, ["pageSize"]: 100, ["family"]: "false", ...payload };
    return { "use_access_token": use_access_token, "url": "file/listRecycleBinFiles.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-recyclebin-list-v3": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? 1 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["pageNum"]: payload };
    }
    payload = { ["pageNum"]: 1, ["pageSize"]: 100, ["family"]: "false", ...payload };
    return { "use_access_token": use_access_token, "url": "file/listRecycleBinFilesV3.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-recyclebin-list-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? 1 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/v2/listRecycleBin.action", base_url);
    if (!object(payload)) {
      payload = { ["pageNum"]: payload };
    }
    payload = { ["pageNum"]: 1, ["pageSize"]: 100, ["family"]: "false", ...payload };
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-recyclebin-list-v2-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? 1 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/v2/listRecycleBinFiles.action", base_url);
    if (!object(payload)) {
      payload = { ["pageNum"]: payload };
    }
    payload = { ["pageNum"]: 1, ["pageSize"]: 100, ["family"]: "false", ...payload };
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-recyclebin-list-v3-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? 1 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/listRecycleBinFilesV3.action", base_url);
    if (!object(payload)) {
      payload = { ["pageNum"]: payload };
    }
    payload = { ["pageNum"]: 1, ["pageSize"]: 100, ["family"]: "false", ...payload };
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-rename-dir": (args) => {
    let fid, method, name, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    if (!object(payload)) {
      [fid, name, ..._] = payload;
      payload = { ["folderId"]: fid, ["destFolderName"]: name };
    }
    return { "use_access_token": use_access_token, "url": "file/renameFolder.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-rename-file": (args) => {
    let fid, method, name, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    if (!object(payload)) {
      [fid, name, ..._] = payload;
      payload = { ["fileId"]: fid, ["destFileName"]: name };
    }
    return { "use_access_token": use_access_token, "url": "file/renameFile.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-rename-portal": (args) => {
    let api, base_url, fid, method, name, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    api = completeURL2("portal/v2/renameFile.action", base_url);
    if (!object(payload)) {
      [fid, name, ..._] = payload;
      payload = { ["fileId"]: fid, ["destFileName"]: name };
    }
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-restore": (args) => {
    let payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    if (!(object(payload) && (has(payload, "taskInfos") || has(payload, "targetFolderId")))) {
      payload = { ["taskInfos"]: payload };
    }
    payload["type"] = "RESTORE";
    return { call: "fs-batch", args: { ...args, "use_access_token": use_access_token, "payload": payload } };
  },
  "fs-search": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? "." : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["filename"]: payload };
    }
    payload = { ["filename"]: ".", ["folderId"]: "", ["pageNum"]: 1, ["pageSize"]: 100, ["iconOption"]: 5, ["mediaType"]: 0, ["orderBy"]: "lastOpTime", ["descending"]: "true", ["recursive"]: 0, ...payload };
    return { "use_access_token": use_access_token, "url": "file/searchFiles.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "fs-search-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? "." : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("api/searchFiles.action", base_url);
    if (!object(payload)) {
      payload = { ["filename"]: payload };
    }
    payload = { ["filename"]: ".", ["folderId"]: "", ["pageNum"]: 1, ["pageSize"]: 100, ["iconOption"]: 5, ["mediaType"]: 0, ["orderBy"]: "lastOpTime", ["descending"]: "true", ["recursive"]: 0, ...payload };
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-cancel": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    if (!object(payload)) {
      if (typeof payload === "number" || typeof payload === "string") {
        payload = { ["shareIdList"]: payload };
      } else {
        payload = { ["shareIdList"]: payload.map(String).join(",") };
      }
    }
    return { "use_access_token": use_access_token, "url": "portal/cancelShare.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-check-access-token": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "share/checkAccessCode.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-create": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    if (!object(payload)) {
      payload = { ["fileId"]: payload };
    }
    payload = { ["shareType"]: 3, ["expireTime"]: 2099, ...payload };
    return { "use_access_token": use_access_token, "url": "share/createShareLink.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-create-batch": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    api = completeURL2("share/createBatchShare.action", base_url);
    if (typeof payload === "number" || typeof payload === "string") {
      payload = { ["fileIdList"]: [payload] };
    } else {
      if (!object(payload)) {
        if (!(Array.isArray(payload) || Array.isArray(payload))) {
          payload = Array.from(payload);
        }
        payload = { ["fileIdList"]: payload };
      }
    }
    payload = { ["shareType"]: 3, ["expireTime"]: 2099, ...payload };
    return { "json": payload, "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-fs-list": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? null : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!(payload !== null)) fail("\u53C2\u6570\u4E0D\u6EE1\u8DB3\u4E0A\u6E38\u7EA6\u675F");
    payload = { ["pageNum"]: 1, ["pageSize"]: 100, ["isFolder"]: "true", ...payload };
    if (get(payload, "isFolder") === "true") {
      setDefault(payload, "fileId", payload["shareId"]);
    }
    if (get(payload, "accessCode")) {
      setDefault(payload, "shareMode", 1);
    } else {
      setDefault(payload, "shareMode", 3);
    }
    return { "use_access_token": use_access_token, "url": "share/listShareDir.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-fs-list-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/v2/listShareDirByShareIdAndFileId.action", base_url);
    payload = { ["pageNum"]: 1, ["pageSize"]: 100, ...payload };
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-info": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["shareId"]: payload };
    }
    return { "use_access_token": use_access_token, "url": "portal/getShareInfo.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-info-by-code": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? null : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!(payload !== null)) fail("\u53C2\u6570\u4E0D\u6EE1\u8DB3\u4E0A\u6E38\u7EA6\u675F");
    if (!object(payload)) {
      payload = { ["shareCode"]: payload };
    }
    return { "use_access_token": use_access_token, "url": "share/getShareInfoByCode.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-info-by-code-v2": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["shareCode"]: payload };
    }
    return { "use_access_token": use_access_token, "url": "share/getShareInfoByCodeV2.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-last-save-path": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "getLastSavePath.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-list": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? 1 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["pageNum"]: payload };
    }
    payload = { ["pageNum"]: 1, ["pageSize"]: 100, ["shareType"]: 1, ...payload };
    return { "use_access_token": use_access_token, "url": "portal/listShares.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "share-save": (args) => {
    let payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    payload["type"] = "SHARE_SAVE";
    return { call: "fs-batch", args: { ...args, "use_access_token": use_access_token, "payload": payload } };
  },
  "upload-generate-rsakey": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "security/generateRsaKey.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "upload-init": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    return { "payload": { ["fileName"]: String(randomID()), ["resumePolicy"]: 1, ...payload }, "use_access_token": use_access_token, "url": "file/createUploadFile.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "upload-init-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    api = completeURL2("api/createUploadFile.action", base_url);
    return { "payload": { ["fileName"]: String(randomID()), ["resumePolicy"]: 1, ...payload }, "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "upload-list-latest": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? {} : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    api = completeURL2("portal/listLatestUploadFiles.action", base_url);
    if (!object(payload)) {
      payload = { ["timeStamp"]: payload };
    }
    if (has(payload, "timeStamp")) {
      setDefault(payload, "loadType", 1);
    }
    payload = { ["pageSize"]: 100, ...payload };
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "upload-multipart-commit": (args) => {
    let method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { call: "-upload-request", args: { ...args, "method": method, "payload": payload, "api": "commitMultiUploadFile" } };
  },
  "upload-multipart-list-parts": (args) => {
    let method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!object(payload)) {
      payload = { ["uploadFileId"]: payload };
    }
    return { call: "-upload-request", args: { ...args, "method": method, "payload": payload, "api": "getUploadedPartsInfo" } };
  },
  "upload-multipart-second-check": (args) => {
    let method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { call: "-upload-request", args: { ...args, "method": method, "payload": payload, "api": "checkTransSecond" } };
  },
  "upload-multipart-url": (args) => {
    let method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? void 0 : args["payload"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { call: "-upload-request", args: { ...args, "method": method, "payload": payload, "api": "getMultiUploadUrls" } };
  },
  "user-draw": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? "TASK_SIGNIN" : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://m.cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    api = completeURL2("/v2/drawPrizeMarketDetails.action", base_url);
    if (!object(payload)) {
      payload = { ["taskId"]: payload };
    }
    payload = { ["taskId"]: "TASK_SIGNIN", ["activityId"]: "ACT_SIGNIN", ...payload };
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-get": (args) => {
    let method, payload, use_access_token;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? {} : args["payload"];
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    if (!(payload !== null)) fail("\u53C2\u6570\u4E0D\u6EE1\u8DB3\u4E0A\u6E38\u7EA6\u675F");
    if (!object(payload)) {
      payload = { ["userId"]: payload };
    }
    return { "use_access_token": use_access_token, "url": "subscribe/getUser.action", "method": method, "payload": payload, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-info": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "user/getUserInfo.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-info-portal": (args) => {
    let api, base_url, method;
    const request_kwargs = { headers: {} };
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("api/getUserInfo.action", base_url);
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-info-base": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "user/getUserInfoForPortal.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-info-base-portal": (args) => {
    let api, base_url, method;
    const request_kwargs = { headers: {} };
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/getUserInfoForPortal.action", base_url);
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-info-brief": (args) => {
    let api, base_url, method;
    const request_kwargs = { headers: {} };
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/v2/getUserBriefInfo.action", base_url);
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-info-ext": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "user/getUserInfoExt.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-info-ext-portal": (args) => {
    let api, base_url, method;
    const request_kwargs = { headers: {} };
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("api/getUserInfoExt.action", base_url);
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-logined-infos": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "user/getLoginedInfos.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-logined-infos-portal": (args) => {
    let api, base_url, method;
    const request_kwargs = { headers: {} };
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/getLoginedInfos.action", base_url);
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-logined-infos-v2": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "user/v2/getLoginedInfos.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-logined-infos-v2-portal": (args) => {
    let api, base_url, method;
    const request_kwargs = { headers: {} };
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/v2/getLoginedInfos.action", base_url);
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-privileges": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "user/getUserPrivileges.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-privileges-portal": (args) => {
    let api, base_url, method;
    const request_kwargs = { headers: {} };
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("api/getUserPrivileges.action", base_url);
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-privileges-v2": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "user/getUserPrivilegesV2.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-privileges-v2-portal": (args) => {
    let api, base_url, method;
    const request_kwargs = { headers: {} };
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("api/getUserPrivilegesV2.action", base_url);
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-security-query": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "user/userSecurityQuery.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-size-info": (args) => {
    let method, use_access_token;
    const request_kwargs = { headers: {} };
    use_access_token = args["use_access_token"] === void 0 ? false : args["use_access_token"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    return { "use_access_token": use_access_token, "url": "user/getUserSizeInfo.action", "method": method, "signed": true, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-size-info-portal": (args) => {
    let api, base_url, method;
    const request_kwargs = { headers: {} };
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "GET" : args["method"];
    api = completeURL2("portal/getUserSizeInfo.action", base_url);
    return { "url": api, "method": method, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-sign": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? "TELEANDROID" : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    api = completeURL2("/api/mkt/userSign.action", base_url);
    if (!object(payload)) {
      payload = { ["clientType"]: payload };
    }
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  },
  "user-sign-portal": (args) => {
    let api, base_url, method, payload;
    const request_kwargs = { headers: {} };
    payload = args["payload"] === void 0 ? {} : args["payload"];
    base_url = args["base_url"] === void 0 ? "https://cloud.189.cn" : args["base_url"];
    method = args["method"] === void 0 ? "POST" : args["method"];
    api = completeURL2("/mkt/userSign.action", base_url);
    if (!object(payload)) {
      payload = { ["clientType"]: payload };
    }
    return { "url": api, "method": method, "payload": payload, "signed": false, headers: { ...request_kwargs.headers, ...{} } };
  }
};

// plugins/cloud189/sign.js
var DEFAULT_N = 0x992f257880734350624c66839c61abb198d12c2ab7344e52de04455520840dcc6e16aa38a671e3a3e51f444f00de792377c9e8c028b187831f37972cb6c018ef9db7e6fe72ce6f25b0403ff4f429a965dc68158087eab7438d1a7064e6769d7499a609195e838191f3573719cdef8697b61a3676a0729d3c373454d6c9097c05n;
var rawQuery = (p) => Object.entries(p || {}).map(([k, v]) => k + "=" + String(v)).join("&");
function dateText(ms = Date.now(), short = false) {
  const d = new Date(ms + 8 * 36e5), p = (n) => String(n).padStart(2, "0");
  return String(d.getUTCFullYear()).slice(short ? 2 : 0) + "-" + p(d.getUTCMonth() + 1) + "-" + p(d.getUTCDate()) + p(d.getUTCHours()) + ":" + p(d.getUTCMinutes()) + ":" + p(d.getUTCSeconds());
}
async function accessHeaders(ctx, token, payload = {}, headers = {}) {
  const auth = typeof token === "string" ? { AccessToken: token } : { ...token };
  auth.Timestamp = auth.Timestamp || String(Date.now());
  const data = { ...payload, ...auth };
  const sorted = Object.fromEntries(Object.keys(data).sort().map((k) => [k, data[k]]));
  return { ...headers, ...auth, "Sign-Type": "1", Signature: await ctx.crypto.digest("md5", rawQuery(sorted)) };
}
async function sessionHeaders(ctx, s, url, method = "GET", family = false, headers = {}) {
  const key = text(s[family ? "familySessionKey" : "sessionKey"], "sessionKey"), secret = text(s[family ? "familySessionSecret" : "sessionSecret"], "sessionSecret");
  const date = headers.Date || dateText(Date.now(), true), msg = rawQuery({ SessionKey: key, Operate: method.toUpperCase(), RequestURI: endpoint(url).path.split("?")[0], Date: date });
  return { ...headers, Date: date, SessionKey: key, Signature: (await ctx.crypto.hmacSHA1(secret, msg)).toUpperCase() };
}
function modpow(a, e, n) {
  let x = 1n;
  for (; e; e >>= 1n, a = a * a % n) if (e & 1n) x = x * a % n;
  return x;
}
function keyParts(pem) {
  const bytes = unbase64(pem.replace(/-----[^-]+-----|\s+/g, ""));
  function read(at) {
    const tag = bytes[at++];
    let size = bytes[at++];
    if (size & 128) {
      let n = size & 127;
      size = 0;
      while (n--) size = size << 8 | bytes[at++];
    }
    if (at + size > bytes.length) fail("\u65E0\u6548 RSA \u516C\u94A5");
    return { tag, start: at, end: at + size };
  }
  let root = read(0), a = read(root.start);
  if (a.tag === 48) {
    const bit = read(a.end);
    root = read(bit.start + 1);
    a = read(root.start);
  }
  const b = read(a.end);
  if (a.tag !== 2 || b.tag !== 2) fail("\u65E0\u6548 RSA \u516C\u94A5");
  return [BigInt("0x" + hex(bytes.slice(a.start, a.end))), BigInt("0x" + hex(bytes.slice(b.start, b.end)))];
}
function rsa(data, pem) {
  if (typeof data === "string") data = utf8(data);
  const [n, e] = pem ? keyParts(pem) : [DEFAULT_N, 65537n], size = Math.ceil(n.toString(16).length / 2), out = [];
  for (let off = 0; off < data.length; off += size - 11) {
    const part = data.slice(off, off + size - 11), block = new Uint8Array(size);
    block.fill(2);
    block[0] = 0;
    block[size - part.length - 1] = 0;
    block.set(part, size - part.length);
    const m = BigInt("0x" + hex(block)), v = modpow(m, e, n).toString(16).padStart(size * 2, "0");
    out.push(...unhex(v));
  }
  return new Uint8Array(out);
}
async function encryptedHeaders(ctx, s, url, method, payload) {
  const key = "30303030303030303030303030303030", bytes = utf8(rawQuery(payload)), pad = 16 - bytes.length % 16, padded = new Uint8Array(bytes.length + pad);
  padded.set(bytes);
  padded.fill(pad, bytes.length);
  let params = "";
  for (let i = 0; i < padded.length; i += 16) params += (await ctx.crypto.aesCBC("encrypt", key, "0".repeat(32), hex(padded.slice(i, i + 16)))).slice(0, 32);
  const timestamp = String(Date.now()), sessionKey = text(s.sessionKey, "sessionKey");
  const encryptedKey = s.pubKey ? base64(rsa("0000000000000000", s.pubKey)) : "WS+7/J9D2JG7/8OpDwT84XTqpMIgwYCj2T9ffLVEoFtvBUetFkX2D6LNc9ctcS19uMiQ2DtXNRRDQOw4YouzbQt2jsgX/1UODAGolRDaZutVKkrG/U4hyNResJ+y929QzAXgv0GjhgGjfx1v+nr/rTppjKok63zBKIb+vaSz1UA=";
  return { params: { params }, headers: { ...s.pkId ? { PkId: s.pkId } : {}, EncryptionText: encryptedKey, SessionKey: sessionKey, Signature: await ctx.crypto.hmacSHA1("0000000000000000", rawQuery({ SessionKey: sessionKey, Operate: method.toUpperCase(), RequestURI: endpoint(url).path.split("?")[0], Date: timestamp, params })), "X-Request-Date": timestamp } };
}

// plugins/cloud189/xml.js
function entities(s) {
  return s.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos);/gi, (_2, x) => x[0] === "#" ? String.fromCodePoint(x[1].toLowerCase() === "x" ? parseInt(x.slice(2), 16) : Number(x.slice(1))) : { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" }[x]);
}
function xml(s) {
  if (/<!DOCTYPE|<!ENTITY/i.test(s)) fail("\u4E0D\u63A5\u53D7 DTD XML", "upstream");
  const stack = [], root = {};
  let current = root;
  const toks = s.match(/<!\[CDATA\[[\s\S]*?\]\]>|<!--[\s\S]*?-->|<[^>]+>|[^<]+/g) || [];
  for (const t of toks) {
    if (t.startsWith("<?") || t.startsWith("<!--")) continue;
    if (t.startsWith("</")) {
      if (!stack.length) fail("\u65E0\u6548 XML", "upstream");
      const { parent, name, node } = stack.pop();
      const content = node._text || "";
      delete node._text;
      let v = Object.keys(node).length ? node : entities(content);
      if (typeof v === "string" && /^-?[1-9]\d*$/.test(v) && Number.isSafeInteger(Number(v))) v = Number(v);
      if (Object.hasOwn(parent, name)) parent[name] = Array.isArray(parent[name]) ? [...parent[name], v] : [parent[name], v];
      else parent[name] = v;
      current = parent;
    } else if (t.startsWith("<") && !t.startsWith("<![CDATA[")) {
      const name = /^<([^\s/>]+)/.exec(t)?.[1];
      if (!name || ["__proto__", "constructor", "prototype"].includes(name)) fail("\u65E0\u6548 XML \u6807\u7B7E", "upstream");
      if (t.endsWith("/>")) current[name] = "";
      else {
        const node = {};
        stack.push({ parent: current, name, node });
        current = node;
      }
    } else {
      const v = t.startsWith("<![CDATA[") ? t.slice(9, -3) : t;
      if (v.trim()) current._text = (current._text || "") + v;
    }
  }
  if (stack.length) fail("\u4E0D\u5B8C\u6574 XML", "upstream");
  const values = Object.values(root);
  return values.length === 1 ? values[0] : root;
}

// plugins/cloud-common/file.js
async function info(ctx, path) {
  text(path, "sourcePath");
  const s = await ctx.fs.stat(path);
  if (s.directory || !Number.isSafeInteger(s.size) || s.size < 0) fail("\u6E90\u6587\u4EF6\u4E0D\u662F\u6709\u6548\u666E\u901A\u6587\u4EF6");
  return { size: s.size, modified: s.modified };
}
async function unchanged(ctx, path, before) {
  const after = await info(ctx, path);
  if (after.size !== before.size || after.modified !== before.modified) fail("\u6E90\u6587\u4EF6\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u521D\u59CB\u5316\u4E0A\u4F20", "conflict");
}
async function digest(ctx, path, algorithm = "md5", offset = 0, length) {
  return ctx.fs.hashRange(path, offset, length, algorithm);
}

// plugins/cloud-common/transfer.js
function decode(a) {
  let s = "";
  for (const b of a) s += "%" + b.toString(16).padStart(2, "0");
  return decodeURIComponent(s);
}
function etag(headers) {
  for (const [k, v] of Object.entries(headers || {})) if (k.toLowerCase() === "etag") return Array.isArray(v) ? v[0] : v;
  return "";
}
async function write(ctx, h, data) {
  let i = 0;
  while (i < data.length) {
    const n = await ctx.net.write({ handle: h, data: data.subarray(i) });
    if (!Number.isInteger(n) || n <= 0 || n > data.length - i) fail("\u7F51\u7EDC \u5199\u5165\u672A\u5B8C\u6210", "upstream", true);
    i += n;
  }
}
function parseReply(bytes) {
  let raw = "";
  for (const b of bytes) raw += String.fromCharCode(b);
  const end = raw.indexOf("\r\n\r\n");
  if (end < 0) fail("\u4E0A\u4F20 HTTP \u54CD\u5E94\u5934\u4E0D\u5B8C\u6574", "upstream");
  const head = raw.slice(0, end).split("\r\n"), status = Number(/^HTTP\/1\.[01] (\d{3})/.exec(head.shift())?.[1]);
  if (!status) fail("\u65E0\u6548 \u4E0A\u4F20 HTTP \u72B6\u6001", "upstream");
  const headers = {};
  for (const line of head) {
    const i = line.indexOf(":");
    if (i < 1) fail("\u65E0\u6548 \u4E0A\u4F20 HTTP \u5934", "upstream");
    headers[line.slice(0, i).toLowerCase()] = line.slice(i + 1).trim();
  }
  let body = bytes.subarray(end + 4);
  if (/chunked/i.test(headers["transfer-encoding"] || "")) {
    let pos = end + 4;
    const chunks = [];
    for (; ; ) {
      const e = raw.indexOf("\r\n", pos);
      if (e < 0) fail("\u4E0A\u4F20 \u5206\u5757\u54CD\u5E94\u4E0D\u5B8C\u6574", "upstream");
      const token = raw.slice(pos, e).split(";")[0];
      if (!/^[0-9a-f]+$/i.test(token)) fail("\u65E0\u6548 \u4E0A\u4F20 \u5206\u5757\u957F\u5EA6", "upstream");
      const size = parseInt(token, 16);
      pos = e + 2;
      if (size === 0) break;
      if (pos + size + 2 > bytes.length || raw.slice(pos + size, pos + size + 2) !== "\r\n") fail("\u4E0A\u4F20 \u5206\u5757\u54CD\u5E94\u4E0D\u5B8C\u6574", "upstream");
      chunks.push(...bytes.subarray(pos, pos + size));
      pos += size + 2;
    }
    body = new Uint8Array(chunks);
  } else if (headers["content-length"] !== void 0) {
    const n = Number(headers["content-length"]);
    integer(n, "Content-Length");
    if (body.length !== n) fail("\u4E0A\u4F20 \u54CD\u5E94\u957F\u5EA6\u4E0D\u5339\u914D", "upstream");
  }
  return { status, headers, body: decode(body), etag: headers.etag || "" };
}
async function transfer(ctx, a) {
  const u = endpoint(a.url, { http: !!a.allowHTTP });
  if (!a.sourceRange && !a.bodyStream) {
    const r = await ctx.net.request({ url: a.url, method: a.method, headers: a.headers, ...a.body !== void 0 ? { body: utf8(a.body) } : {}, responseType: "text", maxBytes: 24e4, followRedirects: false });
    return { ...r, etag: etag(r.headers) };
  }
  const before = a.sourceRange ? await info(ctx, a.sourcePath) : null;
  const { offset = 0, length } = a.sourceRange || a.bodyStream;
  integer(offset, "offset", 0, before?.size ?? 0);
  integer(length, "length", 0, before ? before.size - offset : Number.MAX_SAFE_INTEGER);
  if (before && offset === 0 && length === before.size) {
    const r = await ctx.net.request({ url: a.url, method: a.method, headers: a.headers, bodyPath: a.sourcePath, responseType: "text", maxBytes: 24e4, followRedirects: false });
    await unchanged(ctx, a.sourcePath, before);
    return { ...r, etag: etag(r.headers) };
  }
  const socket = await ctx.net.connect({ protocol: "tcp", address: u.host + ":" + u.port, tls: u.scheme === "https" });
  try {
    const headers = { ...a.headers, Host: u.host + (u.scheme === "https" && u.port === 443 || u.scheme === "http" && u.port === 80 ? "" : ":" + u.port), "Content-Length": String(length), Connection: "close" };
    let head = a.method + " " + u.path + " HTTP/1.1\r\n";
    for (const [k, v] of Object.entries(headers)) {
      if (/[\r\n]/.test(k + v)) fail("\u975E\u6CD5\u8BF7\u6C42\u5934");
      head += k + ": " + v + "\r\n";
    }
    await write(ctx, socket.handle, utf8(head + "\r\n"));
    if (a.bodyStream) {
      let sent = 0;
      for await (const chunk of a.bodyStream.chunks()) {
        const b = chunk instanceof Uint8Array ? chunk : utf8(chunk);
        if (sent + b.length > length) fail("\u8BF7\u6C42\u6B63\u6587\u957F\u5EA6\u53D1\u751F\u53D8\u5316", "conflict");
        await write(ctx, socket.handle, b);
        sent += b.length;
      }
      if (sent !== length) fail("\u8BF7\u6C42\u6B63\u6587\u957F\u5EA6\u53D1\u751F\u53D8\u5316", "conflict");
    } else for (let n = 0; n < length; ) {
      const b = await ctx.fs.readBytes(a.sourcePath, offset + n, Math.min(65536, length - n));
      if (!b.length) fail("\u6E90\u6587\u4EF6\u63D0\u524D\u7ED3\u675F", "conflict");
      await write(ctx, socket.handle, b);
      n += b.length;
    }
    const bytes = [];
    for (; ; ) {
      const r = await ctx.net.readBytes({ handle: socket.handle, length: 16384 });
      if (bytes.length + r.data.length > 25e4) fail("\u4E0A\u4F20 \u54CD\u5E94\u8FC7\u5927", "upstream");
      for (const b of r.data) bytes.push(b);
      if (r.eof) break;
      if (!r.data.length) fail("\u4E0A\u4F20 \u54CD\u5E94\u4E2D\u65AD", "upstream", true);
    }
    if (before) await unchanged(ctx, a.sourcePath, before);
    return parseReply(new Uint8Array(bytes));
  } finally {
    await ctx.net.close({ handle: socket.handle });
  }
}

// plugins/cloud189/digest.js
var hexByte = (n) => (n & 255).toString(16).padStart(2, "0");
var sha256K = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];
var md5K = Array.from({ length: 64 }, (_2, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) | 0);
function rotate32(x, n) {
  return x << n | x >>> 32 - n;
}
function newDigest(alg) {
  if (!["sha1", "sha256", "md5", "md4"].includes(alg)) throw fail("\u4E0D\u652F\u6301\u7684\u6458\u8981\u7B97\u6CD5 " + alg);
  return { alg, total: 0, tail: [], h: alg === "sha256" ? [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225] : [1732584193, 4023233417, 2562383102, 271733878, ...alg === "sha1" ? [3285377520] : []] };
}
function digestBlock(s, data, start) {
  const w = new Int32Array(80), big = s.alg.startsWith("sha");
  for (let i = 0; i < 16; i++) {
    const p = start + i * 4;
    w[i] = big ? data[p] << 24 | data[p + 1] << 16 | data[p + 2] << 8 | data[p + 3] : data[p] | data[p + 1] << 8 | data[p + 2] << 16 | data[p + 3] << 24;
  }
  let [a, b, c, d, e, f, g, h] = s.h;
  if (s.alg === "sha1") {
    for (let i = 16; i < 80; i++) w[i] = rotate32(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1);
    for (let i = 0; i < 80; i++) {
      const group = Math.floor(i / 20), fn = group === 0 ? b & c | ~b & d : group === 2 ? b & c | b & d | c & d : b ^ c ^ d;
      const t = rotate32(a, 5) + fn + e + [1518500249, 1859775393, 2400959708, 3395469782][group] + w[i] | 0;
      e = d;
      d = c;
      c = rotate32(b, 30);
      b = a;
      a = t;
    }
  } else if (s.alg === "sha256") {
    for (let i = 16; i < 64; i++) {
      const x = w[i - 15], y = w[i - 2];
      w[i] = w[i - 16] + (rotate32(x, 25) ^ rotate32(x, 14) ^ x >>> 3) + w[i - 7] + (rotate32(y, 15) ^ rotate32(y, 13) ^ y >>> 10) | 0;
    }
    for (let i = 0; i < 64; i++) {
      const t1 = h + (rotate32(e, 26) ^ rotate32(e, 21) ^ rotate32(e, 7)) + (e & f ^ ~e & g) + sha256K[i] + w[i] | 0;
      const t2 = (rotate32(a, 30) ^ rotate32(a, 19) ^ rotate32(a, 10)) + (a & b ^ a & c ^ b & c) | 0;
      h = g;
      g = f;
      f = e;
      e = d + t1 | 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 | 0;
    }
  } else if (s.alg === "md5") {
    for (let i = 0; i < 64; i++) {
      const round = i >>> 4, fn = round === 0 ? b & c | ~b & d : round === 1 ? d & b | ~d & c : round === 2 ? b ^ c ^ d : c ^ (b | ~d);
      const k = round === 0 ? i : round === 1 ? (5 * i + 1) % 16 : round === 2 ? (3 * i + 5) % 16 : 7 * i % 16;
      const shift = [[7, 12, 17, 22], [5, 9, 14, 20], [4, 11, 16, 23], [6, 10, 15, 21]][round][i % 4];
      const t = b + rotate32(a + fn + md5K[i] + w[k] | 0, shift) | 0;
      a = d;
      d = c;
      c = b;
      b = t;
    }
  } else {
    for (let i = 0; i < 48; i++) {
      const round = Math.floor(i / 16), j = i % 16, k = round === 0 ? j : round === 1 ? j % 4 * 4 + (j >>> 2) : [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15][j];
      const fn = round === 0 ? b & c | ~b & d : round === 1 ? b & c | b & d | c & d : b ^ c ^ d;
      const shift = [[3, 7, 11, 19], [3, 5, 9, 13], [3, 9, 11, 15]][round][i % 4];
      const t = rotate32(a + fn + w[k] + [0, 1518500249, 1859775393][round] | 0, shift);
      a = d;
      d = c;
      c = b;
      b = t;
    }
  }
  const result = [a, b, c, d, e, f, g, h];
  s.h = s.h.map((v, i) => v + result[i] | 0);
}
function digestUpdate(s, input) {
  s.total += input.length;
  let index = 0;
  if (s.tail.length) {
    const count = Math.min(64 - s.tail.length, input.length);
    s.tail.push(...input.slice(0, count));
    index = count;
    if (s.tail.length === 64) {
      digestBlock(s, s.tail, 0);
      s.tail = [];
    }
  }
  while (index + 64 <= input.length) {
    digestBlock(s, input, index);
    index += 64;
  }
  if (index < input.length) s.tail.push(...input.slice(index));
  return s;
}
function digestEnd(state) {
  const s = JSON.parse(JSON.stringify(state)), big = s.alg.startsWith("sha"), pad = [...s.tail, 128];
  while (pad.length % 64 !== 56) pad.push(0);
  const bits = BigInt(s.total) * 8n, length = Array.from({ length: 8 }, (_2, i) => Number(bits >> BigInt(i * 8) & 255n));
  pad.push(...big ? length.reverse() : length);
  for (let i = 0; i < pad.length; i += 64) digestBlock(s, pad, i);
  return s.h.map((v) => Array.from({ length: 4 }, (_2, i) => hexByte(v >>> (big ? 24 - i * 8 : i * 8))).join("")).join("");
}

// plugins/cloud-common/upload.js
function uploadActions(provider, driver2) {
  const purpose = provider + "-upload-v1", seal = (ctx, v) => ctx.secrets.seal(purpose, JSON.stringify(v));
  async function ref(ctx, cursor) {
    const r = parseJSON(await ctx.secrets.open(purpose, text(cursor, "cursor")));
    return text(r.id, "taskId");
  }
  async function row(ctx, id) {
    const r = (await ctx.db.query("SELECT * FROM upload_task WHERE id=?", [id]))[0];
    if (!r) fail("\u4E0A\u4F20\u4EFB\u52A1\u4E0D\u5B58\u5728", "not_found");
    return r;
  }
  async function state(ctx, r) {
    const s = parseJSON(await ctx.secrets.open(purpose, r.state));
    if (s.id !== r.id) fail("\u4E0A\u4F20\u72B6\u6001\u4E0D\u4E00\u81F4", "conflict");
    return s;
  }
  const summary = (t, phase, cursor) => ({ cursor, status: phase, nextPart: t.next, totalParts: t.total, uploadedBytes: t.reused ? t.size : Math.min((t.next - 1) * t.partSize, t.size), size: t.size, ...t.result ? { result: t.result } : {}, ...t.ticket ? { uploadId: String(t.ticket.preuploadID || t.ticket.UploadId || t.ticket.uploadFileId || "") } : {} });
  async function acquire(ctx, id) {
    const until = Date.now() + (Number.isFinite(ctx.remaining()) ? Math.max(ctx.remaining(), 1e3) : 6e5) + 3e4;
    if (!await ctx.db.exec("UPDATE upload_task SET lease=lease+1,busy=? WHERE id=? AND busy<=?", [until, id, Date.now()])) fail("\u540C\u4E00\u4E0A\u4F20\u4EFB\u52A1\u6B63\u5728\u64CD\u4F5C", "busy", true);
    return row(ctx, id);
  }
  async function save(ctx, r, t, phase) {
    const sealed = await seal(ctx, t);
    if (!await ctx.db.exec("UPDATE upload_task SET state=?,phase=?,updated=? WHERE id=? AND lease=? AND busy>?", [sealed, phase, Date.now(), r.id, r.lease, Date.now()])) fail("\u4E0A\u4F20\u4EFB\u52A1\u64CD\u4F5C\u5DF2\u8FC7\u671F", "conflict");
    r.phase = phase;
    r.state = sealed;
  }
  async function bound(ctx, t, a) {
    if (t.account !== await ctx.crypto.digest("sha256", a.session || "")) fail("\u4E0A\u4F20\u4EFB\u52A1\u4E0E\u8D26\u53F7\u4F1A\u8BDD\u4E0D\u5339\u914D", "forbidden");
  }
  async function init(ctx, a, env) {
    const sourcePath = text(a.sourcePath, "sourcePath"), before = await info(ctx, sourcePath), md5 = await digest(ctx, sourcePath, "md5", 0, before.size);
    await unchanged(ctx, sourcePath, before);
    const t = { path: sourcePath, size: before.size, modified: before.modified, md5, name: escapeName(a.file_name || sourcePath.split("/").pop()), next: 1, account: await ctx.crypto.digest("sha256", text(a.session, "session")), options: { parent_id: a.parent_id ?? 0, duplicate: a.duplicate ?? 0, family_id: a.family_id, opertype: a.opertype ?? 3, base_url: a.base_url } };
    Object.assign(t, await driver2.begin(ctx, a, env, t));
    integer(t.partSize, "\u5206\u7247\u5927\u5C0F", 1);
    t.total = t.reused ? 0 : Math.ceil(t.size / t.partSize);
    integer(t.total, "\u5206\u7247\u603B\u6570");
    const phase = t.done ? "completed" : t.total === 0 ? "uploaded" : "uploading";
    for (let i = 0; i < 64; i++) {
      t.id = await ctx.crypto.digest("sha256", ctx.runId + ":" + Date.now() + ":" + i);
      if (await ctx.db.exec("INSERT OR IGNORE INTO upload_task(id,state,phase,updated) VALUES (?,?,?,?)", [t.id, await seal(ctx, t), phase, Date.now()])) return summary(t, phase, await seal(ctx, { id: t.id }));
    }
    fail("\u65E0\u6CD5\u521B\u5EFA\u4E0A\u4F20\u8BB0\u5F55", "conflict");
  }
  async function run(ctx, a, env, mode) {
    const id = await ref(ctx, a.cursor);
    let r = await row(ctx, id), t = await state(ctx, r);
    await bound(ctx, t, a);
    if (mode === "status" && r.phase !== "processing") return summary(t, r.phase === "completing" ? "uncertain" : r.phase, a.cursor);
    if (["completed", "cancelled"].includes(r.phase)) return summary(t, r.phase, a.cursor);
    if (r.phase === "completing") fail("\u5408\u5E76\u7ED3\u679C\u5C1A\u672A\u786E\u8BA4\uFF0C\u8BF7\u901A\u8FC7\u539F\u59CB\u4EFB\u52A1\u67E5\u8BE2\u63A5\u53E3\u6838\u5BF9\uFF0C\u7981\u6B62\u91CD\u590D\u5408\u5E76", "conflict");
    r = await acquire(ctx, id);
    try {
      t = await state(ctx, r);
      await bound(ctx, t, a);
      if (["completed", "cancelled"].includes(r.phase)) return summary(t, r.phase, a.cursor);
      if (r.phase === "completing") fail("\u5408\u5E76\u7ED3\u679C\u5C1A\u672A\u786E\u8BA4", "conflict");
      if (r.phase === "processing") {
        if (mode === "cancel") fail("\u4E91\u7AEF\u6B63\u5728\u5408\u5E76\uFF0C\u4E0D\u80FD\u6E05\u7406\u7EED\u4F20\u8BB0\u5F55", "conflict");
        const result = await driver2.poll(ctx, a, env, t);
        t.result = result;
        if (result.data?.completed) {
          delete t.ticket;
          delete t.options;
          delete t.path;
          await save(ctx, r, t, "completed");
        } else await save(ctx, r, t, "processing");
      } else if (mode === "resume") {
        if (a.sourcePath && a.sourcePath !== t.path) fail("\u7EED\u4F20\u6E90\u8DEF\u5F84\u4E0D\u5339\u914D");
        await unchanged(ctx, t.path, t);
        if (await digest(ctx, t.path, "md5", 0, t.size) !== t.md5) fail("\u6E90\u6587\u4EF6\u5185\u5BB9\u5DF2\u53D8\u5316", "conflict");
        integer(a.maxParts ?? 2, "maxParts", 1, 64);
        for (let i = 0; i < (a.maxParts ?? 2) && t.next <= t.total && ctx.remaining() > 1500; i++) {
          await driver2.part(ctx, a, env, t);
          await unchanged(ctx, t.path, t);
          t.next++;
          await save(ctx, r, t, t.next > t.total ? "uploaded" : "uploading");
        }
      } else if (mode === "complete") {
        if (t.next <= t.total) fail("\u5206\u7247\u5C1A\u672A\u5168\u90E8\u4E0A\u4F20", "conflict");
        await save(ctx, r, t, "completing");
        const result = await driver2.complete(ctx, a, env, t);
        t.result = result;
        if (result.data?.async && !result.data?.completed && driver2.poll) {
          await save(ctx, r, t, "processing");
        } else {
          delete t.ticket;
          delete t.options;
          delete t.path;
          await save(ctx, r, t, "completed");
        }
      } else if (mode === "cancel") {
        delete t.ticket;
        delete t.options;
        delete t.path;
        t.result = { localOnly: true };
        await save(ctx, r, t, "cancelled");
      }
      return summary(t, r.phase, a.cursor);
    } finally {
      await ctx.db.exec("UPDATE upload_task SET busy=0 WHERE id=? AND lease=?", [id, r.lease]);
    }
  }
  return { "upload-file": init, "upload-resume": (c, a, e) => run(c, a, e, "resume"), "upload-complete": (c, a, e) => run(c, a, e, "complete"), "upload-status": (c, a, e) => run(c, a, e, "status"), "upload-forget": (c, a, e) => run(c, a, e, "cancel") };
}

// plugins/cloud189/workflows.js
var ROOT = "https://cloud.189.cn";
var AUTH = "https://open.e.189.cn";
function queryValues(url) {
  return Object.fromEntries((url.split("?")[1] || "").split("#")[0].split("&").filter(Boolean).map((x) => {
    const i = x.indexOf("=");
    return [decodeURIComponent(i < 0 ? x : x.slice(0, i)), decodeURIComponent(i < 0 ? "" : x.slice(i + 1).replace(/\+/g, " "))];
  }));
}
async function follow(e, url) {
  let body = "", data = {};
  for (let i = 0; i < 8; i++) {
    const r = await e.send({ url, method: "GET", raw: true });
    const loc = firstHeader(r.headers, "location");
    data = { ...data, ...queryValues(url) };
    if (!loc) {
      body = r.body || "";
      return { ...data, url, body };
    }
    url = loc.startsWith("/") ? endpoint(url).origin + loc : loc.split("#")[0];
  }
  fail("\u767B\u5F55\u91CD\u5B9A\u5411\u6B21\u6570\u8FC7\u591A", "upstream");
}
function fields(s) {
  const out = {};
  for (const k of ["lt", "reqId", "paramId", "returnUrl", "captchaToken"]) {
    const m = new RegExp("(?:var\\s+)?" + k + `\\s*[:=]\\s*["']([^"']*)["']`).exec(s);
    if (m) out[k] = entities(m[1]);
  }
  return out;
}
async function finish(e, r) {
  e.checked(r);
  const url = r.toUrl || r.redirectUrl;
  if (url) await follow(e, url);
  return { status: "completed", session: await e.seal({ ...e.state, ...r.sessionKey ? { sessionKey: r.sessionKey, sessionSecret: r.sessionSecret, familySessionKey: r.familySessionKey || "", familySessionSecret: r.familySessionSecret || "", loginAccessToken: r.accessToken || "" } : {} }) };
}
function batch(p) {
  if (!object(p)) p = { taskInfos: p };
  else p = { ...p };
  if (p.taskInfos !== void 0 && !(typeof p.taskInfos === "string" && p.taskInfos.startsWith("["))) {
    const a = Array.isArray(p.taskInfos) ? p.taskInfos : [p.taskInfos];
    p.taskInfos = JSON.stringify(a.map((x) => object(x) ? { ...x, fileName: x.fileName || "." } : Array.isArray(x) ? { fileId: x[0], fileName: x[1] || "." } : { fileId: x, fileName: "." }));
  }
  return p;
}
var custom = {
  "login-url": async (c, a, e) => {
    const p = { redirectURL: ROOT + "/web/redirect.html", defaultSaveName: 3, defaultSaveNameCheck: "uncheck", ...a.payload };
    const r = await follow(e, ROOT + "/api/portal/loginUrl.action?" + query(p));
    return { ...r, ...fields(r.body), body: void 0 };
  },
  "login-unify-pc": async (c, a, e) => {
    const r = await follow(e, ROOT + "/api/portal/unifyLoginForPC.action?" + query({ appId: "8025431004", clientType: "10020", returnURL: "https://m.cloud.189.cn/zhuanti/2020/loginErrorPc/index.html", timeStamp: Date.now(), ...object(a.payload) ? a.payload : { appId: a.payload || "8025431004" } }));
    return { ...r, ...fields(r.body), body: void 0 };
  },
  "login-qrcode-state": (c, a, e) => e.send({ url: AUTH + "/api/logbox/oauth2/qrcodeLoginState.do", method: a.method || "GET", payload: { appId: "cloud", clientType: 1, date: dateText() + String(Math.floor(Math.random() * 24)), timeStamp: Math.floor(Date.now() / 1e3) * 1e3, cb_SaveName: "3", isOauth2: "false", state: "", ...a.payload } }),
  "login-with-password": async (c, a, e) => {
    const conf = await e.call("login-url", {}), app = e.checked(await e.call("login-app-conf", { payload: a.app_id || "cloud", headers: { lt: conf.lt, reqId: conf.reqId } })).data;
    const r = await e.call("login-submit", { payload: { appKey: a.app_id || "cloud", accountType: "01", pageKey: "normal", userName: "{NRP}" + hex(rsa(text(a.username, "username"))).toUpperCase(), epd: "{NRP}" + hex(rsa(text(a.password, "password"))).toUpperCase(), paramId: app.paramId, returnUrl: encodeURIComponent(app.returnUrl), ...a.captchaToken ? { captchaToken: a.captchaToken } : {} }, headers: { lt: conf.lt, reqid: conf.reqId, referer: conf.url } });
    return finish(e, r);
  },
  "login-with-qrcode": async (c, a, e) => {
    if (!a.cursor) {
      const q = e.checked(await e.call("login-qrcode-uuid", { payload: a.app_id || "cloud" })), conf = await e.call("login-url", {}), app = e.checked(await e.call("login-app-conf", { payload: a.app_id || "cloud", headers: { lt: conf.lt, reqId: conf.reqId } })).data;
      const s2 = { uuid: q.uuid, encryuuid: q.encryuuid, appId: a.app_id || "cloud", paramId: app.paramId, returnUrl: encodeURIComponent(app.returnUrl), conf, cookies: e.state.cookie || "", expires: Date.now() + 18e4 };
      return { status: "waiting", qrcode: q.uuid, imageUrl: AUTH + "/api/logbox/oauth2/image.do?uuid=" + encodeURIComponent(q.uuid), cursor: await c.secrets.seal("189-qr-v1", JSON.stringify(s2)) };
    }
    const s = parseJSON(await c.secrets.open("189-qr-v1", a.cursor));
    if (Date.now() > s.expires) return { status: "expired" };
    if (s.cookies) e.state.cookie = s.cookies;
    const r = await e.call("login-qrcode-state", { payload: { uuid: s.uuid, encryuuid: s.encryuuid, appId: s.appId, paramId: s.paramId, returnUrl: s.returnUrl }, headers: { lt: s.conf.lt, reqid: s.conf.reqId, referer: s.conf.url } });
    const code = Number(r.status ?? r.result);
    if (code === 0) return finish(e, r);
    const status = code === -106 ? "waiting" : code === -11002 ? "scanned" : code === -20099 ? "expired" : "failed";
    return { status, cursor: a.cursor, code };
  },
  "login-with-refresh-token": async (c, a, e) => {
    const r = e.checked(await e.call("login-refresh-token", { payload: text(a.refresh_token, "refresh_token") }));
    const d = e.checked(await e.call("login-session-pc", { payload: { accessToken: r.accessToken, appId: a.app_id || "8025431004" } }));
    delete d.accessToken;
    return { session: await e.seal({ ...e.state, ...d, refreshToken: r.refreshToken, loginAccessToken: r.accessToken }) };
  },
  "login-with-session-key": async (c, a, e) => {
    const r = await e.call("login-sso", { payload: a.session_key });
    return { session: await e.seal({ ...e.state, sessionKey: a.session_key }), ...r };
  },
  "login-sso": async (c, a, e) => {
    const p = object(a.payload) ? a.payload : { sessionKey: a.payload };
    const r = await e.send({ url: ROOT + "/api/portal/ssoLogin.action", method: "GET", params: { redirectUrl: ROOT + "/main.action", ...p }, raw: true });
    return { status: r.status, cookies: !!e.state.cookie };
  },
  "user-access-token": async (c, a, e) => {
    const payload = object(a.payload) ? { sessionKey: e.state.sessionKey, ...a.payload } : { sessionKey: a.payload || e.state.sessionKey };
    text(payload.sessionKey, "sessionKey");
    const headers = await accessHeaders(c, { Appkey: String(a.app_key || "600100422") }, payload);
    const r = await e.send({ url: ROOT + "/api/open/oauth2/getAccessTokenBySsKey.action", method: "GET", params: payload, headers });
    if (r.accessToken) e.state.accessToken = r.accessToken;
    return r;
  },
  "download-url": async (c, a, e) => ({ url: entities(text(e.checked(await e.call("download-url-info", a)).fileDownloadUrl, "\u4E0B\u8F7D\u5730\u5740")) }),
  "api-download-url": async (c, a, e) => ({ url: entities(text(e.checked(await e.call("api-download-url-info", a)).fileDownloadUrl, "\u4E0B\u8F7D\u5730\u5740")) }),
  "fs-batch": (c, a, e) => e.send({ url: "batch/createBatchTask.action", method: a.method || "POST", payload: batch(a.payload), signed: true, use_access_token: a.use_access_token }),
  "fs-batch-manage": (c, a, e) => e.send({ url: "batch/manageBatchTask.action", method: a.method || "POST", payload: batch(a.payload), signed: true, use_access_token: a.use_access_token }),
  "-upload-request": async (c, a, e) => {
    if (!e.state.sessionKey) {
      const r = e.checked(await e.call("user-info-brief"));
      e.state.sessionKey = text(r.sessionKey || r.data?.sessionKey, "sessionKey");
    }
    if (!e.state.pkId || !e.state.keyExpires || e.state.keyExpires < Date.now() + 6e4) {
      const r = e.checked(await e.call("upload-generate-rsakey"));
      e.state.pkId = r.pkId;
      e.state.pubKey = r.pubKey;
      e.state.keyExpires = Number(r.expire);
    }
    const url = "https://upload.cloud.189.cn/" + (a.payload?.familyId !== void 0 ? "family/" : "person/") + text(a.api, "api");
    if (!["initMultiUpload", "commitMultiUploadFile", "getUploadedPartsInfo", "checkTransSecond", "getMultiUploadUrls"].includes(a.api)) fail("\u65E0\u6548\u4E0A\u4F20\u63A5\u53E3");
    const method = a.method || "GET", { params, headers } = await encryptedHeaders(c, e.state, url, method, a.payload || {});
    return e.send({ url, method, ...method === "POST" ? { data: params } : { params }, headers });
  },
  "upload-multipart-init": (c, a, e) => {
    const p = { sliceSize: 10485760, fileName: "upload.bin", ...a.payload };
    if (!p.fileMd5) p.lazyCheck ??= 1;
    if (p.familyId === void 0) p.parentFolderId ??= -11;
    if (p.fileSize <= p.sliceSize && p.fileMd5) p.sliceMd5 ??= p.fileMd5;
    return e.call("-upload-request", { api: "initMultiUpload", payload: p, method: a.method || "GET" });
  },
  "make-signed-headers": async (c, a, e) => ({ headers: await sessionHeaders(c, e.state, text(a.url, "url"), a.method || "GET", !!a.is_family, a.headers || {}) }),
  "make-url-and-signed-headers": async (c, a, e) => {
    const url = tianyiURL(text(a.url, "url"), "https://api.cloud.189.cn", !!a.is_family);
    return { url, headers: await sessionHeaders(c, e.state, url, a.method || "GET", !!a.is_family, a.headers || {}) };
  },
  "api-upload-commit": async (c, a, e) => {
    const url = a.url || "https://hb01.upload.cloud.189.cn/dciClientCommit.action", method = a.method || "POST", headers = await sessionHeaders(c, e.state, url, method, !!a.is_family, a.headers || {});
    return e.send({ url, method, payload: object(a.payload) ? a.payload : { uploadFileId: a.payload }, headers });
  }
};
custom.login = (c, a, e) => e.call(a.username ? "login-with-password" : "login-with-qrcode", a);
custom["api-login"] = (c, a, e) => e.call(a.username ? "api-login-with-password" : "api-login-with-qrcode", a);
custom["api-login-with-password"] = async (c, a, e) => {
  const conf = await e.call("login-unify-pc", { payload: a.app_id || "8025431004" });
  const r = e.checked(await e.call("login-submit", { payload: { appKey: a.app_id || "8025431004", userName: "{NRP}" + hex(rsa(text(a.username, "username"))).toUpperCase(), password: "{NRP}" + hex(rsa(text(a.password, "password"))).toUpperCase(), captchaToken: a.captchaToken || conf.captchaToken || "", paramId: conf.paramId }, headers: { lt: conf.lt, reqid: conf.reqId, referer: AUTH } }));
  const s = e.checked(await e.call("login-session-pc", { payload: r.toUrl }));
  const token = s.accessToken;
  delete s.accessToken;
  return { session: await e.seal({ ...e.state, ...s, loginAccessToken: token }) };
};
custom["api-upload-headers"] = custom["make-signed-headers"];
custom["api-upload-url"] = custom["make-url-and-signed-headers"];
var driver = {
  async begin(c, a, e, t) {
    const size = integer(a.slice_size ?? 10485760, "slice_size", 102400, 5 * 1024 ** 3);
    const md = newDigest("md5");
    let count = 0;
    for (let off = 0; off < t.size; off += size) {
      const h = (await digest(c, t.path, "md5", off, Math.min(size, t.size - off))).toUpperCase();
      digestUpdate(md, utf8((count > 1 ? "\n" : "") + h));
      count++;
    }
    const sliceMD5 = count > 1 ? digestEnd(md) : t.md5;
    const p = { fileSize: t.size, fileMd5: t.md5, fileName: encodeURIComponent(t.name), sliceSize: size, sliceMd5: sliceMD5, lazyCheck: 0 };
    if (a.family_id !== void 0) {
      p.familyId = a.family_id;
      p.parentId = a.parent_id ?? -11;
    } else p.parentFolderId = a.parent_id ?? -11;
    const r = e.checked(await e.call("upload-multipart-init", { payload: p })), d = r.data;
    return { partSize: size, sliceMD5, ticket: d, reused: !!d.fileDataExists };
  },
  async part(c, a, e, t) {
    const offset = (t.next - 1) * t.partSize, length = Math.min(t.partSize, t.size - offset), md5 = await digest(c, t.path, "md5", offset, length);
    const r = e.checked(await e.call("upload-multipart-url", { payload: { uploadFileId: t.ticket.uploadFileId, partInfo: t.next + "-" + base64(unhex(md5)), ...t.options.family_id !== void 0 ? { familyId: t.options.family_id } : {} } }));
    const d = (r.uploadUrls || r.data?.uploadUrls)?.["partNumber_" + t.next];
    if (!d) fail("\u4E0A\u4F20\u7968\u636E\u7F3A\u5C11\u5F53\u524D\u5206\u7247", "upstream");
    const headers = queryValues("?" + d.requestHeader), res = await transfer(c, { url: text(d.requestURL, "\u4E0A\u4F20\u5730\u5740"), method: "PUT", headers, sourcePath: t.path, sourceRange: { offset, length } });
    if (res.status < 200 || res.status >= 300) fail("\u5929\u7FFC\u5206\u7247 HTTP " + res.status, "upstream", true);
  },
  async complete(c, a, e, t) {
    return e.checked(await e.call("upload-multipart-commit", { payload: { uploadFileId: t.ticket.uploadFileId, opertype: t.options.opertype, fileMd5: t.md5, sliceMd5: t.sliceMD5, lazyCheck: 1, ...t.options.family_id !== void 0 ? { familyId: t.options.family_id } : {} } }));
  }
};
Object.assign(custom, uploadActions("cloud189", driver));
custom["request-with-sign"] = (c, a, e) => e.send({ url: text(a.url, "url"), method: a.method || "GET", payload: a.payload, signed: true, use_access_token: a.use_access_token });
custom["api-request-with-sign"] = custom["request-with-sign"];
custom["login-unify-wap"] = async (c, a, e) => {
  let r = await follow(e, "https://m.cloud.189.cn/udb/udb_login.jsp?" + query({ clientType: "wap", pageId: "1", pageKey: "default", returnURL: "https://m.cloud.189.cn/zhuanti/2021/shakeLottery/index.html", ...object(a.payload) ? a.payload : { redirectURL: a.payload } }));
  const link = /href=["'](https:\/\/open\.e\.189\.cn[^"']+)["']/.exec(r.body);
  if (link) r = await follow(e, entities(link[1]));
  return { ...r, ...fields(r.body), body: void 0 };
};
custom["login-with-password2"] = async (c, a, e) => {
  const d = await e.call("login-unify-wap", a);
  const r = await e.call("login-submit", { payload: { appKey: a.app_id || "cloud", accountType: "01", pageKey: "normal", userName: "{NRP}" + hex(rsa(text(a.username, "username"))).toUpperCase(), password: "{NRP}" + hex(rsa(text(a.password, "password"))).toUpperCase(), paramId: d.paramId, returnUrl: encodeURIComponent(d.returnUrl), captchaToken: a.captchaToken || d.captchaToken || "" }, headers: { lt: d.lt, reqid: d.reqId, referer: d.url } });
  return finish(e, r);
};
custom["login-with-sso-cookie"] = async (c, a, e) => {
  e.state.cookie = "SSON=" + text(a.cookie, "cookie");
  const r = await e.call("login-unify-pc", { payload: a.app_id || "8025431004" });
  const d = e.checked(await e.call("login-session-pc", { payload: { redirectURL: r.url, appId: a.app_id || "8025431004" } }));
  const accessToken = d.accessToken;
  delete d.accessToken;
  return { session: await e.seal({ ...e.state, ...d, loginAccessToken: accessToken }) };
};
custom["api-login-with-qrcode"] = async (c, a, e) => {
  if (!a.cursor) {
    const conf = await e.call("login-unify-pc", { payload: a.app_id || "8025431004" }), q = e.checked(await e.call("login-qrcode-uuid", { payload: a.app_id || "8025431004" }));
    return { status: "waiting", qrcode: q.uuid, imageUrl: AUTH + "/api/logbox/oauth2/image.do?uuid=" + encodeURIComponent(q.uuid), cursor: await c.secrets.seal("189-pc-qr-v1", JSON.stringify({ uuid: q.uuid, encryuuid: q.encryuuid, conf, appId: a.app_id || "8025431004", cookie: e.state.cookie, expires: Date.now() + 18e4 })) };
  }
  const s = parseJSON(await c.secrets.open("189-pc-qr-v1", a.cursor));
  if (Date.now() > s.expires) return { status: "expired" };
  e.state.cookie = s.cookie || "";
  const r = await e.call("login-qrcode-state", { payload: { appId: s.appId, uuid: s.uuid, encryuuid: s.encryuuid, returnUrl: "https://m.cloud.189.cn/zhuanti/2020/loginErrorPc/index.html", paramId: s.conf.paramId }, headers: { lt: s.conf.lt, reqid: s.conf.reqId, referer: s.conf.url } });
  const code = Number(r.status ?? r.result);
  if (code === 0) {
    const d = e.checked(await e.call("login-session-pc", { payload: { redirectURL: r.redirectUrl, appId: s.appId } }));
    const token = d.accessToken;
    delete d.accessToken;
    return { status: "completed", session: await e.seal({ ...e.state, ...d, loginAccessToken: token }) };
  }
  return { status: code === -106 ? "waiting" : code === -11002 ? "scanned" : code === -20099 ? "expired" : "failed", cursor: a.cursor, code };
};
custom["api-make-signed-headers"] = custom["make-signed-headers"];
custom["api-make-url-and-signed-headers"] = custom["make-url-and-signed-headers"];
var workflows_default = custom;

// plugins/cloud-common/protocol.js
function createConnector(config2, builders, custom2 = {}) {
  const purpose = config2.id + "-session-v1";
  async function seal(ctx, s) {
    return ctx.secrets.seal(purpose, JSON.stringify(s));
  }
  function validateState(s) {
    if (!object(s)) fail("\u65E0\u6548\u8D26\u53F7\u53C2\u6570");
    for (const k of ["token", "cookie", "accessToken", "sessionKey", "sessionSecret", "familySessionKey", "familySessionSecret", "pkId"]) if (s[k] !== void 0 && (typeof s[k] !== "string" || /[\r\n]/.test(s[k]))) fail("\u65E0\u6548\u51ED\u636E\u5B57\u6BB5 " + k);
    return s;
  }
  const publicAction = (op) => config2.public?.(op) || false;
  async function send(ctx, wire, args, state, op) {
    let w = { ...wire, headers: { ...wire.headers } };
    if (config2.prepare) w = await config2.prepare(ctx, w, args, state, op);
    let base = w.base_url || args.base_url || config2.base;
    if (!/^https?:\/\//.test(w.url)) w.url = providerURL(config2.id, w.url, base);
    const u = endpoint(w.url);
    if (!config2.hosts.includes(u.host)) fail("\u8BF7\u6C42\u5730\u5740\u4E0D\u5C5E\u4E8E\u6B64\u7F51\u76D8");
    w.method = (w.method || "GET").toUpperCase();
    if (!["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"].includes(w.method)) fail("\u4E0D\u652F\u6301\u7684\u8BF7\u6C42\u65B9\u6CD5");
    const publicRequest = publicAction(op) || args.anonymous === true;
    const canonical = (k) => k.toLowerCase().replace(/(^|-)[a-z]/g, (x) => x.toUpperCase());
    const headers = {};
    for (const h of [{ Accept: "application/json" }, config2.headers || {}, w.headers || {}]) for (const [k, v] of Object.entries(h)) headers[canonical(k)] = v;
    if (!publicRequest) {
      if (config2.id === "quark" && state.cookie) headers.Cookie = state.cookie;
      else if (config2.id === "cloud123" && state.token) headers.Authorization = "Bearer " + state.token.replace(/^Bearer /i, "");
      else if (config2.id === "cloud189" && state.cookie) headers.Cookie = state.cookie;
      if (!Object.keys(state).length) fail("\u8BF7\u5148\u8C03\u7528 session-create \u6216 login\uFF0C\u4F20\u5165\u8FD4\u56DE\u7684 session", "unauthorized");
    }
    for (const [k, v] of Object.entries(args.headers || {})) {
      if (!/^[a-zA-Z0-9-]+$/.test(k) || /^(host|authorization|cookie|content-length|transfer-encoding|connection)$/i.test(k) || /[\r\n]/.test(String(v))) fail("\u65E0\u6548\u9644\u52A0\u8BF7\u6C42\u5934");
      headers[canonical(k)] = String(v);
    }
    for (const [k, v] of Object.entries(headers)) if (!/^[a-zA-Z0-9-]+$/.test(k) || /[\r\n]/.test(String(v))) fail("\u65E0\u6548\u8BF7\u6C42\u5934");
    let payload = w.payload;
    if (payload !== void 0) {
      if (w.method === "POST") w.data = payload;
      else w.params = payload;
    }
    let url = w.url, body;
    if (config2.id === "quark") w.params = { pr: "ucpro", fr: "pc", ...args.params, ...w.params };
    if (w.params && Object.keys(w.params).length) url += (url.includes("?") ? "&" : "?") + query(w.params);
    if (w.json !== void 0) {
      headers["Content-Type"] = "application/json";
      body = utf8(JSON.stringify(w.json));
    } else if (w.data !== void 0) {
      headers["Content-Type"] = "application/x-www-form-urlencoded";
      body = utf8(typeof w.data === "string" ? w.data : query(w.data));
    }
    if (w.files) fail("\u6587\u4EF6\u63A5\u53E3\u8BF7\u4F7F\u7528 sourcePath \u7684\u4E0A\u4F20\u52A8\u4F5C");
    const req = { url, method: w.method, headers, ...body ? { body } : {}, responseType: "text", maxBytes: 24e4, followRedirects: false, ...w.bodyPath ? { bodyPath: w.bodyPath } : {}, ...w.outputPath ? { outputPath: w.outputPath } : {} };
    const r = await ctx.net.request(req);
    if (w.raw) {
      if (config2.response) await config2.response(ctx, void 0, r, w, args, state, op);
      return r;
    }
    if (w.outputPath) return { status: r.status, path: r.path, bytes: r.bytes };
    let data;
    if (r.body) {
      try {
        data = parseJSON(r.body);
      } catch {
        if (config2.parse) data = config2.parse(r.body);
        else if (op === "ping") data = { message: r.body };
      }
    }
    if (config2.response) data = await config2.response(ctx, data, r, w, args, state, op);
    if (data === void 0) {
      if (r.status >= 200 && r.status < 300 && !r.body) return {};
      fail(config2.name + " HTTP " + r.status, "upstream", r.status === 429 || r.status >= 500);
    }
    if (r.status >= 400 && (!object(data) || !("code" in data || "errorCode" in data || "res_code" in data || "error" in data))) fail(config2.name + " HTTP " + r.status, "upstream", r.status === 429 || r.status >= 500);
    return data;
  }
  async function execute2(ctx, op, args = {}) {
    valid(args);
    let state = args.session ? validateState(parseJSON(await ctx.secrets.open(purpose, text(args.session, "session")))) : {};
    async function dispatch(operation, a) {
      const env = { state, seal: (s) => seal(ctx, validateState(s)), send: (w2, b = a, o = operation) => send(ctx, w2, b, state, o), call: (o, b = {}) => dispatch(o, { ...a, ...b }), checked: (r) => checked(config2.id, r) };
      if (custom2[operation]) return custom2[operation](ctx, a, env);
      if (operation === "session-create" && !Object.keys(a.credentials || {}).length) fail("credentials \u4E0D\u80FD\u4E3A\u7A7A");
      if (operation === "session-create") return { session: await env.seal({ ...a.credentials, ...a.baseUrl ? { baseUrl: a.baseUrl } : {} }) };
      if (operation === "session-update") return { session: await env.seal({ ...state, ...a.credentials }) };
      if (operation === "session-info") return { provider: config2.name, connected: !!Object.keys(state).length, ...state.baseUrl ? { baseUrl: state.baseUrl } : {} };
      if (operation === "check-response") return checked(config2.id, a.response);
      if (operation === "request") return env.send({ url: text(a.url, "url"), method: a.method || "GET", ...["GET", "HEAD"].includes(a.method || "GET") ? { params: a.payload } : { json: a.payload } }, a, operation);
      const builder = builders[operation];
      if (!builder) fail("\u672A\u77E5\u63A5\u53E3 " + operation);
      const w = builder(a);
      if (w.call) return dispatch(w.call, w.args);
      return send(ctx, w, a, state, operation);
    }
    return dispatch(op, args);
  }
  return execute2;
}
function checked(id, r) {
  if (!object(r)) fail("\u4E0A\u6E38\u54CD\u5E94\u4E0D\u662F\u5BF9\u8C61", "upstream");
  let bad = false;
  if (id === "quark") bad = !!r.code || r.status >= 400;
  else if (id === "cloud123") bad = r.code !== void 0 && ![0, 200, "0", "200"].includes(r.code);
  else bad = r.errorCode !== void 0 && !["", 0, "0"].includes(r.errorCode) || r.res_code !== void 0 && Number(r.res_code) !== 0 || r.result !== void 0 && Number(r.result) !== 0;
  if (bad) fail("\u4E0A\u6E38\u4E1A\u52A1\u9519\u8BEF\uFF1A" + String(r.message || r.msg || r.errorCode || r.res_message || r.code || r.result), "upstream");
  return r;
}

// plugins/cloud189/runtime.js
function cookies(headers, state) {
  const all = [];
  for (const [k, v] of Object.entries(headers || {})) if (k.toLowerCase() === "set-cookie") all.push(...Array.isArray(v) ? v : [v]);
  const jar = Object.fromEntries((state.cookie || "").split(/;\s*/).filter(Boolean).map((x) => {
    const i = x.indexOf("=");
    return [x.slice(0, i), x.slice(i + 1)];
  }));
  for (const s of all) {
    const x = s.split(";")[0], i = x.indexOf("=");
    if (i > 0) jar[x.slice(0, i)] = x.slice(i + 1);
  }
  if (all.length) state.cookie = Object.entries(jar).map(([k, v]) => k + "=" + v).join("; ");
}
var config = {
  id: "cloud189",
  name: "\u5929\u7FFC\u4E91\u76D8",
  base: "https://cloud.189.cn",
  hosts: ["cloud.189.cn", "api.cloud.189.cn", "open.e.189.cn", "m.cloud.189.cn", "upload.cloud.189.cn", "hb01.upload.cloud.189.cn"],
  headers: { "User-Agent": "Mozilla/5.0 AppleWebKit/600 Safari/600 Chrome/124.0.0.0 Edg/124.0.0.0" },
  public: (op) => op.startsWith("login") || op.startsWith("api-login") || ["app-encrypt-conf", "share-check-access-token", "share-fs-list", "share-fs-list-portal", "share-info", "share-info-by-code", "share-info-by-code-v2", "user-get"].includes(op),
  parse: (s) => s.trim().startsWith("<") ? xml(s) : void 0,
  async prepare(ctx, w, args, state, op) {
    if ((op.startsWith("login") || op.startsWith("api-login")) && state.cookie) w.headers = { ...w.headers, Cookie: state.cookie };
    if (w.signed) {
      const family = w.payload?.familyId !== void 0, api = op.startsWith("api-"), use = w.use_access_token;
      w.url = tianyiURL(w.url, api || use ? "https://api.cloud.189.cn" : "https://cloud.189.cn", family, api ? !!use : true);
      if (use) {
        let token = typeof use === "string" || object(use) ? use : state.accessToken;
        if (!token) fail("\u8BE5\u63A5\u53E3\u9700\u8981 accessToken\uFF0C\u8BF7\u5148\u8C03\u7528 user-access-token \u5E76\u66F4\u65B0 session", "unauthorized");
        w.headers = await accessHeaders(ctx, token, w.payload, w.headers);
      } else if (api) w.headers = await sessionHeaders(ctx, state, w.url, w.method, family, w.headers);
    }
    return w;
  },
  async response(ctx, data, r, w, args, state) {
    cookies(r.headers, state);
    return data;
  }
};
var execute = createConnector(config, builders_default, workflows_default);

// plugins/cloud189/entry.js
async function action0(ctx, args = {}) {
  return execute(ctx, "login-with-token", args);
}
async function action1(ctx, args = {}) {
  return execute(ctx, "app-encrypt-conf", args);
}
async function action2(ctx, args = {}) {
  return execute(ctx, "login-app-conf", args);
}
async function action3(ctx, args = {}) {
  return execute(ctx, "login-qrcode-uuid", args);
}
async function action4(ctx, args = {}) {
  return execute(ctx, "login-refresh-token", args);
}
async function action5(ctx, args = {}) {
  return execute(ctx, "login-session-pc", args);
}
async function action6(ctx, args = {}) {
  return execute(ctx, "login-submit", args);
}
async function action7(ctx, args = {}) {
  return execute(ctx, "api-download-url-info", args);
}
async function action8(ctx, args = {}) {
  return execute(ctx, "api-download-url-video", args);
}
async function action9(ctx, args = {}) {
  return execute(ctx, "api-fs-list", args);
}
async function action10(ctx, args = {}) {
  return execute(ctx, "api-upload-generate-rsakey", args);
}
async function action11(ctx, args = {}) {
  return execute(ctx, "api-upload-init", args);
}
async function action12(ctx, args = {}) {
  return execute(ctx, "download-url-info", args);
}
async function action13(ctx, args = {}) {
  return execute(ctx, "download-url-video", args);
}
async function action14(ctx, args = {}) {
  return execute(ctx, "download-url-video-portal", args);
}
async function action15(ctx, args = {}) {
  return execute(ctx, "fs-batch-cancel", args);
}
async function action16(ctx, args = {}) {
  return execute(ctx, "fs-batch-check", args);
}
async function action17(ctx, args = {}) {
  return execute(ctx, "fs-batch-conflict", args);
}
async function action18(ctx, args = {}) {
  return execute(ctx, "fs-clear-recycle", args);
}
async function action19(ctx, args = {}) {
  return execute(ctx, "fs-copy", args);
}
async function action20(ctx, args = {}) {
  return execute(ctx, "fs-delete", args);
}
async function action21(ctx, args = {}) {
  return execute(ctx, "fs-dirs", args);
}
async function action22(ctx, args = {}) {
  return execute(ctx, "fs-dirs-portal", args);
}
async function action23(ctx, args = {}) {
  return execute(ctx, "fs-empty-recycle", args);
}
async function action24(ctx, args = {}) {
  return execute(ctx, "fs-family-from", args);
}
async function action25(ctx, args = {}) {
  return execute(ctx, "fs-family-list", args);
}
async function action26(ctx, args = {}) {
  return execute(ctx, "fs-family-to", args);
}
async function action27(ctx, args = {}) {
  return execute(ctx, "fs-folder-info", args);
}
async function action28(ctx, args = {}) {
  return execute(ctx, "fs-info", args);
}
async function action29(ctx, args = {}) {
  return execute(ctx, "fs-info-portal", args);
}
async function action30(ctx, args = {}) {
  return execute(ctx, "fs-info-v2-portal", args);
}
async function action31(ctx, args = {}) {
  return execute(ctx, "fs-list", args);
}
async function action32(ctx, args = {}) {
  return execute(ctx, "fs-list-portal", args);
}
async function action33(ctx, args = {}) {
  return execute(ctx, "fs-mkdir", args);
}
async function action34(ctx, args = {}) {
  return execute(ctx, "fs-mkdir-portal", args);
}
async function action35(ctx, args = {}) {
  return execute(ctx, "fs-move", args);
}
async function action36(ctx, args = {}) {
  return execute(ctx, "fs-recyclebin-list", args);
}
async function action37(ctx, args = {}) {
  return execute(ctx, "fs-recyclebin-list-v3", args);
}
async function action38(ctx, args = {}) {
  return execute(ctx, "fs-recyclebin-list-portal", args);
}
async function action39(ctx, args = {}) {
  return execute(ctx, "fs-recyclebin-list-v2-portal", args);
}
async function action40(ctx, args = {}) {
  return execute(ctx, "fs-recyclebin-list-v3-portal", args);
}
async function action41(ctx, args = {}) {
  return execute(ctx, "fs-rename-dir", args);
}
async function action42(ctx, args = {}) {
  return execute(ctx, "fs-rename-file", args);
}
async function action43(ctx, args = {}) {
  return execute(ctx, "fs-rename-portal", args);
}
async function action44(ctx, args = {}) {
  return execute(ctx, "fs-restore", args);
}
async function action45(ctx, args = {}) {
  return execute(ctx, "fs-search", args);
}
async function action46(ctx, args = {}) {
  return execute(ctx, "fs-search-portal", args);
}
async function action47(ctx, args = {}) {
  return execute(ctx, "share-cancel", args);
}
async function action48(ctx, args = {}) {
  return execute(ctx, "share-check-access-token", args);
}
async function action49(ctx, args = {}) {
  return execute(ctx, "share-create", args);
}
async function action50(ctx, args = {}) {
  return execute(ctx, "share-create-batch", args);
}
async function action51(ctx, args = {}) {
  return execute(ctx, "share-fs-list", args);
}
async function action52(ctx, args = {}) {
  return execute(ctx, "share-fs-list-portal", args);
}
async function action53(ctx, args = {}) {
  return execute(ctx, "share-info", args);
}
async function action54(ctx, args = {}) {
  return execute(ctx, "share-info-by-code", args);
}
async function action55(ctx, args = {}) {
  return execute(ctx, "share-info-by-code-v2", args);
}
async function action56(ctx, args = {}) {
  return execute(ctx, "share-last-save-path", args);
}
async function action57(ctx, args = {}) {
  return execute(ctx, "share-list", args);
}
async function action58(ctx, args = {}) {
  return execute(ctx, "share-save", args);
}
async function action59(ctx, args = {}) {
  return execute(ctx, "upload-generate-rsakey", args);
}
async function action60(ctx, args = {}) {
  return execute(ctx, "upload-init", args);
}
async function action61(ctx, args = {}) {
  return execute(ctx, "upload-init-portal", args);
}
async function action62(ctx, args = {}) {
  return execute(ctx, "upload-list-latest", args);
}
async function action63(ctx, args = {}) {
  return execute(ctx, "upload-multipart-commit", args);
}
async function action64(ctx, args = {}) {
  return execute(ctx, "upload-multipart-list-parts", args);
}
async function action65(ctx, args = {}) {
  return execute(ctx, "upload-multipart-second-check", args);
}
async function action66(ctx, args = {}) {
  return execute(ctx, "upload-multipart-url", args);
}
async function action67(ctx, args = {}) {
  return execute(ctx, "user-draw", args);
}
async function action68(ctx, args = {}) {
  return execute(ctx, "user-get", args);
}
async function action69(ctx, args = {}) {
  return execute(ctx, "user-info", args);
}
async function action70(ctx, args = {}) {
  return execute(ctx, "user-info-portal", args);
}
async function action71(ctx, args = {}) {
  return execute(ctx, "user-info-base", args);
}
async function action72(ctx, args = {}) {
  return execute(ctx, "user-info-base-portal", args);
}
async function action73(ctx, args = {}) {
  return execute(ctx, "user-info-brief", args);
}
async function action74(ctx, args = {}) {
  return execute(ctx, "user-info-ext", args);
}
async function action75(ctx, args = {}) {
  return execute(ctx, "user-info-ext-portal", args);
}
async function action76(ctx, args = {}) {
  return execute(ctx, "user-logined-infos", args);
}
async function action77(ctx, args = {}) {
  return execute(ctx, "user-logined-infos-portal", args);
}
async function action78(ctx, args = {}) {
  return execute(ctx, "user-logined-infos-v2", args);
}
async function action79(ctx, args = {}) {
  return execute(ctx, "user-logined-infos-v2-portal", args);
}
async function action80(ctx, args = {}) {
  return execute(ctx, "user-privileges", args);
}
async function action81(ctx, args = {}) {
  return execute(ctx, "user-privileges-portal", args);
}
async function action82(ctx, args = {}) {
  return execute(ctx, "user-privileges-v2", args);
}
async function action83(ctx, args = {}) {
  return execute(ctx, "user-privileges-v2-portal", args);
}
async function action84(ctx, args = {}) {
  return execute(ctx, "user-security-query", args);
}
async function action85(ctx, args = {}) {
  return execute(ctx, "user-size-info", args);
}
async function action86(ctx, args = {}) {
  return execute(ctx, "user-size-info-portal", args);
}
async function action87(ctx, args = {}) {
  return execute(ctx, "user-sign", args);
}
async function action88(ctx, args = {}) {
  return execute(ctx, "user-sign-portal", args);
}
async function action89(ctx, args = {}) {
  return execute(ctx, "login-url", args);
}
async function action90(ctx, args = {}) {
  return execute(ctx, "login-unify-pc", args);
}
async function action91(ctx, args = {}) {
  return execute(ctx, "login-qrcode-state", args);
}
async function action92(ctx, args = {}) {
  return execute(ctx, "login-with-password", args);
}
async function action93(ctx, args = {}) {
  return execute(ctx, "login-with-qrcode", args);
}
async function action94(ctx, args = {}) {
  return execute(ctx, "login-with-refresh-token", args);
}
async function action95(ctx, args = {}) {
  return execute(ctx, "login-with-session-key", args);
}
async function action96(ctx, args = {}) {
  return execute(ctx, "login-sso", args);
}
async function action97(ctx, args = {}) {
  return execute(ctx, "user-access-token", args);
}
async function action98(ctx, args = {}) {
  return execute(ctx, "download-url", args);
}
async function action99(ctx, args = {}) {
  return execute(ctx, "api-download-url", args);
}
async function action100(ctx, args = {}) {
  return execute(ctx, "fs-batch", args);
}
async function action101(ctx, args = {}) {
  return execute(ctx, "fs-batch-manage", args);
}
async function action102(ctx, args = {}) {
  return execute(ctx, "upload-multipart-init", args);
}
async function action103(ctx, args = {}) {
  return execute(ctx, "make-signed-headers", args);
}
async function action104(ctx, args = {}) {
  return execute(ctx, "make-url-and-signed-headers", args);
}
async function action105(ctx, args = {}) {
  return execute(ctx, "api-upload-commit", args);
}
async function action106(ctx, args = {}) {
  return execute(ctx, "login", args);
}
async function action107(ctx, args = {}) {
  return execute(ctx, "api-login", args);
}
async function action108(ctx, args = {}) {
  return execute(ctx, "api-login-with-password", args);
}
async function action109(ctx, args = {}) {
  return execute(ctx, "api-upload-headers", args);
}
async function action110(ctx, args = {}) {
  return execute(ctx, "api-upload-url", args);
}
async function action111(ctx, args = {}) {
  return execute(ctx, "upload-file", args);
}
async function action112(ctx, args = {}) {
  return execute(ctx, "upload-resume", args);
}
async function action113(ctx, args = {}) {
  return execute(ctx, "upload-complete", args);
}
async function action114(ctx, args = {}) {
  return execute(ctx, "upload-status", args);
}
async function action115(ctx, args = {}) {
  return execute(ctx, "upload-forget", args);
}
async function action116(ctx, args = {}) {
  return execute(ctx, "request-with-sign", args);
}
async function action117(ctx, args = {}) {
  return execute(ctx, "api-request-with-sign", args);
}
async function action118(ctx, args = {}) {
  return execute(ctx, "login-unify-wap", args);
}
async function action119(ctx, args = {}) {
  return execute(ctx, "login-with-password2", args);
}
async function action120(ctx, args = {}) {
  return execute(ctx, "login-with-sso-cookie", args);
}
async function action121(ctx, args = {}) {
  return execute(ctx, "api-login-with-qrcode", args);
}
async function action122(ctx, args = {}) {
  return execute(ctx, "api-make-signed-headers", args);
}
async function action123(ctx, args = {}) {
  return execute(ctx, "api-make-url-and-signed-headers", args);
}
async function action124(ctx, args = {}) {
  return execute(ctx, "session-create", args);
}
async function action125(ctx, args = {}) {
  return execute(ctx, "session-update", args);
}
async function action126(ctx, args = {}) {
  return execute(ctx, "session-info", args);
}
async function action127(ctx, args = {}) {
  return execute(ctx, "check-response", args);
}
async function action128(ctx, args = {}) {
  return execute(ctx, "request", args);
}
export {
  action0,
  action1,
  action10,
  action100,
  action101,
  action102,
  action103,
  action104,
  action105,
  action106,
  action107,
  action108,
  action109,
  action11,
  action110,
  action111,
  action112,
  action113,
  action114,
  action115,
  action116,
  action117,
  action118,
  action119,
  action12,
  action120,
  action121,
  action122,
  action123,
  action124,
  action125,
  action126,
  action127,
  action128,
  action13,
  action14,
  action15,
  action16,
  action17,
  action18,
  action19,
  action2,
  action20,
  action21,
  action22,
  action23,
  action24,
  action25,
  action26,
  action27,
  action28,
  action29,
  action3,
  action30,
  action31,
  action32,
  action33,
  action34,
  action35,
  action36,
  action37,
  action38,
  action39,
  action4,
  action40,
  action41,
  action42,
  action43,
  action44,
  action45,
  action46,
  action47,
  action48,
  action49,
  action5,
  action50,
  action51,
  action52,
  action53,
  action54,
  action55,
  action56,
  action57,
  action58,
  action59,
  action6,
  action60,
  action61,
  action62,
  action63,
  action64,
  action65,
  action66,
  action67,
  action68,
  action69,
  action7,
  action70,
  action71,
  action72,
  action73,
  action74,
  action75,
  action76,
  action77,
  action78,
  action79,
  action8,
  action80,
  action81,
  action82,
  action83,
  action84,
  action85,
  action86,
  action87,
  action88,
  action89,
  action9,
  action90,
  action91,
  action92,
  action93,
  action94,
  action95,
  action96,
  action97,
  action98,
  action99,
  action99 as "api-download-url",
  action7 as "api-download-url-info",
  action8 as "api-download-url-video",
  action9 as "api-fs-list",
  action107 as "api-login",
  action108 as "api-login-with-password",
  action121 as "api-login-with-qrcode",
  action122 as "api-make-signed-headers",
  action123 as "api-make-url-and-signed-headers",
  action117 as "api-request-with-sign",
  action105 as "api-upload-commit",
  action10 as "api-upload-generate-rsakey",
  action109 as "api-upload-headers",
  action11 as "api-upload-init",
  action110 as "api-upload-url",
  action1 as "app-encrypt-conf",
  action127 as "check-response",
  action98 as "download-url",
  action12 as "download-url-info",
  action13 as "download-url-video",
  action14 as "download-url-video-portal",
  action100 as "fs-batch",
  action15 as "fs-batch-cancel",
  action16 as "fs-batch-check",
  action17 as "fs-batch-conflict",
  action101 as "fs-batch-manage",
  action18 as "fs-clear-recycle",
  action19 as "fs-copy",
  action20 as "fs-delete",
  action21 as "fs-dirs",
  action22 as "fs-dirs-portal",
  action23 as "fs-empty-recycle",
  action24 as "fs-family-from",
  action25 as "fs-family-list",
  action26 as "fs-family-to",
  action27 as "fs-folder-info",
  action28 as "fs-info",
  action29 as "fs-info-portal",
  action30 as "fs-info-v2-portal",
  action31 as "fs-list",
  action32 as "fs-list-portal",
  action33 as "fs-mkdir",
  action34 as "fs-mkdir-portal",
  action35 as "fs-move",
  action36 as "fs-recyclebin-list",
  action38 as "fs-recyclebin-list-portal",
  action39 as "fs-recyclebin-list-v2-portal",
  action37 as "fs-recyclebin-list-v3",
  action40 as "fs-recyclebin-list-v3-portal",
  action41 as "fs-rename-dir",
  action42 as "fs-rename-file",
  action43 as "fs-rename-portal",
  action44 as "fs-restore",
  action45 as "fs-search",
  action46 as "fs-search-portal",
  action106 as login,
  action2 as "login-app-conf",
  action91 as "login-qrcode-state",
  action3 as "login-qrcode-uuid",
  action4 as "login-refresh-token",
  action5 as "login-session-pc",
  action96 as "login-sso",
  action6 as "login-submit",
  action90 as "login-unify-pc",
  action118 as "login-unify-wap",
  action89 as "login-url",
  action92 as "login-with-password",
  action119 as "login-with-password2",
  action93 as "login-with-qrcode",
  action94 as "login-with-refresh-token",
  action95 as "login-with-session-key",
  action120 as "login-with-sso-cookie",
  action0 as "login-with-token",
  action103 as "make-signed-headers",
  action104 as "make-url-and-signed-headers",
  action128 as request,
  action116 as "request-with-sign",
  action124 as "session-create",
  action126 as "session-info",
  action125 as "session-update",
  action47 as "share-cancel",
  action48 as "share-check-access-token",
  action49 as "share-create",
  action50 as "share-create-batch",
  action51 as "share-fs-list",
  action52 as "share-fs-list-portal",
  action53 as "share-info",
  action54 as "share-info-by-code",
  action55 as "share-info-by-code-v2",
  action56 as "share-last-save-path",
  action57 as "share-list",
  action58 as "share-save",
  action113 as "upload-complete",
  action111 as "upload-file",
  action115 as "upload-forget",
  action59 as "upload-generate-rsakey",
  action60 as "upload-init",
  action61 as "upload-init-portal",
  action62 as "upload-list-latest",
  action63 as "upload-multipart-commit",
  action102 as "upload-multipart-init",
  action64 as "upload-multipart-list-parts",
  action65 as "upload-multipart-second-check",
  action66 as "upload-multipart-url",
  action112 as "upload-resume",
  action114 as "upload-status",
  action97 as "user-access-token",
  action67 as "user-draw",
  action68 as "user-get",
  action69 as "user-info",
  action71 as "user-info-base",
  action72 as "user-info-base-portal",
  action73 as "user-info-brief",
  action74 as "user-info-ext",
  action75 as "user-info-ext-portal",
  action70 as "user-info-portal",
  action76 as "user-logined-infos",
  action77 as "user-logined-infos-portal",
  action78 as "user-logined-infos-v2",
  action79 as "user-logined-infos-v2-portal",
  action80 as "user-privileges",
  action81 as "user-privileges-portal",
  action82 as "user-privileges-v2",
  action83 as "user-privileges-v2-portal",
  action84 as "user-security-query",
  action87 as "user-sign",
  action88 as "user-sign-portal",
  action85 as "user-size-info",
  action86 as "user-size-info-portal"
};
