import {execute} from './runtime.js';
export async function action0(ctx,args={}){return execute(ctx,"login-with-token",args);}
export {action0 as "login-with-token"};
export async function action1(ctx,args={}){return execute(ctx,"app-encrypt-conf",args);}
export {action1 as "app-encrypt-conf"};
export async function action2(ctx,args={}){return execute(ctx,"login-app-conf",args);}
export {action2 as "login-app-conf"};
export async function action3(ctx,args={}){return execute(ctx,"login-qrcode-uuid",args);}
export {action3 as "login-qrcode-uuid"};
export async function action4(ctx,args={}){return execute(ctx,"login-refresh-token",args);}
export {action4 as "login-refresh-token"};
export async function action5(ctx,args={}){return execute(ctx,"login-session-pc",args);}
export {action5 as "login-session-pc"};
export async function action6(ctx,args={}){return execute(ctx,"login-submit",args);}
export {action6 as "login-submit"};
export async function action7(ctx,args={}){return execute(ctx,"api-download-url-info",args);}
export {action7 as "api-download-url-info"};
export async function action8(ctx,args={}){return execute(ctx,"api-download-url-video",args);}
export {action8 as "api-download-url-video"};
export async function action9(ctx,args={}){return execute(ctx,"api-fs-list",args);}
export {action9 as "api-fs-list"};
export async function action10(ctx,args={}){return execute(ctx,"api-upload-generate-rsakey",args);}
export {action10 as "api-upload-generate-rsakey"};
export async function action11(ctx,args={}){return execute(ctx,"api-upload-init",args);}
export {action11 as "api-upload-init"};
export async function action12(ctx,args={}){return execute(ctx,"download-url-info",args);}
export {action12 as "download-url-info"};
export async function action13(ctx,args={}){return execute(ctx,"download-url-video",args);}
export {action13 as "download-url-video"};
export async function action14(ctx,args={}){return execute(ctx,"download-url-video-portal",args);}
export {action14 as "download-url-video-portal"};
export async function action15(ctx,args={}){return execute(ctx,"fs-batch-cancel",args);}
export {action15 as "fs-batch-cancel"};
export async function action16(ctx,args={}){return execute(ctx,"fs-batch-check",args);}
export {action16 as "fs-batch-check"};
export async function action17(ctx,args={}){return execute(ctx,"fs-batch-conflict",args);}
export {action17 as "fs-batch-conflict"};
export async function action18(ctx,args={}){return execute(ctx,"fs-clear-recycle",args);}
export {action18 as "fs-clear-recycle"};
export async function action19(ctx,args={}){return execute(ctx,"fs-copy",args);}
export {action19 as "fs-copy"};
export async function action20(ctx,args={}){return execute(ctx,"fs-delete",args);}
export {action20 as "fs-delete"};
export async function action21(ctx,args={}){return execute(ctx,"fs-dirs",args);}
export {action21 as "fs-dirs"};
export async function action22(ctx,args={}){return execute(ctx,"fs-dirs-portal",args);}
export {action22 as "fs-dirs-portal"};
export async function action23(ctx,args={}){return execute(ctx,"fs-empty-recycle",args);}
export {action23 as "fs-empty-recycle"};
export async function action24(ctx,args={}){return execute(ctx,"fs-family-from",args);}
export {action24 as "fs-family-from"};
export async function action25(ctx,args={}){return execute(ctx,"fs-family-list",args);}
export {action25 as "fs-family-list"};
export async function action26(ctx,args={}){return execute(ctx,"fs-family-to",args);}
export {action26 as "fs-family-to"};
export async function action27(ctx,args={}){return execute(ctx,"fs-folder-info",args);}
export {action27 as "fs-folder-info"};
export async function action28(ctx,args={}){return execute(ctx,"fs-info",args);}
export {action28 as "fs-info"};
export async function action29(ctx,args={}){return execute(ctx,"fs-info-portal",args);}
export {action29 as "fs-info-portal"};
export async function action30(ctx,args={}){return execute(ctx,"fs-info-v2-portal",args);}
export {action30 as "fs-info-v2-portal"};
export async function action31(ctx,args={}){return execute(ctx,"fs-list",args);}
export {action31 as "fs-list"};
export async function action32(ctx,args={}){return execute(ctx,"fs-list-portal",args);}
export {action32 as "fs-list-portal"};
export async function action33(ctx,args={}){return execute(ctx,"fs-mkdir",args);}
export {action33 as "fs-mkdir"};
export async function action34(ctx,args={}){return execute(ctx,"fs-mkdir-portal",args);}
export {action34 as "fs-mkdir-portal"};
export async function action35(ctx,args={}){return execute(ctx,"fs-move",args);}
export {action35 as "fs-move"};
export async function action36(ctx,args={}){return execute(ctx,"fs-recyclebin-list",args);}
export {action36 as "fs-recyclebin-list"};
export async function action37(ctx,args={}){return execute(ctx,"fs-recyclebin-list-v3",args);}
export {action37 as "fs-recyclebin-list-v3"};
export async function action38(ctx,args={}){return execute(ctx,"fs-recyclebin-list-portal",args);}
export {action38 as "fs-recyclebin-list-portal"};
export async function action39(ctx,args={}){return execute(ctx,"fs-recyclebin-list-v2-portal",args);}
export {action39 as "fs-recyclebin-list-v2-portal"};
export async function action40(ctx,args={}){return execute(ctx,"fs-recyclebin-list-v3-portal",args);}
export {action40 as "fs-recyclebin-list-v3-portal"};
export async function action41(ctx,args={}){return execute(ctx,"fs-rename-dir",args);}
export {action41 as "fs-rename-dir"};
export async function action42(ctx,args={}){return execute(ctx,"fs-rename-file",args);}
export {action42 as "fs-rename-file"};
export async function action43(ctx,args={}){return execute(ctx,"fs-rename-portal",args);}
export {action43 as "fs-rename-portal"};
export async function action44(ctx,args={}){return execute(ctx,"fs-restore",args);}
export {action44 as "fs-restore"};
export async function action45(ctx,args={}){return execute(ctx,"fs-search",args);}
export {action45 as "fs-search"};
export async function action46(ctx,args={}){return execute(ctx,"fs-search-portal",args);}
export {action46 as "fs-search-portal"};
export async function action47(ctx,args={}){return execute(ctx,"share-cancel",args);}
export {action47 as "share-cancel"};
export async function action48(ctx,args={}){return execute(ctx,"share-check-access-token",args);}
export {action48 as "share-check-access-token"};
export async function action49(ctx,args={}){return execute(ctx,"share-create",args);}
export {action49 as "share-create"};
export async function action50(ctx,args={}){return execute(ctx,"share-create-batch",args);}
export {action50 as "share-create-batch"};
export async function action51(ctx,args={}){return execute(ctx,"share-fs-list",args);}
export {action51 as "share-fs-list"};
export async function action52(ctx,args={}){return execute(ctx,"share-fs-list-portal",args);}
export {action52 as "share-fs-list-portal"};
export async function action53(ctx,args={}){return execute(ctx,"share-info",args);}
export {action53 as "share-info"};
export async function action54(ctx,args={}){return execute(ctx,"share-info-by-code",args);}
export {action54 as "share-info-by-code"};
export async function action55(ctx,args={}){return execute(ctx,"share-info-by-code-v2",args);}
export {action55 as "share-info-by-code-v2"};
export async function action56(ctx,args={}){return execute(ctx,"share-last-save-path",args);}
export {action56 as "share-last-save-path"};
export async function action57(ctx,args={}){return execute(ctx,"share-list",args);}
export {action57 as "share-list"};
export async function action58(ctx,args={}){return execute(ctx,"share-save",args);}
export {action58 as "share-save"};
export async function action59(ctx,args={}){return execute(ctx,"upload-generate-rsakey",args);}
export {action59 as "upload-generate-rsakey"};
export async function action60(ctx,args={}){return execute(ctx,"upload-init",args);}
export {action60 as "upload-init"};
export async function action61(ctx,args={}){return execute(ctx,"upload-init-portal",args);}
export {action61 as "upload-init-portal"};
export async function action62(ctx,args={}){return execute(ctx,"upload-list-latest",args);}
export {action62 as "upload-list-latest"};
export async function action63(ctx,args={}){return execute(ctx,"upload-multipart-commit",args);}
export {action63 as "upload-multipart-commit"};
export async function action64(ctx,args={}){return execute(ctx,"upload-multipart-list-parts",args);}
export {action64 as "upload-multipart-list-parts"};
export async function action65(ctx,args={}){return execute(ctx,"upload-multipart-second-check",args);}
export {action65 as "upload-multipart-second-check"};
export async function action66(ctx,args={}){return execute(ctx,"upload-multipart-url",args);}
export {action66 as "upload-multipart-url"};
export async function action67(ctx,args={}){return execute(ctx,"user-draw",args);}
export {action67 as "user-draw"};
export async function action68(ctx,args={}){return execute(ctx,"user-get",args);}
export {action68 as "user-get"};
export async function action69(ctx,args={}){return execute(ctx,"user-info",args);}
export {action69 as "user-info"};
export async function action70(ctx,args={}){return execute(ctx,"user-info-portal",args);}
export {action70 as "user-info-portal"};
export async function action71(ctx,args={}){return execute(ctx,"user-info-base",args);}
export {action71 as "user-info-base"};
export async function action72(ctx,args={}){return execute(ctx,"user-info-base-portal",args);}
export {action72 as "user-info-base-portal"};
export async function action73(ctx,args={}){return execute(ctx,"user-info-brief",args);}
export {action73 as "user-info-brief"};
export async function action74(ctx,args={}){return execute(ctx,"user-info-ext",args);}
export {action74 as "user-info-ext"};
export async function action75(ctx,args={}){return execute(ctx,"user-info-ext-portal",args);}
export {action75 as "user-info-ext-portal"};
export async function action76(ctx,args={}){return execute(ctx,"user-logined-infos",args);}
export {action76 as "user-logined-infos"};
export async function action77(ctx,args={}){return execute(ctx,"user-logined-infos-portal",args);}
export {action77 as "user-logined-infos-portal"};
export async function action78(ctx,args={}){return execute(ctx,"user-logined-infos-v2",args);}
export {action78 as "user-logined-infos-v2"};
export async function action79(ctx,args={}){return execute(ctx,"user-logined-infos-v2-portal",args);}
export {action79 as "user-logined-infos-v2-portal"};
export async function action80(ctx,args={}){return execute(ctx,"user-privileges",args);}
export {action80 as "user-privileges"};
export async function action81(ctx,args={}){return execute(ctx,"user-privileges-portal",args);}
export {action81 as "user-privileges-portal"};
export async function action82(ctx,args={}){return execute(ctx,"user-privileges-v2",args);}
export {action82 as "user-privileges-v2"};
export async function action83(ctx,args={}){return execute(ctx,"user-privileges-v2-portal",args);}
export {action83 as "user-privileges-v2-portal"};
export async function action84(ctx,args={}){return execute(ctx,"user-security-query",args);}
export {action84 as "user-security-query"};
export async function action85(ctx,args={}){return execute(ctx,"user-size-info",args);}
export {action85 as "user-size-info"};
export async function action86(ctx,args={}){return execute(ctx,"user-size-info-portal",args);}
export {action86 as "user-size-info-portal"};
export async function action87(ctx,args={}){return execute(ctx,"user-sign",args);}
export {action87 as "user-sign"};
export async function action88(ctx,args={}){return execute(ctx,"user-sign-portal",args);}
export {action88 as "user-sign-portal"};
export async function action89(ctx,args={}){return execute(ctx,"login-url",args);}
export {action89 as "login-url"};
export async function action90(ctx,args={}){return execute(ctx,"login-unify-pc",args);}
export {action90 as "login-unify-pc"};
export async function action91(ctx,args={}){return execute(ctx,"login-qrcode-state",args);}
export {action91 as "login-qrcode-state"};
export async function action92(ctx,args={}){return execute(ctx,"login-with-password",args);}
export {action92 as "login-with-password"};
export async function action93(ctx,args={}){return execute(ctx,"login-with-qrcode",args);}
export {action93 as "login-with-qrcode"};
export async function action94(ctx,args={}){return execute(ctx,"login-with-refresh-token",args);}
export {action94 as "login-with-refresh-token"};
export async function action95(ctx,args={}){return execute(ctx,"login-with-session-key",args);}
export {action95 as "login-with-session-key"};
export async function action96(ctx,args={}){return execute(ctx,"login-sso",args);}
export {action96 as "login-sso"};
export async function action97(ctx,args={}){return execute(ctx,"user-access-token",args);}
export {action97 as "user-access-token"};
export async function action98(ctx,args={}){return execute(ctx,"download-url",args);}
export {action98 as "download-url"};
export async function action99(ctx,args={}){return execute(ctx,"api-download-url",args);}
export {action99 as "api-download-url"};
export async function action100(ctx,args={}){return execute(ctx,"fs-batch",args);}
export {action100 as "fs-batch"};
export async function action101(ctx,args={}){return execute(ctx,"fs-batch-manage",args);}
export {action101 as "fs-batch-manage"};
export async function action102(ctx,args={}){return execute(ctx,"upload-multipart-init",args);}
export {action102 as "upload-multipart-init"};
export async function action103(ctx,args={}){return execute(ctx,"make-signed-headers",args);}
export {action103 as "make-signed-headers"};
export async function action104(ctx,args={}){return execute(ctx,"make-url-and-signed-headers",args);}
export {action104 as "make-url-and-signed-headers"};
export async function action105(ctx,args={}){return execute(ctx,"api-upload-commit",args);}
export {action105 as "api-upload-commit"};
export async function action106(ctx,args={}){return execute(ctx,"login",args);}
export {action106 as "login"};
export async function action107(ctx,args={}){return execute(ctx,"api-login",args);}
export {action107 as "api-login"};
export async function action108(ctx,args={}){return execute(ctx,"api-login-with-password",args);}
export {action108 as "api-login-with-password"};
export async function action109(ctx,args={}){return execute(ctx,"api-upload-headers",args);}
export {action109 as "api-upload-headers"};
export async function action110(ctx,args={}){return execute(ctx,"api-upload-url",args);}
export {action110 as "api-upload-url"};
export async function action111(ctx,args={}){return execute(ctx,"upload-file",args);}
export {action111 as "upload-file"};
export async function action112(ctx,args={}){return execute(ctx,"upload-resume",args);}
export {action112 as "upload-resume"};
export async function action113(ctx,args={}){return execute(ctx,"upload-complete",args);}
export {action113 as "upload-complete"};
export async function action114(ctx,args={}){return execute(ctx,"upload-status",args);}
export {action114 as "upload-status"};
export async function action115(ctx,args={}){return execute(ctx,"upload-forget",args);}
export {action115 as "upload-forget"};
export async function action116(ctx,args={}){return execute(ctx,"request-with-sign",args);}
export {action116 as "request-with-sign"};
export async function action117(ctx,args={}){return execute(ctx,"api-request-with-sign",args);}
export {action117 as "api-request-with-sign"};
export async function action118(ctx,args={}){return execute(ctx,"login-unify-wap",args);}
export {action118 as "login-unify-wap"};
export async function action119(ctx,args={}){return execute(ctx,"login-with-password2",args);}
export {action119 as "login-with-password2"};
export async function action120(ctx,args={}){return execute(ctx,"login-with-sso-cookie",args);}
export {action120 as "login-with-sso-cookie"};
export async function action121(ctx,args={}){return execute(ctx,"api-login-with-qrcode",args);}
export {action121 as "api-login-with-qrcode"};
export async function action122(ctx,args={}){return execute(ctx,"api-make-signed-headers",args);}
export {action122 as "api-make-signed-headers"};
export async function action123(ctx,args={}){return execute(ctx,"api-make-url-and-signed-headers",args);}
export {action123 as "api-make-url-and-signed-headers"};
export async function action124(ctx,args={}){return execute(ctx,"session-create",args);}
export {action124 as "session-create"};
export async function action125(ctx,args={}){return execute(ctx,"session-update",args);}
export {action125 as "session-update"};
export async function action126(ctx,args={}){return execute(ctx,"session-info",args);}
export {action126 as "session-info"};
export async function action127(ctx,args={}){return execute(ctx,"check-response",args);}
export {action127 as "check-response"};
export async function action128(ctx,args={}){return execute(ctx,"request",args);}
export {action128 as "request"};