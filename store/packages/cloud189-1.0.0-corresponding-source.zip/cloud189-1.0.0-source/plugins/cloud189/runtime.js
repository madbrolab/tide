import builders from './builders.js';
import custom from './workflows.js';
import {createConnector} from '../cloud-common/protocol.js';
import {object,tianyiURL,parseJSON,endpoint,firstHeader,fail,text} from '../cloud-common/normalize.js';
import {accessHeaders,sessionHeaders} from './sign.js';
import {xml} from './xml.js';
export {custom};
function cookies(headers,state){const all=[];for(const [k,v] of Object.entries(headers||{}))if(k.toLowerCase()==='set-cookie')all.push(...(Array.isArray(v)?v:[v]));const jar=Object.fromEntries((state.cookie||'').split(/;\s*/).filter(Boolean).map(x=>{const i=x.indexOf('=');return [x.slice(0,i),x.slice(i+1)];}));for(const s of all){const x=s.split(';')[0],i=x.indexOf('=');if(i>0)jar[x.slice(0,i)]=x.slice(i+1);}if(all.length)state.cookie=Object.entries(jar).map(([k,v])=>k+'='+v).join('; ');}
export const config={id:'cloud189',name:'天翼云盘',base:'https://cloud.189.cn',hosts:['cloud.189.cn','api.cloud.189.cn','open.e.189.cn','m.cloud.189.cn','upload.cloud.189.cn','hb01.upload.cloud.189.cn'],headers:{'User-Agent':'Mozilla/5.0 AppleWebKit/600 Safari/600 Chrome/124.0.0.0 Edg/124.0.0.0'},public:op=>op.startsWith('login')||op.startsWith('api-login')||['app-encrypt-conf','share-check-access-token','share-fs-list','share-fs-list-portal','share-info','share-info-by-code','share-info-by-code-v2','user-get'].includes(op),parse:s=>s.trim().startsWith('<')?xml(s):undefined,
 async prepare(ctx,w,args,state,op){
  if((op.startsWith('login')||op.startsWith('api-login'))&&state.cookie)w.headers={...w.headers,Cookie:state.cookie};
  if(w.signed){const family=w.payload?.familyId!==undefined,api=op.startsWith('api-'),use=w.use_access_token;
   w.url=tianyiURL(w.url,api||use?'https://api.cloud.189.cn':'https://cloud.189.cn',family,api?!!use:true);
   if(use){let token=typeof use==='string'||object(use)?use:state.accessToken;if(!token)fail('该接口需要 accessToken，请先调用 user-access-token 并更新 session','unauthorized');w.headers=await accessHeaders(ctx,token,w.payload,w.headers);}
   else if(api)w.headers=await sessionHeaders(ctx,state,w.url,w.method,family,w.headers);
  }
  return w;
 },
 async response(ctx,data,r,w,args,state){cookies(r.headers,state);return data;}
};
export const execute=createConnector(config,builders,custom);
