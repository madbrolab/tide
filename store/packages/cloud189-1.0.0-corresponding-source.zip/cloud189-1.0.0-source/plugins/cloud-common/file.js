import {fail,text,integer,utf8,randomID} from './normalize.js';
export async function info(ctx,path){text(path,'sourcePath');const s=await ctx.fs.stat(path);if(s.directory||!Number.isSafeInteger(s.size)||s.size<0)fail('源文件不是有效普通文件');return {size:s.size,modified:s.modified};}
export async function unchanged(ctx,path,before){const after=await info(ctx,path);if(after.size!==before.size||after.modified!==before.modified)fail('源文件已变化，请重新初始化上传','conflict');}
export async function digest(ctx,path,algorithm='md5',offset=0,length){return ctx.fs.hashRange(path,offset,length,algorithm);}
export async function multipart(ctx,path,{fields={},field='file',filename='upload.bin',offset=0,length}={}){
 const before=await info(ctx,path);length=length??before.size-offset;integer(offset,'offset',0,before.size);integer(length,'length',0,before.size-offset);
 for(const x of [field,filename,...Object.keys(fields)])if(/[\r\n"\\]/.test(x))fail('无效 multipart 名称');
 const boundary='tide-'+randomID();let start='';
 for(const [k,v] of Object.entries(fields))start+='--'+boundary+'\r\nContent-Disposition: form-data; name="'+k+'"\r\n\r\n'+String(v)+'\r\n';
 start+='--'+boundary+'\r\nContent-Disposition: form-data; name="'+field+'"; filename="'+filename+'"\r\nContent-Type: application/octet-stream\r\n\r\n';const end='\r\n--'+boundary+'--\r\n';
 return {headers:{'Content-Type':'multipart/form-data; boundary='+boundary},bodyStream:{length:utf8(start).length+length+utf8(end).length,async *chunks(){await unchanged(ctx,path,before);yield start;for(let n=0;n<length;){const b=await ctx.fs.readBytes(path,offset+n,Math.min(65536,length-n));if(!b.length)fail('源文件提前结束','conflict');yield b;n+=b.length;}await unchanged(ctx,path,before);yield end;}}};
}
