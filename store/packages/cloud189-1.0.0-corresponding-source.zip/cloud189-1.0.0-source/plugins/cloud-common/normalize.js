// Shared MIT utilities, bundled into each independent connector.
export function fail(message,code='invalid_input',retryable=false){const e=new Error(message);e.code=code;e.retryable=retryable;throw e;}
export const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
export const has=(v,k)=>typeof v==='string'||Array.isArray(v)?v.includes(k):Object.hasOwn(v||{},k);
export const get=(v,k,d=null)=>has(v,k)?v[k]:d;
export function setDefault(v,k,d=null){if(!has(v,k))v[k]=d;return v[k];}
export function lowerMerge(p,...defaults){const out={};for(const d of defaults)for(const [k,v] of Object.entries(d||{}))out[k.toLowerCase()]=v;for(const [k,v] of Object.entries(p||{}))out[k.toLowerCase()]=v;return out;}
export function format(s,vs){let i=0;const a=Array.isArray(vs)?vs:[vs];return s.replace(/%[sd]/g,()=>String(a[i++]));}
export function split(s,sep,max){if(max===undefined)return s.split(sep);const a=[];while(a.length<max){const i=s.indexOf(sep);if(i<0)break;a.push(s.slice(0,i));s=s.slice(i+sep.length);}return [...a,s];}
export function completeURL(path,base=''){if(/^https?:\/\//.test(path))return path;if(path.startsWith('//'))return 'https:'+path;return base.replace(/\/+$/,'')+'/'+path.replace(/^\/+/, '');}
export function escapeName(s){return String(s).replace(/[\"\\/:*?|><]/g,c=>String.fromCharCode(c.charCodeAt(0)+65248));}
export function valid(v){if(typeof v==='number'&&(!Number.isFinite(v)||Number.isInteger(v)&&!Number.isSafeInteger(v)))fail('数字必须为安全整数，长 ID 请使用字符串');if(v&&typeof v==='object')for(const [k,x] of Object.entries(v)){if(['__proto__','constructor','prototype'].includes(k))fail('不允许的参数键');valid(x);}return v;}
export function text(v,n){if(typeof v!=='string'||!v.length)fail(n+' 必须为非空字符串');return v;}
export function integer(v,n,min=0,max=Number.MAX_SAFE_INTEGER){if(!Number.isSafeInteger(v)||v<min||v>max)fail(n+' 超出允许范围');return v;}
export function utf8(s){const a=[];for(const c of s){const n=c.codePointAt(0);if(n<128)a.push(n);else if(n<2048)a.push(192|(n>>6),128|(n&63));else if(n<65536)a.push(224|(n>>12),128|((n>>6)&63),128|(n&63));else a.push(240|(n>>18),128|((n>>12)&63),128|((n>>6)&63),128|(n&63));}return new Uint8Array(a);}
export function decode(a){let s='';for(const b of a)s+='%'+b.toString(16).padStart(2,'0');return decodeURIComponent(s);}
export function base64(a){const t='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';let s='';for(let i=0;i<a.length;i+=3){const n=(a[i]<<16)|((a[i+1]||0)<<8)|(a[i+2]||0);s+=t[n>>>18]+t[(n>>>12)&63]+(i+1<a.length?t[(n>>>6)&63]:'=')+(i+2<a.length?t[n&63]:'=');}return s;}
export function unbase64(s){const t='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';let n=0,bits=0,a=[];for(const c of s.replace(/-/g,'+').replace(/_/g,'/').replace(/=+$/,'')){const v=t.indexOf(c);if(v<0)fail('无效 Base64');n=(n<<6)|v;bits+=6;if(bits>=8){bits-=8;a.push((n>>bits)&255);}}return new Uint8Array(a);}
export const hex=a=>Array.from(a,b=>b.toString(16).padStart(2,'0')).join('');
export const unhex=s=>Uint8Array.from(s.match(/../g)||[],b=>parseInt(b,16));
export function parseJSON(s){return JSON.parse(s.replace(/"(?:[^"\\]|\\.)*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g,t=>t[0]!=='"'&&/^-?\d+$/.test(t)&&!Number.isSafeInteger(Number(t))?JSON.stringify(t):t));}
export const query=p=>Object.entries(p||{}).flatMap(([k,v])=>(Array.isArray(v)?v:[v]).map(x=>encodeURIComponent(k)+'='+encodeURIComponent(x===null?'':String(x)))).join('&');
export const firstHeader=(h,k)=>{for(const [n,v] of Object.entries(h||{}))if(n.toLowerCase()===k.toLowerCase())return Array.isArray(v)?v[0]:v;return '';};
export function endpoint(url,{http=false}={}){const m=/^(https?):\/\/(\[[a-fA-F0-9:]+\]|[a-zA-Z0-9.-]+)(?::(\d+))?(\/[^#]*)?$/.exec(text(url,'URL'));if(!m||(!http&&m[1]!=='https')||/%0[ad]/i.test(url)||/[\r\n\\]/.test(url))fail('无效服务地址');return {scheme:m[1],host:m[2].toLowerCase(),port:Number(m[3]||(m[1]==='https'?443:80)),path:m[4]||'/',origin:m[1]+'://'+m[2]+(m[3]?':'+m[3]:'')};}
export function randomID(){return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.floor(Math.random()*16);return (c==='x'?r:(r&3)|8).toString(16);});}
export const template=(s,p)=>s.replace(/\{([^}]+)\}/g,(_,k)=>String(p[k]));
export function providerURL(provider,path,base){
 if(/^https?:\/\//.test(path))return path;
 if(provider==='cloud123')return completeURL(path.startsWith('/')?path:'/api/'+path,base||'https://www.123pan.com/b');
 if(provider==='cloud189')return tianyiURL(path,base||'https://cloud.189.cn');
 return completeURL(path,base);
}
export function tianyiURL(path,base='https://cloud.189.cn',family=false,open=true){
 if(/^https?:\/\//.test(path))return path;
 let prefix=family?(!path.includes('/')?'/family/file':path.startsWith('file/')?'/family':''):open&&!path.includes('/')?'/file':'';
 if(path.startsWith('api/'))path='/'+path;
 if(!path.startsWith('/')){if(base.startsWith('https://api.')){if(open&&!/^(portal|open)\//.test(path))prefix='/open'+prefix;}else if(/^(portal|open)\//.test(path))prefix='/api'+prefix;else if(open)prefix='/api/open'+prefix;prefix+='/';}
 return base+prefix+path;
}
