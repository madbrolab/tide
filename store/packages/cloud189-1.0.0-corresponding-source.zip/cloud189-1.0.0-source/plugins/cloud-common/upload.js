// Persisted, fenced upload tasks. Cursors contain only an opaque task ID.
import {fail,text,integer,parseJSON,escapeName} from './normalize.js';
import {info,unchanged,digest} from './file.js';
const SQL='CREATE TABLE IF NOT EXISTS upload_task (id TEXT PRIMARY KEY, state TEXT NOT NULL, phase TEXT NOT NULL, lease INTEGER NOT NULL DEFAULT 0, busy INTEGER NOT NULL DEFAULT 0, updated INTEGER NOT NULL) WITHOUT ROWID';
export const migrations=[SQL];
export function uploadActions(provider,driver){
 const purpose=provider+'-upload-v1',seal=(ctx,v)=>ctx.secrets.seal(purpose,JSON.stringify(v));
 async function ref(ctx,cursor){const r=parseJSON(await ctx.secrets.open(purpose,text(cursor,'cursor')));return text(r.id,'taskId');}
 async function row(ctx,id){const r=(await ctx.db.query('SELECT * FROM upload_task WHERE id=?',[id]))[0];if(!r)fail('上传任务不存在','not_found');return r;}
 async function state(ctx,r){const s=parseJSON(await ctx.secrets.open(purpose,r.state));if(s.id!==r.id)fail('上传状态不一致','conflict');return s;}
 const summary=(t,phase,cursor)=>({cursor,status:phase,nextPart:t.next,totalParts:t.total,uploadedBytes:t.reused?t.size:Math.min((t.next-1)*t.partSize,t.size),size:t.size,...(t.result?{result:t.result}:{}),...(t.ticket?{uploadId:String(t.ticket.preuploadID||t.ticket.UploadId||t.ticket.uploadFileId||'')}: {})});
 async function acquire(ctx,id){const until=Date.now()+(Number.isFinite(ctx.remaining())?Math.max(ctx.remaining(),1000):600000)+30000;if(!await ctx.db.exec('UPDATE upload_task SET lease=lease+1,busy=? WHERE id=? AND busy<=?',[until,id,Date.now()]))fail('同一上传任务正在操作','busy',true);return row(ctx,id);}
 async function save(ctx,r,t,phase){const sealed=await seal(ctx,t);if(!await ctx.db.exec('UPDATE upload_task SET state=?,phase=?,updated=? WHERE id=? AND lease=? AND busy>?',[sealed,phase,Date.now(),r.id,r.lease,Date.now()]))fail('上传任务操作已过期','conflict');r.phase=phase;r.state=sealed;}
 async function bound(ctx,t,a){if(t.account!==await ctx.crypto.digest('sha256',a.session||''))fail('上传任务与账号会话不匹配','forbidden');}
 async function init(ctx,a,env){
  const sourcePath=text(a.sourcePath,'sourcePath'),before=await info(ctx,sourcePath),md5=await digest(ctx,sourcePath,'md5',0,before.size);await unchanged(ctx,sourcePath,before);
  const t={path:sourcePath,size:before.size,modified:before.modified,md5,name:escapeName(a.file_name||sourcePath.split('/').pop()),next:1,account:await ctx.crypto.digest('sha256',text(a.session,'session')),options:{parent_id:a.parent_id??0,duplicate:a.duplicate??0,family_id:a.family_id,opertype:a.opertype??3,base_url:a.base_url}};
  Object.assign(t,await driver.begin(ctx,a,env,t));integer(t.partSize,'分片大小',1);t.total=t.reused?0:Math.ceil(t.size/t.partSize);integer(t.total,'分片总数');
  const phase=t.done?'completed':t.total===0?'uploaded':'uploading';
  for(let i=0;i<64;i++){t.id=await ctx.crypto.digest('sha256',ctx.runId+':'+Date.now()+':'+i);if(await ctx.db.exec('INSERT OR IGNORE INTO upload_task(id,state,phase,updated) VALUES (?,?,?,?)',[t.id,await seal(ctx,t),phase,Date.now()]))return summary(t,phase,await seal(ctx,{id:t.id}));}
  fail('无法创建上传记录','conflict');
 }
 async function run(ctx,a,env,mode){const id=await ref(ctx,a.cursor);let r=await row(ctx,id),t=await state(ctx,r);await bound(ctx,t,a);
  if(mode==='status'&&r.phase!=='processing')return summary(t,r.phase==='completing'?'uncertain':r.phase,a.cursor);
  if(['completed','cancelled'].includes(r.phase))return summary(t,r.phase,a.cursor);
  if(r.phase==='completing')fail('合并结果尚未确认，请通过原始任务查询接口核对，禁止重复合并','conflict');
  r=await acquire(ctx,id);
  try{
   t=await state(ctx,r);await bound(ctx,t,a);if(['completed','cancelled'].includes(r.phase))return summary(t,r.phase,a.cursor);if(r.phase==='completing')fail('合并结果尚未确认','conflict');
   if(r.phase==='processing'){
    if(mode==='cancel')fail('云端正在合并，不能清理续传记录','conflict');const result=await driver.poll(ctx,a,env,t);t.result=result;if(result.data?.completed){delete t.ticket;delete t.options;delete t.path;await save(ctx,r,t,'completed');}else await save(ctx,r,t,'processing');
   }else if(mode==='resume'){
    if(a.sourcePath&&a.sourcePath!==t.path)fail('续传源路径不匹配');await unchanged(ctx,t.path,t);
    // Re-hash the full source once per resumed action: catches changes even if mtime was restored.
    if(await digest(ctx,t.path,'md5',0,t.size)!==t.md5)fail('源文件内容已变化','conflict');
    integer(a.maxParts??2,'maxParts',1,64);
    for(let i=0;i<(a.maxParts??2)&&t.next<=t.total&&ctx.remaining()>1500;i++){
     await driver.part(ctx,a,env,t);await unchanged(ctx,t.path,t);t.next++;await save(ctx,r,t,t.next>t.total?'uploaded':'uploading');
    }
   }else if(mode==='complete'){
    if(t.next<=t.total)fail('分片尚未全部上传','conflict');await save(ctx,r,t,'completing');
    const result=await driver.complete(ctx,a,env,t);t.result=result;if(result.data?.async&&!result.data?.completed&&driver.poll){await save(ctx,r,t,'processing');}else{delete t.ticket;delete t.options;delete t.path;await save(ctx,r,t,'completed');}
   }else if(mode==='cancel'){
    // These upstreams have no upload-abort endpoint. Forget local progress explicitly only.
    delete t.ticket;delete t.options;delete t.path;t.result={localOnly:true};await save(ctx,r,t,'cancelled');
   }
   return summary(t,r.phase,a.cursor);
  }finally{await ctx.db.exec('UPDATE upload_task SET busy=0 WHERE id=? AND lease=?',[id,r.lease]);}
 }
 return {'upload-file':init,'upload-resume':(c,a,e)=>run(c,a,e,'resume'),'upload-complete':(c,a,e)=>run(c,a,e,'complete'),'upload-status':(c,a,e)=>run(c,a,e,'status'),'upload-forget':(c,a,e)=>run(c,a,e,'cancel')};
}
