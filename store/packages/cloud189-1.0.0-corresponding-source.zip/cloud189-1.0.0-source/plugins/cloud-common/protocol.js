import {object,fail,text,endpoint,providerURL,valid,query,utf8,parseJSON,firstHeader} from './normalize.js';
export function createConnector(config,builders,custom={}){
 const purpose=config.id+'-session-v1';
 async function seal(ctx,s){return ctx.secrets.seal(purpose,JSON.stringify(s));}
 function validateState(s){
  if(!object(s))fail('无效账号参数');
  for(const k of ['token','cookie','accessToken','sessionKey','sessionSecret','familySessionKey','familySessionSecret','pkId'])if(s[k]!==undefined&&(typeof s[k]!=='string'||/[\r\n]/.test(s[k])))fail('无效凭据字段 '+k);
  return s;
 }
 const publicAction=op=>config.public?.(op)||false;
 async function send(ctx,wire,args,state,op){
  let w={...wire,headers:{...wire.headers}};
  if(config.prepare)w=await config.prepare(ctx,w,args,state,op);
  let base=w.base_url||args.base_url||config.base;
  if(!/^https?:\/\//.test(w.url))w.url=providerURL(config.id,w.url,base);
  const u=endpoint(w.url);
  if(!config.hosts.includes(u.host))fail('请求地址不属于此网盘');
  w.method=(w.method||'GET').toUpperCase();if(!['GET','POST','PUT','PATCH','DELETE','HEAD'].includes(w.method))fail('不支持的请求方法');
  const publicRequest=publicAction(op)||args.anonymous===true;
  const canonical=k=>k.toLowerCase().replace(/(^|-)[a-z]/g,x=>x.toUpperCase());
  const headers={};for(const h of [{Accept:'application/json'},config.headers||{},w.headers||{}])for(const [k,v] of Object.entries(h))headers[canonical(k)]=v;
  if(!publicRequest){
   if(config.id==='quark'&&state.cookie)headers.Cookie=state.cookie;
   else if(config.id==='cloud123'&&state.token)headers.Authorization='Bearer '+state.token.replace(/^Bearer /i,'');
   else if(config.id==='cloud189'&&state.cookie)headers.Cookie=state.cookie;
   if(!Object.keys(state).length)fail('请先调用 session-create 或 login，传入返回的 session','unauthorized');
  }
  for(const [k,v] of Object.entries(args.headers||{})){
   if(!/^[a-zA-Z0-9-]+$/.test(k)||/^(host|authorization|cookie|content-length|transfer-encoding|connection)$/i.test(k)||/[\r\n]/.test(String(v)))fail('无效附加请求头');headers[canonical(k)]=String(v);
  }
  for(const [k,v] of Object.entries(headers))if(!/^[a-zA-Z0-9-]+$/.test(k)||/[\r\n]/.test(String(v)))fail('无效请求头');
  let payload=w.payload;
  if(payload!==undefined){if(w.method==='POST')w.data=payload;else w.params=payload;}
  let url=w.url,body;
  if(config.id==='quark')w.params={pr:'ucpro',fr:'pc',...args.params,...w.params};
  if(w.params&&Object.keys(w.params).length)url+=(url.includes('?')?'&':'?')+query(w.params);
  if(w.json!==undefined){headers['Content-Type']='application/json';body=utf8(JSON.stringify(w.json));}
  else if(w.data!==undefined){headers['Content-Type']='application/x-www-form-urlencoded';body=utf8(typeof w.data==='string'?w.data:query(w.data));}
  if(w.files)fail('文件接口请使用 sourcePath 的上传动作');
  const req={url,method:w.method,headers,...(body?{body}:{}),responseType:'text',maxBytes:240000,followRedirects:false,...(w.bodyPath?{bodyPath:w.bodyPath}:{}),...(w.outputPath?{outputPath:w.outputPath}: {})};
  const r=await ctx.net.request(req);
  if(w.raw){if(config.response)await config.response(ctx,undefined,r,w,args,state,op);return r;}
  if(w.outputPath)return {status:r.status,path:r.path,bytes:r.bytes};
  let data;
  if(r.body){try{data=parseJSON(r.body);}catch{if(config.parse)data=config.parse(r.body);else if(op==='ping')data={message:r.body};}}
  if(config.response)data=await config.response(ctx,data,r,w,args,state,op);
  if(data===undefined){if(r.status>=200&&r.status<300&&!r.body)return {};fail(config.name+' HTTP '+r.status,'upstream',r.status===429||r.status>=500);}
  if(r.status>=400&&(!object(data)||!('code'in data||'errorCode'in data||'res_code'in data||'error'in data)))fail(config.name+' HTTP '+r.status,'upstream',r.status===429||r.status>=500);
  return data;
 }
 async function execute(ctx,op,args={}){
  valid(args);let state=args.session?validateState(parseJSON(await ctx.secrets.open(purpose,text(args.session,'session')))):{};
  async function dispatch(operation,a){
   const env={state,seal:s=>seal(ctx,validateState(s)),send:(w,b=a,o=operation)=>send(ctx,w,b,state,o),call:(o,b={})=>dispatch(o,{...a,...b}),checked:r=>checked(config.id,r)};
   if(custom[operation])return custom[operation](ctx,a,env);
   if(operation==='session-create'&&!Object.keys(a.credentials||{}).length)fail('credentials 不能为空');
   if(operation==='session-create')return {session:await env.seal({...a.credentials,...(a.baseUrl?{baseUrl:a.baseUrl}:{})})};
   if(operation==='session-update')return {session:await env.seal({...state,...a.credentials})};
   if(operation==='session-info')return {provider:config.name,connected:!!Object.keys(state).length,...(state.baseUrl?{baseUrl:state.baseUrl}:{})};
   if(operation==='check-response')return checked(config.id,a.response);
   if(operation==='request')return env.send({url:text(a.url,'url'),method:a.method||'GET',...(['GET','HEAD'].includes(a.method||'GET')?{params:a.payload}:{json:a.payload})},a,operation);
   const builder=builders[operation];if(!builder)fail('未知接口 '+operation);
   const w=builder(a);
   if(w.call)return dispatch(w.call,w.args);
   return send(ctx,w,a,state,operation);
  }
  return dispatch(op,args);
 }
 return execute;
}
export function checked(id,r){if(!object(r))fail('上游响应不是对象','upstream');let bad=false;if(id==='quark')bad=!!r.code||r.status>=400;else if(id==='cloud123')bad=r.code!==undefined&&![0,200,'0','200'].includes(r.code);else bad=r.errorCode!==undefined&&!['',0,'0'].includes(r.errorCode)||r.res_code!==undefined&&Number(r.res_code)!==0||r.result!==undefined&&Number(r.result)!==0;if(bad)fail('上游业务错误：'+String(r.message||r.msg||r.errorCode||r.res_message||r.code||r.result),'upstream');return r;}
