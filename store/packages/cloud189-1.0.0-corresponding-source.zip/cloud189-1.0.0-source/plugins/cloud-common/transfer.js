// Stream file ranges through SDK sockets without buffering whole files.
// Use SDK 2 网络 sockets and file slices, with at most 64 KiB buffered per write.
import {endpoint,utf8,fail,integer,firstHeader} from './normalize.js';
import {info,unchanged} from './file.js';
function decode(a){let s='';for(const b of a)s+='%'+b.toString(16).padStart(2,'0');return decodeURIComponent(s);}
function etag(headers){for(const [k,v] of Object.entries(headers||{}))if(k.toLowerCase()==='etag')return Array.isArray(v)?v[0]:v;return '';}
async function write(ctx,h,data){let i=0;while(i<data.length){const n=await ctx.net.write({handle:h,data:data.subarray(i)});if(!Number.isInteger(n)||n<=0||n>data.length-i)fail('网络 写入未完成','upstream',true);i+=n;}}
export function parseReply(bytes){
  // HTTP metadata and chunk boundaries are ASCII; decode the body as UTF-8 last.
  let raw='';for(const b of bytes)raw+=String.fromCharCode(b);
  const end=raw.indexOf('\r\n\r\n');if(end<0)fail('上传 HTTP 响应头不完整','upstream');
  const head=raw.slice(0,end).split('\r\n'),status=Number(/^HTTP\/1\.[01] (\d{3})/.exec(head.shift())?.[1]);if(!status)fail('无效 上传 HTTP 状态','upstream');
  const headers={};for(const line of head){const i=line.indexOf(':');if(i<1)fail('无效 上传 HTTP 头','upstream');headers[line.slice(0,i).toLowerCase()]=line.slice(i+1).trim();}
  let body=bytes.subarray(end+4);
  if(/chunked/i.test(headers['transfer-encoding']||'')){
    let pos=end+4;const chunks=[];
    for(;;){const e=raw.indexOf('\r\n',pos);if(e<0)fail('上传 分块响应不完整','upstream');const token=raw.slice(pos,e).split(';')[0];if(!/^[0-9a-f]+$/i.test(token))fail('无效 上传 分块长度','upstream');const size=parseInt(token,16);pos=e+2;if(size===0)break;if(pos+size+2>bytes.length||raw.slice(pos+size,pos+size+2)!=='\r\n')fail('上传 分块响应不完整','upstream');chunks.push(...bytes.subarray(pos,pos+size));pos+=size+2;}
    body=new Uint8Array(chunks);
  }else if(headers['content-length']!==undefined){const n=Number(headers['content-length']);integer(n,'Content-Length');if(body.length!==n)fail('上传 响应长度不匹配','upstream');}
  return {status,headers,body:decode(body),etag:headers.etag||''};
}
export async function transfer(ctx,a){
  const u=endpoint(a.url,{http:!!a.allowHTTP});
  if(!a.sourceRange&&!a.bodyStream){
    const r=await ctx.net.request({url:a.url,method:a.method,headers:a.headers,...(a.body!==undefined?{body:utf8(a.body)}:{}),responseType:'text',maxBytes:240000,followRedirects:false});
    return {...r,etag:etag(r.headers)};
  }
  const before=a.sourceRange?await info(ctx,a.sourcePath):null;
  const {offset=0,length}=a.sourceRange||a.bodyStream;integer(offset,'offset',0,before?.size??0);integer(length,'length',0,before?before.size-offset:Number.MAX_SAFE_INTEGER);
  if(before&&offset===0&&length===before.size){
    const r=await ctx.net.request({url:a.url,method:a.method,headers:a.headers,bodyPath:a.sourcePath,responseType:'text',maxBytes:240000,followRedirects:false});
    await unchanged(ctx,a.sourcePath,before);return {...r,etag:etag(r.headers)};
  }
  const socket=await ctx.net.connect({protocol:'tcp',address:u.host+':'+u.port,tls:u.scheme==='https'});
  try{
    const headers={...a.headers,Host:u.host+((u.scheme==='https'&&u.port===443||u.scheme==='http'&&u.port===80)?'':':'+u.port),'Content-Length':String(length),Connection:'close'};
    let head=a.method+' '+u.path+' HTTP/1.1\r\n';
    for(const [k,v] of Object.entries(headers)){if(/[\r\n]/.test(k+v))fail('非法请求头');head+=k+': '+v+'\r\n';}
    await write(ctx,socket.handle,utf8(head+'\r\n'));
    if(a.bodyStream){let sent=0;for await(const chunk of a.bodyStream.chunks()){const b=chunk instanceof Uint8Array?chunk:utf8(chunk);if(sent+b.length>length)fail('请求正文长度发生变化','conflict');await write(ctx,socket.handle,b);sent+=b.length;}if(sent!==length)fail('请求正文长度发生变化','conflict');}
    else for(let n=0;n<length;){const b=await ctx.fs.readBytes(a.sourcePath,offset+n,Math.min(65536,length-n));if(!b.length)fail('源文件提前结束','conflict');await write(ctx,socket.handle,b);n+=b.length;}
    const bytes=[];for(;;){const r=await ctx.net.readBytes({handle:socket.handle,length:16384});if(bytes.length+r.data.length>250000)fail('上传 响应过大','upstream');for(const b of r.data)bytes.push(b);if(r.eof)break;if(!r.data.length)fail('上传 响应中断','upstream',true);}
    if(before)await unchanged(ctx,a.sourcePath,before);return parseReply(new Uint8Array(bytes));
  }finally{await ctx.net.close({handle:socket.handle});}
}
