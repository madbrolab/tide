// Build-time Node only; distribution runs inside Tide's existing QuickJS engine.
import {readFile,writeFile,copyFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {build} from '../../sdk/packager/node_modules/esbuild/lib/main.js';
import {migrations} from '../../plugins/cloud-common/upload.js';
const root=fileURLToPath(new URL('../../',import.meta.url));
const shape=(type,description,extra={})=>({type:Array.isArray(type)?type:[type],description,...extra});
const str=d=>shape('string',d),num=d=>shape('integer',d),bool=d=>shape('boolean',d),obj=d=>shape('object',d,{additionalProperties:true});
const value=shape(['object','array','string','integer','boolean','null'],'上游原始参数；长 ID 使用字符串',{additionalProperties:true,items:shape(['object','array','string','integer','boolean','null'],'参数条目',{additionalProperties:true,items:shape(['object','string','integer','boolean','null'],'嵌套条目',{additionalProperties:true})})});
const common={session:str('session-create 或登录动作返回的加密会话；只适用于当前插件'),payload:value,base_url:str('可选上游兼容域地址，仅允许该网盘域名'),headers:obj('额外协议头；不允许覆盖凭据、Host 或 Content-Length'),anonymous:bool('公开分享接口不附加会话凭据')};
const extra={cookie:str('SSO 登录 Cookie 值'),use_access_token:shape(['boolean','string','object'],'是否使用 AccessToken 签名，亦可显式传 token 或认证头',{additionalProperties:true}),credentials:obj('账号凭据；夸克 cookie；123 token；天翼 cookie 或 sessionKey/sessionSecret 等'),response:obj('待检查的上游响应'),url:str('请求或下载地址'),method:str('请求方法'),params:obj('夸克公共请求参数，默认 pr=ucpro、fr=pc'),sourcePath:str('宿主可读的本机文件绝对路径'),file_name:str('远端文件名'),file_md5:str('文件 MD5 十六进制'),file_size:num('文件总字节数'),slice_size:num('天翼分片字节数，默认 10 MiB'),parent_id:shape(['string','integer'],'父目录 ID'),family_id:shape(['string','integer'],'家庭共享 ID'),duplicate:num('123 同名策略：0 提示、1 保留两者、2 替换'),opertype:num('天翼同名策略：1 保留两者、2 忽略、3 替换'),mode:str('123 上传通道：web/open/oss'),maxParts:num('一次续传 1–64 片，默认 2'),offset:num('源文件字节偏移'),length:num('传输字节数'),cursor:str('登录或上传流程的加密游标'),username:str('天翼账号'),passport:str('123 账号'),password:str('账号密码'),client_id:str('开放平台应用 ID'),client_secret:str('开放平台应用密钥'),refresh_token:str('刷新令牌'),app_id:str('登录应用 ID'),session_key:str('天翼 sessionKey'),token:str('访问令牌'),redirect_uri:str('OAuth 回调地址'),captchaToken:str('官方验证流程取得的验证码令牌'),is_family:bool('是否家庭共享'),platform:num('123 扫码设备类型'),remember:bool('保持登录')};
const labels={'session-create':'导入账号并生成加密会话','session-info':'查看当前会话状态','session-update':'更新账号凭据并生成新会话','check-response':'检查上游业务响应','request':'调用指定上游接口','login':'账号或扫码登录','open-login':'开放平台登录','login-with-qrcode':'分步扫码登录','upload-file':'初始化文件上传','open-upload-file':'初始化开放平台上传','open-oss-upload-file':'初始化开放平台 OSS 上传','upload-resume':'继续上传并保存进度','upload-complete':'合并已上传分片','upload-status':'查询持久化上传进度','upload-forget':'停止本地续传并清除本地票据'};
for(const id of process.argv.slice(2).length?process.argv.slice(2):['quark','cloud123','cloud189']){
 const dir=resolve(root,'plugins',id),api=JSON.parse(await readFile(resolve(dir,'api.json'),'utf8'));
 const {config,custom}=await import(resolve(dir,'runtime.js'));
 const names=[...new Set([...Object.keys(api),...Object.keys(custom).filter(n=>!n.startsWith('-')),'session-create','session-update','session-info','check-response','request'])];
 const manifest={sdk:2,id:'com.tide.'+id,name:config.name+'连接器',version:'1.0.0',description:'纯 JS '+config.name+'连接器，提供账号、文件、分享与'+(id==='quark'?'回收站接口。':'分片续传接口。'),developer:{name:'Tide',repository:'https://github.com/madbrolab/tide'},icon:'icon.png',symbol:'globe',connector:true,credentialTarget:'com.tide.'+id,credentialKinds:[id==='quark'||id==='cloud189'?'cookie':'bearer'],domains:config.hosts,actions:{},...(id!=='quark'?{storage:'sql'}:{})};
 const ops={},lines=["import {execute} from './runtime.js';"];
 for(const [i,name] of names.entries()){
  const c=api[name],summary=labels[name]||c?.summary||name;let properties={...common},required=[];
  for(const [p,d] of Object.entries(c?.parameters||{})){
   if(!properties[p])properties[p]=extra[p]||(/^True$|^False$/.test(d||'')?bool('上游参数 '+p):/^[-\d]+$/.test(d||'')?num('上游参数 '+p):value);
   if(d===null)required.push(p);
  }
  if(custom[name]||!c){properties={...properties,...extra};required=name==='session-create'?['credentials']:name==='session-update'?['session','credentials']:name==='check-response'?['response']:name==='request'?['url']:name==='upload-file'||name==='open-upload-file'||name==='open-oss-upload-file'||name==='open-upload-single'||name==='open-upload-slice'||name==='offline-task-upload-seed'?['session','sourcePath']:name.startsWith('upload-')&&['resume','complete','status','forget'].includes(name.slice(7))?['session','cursor']:[];}
  let args={};for(const p of required)args[p]=p==='payload'?{}:p==='credentials'?{[id==='cloud123'?'token':'cookie']:'example'}:p==='response'?{code:id==='cloud123'?0:200}:p==='sourcePath'?'/data/example.bin':p==='url'?config.base+'/':'example';
  const notes=(c?.doc||'')+'\n\n使用 session-create 或登录返回的 session。网络接口原样返回业务响应；check-response 可显式检查。Python 对象、同步调用和迭代器不进入运行时。'+(name.startsWith('upload-')?' 上传流程：upload-file → upload-resume → upload-complete；原 cursor 查询私库最新进度。forget 只清理本地，不代表删除云端未完成分片。':'');
  manifest.actions[name]={label:summary.slice(0,32),external:true,immediateOnly:true,entry:'main',bootstrap:true};
  ops[name]={summary,input:shape('object','调用参数',{properties,required}),output:obj('上游原始响应或流程状态'),notes,example:{args,result:{}}};
  lines.push(`export async function action${i}(ctx,args={}){return execute(ctx,${JSON.stringify(name)},args);}\nexport {action${i} as ${JSON.stringify(name)}};`);
 }
 await writeFile(resolve(dir,'entry.js'),lines.join('\n'));
 await build({absWorkingDir:root,entryPoints:[resolve(dir,'entry.js')],outfile:resolve(dir,'main.js'),bundle:true,format:'esm',target:'es2022',minify:false});
 await writeFile(resolve(dir,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');await writeFile(resolve(dir,'operations.json'),JSON.stringify(ops,null,2)+'\n');
 await writeFile(resolve(dir,'package.json'),JSON.stringify({name:'@tide/'+id,version:'1.0.0',private:true,type:'module',scripts:{build:'node ../../tools/cloud-connectors/build.mjs '+id,test:'node --test ../cloud-common/tests/*.test.mjs'}},null,2)+'\n');
 if(id!=='quark')await writeFile(resolve(dir,'migrations.json'),JSON.stringify(migrations,null,2)+'\n');
 console.log(JSON.stringify({id,actions:names.length,groups:1}));
}
