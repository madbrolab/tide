function cookieMap(value){
  if(value==null)return {};
  if(typeof value==="object"&&!Array.isArray(value))return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,String(v)]));
  const result={};for(const part of String(value).split(";")){const pos=part.indexOf("=");if(pos>0){const key=part.slice(0,pos).trim(),val=part.slice(pos+1).trim();if(!/^[!#$%&'*+.^_`|~\w-]+$/.test(key)||/[\r\n]/.test(val))throw connectorError("Cookie 格式无效");result[key]=val;}}
  return result;
}
async function clientState(ctx,a,operation){
  let state=a.session?losslessJSON(await ctx.secrets.open("p115-client",a.session)):{kind:a.kind??"cookie",cookies:{},headers:{"user-agent":"Mozilla/5.0","accept":"*/*"}};
  if(operation==="from_path"){
    if(typeof a.path!=="string"||!a.path.startsWith("/"))throw connectorError("需要凭据文件的绝对路径");
    const b=await ctx.fs.readBytes(a.path,0,16385);if(b.length>16384)throw connectorError("凭据文件过大");state.cookies=cookieMap(decodeURIComponent(Array.from(b,v=>"%"+hexByte(v)).join("")));
  }
  if(operation==="init"||operation==="update_cookies"){
    if(a.cookies!==undefined)state.cookies=operation==="update_cookies"?{...state.cookies,...cookieMap(a.cookies)}:cookieMap(a.cookies);
    if(a.cookies===null)state.cookies={};
    if(a.access_token)state.access_token=a.access_token;if(a.refresh_token)state.refresh_token=a.refresh_token;
    if(a.refresh_token&&!a.access_token){const r=ensureOK(await do_common_login_refresh_token_open(ctx,{payload:{refresh_token:a.refresh_token}}));state.access_token=r.data.access_token;state.refresh_token=r.data.refresh_token;}
    if(a.headers)state.headers={...state.headers,...a.headers};
    if(operation==="init"&&(state.kind==="cookie"?!Object.keys(state.cookies).length:!state.access_token)){
      const qr=await extendedQR(ctx,{...a,session:state.qr},state.kind==="bearer");
      if(qr.stage!=="complete"){state.qr=qr.session;return {stage:qr.stage,qrcode:qr.qrcode??null,session:await ctx.secrets.seal("p115-client",JSON.stringify(state))};}
      delete state.qr;if(state.kind==="cookie")state.cookies=cookieMap(qr.result.data.cookie);else{state.access_token=qr.result.data.access_token;state.refresh_token=qr.result.data.refresh_token;}
    }
  }
  if(operation==="cookies")return state.cookies;
  if(operation==="cookies_str")return Object.entries(state.cookies).map(([k,v])=>k+"="+v).join("; ");
  if(operation==="headers")return state.headers;
  if(operation==="user_id"){
    if(state.cookies.UID)return state.cookies.UID.split("_")[0];
    if(!state.access_token||!a.uuid)throw connectorError("需要有效 session；令牌会话还需要 uuid");
    const r=ensureOK((await ctx.invoke({version:1,target:"com.tide.cloud115",operation:"open-user-info",uuid:a.uuid,credential:{kind:"bearer",inline:state.access_token},args:{}})).data);return remoteId(r.data.user_id);
  }
  if(operation==="login_ssoent"){
    if(state.cookies.UID)return state.cookies.UID.split("_")[1]??"";
    return "";
  }
  const session=await ctx.secrets.seal("p115-client",JSON.stringify(state));
  return {session,kind:state.kind,headers:state.headers,...(a.uuid?{credential:await ctx.secrets.issue({uuid:a.uuid,kind:state.kind,value:state.kind==="cookie"?Object.entries(state.cookies).map(([k,v])=>k+"="+v).join("; "):state.access_token})}:{})};
}
async function currentAccount(ctx){const kind=(await ctx.connection()).kind;if(kind==="bearer"){const r=ensureOK(await do_open_user_info(ctx,{}));return remoteId(r.data?.user_id??r.user_id);}if(kind==="cookie")return String(await remoteUser(ctx,{}));throw connectorError("需要账号凭据","forbidden");}
const appSSO={web:"A1",desktop:"A1",ios:"D1",bios:"D2","115ios":"D3",android:"F1",bandroid:"F2","115android":"F3",ipad:"H1",bipad:"H2","115ipad":"H3",tv:"I1",apple_tv:"I2",qandroid:"M1",qios:"N1",qipad:"O1",os_windows:"P1",os_mac:"P2",os_linux:"P3",windows:"P1",mac:"P2",linux:"P3",wechatmini:"R1",alipaymini:"R2",harmony:"S1"};
async function clientLock(ctx,a){
  const key=String(a.key??"");if(!key||key.length>128)throw connectorError("需要锁的 key");
  if(a.release){return {released:await ctx.db.exec("DELETE FROM client_locks WHERE lock_key=? AND token=?",[key,a.token??""])===1};}
  const now=Date.now(),expires=now+bounded(a.ttl_ms??30000,100,300000),token=ctx.runId;
  const changed=await ctx.db.exec("INSERT INTO client_locks(lock_key,token,expires) VALUES(?,?,?) ON CONFLICT(lock_key) DO UPDATE SET token=excluded.token,expires=excluded.expires WHERE client_locks.expires<?",[key,token,expires,now]);
  return changed?{acquired:true,key,token,expires}:{acquired:false,key};
}
function derRead(data,pos){const tag=data[pos++];let length=data[pos++];if(length&128){let n=length&127;length=0;if(n>4)throw connectorError("RSA DER 长度无效");while(n--)length=length*256+data[pos++];}if(pos+length>data.length)throw connectorError("RSA DER 截断");return {tag,start:pos,end:pos+length,data:data.slice(pos,pos+length)};}
function rsaKey(pem){
  const data=from64(pem.replace(/-----[^-]+-----/g,"").replace(/\s/g,""));let sequence=derRead(data,0),first=derRead(data,sequence.start);
  if(first.tag!==2){const bit=derRead(data,first.end);if(bit.tag!==3||bit.data[0]!==0)throw connectorError("RSA 公钥结构无效");sequence=derRead(bit.data,1);const mod=derRead(bit.data,sequence.start),exp=derRead(bit.data,mod.end);return {n:BigInt("0x"+mod.data.map(hexByte).join("")),e:BigInt("0x"+exp.data.map(hexByte).join("")),size:mod.data[0]===0?mod.data.length-1:mod.data.length};}
  const exp=derRead(data,first.end);return {n:BigInt("0x"+first.data.map(hexByte).join("")),e:BigInt("0x"+exp.data.map(hexByte).join("")),size:first.data[0]===0?first.data.length-1:first.data.length};
}
async function passwordLogin(ctx,a){
  if(a.sms_code)return await do_common_login_two_step_sms_login(ctx,{payload:{account:a.account,code:a.sms_code}});
  if(a.session?.user_id){return {stage:"sms",session:a.session,result:await do_common_login_two_step_sms(ctx,{payload:{user_id:a.session.user_id}})};}
  const response=ensureOK(await do_common_app_publick_key(ctx,{})),pem=decodeURIComponent(from64(response.data.key).map(v=>"%"+hexByte(v)).join("")),key=rsaKey(pem);
  const plain=utf8Bytes(await ctx.crypto.digest("sha1",a.password)+"_"+Math.floor(Date.now()/1000));
  if(key.size<plain.length+11||key.size>512)throw connectorError("RSA 公钥位数不符合登录协议","upstream");
  const padding=[];while(padding.length<key.size-plain.length-3){const random=await ctx.fs.readBytes("/dev/urandom",0,key.size);for(const b of random)if(b&&padding.length<key.size-plain.length-3)padding.push(b);}
  let input=BigInt("0x"+[0,2,...padding,0,...plain].map(hexByte).join("")),exponent=key.e,result=1n;
  while(exponent){if(exponent&1n)result=result*input%key.n;input=input*input%key.n;exponent>>=1n;}
  const passwd=base64(bytes(result.toString(16).padStart(key.size*2,"0")));
  const r=await do_common_login_login(ctx,{app:a.app??"web",payload:{account:a.account,passwd,device_id:a.device_id??"",code:a.code??"",code_id:a.code_id??""}});
  return Number(r.errno)===40101010?{stage:"sms",session:{user_id:r.data.user_id},result:r}:{stage:failed(r)?"challenge":"complete",result:r};
}
async function genericRequest(ctx,a){
  if(typeof a.url!=="string"||!/^https:\/\/[^/]+\.115\.com(?:\/|$)/.test(a.url)&&!a.url.startsWith("https://115.com/"))throw connectorError("协议请求仅支持 115 HTTPS 地址");
  const method=a.method??"GET";if(!["GET","POST","PUT","DELETE","HEAD"].includes(method))throw connectorError("HTTP 方法无效");
  let url=a.url,body=a.body,headers={"User-Agent":"Mozilla/5.0",...a.headers},bodyHex;
  if(a.payload){if(method==="GET"||method==="HEAD")url+=(url.includes("?")?"&":"?")+wireForm(a.payload);else{body=wireForm(a.payload);headers["Content-Type"]="application/x-www-form-urlencoded";}}
  if(a.ecdh_encrypt){
    if(body){const data=utf8Bytes(body+"&"),pad=(16-data.length%16)%16;bodyHex=await ctx.crypto.aesCBC("encrypt",aesKey,aesIV,data.map(hexByte).join("")+hexByte(pad).repeat(pad));body=undefined;}
    url+=(url.includes("?")?"&":"?")+"k_ec="+quote(uploadToken(0));
  }
  const r=await ctx.http.request({url,method,credential:a.credential!==false,headers,...(body!==undefined?{body}:{}),...(bodyHex!==undefined?{bodyHex}:{}),...(a.ecdh_encrypt?{response:"hex"}:{})});
  if(a.raw)return r;if(r.status<200||r.status>=300)throw connectorError("115 HTTP "+r.status,"upstream");
  const data=a.ecdh_encrypt?uploadReply(await ctx.crypto.aesCBC("decrypt",aesKey,aesIV,r.body.slice(0,r.body.length-r.body.length%32))):losslessJSON(r.body);
  return a.check?ensureOK(data):data;
}
async function encryptedSend(ctx,url,method,params,body,publicAction){
  if(params)url+=(url.includes("?")?"&":"?")+wireForm({app_ver:version,...params});
  return await genericRequest(ctx,{url,method,ecdh_encrypt:true,credential:!publicAction,...(body?{body:wireForm(body)}:{}),headers:{"Content-Type":"application/x-www-form-urlencoded","User-Agent":userAgent}});
}
async function offlineRequest(ctx,a){
  const p={...a.payload,...(a.action?{ac:a.action}:{})},type=a.type??"web";
  if(type==="ssp"){
    const r=await send(ctx,"https://clouddownload.115.com/lixianssp/","POST",null,{data:rsaEncode(JSON.stringify(Object.fromEntries(Object.entries({app_ver:version,...p}).map(([k,v])=>[k,String(v)]))))});
    if(typeof r.data==="string")try{r.data=losslessJSON(rsaDecode(r.data));}catch{}return r;
  }
  return await genericRequest(ctx,{url:"https://clouddownload.115.com/"+(type==="web"?"web/":""),payload:p,method:a.method??"POST",ecdh_encrypt:type!=="web"&&(a.method??"POST")==="POST"});
}
function parseLiteral(text){
  let pos=0,nodes=0;
  function space(){while(/\s/.test(text[pos]??"")&&pos<text.length)pos++;}
  function parse(depth=0){space();if(++nodes>100000||depth>32)throw connectorError("区域数据过深或过大","upstream");
    const c=text[pos++];if(c==="{"||c==="["){const o=c==="{"?{}:[],end=c==="{"?"}":"]";space();while(text[pos]!==end){if(c==="{"){space();const quoted=text[pos]==='\"'||text[pos]==="'",key=text[pos]==="'"||text[pos]==='"'?parse(depth+1):(/^[\w]+/.exec(text.slice(pos))??[])[0];if(key===undefined)throw connectorError("区域数据键无效","upstream");if(!quoted)pos+=String(key).length;space();if(text[pos++]!==":")throw connectorError("区域数据结构无效","upstream");Object.defineProperty(o,key,{value:parse(depth+1),enumerable:true});}else o.push(parse(depth+1));space();if(text[pos]===end)break;if(text[pos++]!==",")throw connectorError("区域数据分隔无效","upstream");space();}pos++;return o;}
    if(c==="'"||c==='"'){let out="";while(pos<text.length){const ch=text[pos++];if(ch===c)return out;if(ch==="\\"){const e=text[pos++];if(e==="u"||e==="x"){const n=e==="u"?4:2,h=text.slice(pos,pos+n);if(!new RegExp("^[0-9a-f]{"+n+"}$","i").test(h))throw connectorError("区域字符串转义无效");out+=String.fromCharCode(parseInt(h,16));pos+=n;}else out+=({n:"\n",r:"\r",t:"\t",b:"\b",f:"\f"})[e]??e;}else out+=ch;}throw connectorError("区域字符串未结束");}
    pos--;const m=/^(?:-?\d+(?:\.\d+)?|true|false|null)/.exec(text.slice(pos));if(!m)throw connectorError("区域数据包含非字面量","upstream");pos+=m[0].length;return JSON.parse(m[0]);
  }
  const value=parse();space();if(pos!==text.length)throw connectorError("区域数据含额外内容","upstream");return value;
}
async function clientStatic(ctx,a,operation){
  if(operation==="area"){
    const r=await ctx.http.request({url:"https://cdnres.115.com/my/m_r/setting_new/js/ylmf_area.js",credential:false});
    const text=/(?<=n=)\{[\s\S]+?\}(?=;)/.exec(r.body)?.[0];if(!text)throw connectorError("区域数据未找到","upstream");
    const root=parseLiteral(text),data=[];function walk(v){for(const [key,detail] of Object.entries(v))if(/^\d+$/.test(key)){data.push([Number(key),typeof detail==="object"?detail.n:detail]);if(detail&&typeof detail==="object"&&(detail.c||detail.t))walk(detail.c||detail.t);}}walk(root);return {state:true,data};
  }
  if(operation==="face"){const r=await ctx.http.request({url:"https://my.115.com/api/face_code.js",credential:false});return losslessJSON(r.body.slice(25,-1));}
  if(operation==="authorize"){
    const r=await ctx.net.request({url:"https://qrcodeapi.115.com/open/authorize?"+wireForm({response_type:"code",...a.payload}),responseType:"text",followRedirects:false});
    if(r.status===302){const url=r.headers.location?.[0]??r.headers.Location?.[0],data={};for(const p of (url.split("?")[1]??"").split("&")){const [k,...v]=p.split("=");data[decodeURIComponent(k)]=decodeURIComponent(v.join("=").replaceAll("+"," "));}return {state:true,url,data,headers:r.headers};}return losslessJSON(r.body);
  }
  if(operation==="logout"){
    const app=a.app??(await extendedLoginDevice(ctx))?.icon;if(!app)throw connectorError("无法确定退出的设备");
    const r=await ctx.http.request({url:"https://qrcodeapi.115.com/app/1.0/"+platform({app},"web",false)+"/1.0/logout/logout",credential:true});if(r.status!==200)throw connectorError("退出登录失败","upstream");return null;
  }
  if(operation==="avatar2"){
    let data=a.base64;if(data===undefined){const b=await ctx.fs.readBytes(a.path,0,196609);if(b.length>196608)throw connectorError("头像超过单次请求限制，请先缩小图片");data=base64(b);}
    return await request(ctx,"https://job.115.com/api/1.0/"+platform(a,"web",false)+"/1.0/upload/avatar",{method:"POST",body:"img="+data,headers:{"Content-Type":"application/x-www-form-urlencoded"}});
  }
  throw connectorError("未知客户端辅助操作");
}
