"""python3.12 generate.py /path/to/pinned/p115client/repository"""

import ast
import csv
import hashlib
import json
import re
import sys
import subprocess
from pathlib import Path
from urllib.parse import urlencode, parse_qsl

from bindings import Binding, Unsupported, js, PLATFORMS

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT.parents[1] / "docs" / "115模块"
PIN = "856e4f8f09ce034534bd458f06d3dee4474a1698"
FILES = {
    "client.py": "0ee3510bdaf63e8c1294a63eecfe7e41cb823e259748e7f04712d5a4d2ed865f",
    "util.py": "e3b2ece46dd190c366378bdb205ce07bd164399711aae84f6c35c4d67a4d1760",
    "const.py": "c347ca13ba2e375abcb3dfeea4383f3e95cd9e7010d635805678e7412789d213",
    "tool/attr.py": "8ea189b712ea1930160dcc5f6184dfd5ed7f9276534f36820b4ae684a4b5db1e",
    "tool/history.py": "f9731cbafa9a24517021bc7269ee9db299ba8535060e5bb4f8e0d632a52d119c",
    "tool/life.py": "b3d2941ae41517e33b13fbf5f90ad16c56a5786aa40f18ddb0c9dc2d4e57c86e",
}
CHECKOUT = Path(sys.argv[1]) / "p115client"
sources = {}
for file, digest in FILES.items():
    data = (CHECKOUT / file).read_bytes()
    if hashlib.sha256(data).hexdigest() != digest:
        raise SystemExit(f"{file} does not match {PIN}")
    sources[file] = ast.parse(data)

# Execute only the hash-pinned, pure upstream URL formatter at build time.
from collections.abc import Container

urlfunc = next(
    n for n in sources["util.py"].body if getattr(n, "name", "") == "complete_url"
)
constants = [
    n
    for n in sources["util.py"].body
    if isinstance(n, ast.AnnAssign) and ast.unparse(n.target) == "URL_PATH_TRANSTAB"
]
ns = dict(Container=Container, urlencode=urlencode, parse_qsl=parse_qsl)
exec(
    compile(
        "from __future__ import annotations\n"
        + "\n".join(ast.unparse(n) for n in constants + [urlfunc]),
        "<pinned-url>",
        "exec",
    ),
    ns,
)
manifest = {
    "sdk": 2,
    "id": "com.tide.cloud115",
    "name": "115 连接器",
    "version": "2.0.2",
    "icon": "icon.png",
    "developer": {"name": "Tide", "repository": "https://github.com/madbrolab/tide"},
    "description": "按账号 UUID 限速，转发 115 协议并返回上游结果。",
    "symbol": "globe",
    "connector": True,
    "storage": "sql",
    "actions": {},
    "credentialKinds": ["cookie", "bearer"],
    "credentialTarget": "com.tide.cloud115",
    "domains": [
        "webapi.115.com",
        "proapi.115.com",
        "uplb.115.com",
        "clouddownload.115.com",
        "avatars.115.com",
        "ictxl.115.com",
        "credentials.115.com",
    ],
    "contentDomains": ["*.115cdn.net", "*.115cdn.com", "*.115.com"],
    "transferDomains": ["fhnfile.oss-cn-shenzhen.aliyuncs.com","ictxl.115.com","credentials.115.com"],
}
ops = {}
src = [(ROOT / "src/business.js").read_text(), (ROOT / "src/protocol.js").read_text()]
qr_devices = [app for group in json.loads((ROOT / "qr-devices.json").read_text()).values() for app in group]
src.append("const qrDevices=" + js(qr_devices) + ";")
rows = list(csv.reader((DOC / "P115C操作映射.tsv").open(), delimiter="\t"))[1:]
by_source = {r[2]: r for r in rows}
coverage = {}
domains = set(manifest["domains"])


def shape(types, desc, **extra):
    return dict(type=types, description=desc, **extra)


def payload_fields(doc):
    fields = {}
    for match in re.finditer(r"^\s*- ([a-zA-Z_][\w\[\].-]*):\s*([^\n]+)", doc, re.M):
        k, descr = match.groups()
        if k in (
            "ct",
            "ac",
            "action",
            "method",
            "callback",
            "constructor",
            "__proto__",
        ):
            continue
        hint = descr.split("💡")[0].split("=")[0].strip()
        ty = []
        if "str" in hint:
            ty.append("string")
        if "int" in hint or re.match(r"^-?\d", hint):
            ty += ["integer", "string"]  # large IDs may be decimal strings
        if "bool" in hint:
            ty.append("boolean")
        fields[k] = shape(
            list(dict.fromkeys(ty)) or ["string", "integer", "boolean"],
            descr.strip()[:200],
        )
    return fields


def add(classname, name):
    prefix = {
        "ClientRequestMixin": "common-",
        "P115Client": "",
        "P115OpenClient": "open-",
    }[classname]
    return prefix + name.replace("_", "-")


methods = {}
names = {}
for cls in sources["client.py"].body:
    if not isinstance(cls, ast.ClassDef):
        continue
    for n in cls.body:
        if (
            not isinstance(n, ast.FunctionDef)
            or n.name.startswith("_")
            or not ast.get_docstring(n)
        ):
            continue
        key = "p115client.client." + cls.name + "." + n.name
        if key not in by_source:
            continue
        try:
            b = Binding(n, ns["complete_url"])
            code = b.compile()
        except (Unsupported, ValueError, TypeError, KeyError, StopIteration) as err:
            coverage[key] = ("", str(err))
            continue
        action = add(cls.name, n.name)
        qr_result = action == "common-login-qrcode-scan-result"
        qr_status = action == "common-login-qrcode-scan-status"
        if not b.platform and isinstance(b.values.get('app'),str) and not qr_result:
            # Some upstream methods normalize app before constructing a URL or
            # pass it to another method. Specialize every declared app instead
            # of silently fixing those methods to their Python default.
            variants={}
            default_app=Binding(n,ns['complete_url']).values['app']
            for app in dict.fromkeys([default_app]+PLATFORMS):
                variant=Binding(n,ns['complete_url']);variant.values['app']=app;variant.platform=False
                try:variant_code=variant.compile()
                except Unsupported as err:
                    if action=='share-download-url-app' and app in ('','chrome'):
                        variant_code='return shareDownloadAppRaw(ctx,args);'
                    else:raise ValueError(f'{action}/{app}: {err}') from err
                variants.setdefault(variant_code,[]).append(app)
                b.locals.update(variant.locals);b.domains.update(variant.domains);b.dependencies.update(variant.dependencies)
            code=''.join('if('+js(apps)+'.includes(args.app??'+js(default_app)+')){'+body+'}' for body,apps in variants.items())+'throw Error("未知客户端 app");'
            b.platform=True;b.values['app']=default_app
        if qr_status:
            code = "if(args.mode===\"snapshot\")return qrSnapshot(ctx,payload);if(args.mode!==undefined&&args.mode!==\"wait\")throw Error(\"未知扫码查询模式\");" + code
        if qr_result:
            b.platform = True
            code = "return qrLoginResult(ctx,args);"
        if not re.fullmatch("[a-z][a-z0-9-]{0,47}", action):
            raise ValueError(action)
        ident = "do_" + action.replace("-", "_")
        methods_allowed = "method" in b.values and b.values["method"] in ("GET", "POST")
        share_link = b.has_payload and "share_url" in b.values
        if methods_allowed:
            alternate = Binding(n, ns["complete_url"])
            alt = "POST" if b.values["method"] == "GET" else "GET"
            alternate.values["method"] = alt
            try:
                other = alternate.compile()
            except (Unsupported, ValueError, TypeError, KeyError, StopIteration):
                methods_allowed = False
            else:
                code = (
                    "if(!['GET','POST'].includes(args.method??"
                    + js(b.values["method"])
                    + "))throw Error('method 无效');if(args.method==="
                    + js(alt)
                    + "){"
                    + other
                    + "}"
                    + code
                )
                b.locals.update(alternate.locals)
        locals_ = sorted(b.locals - {"payload", "query", "body"})
        local = "let " + ",".join(["query=null", "body=null"] + locals_) + ";"
        args = (
            "let payload=protocolArgs(args,"
            + js(
                list(b.params)
                + (["mode"] if qr_status else [])
                + (["method"] if methods_allowed else [])
                + (["shareUrl"] if share_link else [])
                + (["app"] if b.platform else [])
                + (["userId"] if b.account_id else [])
            )
            + ","
            + js(b.has_payload)
            + ");"
            + "".join("item(args," + js(k) + ");" for k in sorted(b.required))
        )
        if share_link:
            args += (
                "if(args.shareUrl)Object.assign(payload,shareFields(args.shareUrl));"
            )
        src.append(
            "function "
            + ident
            + "(ctx,args){"
            + args
            + local
            + code
            + "}\nexport { "
            + ident
            + " as "
            + js(action)
            + " };"
        )
        names[(cls.name, n.name)] = ident
        domains.update(b.domains)
        methods[key] = (action, b, n)
        coverage[key] = (action, "JSON 对象绑定")
        kind = "bearer" if cls.name == "P115OpenClient" else "cookie"
        summary = ast.get_docstring(n).split("\n")[0][:110]
        manifest["actions"][action] = {"label": summary, "external": True}
        input_fields = {}
        if qr_status:
            input_fields["mode"] = shape(["string"],"wait 使用上游长轮询（默认）；snapshot 即时读取 uid 当前状态，返回标准的 data.status",enum=["wait","snapshot"])
        if methods_allowed:
            input_fields["method"] = shape(
                ["string"],
                "此操作可切换协议方法，默认 " + b.values["method"],
                enum=["GET", "POST"],
            )
        if share_link:
            input_fields["shareUrl"] = shape(
                ["string"], "分享链接或 分享码-提取码，覆盖 payload 中的分享信息"
            )
        if b.has_payload:
            input_fields["payload"] = shape(
                ["object"],
                "上游协议字段。大整数 ID 使用十进制字符串。",
                properties=payload_fields(ast.get_docstring(n)),
                additionalProperties=True,
            )
        if b.account_id:
            input_fields["userId"] = shape(
                ["integer", "string"], "自带账号 ID，省略时读取上传账号信息"
            )
        if b.platform:
            input_fields["app"] = shape(
                ["string"],
                "客户端身份，默认 " + b.values["app"],
                enum=qr_devices if qr_result else list(dict.fromkeys([b.values["app"]] + PLATFORMS)),
            )
        for k, v in b.params.items():
            input_fields[k] = shape(
                ["string", "integer", "boolean"] + (["null"] if v is None else []),
                "上游参数 " + k + "，默认 " + js(v),
            )
        if not b.public:
            manifest["actions"][action]["inlineCredential"] = kind
        if b.public:
            kind = "无需账号凭据"
        manifest["actions"][action]["immediateOnly"] = True
        sample = {}
        if b.has_payload:
            # Choose an example from the documented wire fields without assuming an actual account.
            keys = input_fields["payload"]["properties"]
            payload = {
                k: (20 if k == "limit" else 0 if k in ("offset", "cid", "pid") else 1)
                for k in ("cid", "offset", "limit", "page")
                if k in keys
            }
            if action == "login-two-step-trust-device-del":
                payload = {"id": 1}
                input_fields["payload"]["required"] = ["id"]
            sample = {"payload": payload}
        output = shape(
            ["object"],
            "原始 115 JSON 对象。state 为业务状态，其他字段随方法及状态变化，超出安全整数的 ID 返回为字符串。",
            additionalProperties=True,
            properties={
                "state": shape(["boolean", "integer", "string"], "115 业务状态"),
                "errno": shape(["integer", "string"], "上游错误码"),
            },
        )
        if b.binary:
            output = shape(
                ["object"],
                "上游二进制数据",
                properties={"hex": shape(["string"], "原始字节的十六进制表示")},
                required=["hex"],
            )
        for k in sorted(b.required):
            sample[k] = "1"
        if b.account_id:
            sample["userId"] = "123"
        ops[action] = {
            "summary": summary,
            "input": shape(
                ["object"],
                "方法参数",
                properties=input_fields,
                required=sorted(b.required),
            ),
            "output": output,
            "notes": key + " · " + kind + " · " + by_source[key][7],
            "example": {
                "args": sample,
                "result": {"hex": "0102"} if b.binary else {"state": True},
            },
        }

for key, (action, b, node) in methods.items():
    for target in b.dependencies:
        if target.replace("_", "-") not in manifest["actions"]:
            raise ValueError("missing delegate " + target + " for " + action)

for cls in sources["client.py"].body:
    if not isinstance(cls, ast.ClassDef):
        continue
    for n in cls.body:
        if (
            not isinstance(n, ast.Assign)
            or not isinstance(n.value, ast.Name)
            or len(n.targets) != 1
            or not isinstance(n.targets[0], ast.Name)
        ):
            continue
        old = (cls.name, n.value.id)
        new = n.targets[0].id
        key = "p115client.client." + cls.name + "." + new
        if old in names and key in by_source:
            # One security scope and executable action for both upstream spellings.
            coverage[key] = (add(*old), "同一动作的上游别名")

from wire_docs import describe

describe(ops)
from connector_ops import extend

src.extend((ROOT / "src" / name).read_text() for name in ("download.js", "upload.js"))
extend(ops, manifest, src, coverage, rows)
from extended_ops import extend as extend_extra
src.append((ROOT / "src/extended.js").read_text())
extend_extra(ops, manifest, src, coverage, rows)
from library_ops import extend as extend_library
src.extend((ROOT / "src" / name).read_text() for name in ("filesystem.js", "digests.js", "pickcodes.js"))
library = extend_library(ops, manifest, src, coverage, rows, CHECKOUT)
from composition_ops import extend as extend_composition
src.append((ROOT / "src/composition.js").read_text())
extend_composition(library)
from index_ops import extend as extend_index
src.append((ROOT / "src/indexdb.js").read_text())
extend_index(library, ROOT)
from client_ops import extend as extend_client
src.append((ROOT / "src/client-state.js").read_text())
extend_client(library)
from upload_ops import extend as extend_upload
src.append((ROOT / "src/resumable-upload.js").read_text())
extend_upload(library)
from workflow_ops import extend as extend_workflows
src.append((ROOT / "src/library-workflows.js").read_text())
extend_workflows(library)
from support_ops import extend as extend_support
src.append((ROOT / "src/support.js").read_text())
extend_support(library, CHECKOUT, DOC)
migrations_path = ROOT / "migrations.json"
previous = json.loads(migrations_path.read_text()) if migrations_path.exists() else []
if library.migrations[:len(previous)] != previous:
    raise ValueError("published migration prefix changed")
migrations_path.write_text(json.dumps(library.migrations,ensure_ascii=False,indent=2)+"\n")
# Login sessions and bearer identity discovery precede account identification.
for name, action in manifest["actions"].items():
    if name.startswith("common-login-qrcode") or name in ("open-user-info","common-login-authorize-access-token-open","common-login-refresh-token-open"):
        action["bootstrap"] = True
        ops[name]["notes"] += " · 登录发现，无需账号 UUID，使用共享认证限额。"
manifest["domains"] = sorted(domains | set(manifest["domains"]))
from layout import apply_layout
apply_layout(manifest)
(ROOT / "manifest.json").write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
)
(ROOT / "operations.json").write_text(
    "{\n" + ",\n".join("  " + js(k) + ":" + js(v) for k, v in ops.items()) + "\n}\n"
)
program = (
    "// Generated with dev/generate.py from reviewed sources.\n" + "\n".join(src) + "\n"
)
subprocess.run(['node',str(ROOT/'dev/check-calls.mjs'),'--generated'],input=program,text=True,check=True)
program = subprocess.run(
    ["node", str(ROOT / "dev/async-sdk.mjs")], input=program,
    text=True, capture_output=True, check=True,
).stdout
missing = set(re.findall(r"\b(do_\w+)\(", program)) - set(
    re.findall(r"function (do_\w+)\(", program)
)
if missing:
    raise ValueError("unknown protocol dependencies: " + ", ".join(sorted(missing)))
# Use plugin-local development dependencies; the deployed module has no imports.
esbuild = ROOT / "node_modules/.bin/esbuild"
compiled = subprocess.run(
    [
        str(esbuild),
        "--format=esm",
        "--target=es2022",
        "--minify",
        "--tree-shaking=true",
        "--charset=utf8",
        "--legal-comments=none",
        "--minify-whitespace=false",
    ],
    input=program,
    text=True,
    capture_output=True,
    check=True,
).stdout
# This is the build input. SDK 2's official bundler enforces 256 KiB on each
# shipped action group (source AND bytecode), not on the unsharded build input.
if len(compiled.encode()) > 2 * 1024 * 1024:
    raise ValueError("unexpectedly large JS build input")
(ROOT / "main.js").write_text(compiled)
with (DOC / "P115C实现覆盖.tsv").open("w") as f:
    w = csv.writer(f, delimiter="\t", lineterminator="\n")
    w.writerow(["operation", "宿主动作", "适配状态", "上游定义"])
    for r in rows:
        a, why = coverage.get(r[2], ("", "需组合、句柄或独立组件适配"))
        w.writerow([r[1], a, why if a else "未交付 · " + why, r[7]])
print(
    "published",
    len(ops),
    "bound definitions",
    sum(bool(v[0]) for v in coverage.values()),
    "of",
    len(rows),
)
